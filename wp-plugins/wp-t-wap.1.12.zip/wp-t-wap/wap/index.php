<?php
/*
+----------------------------------------------------------------+
|								
|	WP-T-Wap
|	Copyright (c) 2007 TangGaowei
|								
|	File Written By:			
|	- TangGaowei
|	- http://www.tanggaowei.com
|								
|	File Information:			
|	- 手机能浏览的HTML页面
|	- index.php														
|																				
+----------------------------------------------------------------+
*/
require_once('wap-config.php');

_wp('pagename=&category_name=&attachment=&name=&static=&subpost=&post_type=post&page_id=');

// 输出测试信息
$test = $_GET['test'];
if(!empty( $test ) && strcmp ( $test, 'true' ) == 0 )
{
    echo '-------------------------------------<br>';
    echo 'WP 函数值<br>';
    echo '-------------------------------------<br>';
    echo "get_bloginfo('charset') = " . get_bloginfo('charset') . '<br>';
    echo "get_option('home') = " . get_option('home') . '<br>';
    echo "get_option( 'siteurl' ) = " . get_option( 'siteurl' ) . '<br>';
    echo 'WPLANG = ' . WPLANG . '<br>';
    echo "ABSPATH = " . ABSPATH . '<br>';
    echo '_get_wap_home() = ' . _get_wap_home() . '<br>';

    echo '<br>-------------------------------------<br>';
    echo '$wp_query->query_vars<br>';
    echo '-------------------------------------<br>';
    echo '<pre>';
    global $wp_query;
    print_r($wp_query->query_vars);
    echo '</pre>';                  

    echo '-------------------------------------<br>';
    echo '$_SERVER<br>';
    echo '-------------------------------------<br>';
    echo '<pre>';
    print_r($_SERVER);
    echo '</pre>';

    echo '-------------------------------------<br>';
    echo '$_GET<br>';
    echo '-------------------------------------<br>';
    echo '<pre>';
    print_r($_GET);
    echo '</pre>';    

    exit;
}

// 自动定位到 index.php，以配合正确的翻页路径
$url = remove_query_arg( 'paged' );
if( strstr($url,'index.php') == '' || strstr($url,'index.php') == false )
    header("location:index.php");
?>
<?php _wap_header();?>
<?php _single_cat_title('['. __('Category', 'wap') .']'); _single_tag_title('['. __('Tag', 'wap') .']');?>

<?php if(empty($_GET['p'])): ?>

    <?php if(have_posts()): ?>
        <ul>
        <?php while (have_posts()): the_post(); ?>
            <li>
                <span class="stamp"><?php the_time(get_option('date_format').' ('.get_option('time_format').')'); ?></span><br />
                <a href="index.php?p=<?php the_id(); ?>"><?php the_title_rss(); ?></a><?php if ('open' == $post->comment_status): ?><span class="stamp">&nbsp;|&nbsp;<a href="comments.php?p=<?php the_ID(); ?>"><?php comments_number(__('No Comments','wap'), __('1 Comment','wap'), __('% Comments','wap')); ?></a></span><?php else: echo '<span class="stamp">&nbsp;|&nbsp;' . __('Comments Closed','wap') . '</span>'; endif; ?><?php if(function_exists('the_views')) {  echo '&nbsp;<span class="stamp">'; the_views(); echo '</span>';} ?> 
            </li>
        <?php endwhile; ?>
        </ul>
        <br/>
        <?php
        if ( !isset( $_GET['paged'] ) )
        	$_GET['paged'] = 1;
        $page_links = paginate_links( array(
            'base' => add_query_arg( 'paged', '%#%' ),
            'format' => '',
            'total' => $wp_query->max_num_pages,
            'current' => $_GET['paged']
        ));

        if ( $page_links )
            echo "<div class='tablenav-pages'>$page_links</div>";
        ?>
        
        <ul class="catlist">
			<?php _wp_list_categories('show_count=1&title_li=<h2>' . __('Categories', 'wap') . '</h2>'); ?>
		</ul>
        
        <?php if ( get_option("wap_show_last_comments") == 'yes' ): ?>
        <h2><?php _e("Last Comments","wap") ?></h2>
	    <?php
            global $wpdb;

            $sql = "SELECT DISTINCT ID, post_title, post_password, comment_ID,
            comment_post_ID, comment_author, comment_date_gmt, comment_approved,
            comment_type,comment_author_url,
            SUBSTRING(comment_content,1,40) AS com_excerpt
            FROM $wpdb->comments
            LEFT OUTER JOIN $wpdb->posts ON ($wpdb->comments.comment_post_ID =
            $wpdb->posts.ID)
            WHERE comment_approved = '1' AND comment_type = '' AND
            post_password = ''
            ORDER BY comment_date_gmt DESC
            LIMIT 10";
            $comments = $wpdb->get_results($sql);

            $output = $pre_HTML;
            $output .= "\n<ul>";

            foreach ($comments as $comment) 
            {
                $output .= "\n<li><span class=\"stamp\">"
                    .strip_tags($comment->comment_author) ."</span>:" 
                    . "<a href=\"comments.php?p=" 
                    . $comment->comment_post_ID . "#comment-" 
                    . $comment->comment_ID . "\" title=\"on " .
                    $comment->post_title . "\">" . ustrcut($comment->com_excerpt, 36) . "</a></li>";
            }

            $output .= "\n</ul>";
            $output .= $post_HTML;

            echo $output;
        ?>
        <?php endif; ?>

        <?php if( get_option("wap_show_hot_posts") == 'yes' and function_exists('get_most_viewed') ): ?>
        <h2><?php _e('Hot Posts','wap'); ?></h2>
		<ul>
			
			    <?php _get_most_viewed('post', 10, '', true) ?>   
			
		</ul>        
        <?php endif;?>
    <?php else:?>
        <div style="padding:5px; font-size:14px;">
        <?php _e('Not find related posts！<br>（If you have any questions，please email to tanggaowei@gmail.com，and append the site url，thanks！）','wap'); ?>
        </div>
        <!--<?php global $wp_query;
                  print_r($wp_query->query_vars);
        ?>-->
    <?php endif; ?>

<?php else : ?>

	<?php if (have_posts()) : ?>

		<?php while (have_posts()) : the_post(); ?>
			<p><?php _e('Title', 'wap') ?>：<?php the_title_rss(); ?><?php if(function_exists('the_views')) {  echo '&nbsp;<span class="stamp">'; the_views(); echo '</span>';} ?> </p>
			<p class="stamp"><?php _e('Time', 'wap') ?>：<?php the_time(get_option('date_format').' ('.get_option('time_format').')'); ?></p>
			<p class="stamp"><?php _e('Categories','wap') ?>：<?php echo _get_the_category_list(', '); ?></p>
            <p class="stamp"><?php _e('Tags', 'wap') ?>：<?php echo _get_the_tag_list(); ?></p>
			<p class="stamp"><?php _e('Author', 'wap') ?>：<?php the_author(); ?></p>
            <?php if ('open' == $post->comment_status): ?>
			<p class="stamp"><?php _e('Comment(s)', 'wap') ?>：<a href="comments.php?p=<?php the_ID(); ?>"><?php comments_number(__('No Comments','wap'), __('1 Comment','wap'), __('% Comments','wap')); ?></a></p>
            <?php endif; ?>
            <?php
            if ( is_user_logged_in() ){  echo '<p class="stamp">' . __('Operation','wap') . '：<a href="post.php?action=edit&post=' . $id . '">' . __('Edit','wap') . '</a>&nbsp;|&nbsp;<a href="post.php?action=append&post=' . $id . '">' . __('Append','wap') . '</a>&nbsp;|&nbsp;<a href="post.php?post=' . $id . '&deletepost=true">' . __('Delete','wap') . '</a></p>';  }
            ?>
            <p>
            <?php   
                if ( get_option("wap_show_detail") == 'no' ){
                    the_content_rss();
                }else{
                    if ( strlen( $post->post_content ) > 0 ) : 
                        the_content();
                    else :
                        the_excerpt_rss();
                    endif; 
                }
            ?>
            <?php _wap_link_pages(array('before' => '<p>&nbsp;</p><p><strong>' . __('Pages:','wap') . '</strong> ', 'after' => '</p>', 'next_or_number' => 'number')); ?>
            </p>
            <p>
            <div class="navigation">			
            <?php _next_post_link("<span class=\"stamp\">" . __('Previous Post','wap') . "：</span>%link<br/>"); ?>
            <?php _previous_post_link("<span class=\"stamp\">" . __('Next Post','wap') . "：</span>%link"); ?>
		    </div>
            </p>
    
            <?php if( get_option("wap_show_related_posts") == 'yes' and function_exists('wp23_related_posts')): ?>
            <!-- Related Posts -->
            <div class="similiar">
            <?php _wp23_related_posts(); ?>
            </div>

            <?php endif; ?>            
		<?php endwhile; ?>

	<?php else : ?>
		<p><?php _e('No Posts Matched Your Criteria','wap') ?></p>
	<?php endif; ?>


<?php endif; ?>

<?php _wap_footer();?>