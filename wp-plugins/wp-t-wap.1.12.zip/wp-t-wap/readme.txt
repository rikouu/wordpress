=== Plugin Name ===
Contributors: tanggaowei
Donate link: http://www.tanggaowei.com/
Tags: wap,mobile,phone
Requires at least: 2.3
Tested up to: 2.5
Stable tag: 1.12

Browse and manage your WordPress's blog on a mobile phone with web explorer.

== Description ==

<p>Browse and manage your WordPress's blog on a mobile phone with web explorer.</p>

<b>New Features:</b>
append post ( text and picture );
support imax-width plugin;
support Wordpress MU.
<br>

<b>Features:</b>

manage articles;<br>
manage comments;<br>
browse articles and comments;<br>
page article;<br>
adjacent article link;<br>
the latest comments;<br>
popular articles ( Requires WP-PostViews Plugin );<br>
related articles ( Requires WP Related Posts Plugin );<br>
articles list of the category;<br>
articles list of the tag;<br>
custom site title;<br>
binding domain;<br>
bilingual international: en_US, zh_CN;<br>
support Wordpress MU;<br>
support imax-width plugin.<br>

<p>
URL:<a href="http://www.tanggaowei.com/2008/01/04/7.html">http://www.tanggaowei.com/2008/01/04/7.html</a>
</p>

== Installation ==

-- install --

1. Upload all files to the '/wp-content/plugins/wp-t-wap/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Access wap site from the url like 'http://www.mysite.com/wap/'.

( Attention: Must have permission to read and write the 'wap' folder of your WordPress's blog. )

-- update --

update plugin files, than deactivate and activate the plugin.

-- setup --

'settings'->'WP-T-WAP'.

-- binding domain --

binding domain to the 'wap' folder of your WordPress's blog.