-- phpMyAdmin SQL Dump
-- version 3.5.8.1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2013 年 11 月 26 日 15:21
-- 服务器版本: 5.5.32
-- PHP 版本: 5.3.27

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `simple`
--

-- --------------------------------------------------------

--
-- 表的结构 `hbdx_baseinfo`
--

CREATE TABLE IF NOT EXISTS `hbdx_baseinfo` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TAGFIRST` varchar(64) NOT NULL,
  `TAGSECOND` varchar(64) NOT NULL,
  `CODE` varchar(512) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=76 ;

--
-- 转存表中的数据 `hbdx_baseinfo`
--

INSERT INTO `hbdx_baseinfo` (`ID`, `TAGFIRST`, `TAGSECOND`, `CODE`) VALUES
(1, 'SYSTEMINFO', 'FILESHOW', '50'),
(52, 'SYSTEMINFO', 'TITLE', 'Simple Down演示站'),
(59, 'LIST', '1', '电影'),
(54, 'SYSTEMINFO', 'MAXSIZE', '2048'),
(55, 'SYSTEMINFO', 'TYPEEXTS', '*.gif; *.jpg; *.png; *.pdf;'),
(72, 'SYSTEMINFO', 'TONGJI', '站长统计'),
(64, 'SHOW', '操作', 'TRUE'),
(65, 'SHOW', '大小', 'TRUE'),
(66, 'SHOW', '下载量', 'TRUE'),
(67, 'SHOW', '发布者', 'TRUE'),
(68, 'SHOW', '日期', 'TRUE'),
(69, 'SHOW', '标签', 'TRUE'),
(73, 'SYSTEMINFO', 'PINGLUN', '社会化评论插件'),
(74, 'SYSTEMINFO', 'KEYWORDS', ''),
(75, 'SYSTEMINFO', 'DESCRIPTION', '');

-- --------------------------------------------------------

--
-- 表的结构 `hbdx_blue`
--

CREATE TABLE IF NOT EXISTS `hbdx_blue` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FILETITLE` varchar(128) NOT NULL,
  `FILENAME` varchar(255) NOT NULL,
  `FILESIZE` varchar(255) NOT NULL,
  `FILETYPE` varchar(255) NOT NULL,
  `FILEURL` varchar(255) NOT NULL,
  `FILEEXT` varchar(255) NOT NULL,
  `FILENUM` int(10) NOT NULL,
  `LOADDATE` date NOT NULL,
  `FILEUSER` varchar(60) NOT NULL,
  `FILETAG` varchar(16) NOT NULL,
  `FILETEXT` longtext NOT NULL,
  `TOP` int(4) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `hbdx_fav`
--

CREATE TABLE IF NOT EXISTS `hbdx_fav` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `FAV_VIEWID` int(10) NOT NULL,
  `FAV_VIEWTITLE` varchar(60) NOT NULL,
  `FAV_USERNAME` varchar(20) NOT NULL,
  `FAV_DATE` date NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `hbdx_tag`
--

CREATE TABLE IF NOT EXISTS `hbdx_tag` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TAG_NAME` varchar(64) NOT NULL DEFAULT '',
  `TAG_NUM` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=65 ;

--
-- 转存表中的数据 `hbdx_tag`
--

INSERT INTO `hbdx_tag` (`ID`, `TAG_NAME`, `TAG_NUM`) VALUES
(63, '蓝光', 0);

-- --------------------------------------------------------

--
-- 表的结构 `hbdx_users`
--

CREATE TABLE IF NOT EXISTS `hbdx_users` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `USER_NAME` varchar(60) NOT NULL,
  `USER_PASS` varchar(64) NOT NULL,
  `USER_DISPLAYNAME` varchar(250) NOT NULL,
  `USER_QQ` varchar(15) NOT NULL,
  `USER_MAIL` varchar(100) NOT NULL,
  `USER_LOGINNUM` int(10) NOT NULL,
  `REGISTERDATE` datetime NOT NULL,
  `LOGINDATE` datetime NOT NULL,
  `USER_GROUP` varchar(10) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
