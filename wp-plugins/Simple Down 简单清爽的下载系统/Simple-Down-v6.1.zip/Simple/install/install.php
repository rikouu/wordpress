<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="author" content="root@dolphin" />
	<meta name="copyright" content="© http://hbdx.cc" />
	<meta charset="utf-8">
	<title>Simple Down安装向导</title>
<style>
body,h1,h2,h3,h4,h5,h6,hr,p,blockquote,dl,dt,dd,ul,ol,li,pre,form,fieldset,legend,button,input,textarea,th,td {
margin:0;
padding:0;
}

.container {
margin-top:10px;
margin-right:5%;
margin-left:5%;
zoom:1;
}

.hero-unit {
margin-bottom:10px;
font-size:14px;
line-height:30px;
color:inherit;
background-color:#EEE;
-webkit-border-radius:6px;
-moz-border-radius:6px;
border-radius:6px;
padding:40px;
}

body,button,input,select,textarea {
font:12px/1.5 tahoma,arial,\5b8b\4f53,sans-serif;
text-align:justify;
text-justify:inter-ideograph;
word-break:break-all;
word-wrap:break-word;
}

body {
behavior:url(css/hover_htc.htc);
font-family:"Microsoft YaHei",宋体;
color:#333;
}

.login .id input,.login .pw input,.in_id,.in_mo,.reg_input,.reg_input_pic {
background-color:#FFF;
border:1px solid #d5cfc2;
font-size:14px;
font-weight:700;
vertical-align:middle;
}

.reg {
width:800px;
font-size:14px;
line-height:25px;
overflow:hidden;
padding-left:50px;
}

.reg dl {
padding-left:10px;
font-size:14px;
}

.reg dl dd {
padding:3px 0;
}

.reg .title {
width:100px;
display:inline-block;
text-align:right;
padding-right:10px;
}

.id input,.pw input,.in_id,.in_mo,.reg_input,.reg_input_pic {
_behavior:url(js/Round_htc.htc);
-moz-border-radius:4px;
-webkit-border-radius:4px;
border-radius:4px;
height:25px;
}

.onShow,.onFocus,.onError,.onCorrect,.onLoad {
background:url(images/reg_bg.png) no-repeat 3000px 3000px;
padding-left:30px;
font-size:12px;
height:25px;
width:124px;
display:inline-block;
line-height:25px;
vertical-align:middle;
overflow:hidden;
margin-left:6px;
}

.onFocus {
background-position:0 -30px;
color:#333;
}
  /* Buttons */
.menu-toggle,
input[type="submit"],
input[type="button"],
input[type="reset"],
article.post-password-required input[type=submit],
.bypostauthor cite span {
    padding: 6px 10px;
    padding: 0.428571429rem 0.714285714rem;
    font-size: 11px;
    font-size: 0.785714286rem;
    line-height: 1.428571429;
    font-weight: normal;
    color: #7c7c7c;
    background-color: #e6e6e6;
    background-repeat: repeat-x;
    background-image: -moz-linear-gradient(top, #f4f4f4, #e6e6e6);
    background-image: -ms-linear-gradient(top, #f4f4f4, #e6e6e6);
    background-image: -webkit-linear-gradient(top, #f4f4f4, #e6e6e6);
    background-image: -o-linear-gradient(top, #f4f4f4, #e6e6e6);
    background-image: linear-gradient(top, #f4f4f4, #e6e6e6);
    border: 1px solid #d2d2d2;
    border-radius: 3px;
    box-shadow: 0 1px 2px rgba(64, 64, 64, 0.1);
}
.menu-toggle,
button,
input[type="submit"],
input[type="button"],
input[type="reset"] {
    cursor: pointer;
}
button[disabled],
input[disabled] {
    cursor: default;
}
.menu-toggle:hover,
button:hover,
input[type="submit"]:hover,
input[type="button"]:hover,
input[type="reset"]:hover,
article.post-password-required input[type=submit]:hover {
    color: #5e5e5e;
    background-color: #ebebeb;
    background-repeat: repeat-x;
    background-image: -moz-linear-gradient(top, #f9f9f9, #ebebeb);
    background-image: -ms-linear-gradient(top, #f9f9f9, #ebebeb);
    background-image: -webkit-linear-gradient(top, #f9f9f9, #ebebeb);
    background-image: -o-linear-gradient(top, #f9f9f9, #ebebeb);
    background-image: linear-gradient(top, #f9f9f9, #ebebeb);
}
.menu-toggle:active,
.menu-toggle.toggled-on,
button:active,
input[type="submit"]:active,
input[type="button"]:active,
input[type="reset"]:active {
    color: #757575;
    background-color: #e1e1e1;
    background-repeat: repeat-x;
    background-image: -moz-linear-gradient(top, #ebebeb, #e1e1e1);
    background-image: -ms-linear-gradient(top, #ebebeb, #e1e1e1);
    background-image: -webkit-linear-gradient(top, #ebebeb, #e1e1e1);
    background-image: -o-linear-gradient(top, #ebebeb, #e1e1e1);
    background-image: linear-gradient(top, #ebebeb, #e1e1e1);
    box-shadow: inset 0 0 8px 2px #c6c6c6, 0 1px 0 0 #f4f4f4;
    border-color: transparent;
}
#adminmenuwrap {
background-color: #ECECEC;
border-color: #CCC;
position: relative;
float: left;
border-width: 0 1px 0 0;
border-style: solid;
width: 145px;
}
</style>
</head>
<body>
<div class="container">       
	<div class="hero-unit">
        <div class="reg">
<?php
	//生成数据库配置文件
	$str_server = trim($_POST['dbserver']);
	$str_user 	= trim($_POST['dbuser']);
	$str_pass	= trim($_POST['dbpass']);
	$str_db 	= trim($_POST['dbname']);

	if( !empty($str_server) && !empty($str_user) && !empty($str_pass) )
	{
		if( !@mysql_connect( $str_server, $str_user, $str_pass ) ) 
		{
			echo "不能正确连接数据库，请检查数据库信息是否正确。";
			exit;
		}
		else
		{
			$database = addslashes( $str_db );
			if( version_compare( mysql_get_server_info(), '4.1.0', '>=' ) )
			{
				$DATABASESQL="DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci";
			}
			if( !@mysql_select_db( $str_db ) )
			{
   				$create = FALSE;
				mysql_query( "CREATE DATABASE `$database` ".$DATABASESQL );
				@mysql_select_db( $database );
       		}
			mysql_query("set names utf8");

			mysql_query( "CREATE TABLE IF NOT EXISTS `hbdx_baseinfo` (
						  `ID` int(11) NOT NULL AUTO_INCREMENT,
						  `TAGFIRST` varchar(64) NOT NULL,
						  `TAGSECOND` varchar(64) NOT NULL,
						  `CODE` varchar(512) NOT NULL,
						  PRIMARY KEY (`ID`)
						)".$DATABASESQL );

			mysql_query( "CREATE TABLE IF NOT EXISTS `hbdx_blue` (
						  `ID` int(11) NOT NULL AUTO_INCREMENT,
						  `FILETITLE` varchar(128) NOT NULL,
						  `FILENAME` varchar(255) NOT NULL,
						  `FILESIZE` varchar(255) NOT NULL,
						  `FILETYPE` varchar(255) NOT NULL,
						  `FILEURL` varchar(255) NOT NULL,
						  `FILEEXT` varchar(255) NOT NULL,
						  `FILENUM` int(10) NOT NULL,
						  `LOADDATE` date NOT NULL,
						  `FILEUSER` varchar(60) NOT NULL,
						  `FILETAG` varchar(16) NOT NULL,
						  `FILETEXT` longtext NOT NULL,
						  `TOP` int(4) NOT NULL,
						  PRIMARY KEY (`ID`)
						)".$DATABASESQL );

			mysql_query( "CREATE TABLE IF NOT EXISTS `hbdx_fav` (
						  `ID` int(11) NOT NULL AUTO_INCREMENT,
						  `FAV_VIEWID` int(10) NOT NULL,
						  `FAV_VIEWTITLE` varchar(60) NOT NULL,
						  `FAV_USERNAME` varchar(20) NOT NULL,
						  `FAV_DATE` date NOT NULL,
						  PRIMARY KEY (`ID`)
						)".$DATABASESQL );

			mysql_query( "
						CREATE TABLE IF NOT EXISTS `hbdx_tag` (
						  `ID` int(11) NOT NULL AUTO_INCREMENT,
						  `TAG_NAME` varchar(64) NOT NULL DEFAULT '',
						  `TAG_NUM` int(10) NOT NULL DEFAULT '0',
						  PRIMARY KEY (`ID`)
						)".$DATABASESQL );

			mysql_query( "CREATE TABLE IF NOT EXISTS `hbdx_users` (
						  `ID` int(11) NOT NULL AUTO_INCREMENT,
						  `USER_NAME` varchar(60) NOT NULL,
						  `USER_PASS` varchar(64) NOT NULL,
						  `USER_DISPLAYNAME` varchar(250) NOT NULL,
						  `USER_QQ` varchar(15) NOT NULL,
						  `USER_MAIL` varchar(100) NOT NULL,
						  `USER_LOGINNUM` int(10) NOT NULL,
						  `REGISTERDATE` datetime NOT NULL,
						  `LOGINDATE` datetime NOT NULL,
						  `USER_GROUP` varchar(10) NOT NULL,
						  PRIMARY KEY (`ID`)
						)".$DATABASESQL );

			mysql_query( "INSERT INTO `hbdx_tag` (`ID`, `TAG_NAME`, `TAG_NUM`) VALUES (64, '开源', 0),(63, '蓝光', 0)" );

			mysql_query( "INSERT INTO `hbdx_baseinfo` (`ID`, `TAGFIRST`, `TAGSECOND`, `CODE`) VALUES
						(1, 'SYSTEMINFO', 'FILESHOW', '50'),
						(52, 'SYSTEMINFO', 'TITLE', 'Simple Down演示站'),
						(59, 'LIST', '1', '电影'),
						(54, 'SYSTEMINFO', 'MAXSIZE', '2048'),
						(55, 'SYSTEMINFO', 'TYPEEXTS', '*.gif; *.jpg; *.png; *.pdf;'),
						(72, 'SYSTEMINFO', 'TONGJI', '站长统计'),
						(64, 'SHOW', '操作', 'TRUE'),
						(65, 'SHOW', '大小', 'TRUE'),
						(66, 'SHOW', '下载量', 'TRUE'),
						(67, 'SHOW', '发布者', 'TRUE'),
						(68, 'SHOW', '日期', 'TRUE'),
						(69, 'SHOW', '标签', 'TRUE'),
						(73, 'SYSTEMINFO', 'PINGLUN', '社会化评论插件'),
						(74, 'SYSTEMINFO', 'KEYWORDS', ''),
						(75, 'SYSTEMINFO', 'DESCRIPTION', '')" );

			$fp  = fopen('../root/config/database.php', 'w');
			$str = "<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

					\$active_group = 'default';
					\$active_record = TRUE;

					\$db['default']['hostname'] = '".$str_server."';
					\$db['default']['username'] = '".$str_user."';
					\$db['default']['password'] = '".$str_pass."';
					\$db['default']['database'] = '".$str_db."';
					\$db['default']['dbdriver'] = 'mysql';
					\$db['default']['dbprefix'] = '';
					\$db['default']['pconnect'] = TRUE;
					\$db['default']['db_debug'] = TRUE;
					\$db['default']['cache_on'] = FALSE;
					\$db['default']['cachedir'] = '';
					\$db['default']['char_set'] = 'utf8';
					\$db['default']['dbcollat'] = 'utf8_general_ci';
					\$db['default']['swap_pre'] = '';
					\$db['default']['autoinit'] = TRUE;
					\$db['default']['stricton'] = FALSE;";
			fwrite($fp, $str);
			fclose($fp);
?>
        <div class="reg">
        <dl>
            <dt class="f14">数据库安装成功，请继续设置管理员账号。</dt>
            <form action="admin.php" method="post">
            	<dd><span class="title">管理员：</span><input class="reg_input" name="adminname" type="text" value="admin"/><span class="onFocus">管理员账号</span></dd>
         		<dd><span class="title">密码：</span><input class="reg_input" name="adminpass" type="text"/><span class="onFocus">…及其密码</span></dd>
         		<dd><span class="title">邮箱：</span><input class="reg_input" name="adminmail" type="text"/><span class="onFocus">管理员邮箱</span></dd>
         		<input name="dbname" value="<?php echo $str_db ?>" style="display:none;">
         		<input name="dbuser" value="<?php echo $str_user ?>" style="display:none;">
         		<input name="dbpass" value="<?php echo $str_pass ?>" style="display:none;">
         		<input name="dbserver" value="<?php echo $str_server ?>" style="display:none;">
         		<input type="submit" value="保存设置"/>
            </form> 
        </dl>                            
        </div>
<?php
       	}
	}
	else
	{
		echo "请填写完整的数据库信息。";
	}	
?>
        </div>
    </div>
</div>
</body>
</html>