<?php
class Simple_model extends CI_Model
{
  var $limitnum;  //每页显示的最大记录数
	public function __construct()
  {
    $this->load->database();
  }
  //查询数据库获得每页显示的最大记录数
  public function get_shownum()
  {
    $query = $this->db->get_where('hbdx_baseinfo',array('TAGSECOND' => 'FILESHOW'));
    foreach ($query->result_array() as $row)
    {
      $this->limitnum = $row['CODE'];
      return $row['CODE'];
    }
  }
  public function get_title()
  {
    $query = $this->db->get_where('hbdx_baseinfo',array('TAGSECOND' => 'TITLE'));
    foreach ($query->result_array() as $row)
    {
     return $row['CODE'];
    }
  }
  //根据type和page查询记录，type = all时查询所有记录
  public function get_data($type,$page)
  {
    if($type=="all")
    {
      $this->db->order_by("TOP", "asc");
      $this->db->order_by("ID", "desc");  
      $query = $this->db->get('hbdx_blue',$this->limitnum,$this->limitnum*($page-1));
      return $query->result_array();
    }
    $this->db->order_by("TOP", "asc");
    $this->db->order_by("ID", "desc"); 
    $query = $this->db->get_where('hbdx_blue', array('FILETYPE' => $type),$this->limitnum,$this->limitnum*($page-1));
    return $query->result_array();
  }
  //根据type返回查询到的记录数
  public function get_data_num($type)
  {
    if($type=="all")
    {
      $query = $this->db->get('hbdx_blue');
      $data_num = $query->num_rows();
      return ceil($data_num/$this->limitnum);
    }
    $query = $this->db->get_where('hbdx_blue', array('FILETYPE' => $type));
    $data_num = $query->num_rows();
    return ceil($data_num/($this->limitnum));
  }
  //根据记录ID查询一条记录
  public function get_view( $id )
  {
    $query = $this->db->get_where('hbdx_blue',array('ID' => $id));
    return $query->result_array();
  }
  public function bool_view( $id )
  {
    $query = $this->db->get_where('hbdx_blue',array('ID' => $id));
    return $query->num_rows();
  }
  //查询所有分类
  public function get_type()
  {
    $this->db->order_by("TAGSECOND", "asc"); 
    $query = $this->db->get_where('hbdx_baseinfo', array('TAGFIRST' => 'LIST'));
    return $query->result_array();
  }

  public function update_filenum($id)
  {
    $query = $this->db->get_where( 'hbdx_blue',array( 'ID' => $id ) );
    foreach ($query->result_array() as $row)
    {
      $num = $row['FILENUM'];
    }

    $num++;
    $data = array( 'FILENUM' => $num );  
    $this->db->where('ID',$id); 
    $this->db->update('hbdx_blue', $data);  

  }

  public function Search($value)
  {
    $this->db->order_by("TOP", "asc");
    $this->db->order_by("ID", "desc"); 
    $this->db->like('FILETITLE', $value); 
    $query = $this->db->get('hbdx_blue');
    return $query->result_array();
  }

    //查询所有标签
  public function get_tag()
  {
    $this->db->order_by("ID", "asc"); 
    $query = $this->db->get('hbdx_tag');
    return $query->result_array();
  }

  public function tag($value)
  {
    $this->db->order_by("TOP", "asc");
    $this->db->order_by("ID", "desc"); 

    for ($i=0; $i < count($value); $i++) { 
      $this->db->like('FILETAG', $value[$i]);
    }
    $query = $this->db->get('hbdx_blue');
    return $query->result_array();
  }

  public function reg_user()
  {
    $query = $this->db->get_where('hbdx_users',array('USER_NAME' => $this->input->post('t_UserName')));
    if( $query->num_rows() )
    {
      return 0;
    }
    $query = $this->db->get_where('hbdx_users',array('USER_DISPLAYNAME' => $this->input->post('iptNickName')));
    if( $query->num_rows() )
    {
      return 0;
    }
    $query = $this->db->get_where('hbdx_users',array('USER_MAIL' => $this->input->post('t_Email')));
    if( $query->num_rows() )
    {
      return 0;
    }

    $date = date("Y-m-d H:i:s");

    $insert = array(
      'USER_NAME' => $this->input->post('t_UserName'), 
      'USER_DISPLAYNAME' => $this->input->post('iptNickName'),
      'USER_PASS' => md5($this->input->post('t_UserPass')),
      'USER_QQ' => $this->input->post('iptCard'),
      'USER_MAIL' => $this->input->post('t_Email'),
      'USER_GROUP' => "普通会员",
      'REGISTERDATE' => $date
    );

    $sdb = $this->db->insert('hbdx_users',$insert);
    return $sdb;
  }

  function login_user()
  {
    $this->db->where('USER_NAME',$this->input->post('t_UserName'));
    $this->db->where('USER_PASS',md5($this->input->post('t_UserPass')));
    $query = $this->db->get('hbdx_users');

    return $query->num_rows();
  }

  function net_insert()
  {
    $date = date("Y-m-d H:i:s");
    $id = $this->input->post('fileid');

    $query = $this->db->get_where('hbdx_blue',array('ID' => $id));
    if( $query->num_rows())
    {
      $updata = array(
        'FILETITLE' => $this->input->post('title'), 
        'FILENAME' => $this->input->post('filename'),
        'FILESIZE' => $this->input->post('filesize'),
        'FILETYPE' => $this->input->post('filetype'),
        'FILEURL' => $this->input->post('fileurl'),
        'FILETAG' => $this->input->post('tag'),
        'FILETEXT' => $this->input->post('message')
      );

      $this->db->where('ID', $id);
      $sdb = $this->db->update('hbdx_blue', $updata);
      return $sdb;
    }
    else
    {
      $insert = array(
        'FILETITLE' => $this->input->post('title'), 
        'FILENAME' => $this->input->post('filename'),
        'FILESIZE' => $this->input->post('filesize'),
        'FILETYPE' => $this->input->post('filetype'),
        'FILEURL' => $this->input->post('fileurl'),
        'FILEEXT' => $this->input->post('fileext'),
        'FILEUSER' => $this->input->post('diaplayname'),
        'FILETAG' => $this->input->post('tag'),
        'FILETEXT' => $this->input->post('message'),
        'FILENUM' => 0,
        'LOADDATE' => $date,
        'TOP' => 1
      );

      $sdb = $this->db->insert('hbdx_blue',$insert);

      return $sdb;
    }
    
  }

  function upload_insert()
  {
      $date = date("Y-m-d H:i:s");
      $insert = array(
      'FILETITLE' => $this->input->post('title'), 
      'FILENAME' => $this->input->post('filename'),
      'FILESIZE' => $this->input->post('filesize'),
      'FILETYPE' => $this->input->post('filetype'),
      'FILEURL' => $this->input->post('fileurl'),
      'FILEEXT' => $this->input->post('fileext'),
      'FILEUSER' => $this->input->post('diaplayname'),
      'FILETAG' => $this->input->post('tag'),
      'FILETEXT' => $this->input->post('message'),
      'FILENUM' => 0,
      'LOADDATE' => $date,
      'TOP' => 1
    );

    $sdb = $this->db->insert('hbdx_blue',$insert);
    return $sdb;
  }

    //根据UserName查询DisplayName
  public function get_userdisplayname( $name )
  {
    $query = $this->db->get_where('hbdx_users',array('USER_NAME' => $name));
    return $query->result_array();
  }

  public function is_admin( $name )
  {
    $query = $this->db->get_where('hbdx_users',array('USER_NAME' => $name,'USER_GROUP' => "管理员"));
    return $query->num_rows();
  }

  public function this_id_is_admin( $id )
  {
    $query = $this->db->get_where('hbdx_users',array('ID' => $id,'USER_GROUP' => "管理员"));
    return $query->num_rows();
  }

  public function get_user( $name )
  {
    $query = $this->db->get_where('hbdx_users',array('USER_NAME' => $name));
    return $query->result_array();
  }

  public function del_view($id)
  {
    $this->db->where('ID',$id); 
    $query=$this->db->delete('hbdx_blue'); 
    return $query; 
  }

  public function is_myfav( $id,$name )
  {
    $query = $this->db->get_where('hbdx_fav',array('FAV_VIEWID' => $id,'FAV_USERNAME' => $name));
    return $query->num_rows();
  }

  public function fav_view($id,$name)
  {
    $date = date("Y-m-d H:i:s");
    $view = $this->db->get_where('hbdx_blue',array('ID' => $id));
    foreach ($view->result_array() as $row)
    {
      $title = $row['FILETITLE'];
    }
    
    $insert = array(
      'FAV_VIEWID' => $id,
      'FAV_VIEWTITLE' => $title, 
      'FAV_USERNAME' => $name,
      'FAV_DATE' => $date
    );

    $query = $this->db->insert('hbdx_fav',$insert);
    return $query;
  }

  public function unfav_view($id,$name)
  {
    $view = $this->db->get_where('hbdx_fav',array('ID' => $id));
    foreach ($view->result_array() as $row)
    {
      $username = $row['FAV_USERNAME'];
    }

    if($row['FAV_USERNAME'] == $name)
    {
      $this->db->where('ID',$id); 
      $query=$this->db->delete('hbdx_fav'); 
      return $query; 
    }
    else
    {
      return false;
    }


  }

  public function get_fav($name)
  {
    $query = $this->db->get_where('hbdx_fav',array('FAV_USERNAME' => $name));
    return $query->result_array();
  }

  public function is_top($id)
  {
    $query = $this->db->get_where('hbdx_blue',array('ID' => $id));
    foreach ($query->result_array() as $row)
    {
      if( $row['TOP'] == 0 )
      {
        return true;
      }
      else
      {
        return false;
      }
    }
  }

  public function top_view($id)
  {
    $data = array('TOP' => 0);
    $this->db->where('ID', $id);
    $query = $this->db->update('hbdx_blue', $data);
    return $query;
  }

  public function untop_view($id)
  {
    $data = array('TOP' => 1);
    $this->db->where('ID', $id);
    $query = $this->db->update('hbdx_blue', $data);
    return $query;
  }

  public function get_data_name($name)
  {
    $this->db->order_by("TOP", "asc");
    $this->db->order_by("ID", "desc");
    $query = $this->db->get_where('hbdx_blue',array('FILEUSER' => $name));
    return $query->result_array();
  }

  public function get_data_user($id)
  {
    $query = $this->db->get_where('hbdx_blue',array('ID' => $id));
    foreach ($query->result_array() as $row)
    {
      return $row['FILEUSER'];
    }
  }

  public function get_alluser($page)
  {
    $this->db->order_by("USER_GROUP", "desc"); 
    $query = $this->db->get('hbdx_users',30,30*($page-1));
    return $query->result_array();
  }

  public function get_user_num()
  {
    $query = $this->db->get('hbdx_users');
    $data_num = $query->num_rows();
    return ceil($data_num/30);
  }

  public function del_user($id)
  {
    $this->db->where('ID',$id);
    $query=$this->db->delete('hbdx_users'); 
    return $query; 
  }

  public function admin_user($id)
  {
    $data = array('USER_GROUP' => "管理员");
    $this->db->where('ID', $id);
    $query = $this->db->update('hbdx_users', $data);
    return $query;
  }

  public function repassword($id)
  {
     $pass = md5($this->input->post('t_UserPass'));
     $data = array('USER_PASS' => $pass);
     $this->db->where('ID', $id);
     $query = $this->db->update('hbdx_users', $data);
     return $query;
  }

  public function get_system()
  {
    $this->db->order_by("TAGSECOND", "asc"); 
    $query = $this->db->get_where('hbdx_baseinfo', array('TAGFIRST' => 'SYSTEMINFO'));
    return $query->result_array();
  }

  public function get_show()
  {
    $this->db->order_by("TAGSECOND", "desc"); 
    $query = $this->db->get_where('hbdx_baseinfo', array('TAGFIRST' => 'SHOW'));
    return $query->result_array();
  }

  public function set_sys()
  {
    $title = array( 'CODE' => $this->input->post('title') );  
    $this->db->where('TAGSECOND',"TITLE");
    $query = $this->db->update('hbdx_baseinfo', $title); 

    $fileshow = array( 'CODE' => $this->input->post('fileshow') );  
    $this->db->where('TAGSECOND',"FILESHOW");
    $query = $this->db->update('hbdx_baseinfo', $fileshow); 

    $maxsize = array( 'CODE' => $this->input->post('maxsize') );  
    $this->db->where('TAGSECOND',"MAXSIZE");
    $query = $this->db->update('hbdx_baseinfo', $maxsize); 

    $typeexts = array( 'CODE' => $this->input->post('typeexts') );  
    $this->db->where('TAGSECOND',"TYPEEXTS");
    $query = $this->db->update('hbdx_baseinfo', $typeexts); 

    $keywords = array( 'CODE' => $this->input->post('keywords') );  
    $this->db->where('TAGSECOND',"KEYWORDS");
    $query = $this->db->update('hbdx_baseinfo', $keywords); 

    $description = array( 'CODE' => $this->input->post('description') );  
    $this->db->where('TAGSECOND',"DESCRIPTION");
    $query = $this->db->update('hbdx_baseinfo', $description);

    $tongji = array( 'CODE' => $this->input->post('tongji') );
    $this->db->where('TAGSECOND',"TONGJI");
    $query = $this->db->update('hbdx_baseinfo', $tongji);

    $pinglun = array( 'CODE' => $this->input->post('pinglun') );
    $this->db->where('TAGSECOND',"PINGLUN");
    $query = $this->db->update('hbdx_baseinfo', $pinglun);

    return $query;
  }

  public function del_type($id)
  {
    $this->db->where('ID',$id); 
    $query=$this->db->delete('hbdx_baseinfo'); 
    return $query; 
  }

    public function del_tag($id)
  {
    $this->db->where('ID',$id); 
    $query=$this->db->delete('hbdx_tag'); 
    return $query; 
  }

  public function set_type()
  {
    $name = $this->input->post('type_name');
    $id   = $this->input->post('type_id');

    $query = $this->db->get_where('hbdx_baseinfo',array('CODE' => $name));
    if( $query->num_rows() )
    {
      $query = $this->db->get_where('hbdx_baseinfo',array('TAGSECOND' => $id));

      if( $query->num_rows() )
      {
        return false;
      }
      else
      {
        $typename = array( 'TAGSECOND' => $id );  
        $this->db->where('CODE',$name);
        $query = $this->db->update('hbdx_baseinfo', $typename); 

        return $query;
      }
    }

    $query = $this->db->get_where('hbdx_baseinfo',array('TAGSECOND' => $id));
    if( $query->num_rows() )
    {
      $typeid = array( 'CODE' => $name );  
      $this->db->where('TAGSECOND',$id);
      $query = $this->db->update('hbdx_baseinfo', $typeid); 

      return $query;
    }

    $type = array(
      'TAGFIRST' => "LIST",
      'TAGSECOND' => $id, 
      'CODE' => $name
    );

    $query = $this->db->insert('hbdx_baseinfo',$type);
    return $query;
  }

  public function update_show($id)
  {
    $query = $this->db->get_where( 'hbdx_baseinfo',array( 'ID' => $id ) );
    foreach ($query->result_array() as $row)
    {
      if ($row['CODE'] == "TRUE") {
        $show = "FALSE";
      } else {
        $show = "TRUE";
      }
    }

    $showfalg = array( 'CODE' => $show );  
    $this->db->where('ID',$id);
    $query = $this->db->update('hbdx_baseinfo', $showfalg); 

    return $query;
  }

  public function set_tag()
  {
    $name = $this->input->post('tag_name');

    $query = $this->db->get_where('hbdx_tag',array('TAG_NAME' => $name));
    if( $query->num_rows() )
    {
      return false;
    }

    $tag = array('TAG_NAME' => $name);

    $query = $this->db->insert('hbdx_tag',$tag);
    return $query;
  }

  public function get_show_size()
  {
    $query = $this->db->get_where('hbdx_baseinfo',array('TAGSECOND' => '大小'));
    foreach ($query->result_array() as $row)
    {
     return $row['CODE'];
    }
  }

  public function get_show_use()
  {
    $query = $this->db->get_where('hbdx_baseinfo',array('TAGSECOND' => '操作'));
    foreach ($query->result_array() as $row)
    {
     return $row['CODE'];
    }
  }

  public function get_show_number()
  {
    $query = $this->db->get_where('hbdx_baseinfo',array('TAGSECOND' => '下载量'));
    foreach ($query->result_array() as $row)
    {
     return $row['CODE'];
    }
  }

  public function get_show_user()
  {
    $query = $this->db->get_where('hbdx_baseinfo',array('TAGSECOND' => '发布者'));
    foreach ($query->result_array() as $row)
    {
     return $row['CODE'];
    }
  }

  public function get_show_date()
  {
    $query = $this->db->get_where('hbdx_baseinfo',array('TAGSECOND' => '日期'));
    foreach ($query->result_array() as $row)
    {
     return $row['CODE'];
    }
  }

  public function get_show_tag()
  {
    $query = $this->db->get_where('hbdx_baseinfo',array('TAGSECOND' => '标签'));
    foreach ($query->result_array() as $row)
    {
     return $row['CODE'];
    }
  }
  

  public function get_show_typexts()
  {
    $query = $this->db->get_where('hbdx_baseinfo',array('TAGSECOND' => 'TYPEEXTS'));
    foreach ($query->result_array() as $row)
    {
     return $row['CODE'];
    }
  }

  public function get_show_maxsize()
  {
    $query = $this->db->get_where('hbdx_baseinfo',array('TAGSECOND' => 'MAXSIZE'));
    foreach ($query->result_array() as $row)
    {
     return $row['CODE'];
    }
  }

  public function get_show_tongji()
  {
    $query = $this->db->get_where('hbdx_baseinfo',array('TAGSECOND' => 'TONGJI'));
    foreach ($query->result_array() as $row)
    {
     return $row['CODE'];
    }
  }

  public function get_show_pinglun()
  {
    $query = $this->db->get_where('hbdx_baseinfo',array('TAGSECOND' => 'PINGLUN'));
    foreach ($query->result_array() as $row)
    {
     return $row['CODE'];
    }
  }

  public function get_keywords()
  {
    $query = $this->db->get_where('hbdx_baseinfo',array('TAGSECOND' => 'KEYWORDS'));
    foreach ($query->result_array() as $row)
    {
     return $row['CODE'];
    }
  }

  public function get_description()
  {
    $query = $this->db->get_where('hbdx_baseinfo',array('TAGSECOND' => 'DESCRIPTION'));
    foreach ($query->result_array() as $row)
    {
     return $row['CODE'];
    }
  }

  function mupost_insert($insert)
  {
    $sdb = $this->db->insert('hbdx_blue',$insert);
    return $sdb;
  }
}
