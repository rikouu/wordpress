	</div>
</div>
<div class="scf-footer">
	<ul class="scf-link-list">合作网站：
		<li><a href="http://down.admin5.com" target="_blank">A5源码</a></li>
		<li><a href="http://down.chinaz.com/" target="_blank">站长下载</a></li>
		<li><a href="http://www.tudou.com/home/dolphin836" target="_blank">视频教程</a></li>
		<li class="last"><a href="http://blog.hbdx.cc" target="_blank">站长博客</a></li><br />
	</ul><p>Copyright © 2013 <a href="http://d.hbdx.cc" target="_blank">Simple Down v6.1</a>. All Rights Reserved. <a href="http://hbdx.cc" target="_blank">海兵大侠</a> 版权所有
	<?php echo $this->simple_model->get_show_tongji() ?>
</div>
<script type="text/javascript" src="<?php $this->load->helper('url');echo base_url();?>js/arrow89.js"></script>
</body>
</html>