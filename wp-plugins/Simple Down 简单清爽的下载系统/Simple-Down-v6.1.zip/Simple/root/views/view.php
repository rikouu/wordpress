<style>
#common_content_main{background:#fff;position:relative;}
.common_content_main .yanshi_xiazai{margin-top:18px;margin-bottom:8px;}
.common_content_main .yanshi_xiazai a{font-size:16px;padding:10px 20px;margin-right:20px;background:#2DBFBE;color:#fff;}
.common_content_main .yanshi_xiazai a:hover{background:#FF6263;}
</style>

<div class="container">       
	<div class="hero-unit">
<?php foreach ($hbdx_view as $news_item): ?>

<script type='text/javascript'>
	document.title = '<?php echo $news_item['FILETITLE'] ?>';
</script>

<center><b><?php echo $news_item['FILETITLE'] ?></b>
<div class="common_content_main">
	<p class="yanshi_xiazai">
	<?php
		$id = $news_item['ID'];
	?>
		<a href="<?php echo base_url()."view/".($id - 1) ?>">上一页</a>
		<a href="<?php echo base_url()."down/".$news_item['ID'] ?>" target="_blank">下载资源</a>

		<?php if( $this->session->userdata('online') ) { ?>
            <a href="<?php echo base_url(); ?>fav/<?php echo $news_item['ID']; ?>">收藏资源</a>
            <?php 
                $this->load->model('simple_model');
                $username = $this->session->userdata('Username');//从session中读取name
                if($this->simple_model->is_admin($username))  //是否是管理员组用户
                {
            ?>
                    <a href="<?php echo base_url(); ?>del/<?php echo $news_item['ID']; ?>">删除资源</a>
                    <a href="<?php echo base_url(); ?>repost/<?php echo $news_item['ID']; ?>">编辑资源</a>
                    <?php if( $this->simple_model->is_top($news_item['ID']) ) { ?>
                        <a href="<?php echo base_url(); ?>untop/<?php echo $news_item['ID']; ?>">取消置顶</a>                               
                    <?php } else { ?>
                        <a href="<?php echo base_url(); ?>top/<?php echo $news_item['ID']; ?>">设为置顶</a> 
                    <?php } ?>                       
        <?php 
                }
            }
        ?>
		<a href="<?php echo base_url()."view/".($id + 1) ?>">下一页</a>
	</p>
</div>
</center><br />

共被下载：<?php echo $news_item['FILENUM'] ?>&nbsp;次<br />
文件名称：<?php echo $news_item['FILENAME'] ?><br />
资源大小：<?php echo $news_item['FILESIZE'] ?><br />
文件标签：<?php echo $news_item['FILETAG'] ?><br />
发布日期：<?php echo $news_item['LOADDATE'] ?><br />
资源介绍：<br /><?php echo $news_item['FILETEXT'] ?><br />

<?php endforeach ?>
	</div>
</div>

<?php
if( $news_item['FILEEXT'] == "mp3" )
{
	echo '<div id="SimpleMusicPlayer" data-music="'.base_url().$news_item['FILEURL'].'" data-auto="TRUE"></div>';
	echo '<script type="text/javascript" src="http://hbdx.cc/js/audio.js"></script>';
}
?>

<div class="container">       
	<div class="hero-unit">
<!-- Duoshuo Comment BEGIN -->
<?php echo $this->simple_model->get_show_pinglun() ?>
<!-- Duoshuo Comment END -->
	</div>
</div>

