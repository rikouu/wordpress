<script type='text/javascript'>
	document.title = '<?php if( $type != "all" ) echo $this->simple_model->get_title()."-".$type; ?>';
</script>
<?php
if( $type == "all" ) {
	$type = "";
} else {
	$type = "catalogue/".$type."/";
}

if( $counttotal > 0 )
{
	for( $i = 1; $i <= $counttotal; $i++ )
	{
		if( $count - $i > 5 )
		{
			echo "<a href='".base_url().$type.$i."'>".$i."</a>&nbsp;&nbsp;";
			$i = $count - 4;
			echo "...&nbsp;&nbsp;";
		}
		if( $i > $count + 5 )
		{
			if( $i != $counttotal )
			{
				$i = $counttotal;
				echo "...&nbsp;&nbsp;";
			}
		}
		echo "<a href='".base_url().$type.$i."'>".$i."</a>&nbsp;&nbsp;";
	}
	echo "第<b>".$count."</b>页&nbsp;&nbsp;共<b>".$counttotal."</b>页";
}
?>
	</div>
</div>