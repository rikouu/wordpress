=== Plugin Name ===
Contributors: Clionpid
Tags: cloak, cloaking, cloaker, Short URL, Hide Link, affiliate, affiliates, hop, hoplink, mask, masking, redirect,shorten, shortlink, shorturl, short link , shrink, shrinking, shrink link, link shrink, slug, slugs, track, tracking
Requires at least: 3.0
Tested up to: 3.3.1
Stable tag: 1.3.2

Cloaking your affiliate links and tracking the hits and unique visitors of each link. 

== Description ==
Affiliate link cloaking can hide affiliate links from visitors so that you don't worry about visitors remove your affiliate id and visit product website directly. It also can be used as link shrink plugin. It can shrink link and make it to be short url/short link. When visitors click shrinked link, it will redirect to your original link.  

Affiliate link cloaking also tracks the hits and unique visitors of each link. You can find which cloaked links perform well and which need to be modified or removed.

== Plugin's Official Site ==
[Affiliate Link Cloaking](http://clionpid.com) | [Get Help And Suggest Feature](http://clionpid.com/support)
Your suggestions are always appreciated.

== Installation ==

1. Upload `affiliate-link-cloaking` folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress.

You will find 'Link Cloaking' menu in WordPress admin panel.

== Changelog ==

= Version 1.3.2 =

* Fix php warning bug.
* Fix "&" bug in auto replacing feature.
* Fix link status graph overflow bug.

= Version 1.3.1 =

* Fix post/page edit page panel bug.
* Fix incompatible with some theme bugs.

= Version 1.3 =

* Enhance auto replacing affiliate link to short link feature, now it's compatible with other widget.
* Add control panel in each post/page edit panel.  

= Version 1.2 =

* Add auto replacing affiliate link to short link feature
* Add link table sort feature
* Fix diagram bugs.

= Version 1.1 =

* Add link track diagram
* Add sum item of daily/monthly table

= Version 1.0 =

* Initial release

