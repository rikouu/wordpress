<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

class DLM_Constants {

	const OPTION_CURRENT_VERSION = 'dlm_current_version';

}