<?php

function weixin_robot_check_domain(){
    $domain = parse_url(home_url(), PHP_URL_HOST);
    if(get_option('wpjam_net_domain_check_56') == md5($domain.'56')){
        return true;
    }

    $weixin_user = wpjam_topic_get_weixin_user();

    if($weixin_user && $weixin_user['subscribe']){
        return true;
    }

    return false;
}

function weixin_robot_basic_page() {
    if(weixin_robot_check_domain()){
        echo '<div class="wrap">';
        wpjam_option_page('weixin-robot-basic');
        echo '</div>';
    }else{
        global $current_admin_url;
        $current_admin_url = admin_url('admin.php?page=weixin-robot');
        wpjam_topic_setting_page('微信机器人','<p>请使用微信扫描下面的二维码，获取验证码之后提交即可验证通过！</p>');
    }
}
