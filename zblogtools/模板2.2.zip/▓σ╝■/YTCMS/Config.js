﻿var YT={}||YT;
	YT.eval=function(s){
		return eval('('+s+')');	
	};
	YT.escape=function(s){
		return escape(s);
	};
	YT.unescape=function(s){
		return unescape(s);
	};
var YTConfig = {
	Block:'BLOCK.XML',
	Model:'MODEL.XML'
}