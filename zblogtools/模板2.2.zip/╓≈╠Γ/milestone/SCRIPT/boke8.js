// Slideshow
$(function(){
	var index = 0;
	$("#operate span:first").addClass("hov");
	$("#operate span").mouseover(function(){
	  index  =  $("#operate span").index(this);
	  showImg(index);
	});	
	
	$('#slideshow').hover(function(){
			if(MyTime){
			   clearInterval(MyTime);
			}
	},function(){
			MyTime = setInterval(function(){
			  showImg(index)
			  index++;
			  if(index==5){index=0;}
			} , 2000);
	});
	
	var MyTime = setInterval(function(){
	  showImg(index)
	  index++;
	  if(index==5){index=0;}
	} , 2000);
})
function showImg(i){
	$("#showimg img")
	  .eq(i).stop(true,true).fadeIn(800)
	  .parent().siblings().find("img").hide();
	$("#msg li")
	  .eq(i).stop(true,true).fadeIn(800)
	  .siblings().hide();
	$("#operate span")
	  .eq(i).addClass("hov")
	  .siblings().removeClass("hov");
}