<!DOCYTPE HTML>
<HTML>
<head>
  <title></title>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css"  href="admin.css">
</head>
<body>
<div class="left">
<hr>
文章管理
<hr>
<a href=add.php target="showframe">add</a><br>
<a href=edit.php target="showframe">edit</a><br>
<a href=del.php target="showframe">del</a><br>
</div>
<div class="left">
<hr>
分类管理
<hr>
<a href=addsort.php target="showframe">add</a><br>
<a href=editsort.php target="showframe">edit</a><br>
<a href=delsort.php target="showframe">del</a><br>
</div>
<div class="left">
<hr>
帐号管理
<hr>
<a href=login.php target="showframe">add</a><br>
<a href=editlog.php target="showframe">edit</a><br>
<a href=logout.php target="showframe">del</a><br>
</div>
</body>
</HTML>
