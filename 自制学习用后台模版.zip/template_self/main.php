<!DOCYTPE HTML>
<HTML>
<head>
  <title>后台</title>
<meta charset="utf-8">
<link rel="stylesheet" type="text/css"  href="admin.css">
</head>
<frameset rows="120,*" border="0">
     <frame src="header.php" noresize="noresize" scrolling="no">
     <frameset cols="240,*">

      <frame src="left.php" noresize="noresize">
      <frame src="info.php" name="showframe">
     </frameset>
</frameset>
</HTML>
