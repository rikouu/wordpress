<?php
echo "del";

?>