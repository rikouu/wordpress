<?php
/**
 * Plugin Name: 鬼少浮窗播放器（嘟嘟电台版）
 * Version: 1.5
 * Plugin URL: http://tv1314.com/post-228.html
 * Description: 全站悬浮式播放器，整合嘟嘟电台，更新歌曲方便,更多功能正在添加中
 * Author: 鬼少
 * Author Email: 594483473@qq.com
 * Author URL: http://tv1314.com
 */
 
!defined('EMLOG_ROOT') && exit('access deined!');

function GS_mp3_load(){
	echo '<link href="'.BLOG_URL.'content/plugins/GS_mp3/style/style.css" rel="stylesheet" type="text/css" />'."\n";
	echo '<link href="'.BLOG_URL.'content/plugins/GS_mp3/style/player.css" rel="stylesheet/less">'."\n";
	//echo '<link href="'.BLOG_URL.'content/plugins/GS_mp3/style/font-awesome.min.css" rel="stylesheet" type="text/css" />'."\n";
	echo '<link href="http://libs.baidu.com/fontawesome/4.0.3/css/font-awesome.css" rel="stylesheet" type="text/css" />'."\n";//调用百度公共文件加快速度
	echo '<script language="javascript" src="'.BLOG_URL.'content/plugins/GS_mp3/js/less-1.7.0.min.js"></script>'."\n";
}

function GS_mp3_list(){
	require_once 'GS_mp3_config.php';
	?>
<div id="wenkmPlayer">
		<div class="player">
			<div class="infos">
				<div class="songstyle"><i class="fa fa-music"></i> <span class="song"></span></div>
                		<div class="timestyle"><i class="fa fa-clock-o"></i> <span class="time"></span></div>
				<div class="artiststyle"><i class="fa fa-user"></i> <span class="artist"></span><span class="artiststyle1"><i class="fa fa-list"></i> <span class="artist1"></span></span></div>
			</div>
			<div class="control">
				<i class="loop fa fa-retweet current" title="顺序播放"></i>
				<i class="prev fa fa-backward" title="上一首"></i>
				<div class="status">
					<b>
						<i class="play fa fa-play" title="播放"></i>
						<i class="pause fa fa-pause" title="暂停"></i>
					</b>
				</div>
				<i class="next fa fa-forward" title="下一首"></i>
				<i class="random fa fa-random" title="随机播放"></i>
			</div>
			<div class="bottom">
				<div class="volume">
					<i class="mute fa fa-volume-off"></i>
					<i class="volumeup fa fa-volume-up"></i>
					<div class="progress">
						<div class="volume-on ts5">
							<div class="drag" title="音量"></div>
						</div>
					</div>
				</div>
				<div class="switch-playlist">
					<i class="fa fa-bars" title="播放列表"></i>
				</div>
			</div>
			<div class="cover"></div>
		</div>
		<div class="playlist">
			<div class="mkheader"><i class="fa fa-music"></i></div>
			<div class="mklist"></div>
		</div>
		<div class="flat">
			<i class="fa fa-music"></i>
			<i class="fa fa-music"></i>
			<i class="fa fa-music"></i>
			<i class="fa fa-music"></i>
			<i class="fa fa-music"></i>
			<i class="fa fa-music"></i>
		</div>
		<div class="switch-player">
			<i class="fa fa-angle-right"></i>
		</div>
</div>
<div id="wenkmTips"></div>
<div id="wenkmLrc"></div>
<div id="wenkmKsc"></div>
<div class="myhk_pjax_loading_frame"></div>
<div class="myhk_pjax_loading"></div>
<script language="javascript" src="<?php echo BLOG_URL;?>content/plugins/GS_mp3/js/mousewheel.js"></script>
<script language="javascript" src="<?php echo BLOG_URL;?>content/plugins/GS_mp3/js/scrollbar.js"></script>
<script language="javascript" src="<?php echo BLOG_URL;?>content/plugins/GS_mp3/js/player.js"></script>
<script type="text/javascript">
$(function(){
if (!(navigator.userAgent.match(/(iPhone|iPod|Ipad|Android|ios)/i))) {
<?php if($config['type'] == 'list'){ ?>
	get_data("<?php echo $config['list'] ?>");
<?php }else if($config['type'] == 'user_id'){ ?>
	get_user_id("<?php echo $config['user_id'] ?>");
<?php }?>}
})
</script>
<?php
}

function GS_mp3_menu() {
	echo '<div class="sidebarsubmenu" id="GS_mp3"><a href="./plugin.php?plugin=GS_mp3">鬼少浮窗播放器</a></div>';
}
addAction('index_head', 'GS_mp3_load');
addAction('index_bodys', 'GS_mp3_list');
addAction('adm_sidebar_ext', 'GS_mp3_menu');