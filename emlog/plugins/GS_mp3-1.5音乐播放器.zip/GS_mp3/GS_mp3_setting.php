<?php
/**
 * Plugin Name: 鬼少浮窗播放器（嘟嘟电台版）
 * Version: 1.0
 * Plugin URL: http://tv1314.com/post-228.html
 * Description: 全站悬浮式播放器，整合嘟嘟电台，更新歌曲方便,更多功能正在添加中
 * Author: 鬼少
 * Author Email: 594483473@qq.com
 * Author URL: http://tv1314.com
 */

!defined('EMLOG_ROOT') && exit('access deined!');
function plugin_setting_view(){
	require_once 'GS_mp3_config.php';
	?>
	<link href="/content/plugins/GS_mp3/style/style.css" type="text/css" rel="stylesheet" />
	<div class="com-hd">
		<b>鬼少浮窗播放器设置</b>
		<?php
		if(isset($_GET['setting'])){
			echo "<span class='actived'>设置保存成功!</span>";
		}
		?>
	</div>
	<form action="plugin.php?plugin=GS_mp3&action=setting" method="post">
		<table class="tb-set">
			<tr>
				<td align="right" width="25%"><b>调用方式：</b><br />(选择其一,生效选择的一种)</td>
				<td width="75%"><span class="sel"><select name="type"><option value="list" <?php if($config["type"]=="list") echo "selected"; ?>>列表调用</option><option value="user_id" <?php if($config["type"]=="user_id") echo "selected"; ?>>用户ID调用</option></select></span></td>
			</tr>
			<tr>
				<td align="right"><b>用户ID：</b><br />(填写你在嘟嘟电台注册的用户ID,即可调用该ID喜欢歌曲)</td>
				<td><input type="text" class="txt" name="user_id" value="<?php echo $config["user_id"]; ?>" /></td>
			</tr>
			<tr>
				<td align="right"><b>播放列表：</b><br />(填写嘟嘟电台歌曲ID以英文逗号隔开.)</td>
				<td><textarea class="txt txt-lar" name="list"><?php echo $config["list"]; ?></textarea></td>
			</tr>
			<tr>
				<td>&nbsp;</td>
				<td><input type="submit" name="submit" value="保存" /></td>
			</tr>
		</table>
	</form>
<script>
$('#GS_mp3').addClass('sidebarsubmenu1');
</script>
	<?php
}

function plugin_setting(){
	require_once 'GS_mp3_config.php';
	$type = $_POST["type"]==""?"list":$_POST["type"];
	$user_id = $_POST["user_id"]==""?"100000":$_POST["user_id"];
	$list = $_POST["list"]==""?"1187024,468081,479537,9957100,989109,1327728":$_POST["list"];
	$newConfig = '<?php
$config = array(
	"type" => "'.$type.'",
	"user_id" => "'.$user_id.'",
	"list" => "'.str_replace("\r\n", "", $list).'"
);';
	echo $newConfig;
	@file_put_contents(EMLOG_ROOT.'/content/plugins/GS_mp3/GS_mp3_config.php', $newConfig);
}
?>