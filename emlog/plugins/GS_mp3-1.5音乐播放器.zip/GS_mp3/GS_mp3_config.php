<?php
$config = array(
	"type" => "user_id",
	"user_id" => "100000",
	"list" => "185035"
);