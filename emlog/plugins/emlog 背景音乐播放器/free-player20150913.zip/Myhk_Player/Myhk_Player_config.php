<?php
$config = array(
	"jquery" => "close",
	"user_id" => "填写歌单后台显示的绑定域名，例如：limh.me",
	"user_psd" => "填写歌单后台登陆密码，仅后台显示用于备忘",
	"user_key" => "填写歌单后台显示的激活码，例如：abcdefg123456",
	"user_name" => "填写网站名称用于播放器界面显示，例如：明月浩空博客"
);