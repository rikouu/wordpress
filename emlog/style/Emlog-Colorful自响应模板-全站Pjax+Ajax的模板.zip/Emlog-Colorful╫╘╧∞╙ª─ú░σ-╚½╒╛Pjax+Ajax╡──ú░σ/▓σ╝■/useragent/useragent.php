<?php
/*
Plugin Name: useragent
Version: 2.0
Plugin URL: http://xiaosong.org/share/useragent-plugin-update-again
Description: 显示留言用户所用的浏览器和操作系统
ForEmlog:4.1.0 or higher
Author: 小松
Author Email: sahala_2007@126.com
Author URL: http://xiaosong.org/
*/
!defined('EMLOG_ROOT') && exit('access deined!');

include(EMLOG_ROOT.'/content/plugins/useragent/useragent_config.php');
include(EMLOG_ROOT.'/content/plugins/useragent/useragent-detect-device.php');
include(EMLOG_ROOT.'/content/plugins/useragent/useragent-detect-os.php');
include(EMLOG_ROOT.'/content/plugins/useragent/useragent-detect-platform.php');
include(EMLOG_ROOT.'/content/plugins/useragent/useragent-detect-webbrowser.php');
include(EMLOG_ROOT.'/content/plugins/useragent/useragent-detect-webbrowser-version.php');

$url_img = BLOG_URL."content/plugins/useragent/";

function useragent_menu(){
    echo '<div class="sidebarsubmenu" id="useragent"><a href="./plugin.php?plugin=useragent">useragent</a></div>';
}
addAction('adm_sidebar_ext', 'useragent_menu');

function useragent_do($cid){
    $DB = MySql::getInstance();
    $userAgent = addslashes($_SERVER['HTTP_USER_AGENT']);
    $sql = "UPDATE ".DB_PREFIX."comment SET useragent = '$userAgent' WHERE cid = $cid";
    $DB->query($sql);
}
addAction('comment_saved', 'useragent_do');

function useragent_do_reply(){
    $DB = MySql::getInstance();
    $userAgent = addslashes($_SERVER['HTTP_USER_AGENT']);
    $cid = $DB->once_fetch_array("SELECT cid FROM ".DB_PREFIX."comment ORDER BY cid DESC LIMIT 0, 1");
    $cid = $cid['cid'];
    $sql = "UPDATE ".DB_PREFIX."comment SET useragent = '$userAgent' WHERE cid = $cid";
    $DB->query($sql);
}
addAction('comment_reply', 'useragent_do_reply');

function img($code, $type, $title){
    global $url_img,$ua_size;
    if($ua_size != 16 && $ua_size != 24){
        $ua_size = 16;
    }
    $src = $url_img.$ua_size.$type.$code;
    $img = "<img src='$src.png' title='$title' alt='$title' width='$ua_size' height='$ua_size' class='useragent' />";
    return $img;
}
function display_useragent($cid){
    global $useragent;
    $output = '';
    if($cid > 0){
        $DB = MySql::getInstance();
        $sql = "SELECT useragent FROM ".DB_PREFIX."comment where cid = ".$cid."";
        $result = $DB->query($sql);
        $row = $DB->fetch_array($result);
        if(!empty($row['useragent'])){
            $useragent = $row['useragent'];
            $ua = detect_webbrowser().'&nbsp;'.detect_platform();
        }
        $output = $ua;
    }
    echo $output;
}
?>