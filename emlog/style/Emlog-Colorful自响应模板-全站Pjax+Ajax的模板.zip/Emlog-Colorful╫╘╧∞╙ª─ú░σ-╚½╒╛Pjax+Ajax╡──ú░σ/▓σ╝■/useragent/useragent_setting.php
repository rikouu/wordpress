<?php
/*
 * useragent插件
 * design by 小松
 */
!defined('EMLOG_ROOT') && exit('access deined!');
function plugin_setting_view(){
    require_once('useragent_config.php');
}
?>
<script type="text/javascript">
$(function(){
$("#useragent").addClass('sidebarsubmenu1');
})
</script>
<div class="containertitle"><b>useragent设置</b>
<?php if(isset($_GET['setting'])):?><span class="actived">插件设置完成</span><?php endif;?>
</div>
<div class="line"></div>
<form method="post" name="useragent" action="plugin.php?plugin=useragent&action=setting">
<p>图片大小：（仅限16或24，其他数字无效，单位：px）
<input size="3" name="ua_size" type="text" value="<?php echo $ua_size; ?>" /><br />
是否在图标后显示文字信息：
<input type="checkbox" name="ua_show_text" value="1" <?php if($ua_show_text == '1') echo 'checked';?>/>
</p>
<p><input type="submit" value="保存设置" class="button" /></p>
</form>
<?php
function plugin_setting(){
    $ua_size = isset($_POST['ua_size']) ? abs($_POST['ua_size']) : '';
    $ua_show_text = isset($_POST['ua_show_text']) ? abs($_POST['ua_show_text']) : 0;
    $data = "<?php
    \$ua_size = '".$ua_size."';
    \$ua_show_text = '".$ua_show_text."';
?>";
        $file = EMLOG_ROOT.'/content/plugins/useragent/useragent_config.php';
        @ $fp = fopen($file, 'wb') OR emMsg('读取文件失败，如果您使用的是Unix/Linux主机，请修改文件/content/plugins/useragent/useragent_config.php的权限为777。如果您使用的是Windows主机，请联系管理员，将该文件设为everyone可写');
        @ $fw = fwrite($fp,$data) OR emMsg('写入文件失败，如果您使用的是Unix/Linux主机，请修改文件/content/plugins/useragent/useragent_config.php的权限为777。如果您使用的是Windows主机，请联系管理员，将该文件设为everyone可写');
        fclose($fp);
}
?>