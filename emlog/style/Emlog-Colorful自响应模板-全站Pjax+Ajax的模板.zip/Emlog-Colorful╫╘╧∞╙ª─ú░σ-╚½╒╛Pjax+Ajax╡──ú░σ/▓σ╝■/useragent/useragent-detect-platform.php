<?php

// Detect Platform (check for Device, then OS if no device is found, else return null)
function detect_platform()
{
	global $useragent, $ua_show_text, $ua_text_links;

	if(strlen($detected_platform=detect_device()) > 0)
	{
		return $detected_platform;
	}
	elseif(strlen($detected_platform=detect_os()) > 0)
	{
		return $detected_platform;
	}
	else
	{
		$title="Unknown";
		$link="#";
		$code="null";
	}

	// How should we display this?
	if($ua_show_text=="0")
	{
		$detected_os=img($code, "/net/", $title);
	}
	else if($ua_show_text=="1")
	{
		$detected_os=img($code, "/net/", $title)."&nbsp;".$title;
	}

	return $detected_os;
}

?>
