<?php
    $ua_size = '16';
    $ua_show_text = '0';
?>