<?php

/*@support tpl_options*/
!defined('EMLOG_ROOT') && exit('access deined!');
$options = array(
		//主题公告
		'myhk' => array(
		'type' => 'text',
		'name' => '主题公告',
		'default' => 'Colorful-Pjax明月浩空定制模板，有问题请联系QQ6354321[不可修改]',
		),
		'logo' => array(
        'type' => 'image',
        'name' => '导航圆形头像',
        'values' => array(
            TEMPLATE_URL . 'images/icon.png',
        ),
		'description' => '站点左侧头像，建议png格式，大小正方形。不能上传请手动ftp',
	),
	'logo1' => array(
        'type' => 'image',
        'name' => '响应式头像',
        'values' => array(
            TEMPLATE_URL . 'images/logo.png',
        ),
		'description' => '站点响应式顶部头像，建议png格式，大小长方形。不能上传请手动ftp',
	),
	'weixin' => array(
	    'type' => 'image',
        'name' => '微信二维码',
        'values' => array(
            TEMPLATE_URL . 'images/weixin.png',
        ),
		'description' => '站点导航右侧微信二维码图片',
	),
	'weiboid' => array(
	    'type' => 'text',
		'name' => '新浪微博ID',
		'description' => '新浪微博昵称',
		'default' => 'Dev-明月浩空',
	),
    'weibodz' => array(
	    'type' => 'text',
		'name' => '新浪微博地址',
		'description' => '新浪微博访问地址',
		'default' => 'http://weibo.com/u/3496187780',
	),
	'qqhao' => array(
	    'type' => 'text',
		'name' => '站长qq',
		'default' => '6354321',
	),
	'admine' => array(
	    'type' => 'text',
		'name' => '站长Email',
		'default' => 'admin@limh.me',
	),
	'dis_num' => array(
		'type' => 'text',
		'name' => '自动摘要字符数',
		'description' => '请根据需要输入整数以控制首页摘要的字符数量',
		'default' => '180',
	),
);