----------------------------------------------------------------------------
  Release notes for Piano Black
----------------------------------------------------------------------------

  Version:2.2 (2010/06/06)

  Live demo
  http://www.mono-lab.net/demo3/

  Please send your translated files to
  mail@mono-lab.net

  author:mono-lab
  http://www.mono-lab.net/

----------------------------------------------------------------------------
  Change log
----------------------------------------------------------------------------

  ver2.2 Fixed search.php file
  ver2.1 Add new functions
  ver2.0 Major update,add many new function include Custom menu in WordPress3.0
  ver1.6 Add Korien,Czech,Brazilian Portuguese language file, fixed style.css,functions.php,sidebar.php
  ver1.5 Add German,Polish language file
  ver1.4 Add Catalan,Danish,Dutch language files
  ver1.3 Add Spanish language files
  ver1.2 Add French,Hungarian language files
         Add timestamp in comment,correct spelling mistake.(Thank you Garrett!),fixed style.css
  ver1.1 Add Persian,Traditional Chinese,Italian language files
  ver1.0 2009/10/05 Released


----------------------------------------------------------------------------
  Support Languages
----------------------------------------------------------------------------

  English
  Japanese
  Chinese (by Youl.ERIC )
  Persian (Farsi) (by Siavash Keshmiri URL:http://www.tenet.ir/)
  Traditional Chinese (by Morgan Du)
  Italian (by Matteo Galli URL:http://www.edof.it)
  French (by Wolforg http://www.wolforg.eu)
  Hungarian (by MMKaresz)
  Spanish (by Norbe)
  Catalan (by Octavi)
  Dutch (by Glitch)
  Danish (by Jacob)
  German (by Kacetsu)
  Polish (by Berezynski http://www.planb.media.pl)
  Korien (by Jong-In Kim) http://incommunity.codex.kr
  Czech (by Filip Krechan)
  Brazilian Portuguese (by Marcio Bremm) http://vtnc.org/

----------------------------------------------------------------------------
  Lightbox problem
----------------------------------------------------------------------------

  This theme is using jQuery for javascript.
  So to work lightbox correctly plese try this WP-Slimbox plugin.
 
  WP-Slimbox2 (lightbox based on jQuery)
  http://wordpress.org/extend/plugins/wp-slimbox2/


----------------------------------------------------------------------------
  License
----------------------------------------------------------------------------

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 3 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.