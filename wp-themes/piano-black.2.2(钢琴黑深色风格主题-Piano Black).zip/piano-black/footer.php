  <div id="footer">
  </div>
 
 </div><!-- #contents end -->
</div><!-- #wrapper end -->

<?php $options = get_option('pb_options'); if ($options['return_top']) : ?>
<div id="return_top">
 <a href="#wrapper">&nbsp;</a>
</div>
<?php endif; ?>

<?php wp_footer(); ?>
</body>
</html>