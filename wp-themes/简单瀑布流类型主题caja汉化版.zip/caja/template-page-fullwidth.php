<?php
/*
Template name: Fullwidth page
*/
?>

<?php get_header() ?>

	<!-- Content -->		
	<div class="content-fullwidth">
	<?php the_post() ?>
	
		<!-- content -->
		<div class="content">
			<?php $custom = get_post_custom($post->ID); ?>
			
			<!-- Feature image -->
			<?php if ( has_post_thumbnail($post->ID)): ?>
			<div class="feature-holder">
			<?php $large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'large'); ?>
			<a href="<?php echo $large_image_url[0] ?>" class="clip-620x300" rel="prettyPhoto">
				<img src="<?php echo $large_image_url[0] ?>" alt="<?php the_title() ?>" />
			</a>
			</div>
			<?php endif; ?>
			<!-- ENDS Feature image -->
			
			<div class="padding">
				<h3 class="p-title"><?php the_title() ?></h3>
				<?php the_content() ?>
			</div>
		</div>
		<!-- ENDS content -->
		
	</div>
	<!-- ENDS Content -->

<?php get_footer() ?>