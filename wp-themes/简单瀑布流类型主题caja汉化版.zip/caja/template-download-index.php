<?php
/*
Template name: Download tag index
*/
?>
<?php get_header() ?>

	<!-- search -->
	<?php ansimuz_searchform() ?>
					
	
	<!-- The tag index loop -->
	<?php list_tag_index('downloads_tags')?>
		
	<!-- pager -->	
	<?php ansimuz_pagination('',2); ?>
			


<?php get_footer() ?>