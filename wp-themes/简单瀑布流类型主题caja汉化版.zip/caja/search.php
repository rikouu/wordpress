<?php get_header() ?>

	<!-- Categories nav -->
	<h6 class="search_results">Search results</h6>
	
	<!-- search -->
	<?php ansimuz_searchform() ?>
	
	<!-- Posts -->
	<div>
	
		<!-- The loop -->
		<ul class="blocks-thumbs"><?php include_once('lib/loop.php') ?></ul>
			
		<!-- pager -->	
		<?php ansimuz_pagination('',2); ?>
			
	</div>
	<!-- ENDS posts -->


<?php get_footer() ?>