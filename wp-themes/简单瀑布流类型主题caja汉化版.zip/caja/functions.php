<?php

#--------------------------------------------------------------------
#
#	GENERAL SETUP
#
#--------------------------------------------------------------------

// INCLUDES ----------------------------------------------------//

require_once(TEMPLATEPATH . '/lib/widgets.php');
require_once(TEMPLATEPATH . '/lib/shortcodes.php');
require_once(TEMPLATEPATH . '/lib/post-type-work.php');
require_once(TEMPLATEPATH . '/lib/post-type-downloads.php');


// SHORTCUT CONSTANTS ----------------------------------------------------//

define('CSSPATH', get_template_directory_uri() . "/css/");
define('JSPATH', get_template_directory_uri() . "/js/");
define('IMGPATH', get_template_directory_uri() . "/img/");
define('ADMIN_URI', get_stylesheet_directory_uri() . '/admin/');


// theme data
$theme_data = get_theme_data(TEMPLATEPATH.'/style.css');
define('THEME_NAME', $theme_data['Name']);
define('THEME_AUTHOR', $theme_data['Author']);
define('THEME_HOMEPAGE', $theme_data['URI']);
define('THEME_VERSION', trim($theme_data['Version']));


// LOCALIZATION ------------------------------------------------------------//

function init_localization(){
		load_theme_textdomain('caja',TEMPLATEPATH . '/languages');
}
add_action('after_setup_theme', 'init_localization');

// smart quotes remover ----------------------------------------------------//

remove_filter('the_content', 'wptexturize');
remove_filter('the_title', 'wptexturize');
remove_filter('the_excerpt', 'wptexturize');
remove_filter('comment_text', 'wptexturize');


// Removes styles from gallery ----------------------------------------------------//
	
function remove_gallery_style() {
  return "<div class='project-gallery'>";
}
add_filter('gallery_style', 'remove_gallery_style');

// ADD FRONTEND JS SCRIPTS ----------------------------------------------------//

function load_js_scripts() {
    if ( !is_admin() ) {
    	// General JS
    	wp_enqueue_script( 'jquery' );
    	wp_enqueue_script( 'custom', JSPATH . "custom.js" );
    	wp_enqueue_script( 'easing', JSPATH . "easing.js" );
    	wp_enqueue_script( 'scrollTo', JSPATH . "jquery.scrollTo-1.4.2-min.js" );
    	wp_enqueue_script( 'slides', JSPATH . "slides.min.jquery.js" );
    	wp_enqueue_script( 'jquery-cookie', JSPATH . "jquery.cookie.js" );
    	wp_enqueue_script( 'quicksand', JSPATH . "quicksand.js" );
    	// General CSS
    	wp_enqueue_style('general-styles', CSSPATH . 'style.css');
		wp_enqueue_style('social-icons', CSSPATH . 'social-icons.css');
		
		// Skin CSS
		wp_enqueue_style('skin', get_template_directory_uri() .'/skins/'. currentSkin() . '/style.css');

    	// superfish JS
		wp_enqueue_script('hoverIntent', JSPATH . 'superfish-1.4.8/js/hoverIntent.js');
		wp_enqueue_script('superfish', JSPATH . 'superfish-1.4.8/js/superfish.js');
		wp_enqueue_script('supersubs', JSPATH . 'superfish-1.4.8/js/supersubs.js');
		// superfish CSS
		wp_enqueue_style('superfish', CSSPATH . 'superfish.css');
		
		// Poshytip JS
		wp_enqueue_script('poshytip', JSPATH . 'poshytip-1.0/src/jquery.poshytip.min.js');
		// Poshytip CSS
		wp_enqueue_style('poshytip-twitter', JSPATH . 'poshytip-1.0/src/tip-twitter/tip-twitter.css');
		wp_enqueue_style('poshytip-yellow', JSPATH . 'poshytip-1.0/src/tip-yellowsimple/tip-yellowsimple.css');
						
		// Prettyphoto JS
		wp_enqueue_script('prettyPhoto', JSPATH . 'prettyPhoto/js/jquery.prettyPhoto.js');
		// Prettyphoto CSS
		wp_enqueue_style('prettyPhoto', JSPATH . 'prettyPhoto/css/prettyPhoto.css');
		
		// Google fonts
		wp_enqueue_style('googleFonts', 'http://fonts.googleapis.com/css?family=' . ansimuzFontFamily());
		
		// Slides
		wp_enqueue_script('slides', JSPATH . 'slides.min.jquery.js');
		
		// Tabs JS
		wp_enqueue_script('tabs', JSPATH . 'tabs.js');
		// Tabs CSS
		wp_enqueue_style('tabs', CSSPATH . 'tabs.css');
		
    }
}
add_action('init', 'load_js_scripts');

// ADD ADMIN JS SCRIPTS ----------------------------------------------------//

function load_custom_wp_admin_scripts(){
    
    // scripts
	wp_enqueue_script('jquery-ui-encore');
	wp_enqueue_script('jquery-ui-sortable');
	wp_enqueue_script('jquery-appendo', ADMIN_URI . '/js/jquery.appendo.js', false, '1.0', false);
	wp_enqueue_script('slider-manager', ADMIN_URI . '/js/custom-admin.js', false, '1.0', false);
	
	// styles
	wp_enqueue_style('slider-manager', ADMIN_URI . '/css/admin-styles.css', false, '1.0', 'all');
}
add_action('admin_enqueue_scripts', 'load_custom_wp_admin_scripts');


// Enable support for thumbnails -----------------------------//

add_theme_support('post-thumbnails');
if( function_exists('add_theme_support') ){
	add_theme_support('post-thumbnails');
	add_image_size( 'work-thumb', 300, 9999, false );
	add_image_size( 'featured-thumb', 620, 9999, false ); 
}

add_filter('post_thumbnail_html', 'thumbnail_html', 10, 3);
function thumbnail_html($html, $post_id, $post_image_id){
	$link = get_permalink($post_id);
	$title = esc_attr(get_post_field('post_title', $post_id));
	$html = '<a href="'.$link.'" title="'.$title.'">'.$html.'</a>';
	return $html;
}

// Enable Nav Menu -----------------------------//

if ( function_exists( 'add_theme_support' ) )
add_theme_support ('nav-menus');

function register_ansimuz_menu() {
	register_nav_menus  (array(
		'main'   => __('&#x4E3B;&#x5BFC;&#x822A;', 'main' )
	));
}
add_action('init', 'register_ansimuz_menu' );

// adds nav menu if exists if not add regular menu
function ansimuz_menu(){

	// Filter wp_nav_menu() to add additional links and other output
	function new_nav_menu_items($items) {
		$hirelink = '<li id="hire"><a href="#">'.get_option('ansimuz_profile_link_label').'</a></li>';
		$items .= $homelink . $hirelink;
		return $items;
	}
	add_filter( 'wp_list_pages', 'new_nav_menu_items' );
	add_filter( 'wp_nav_menu_items', 'new_nav_menu_items' );

	wp_nav_menu( array(
    			'menu' => 'main_menu',
    			'menu_id' => 'nav',
				'menu_class' => 'sf-menu',
				'theme_location' => 'main',
				'fallback_cb' => 'regular_ansimuz_menu'
	)); 
}

function regular_ansimuz_menu(){
	?>
   	<ul id="nav" class="sf-menu">
		<?php wp_list_pages('title_li=&sort_column=menu_order, post_title&show_home=1'); ?>
	</ul>
	<?php
}

// sidebars ----------------------------------------------------------//

if ( function_exists('register_sidebar') ){
	
	register_sidebar(array(
		'name' => 'Blog sidebar',
		'before_widget' => '<li>',
		'after_widget' => '</li>',
		'before_title' => '<h6 class="side-title"><span>',
		'after_title' => '</span></h6>'
	));
	
	register_sidebar(array(
		'name' => 'Work sidebar',
		'before_widget' => '<li>',
		'after_widget' => '</li>',
		'before_title' => '<h6 class="side-title"><span>',
		'after_title' => '</span></h6>'
	));
	
	register_sidebar(array(
		'name' => 'Downloads sidebar',
		'before_widget' => '<li class="cat-list">',
		'after_widget' => '</li>',
		'before_title' => '<h6 class="side-title"><span>',
		'after_title' => '</span></h6>'
	));
	
	register_sidebar(array(
		'name' => 'Page sidebar',
		'before_widget' => '<li class="cat-list">',
		'after_widget' => '</li>',
		'before_title' => '<h6 class="side-title"><span>',
		'after_title' => '</span></h6>'
	));
}

#--------------------------------------------------------------------
#
#	HACKS
#
#--------------------------------------------------------------------

// Allows to have rss for custom post types --------------------------//

function myfeed_request($qv) {
	if (isset($qv['feed']) && !isset($qv['post_type']))
		$qv['post_type'] = array('downloads');
	return $qv;
}
add_filter('request', 'myfeed_request');

#--------------------------------------------------------------------
#
#	CUSTOM FUNCTIONS
#
#--------------------------------------------------------------------

// Returns current skin ----------------------------------------------------//

function currentSkin(){
	$out = (get_option('ansimuz_skin') == '') ? 'default' : get_option('ansimuz_skin');
	return $out;
}

// Searchform ----------------------------------------------------//

function ansimuz_searchform(){
	// filter visibility
	if( get_option('ansimuz_search_display') == '')
		get_search_form();
}

// Categories list  ------------------------------------------//

function categoriesNav($title, $taxonomy){
?>
	<ul class="tags">
		<li><span><?php echo $title ?> </span> </li>
		<?php 
		$args = array(
		    		'taxonomy' => $taxonomy
		    		);
		$categories = get_categories( $args );
		foreach($categories as $cat){
			$sel = ($cat->slug == getCurrentTaxSlug() ) ? 'class="active"' : '';
			echo '<li '.$sel.' ><a href="'.get_term_link($cat->slug, $taxonomy).'">'.$cat->name.'</a></li>';
		} ?>
	</ul>
	<?php
}

// Categories filter  ------------------------------------------//

function filterNav($title, $taxonomy){
?>
	<ul class="tags" id="portfolio-filter">
		<li><span><?php echo $title ?> </span> </li>
		<li><a href="#" rel="all"><?php _e('All','caja') ?></a></li>
		<?php 
		$args = array(
		    		'taxonomy' => $taxonomy
		    		);
		$categories = get_categories( $args );
		foreach($categories as $cat){
			echo '<li><a href="#" rel="'.$cat->slug.'">'.$cat->name.'</a></li>';
		} ?>
	</ul>
	<?php
}

// get Current taxonomy slug ------------------------------------------//

function getCurrentTaxSlug(){
	global $wp_query;
	$cat_obj = $wp_query->get_queried_object();
	return $cat_obj->slug;
}

// get Current taxonomy name  ------------------------------------------//

function getCurrentTaxName(){
	global $wp_query;
	$cat_obj = $wp_query->get_queried_object();
	return $cat_obj->name;
}

// Social bar display -----------------------------------------------//

function ansimuz_social_bar(){
	if( get_option('ansimuz_social_bar_display') == ''){
	?>
		<ul class="social <?php echo get_option('ansimuz_social_icon_style') ?>">
		<?php
		$social_links = get_option('social_links');
		if($social_links != "" ):
			foreach($social_links as $k => $link):  
					$social_caption = ( $link['caption'] == "") ? "" : "title='".$link['caption']."'";
					$use_poshytip = ($link['caption'] == "") ? "" : " poshytip ";  
				?>
	
				<li><a href="<?php echo $link['link'] ?>" class="<?php echo $link['class'] . $use_poshytip ?>" <?php echo $social_caption ?>></a></li>
				
			<?php endforeach; ?>
		<?php endif; ?>
		</ul>
	<?php
	}
}

// Headline display -----------------------------------------------//

function ansimuz_headline(){
	if( get_option('ansimuz_headline_display') == ''):
	?>
		<div id="headline">
			<div class="slides_container">
				<?php
				$items = get_option('headline');
				if($items != "" ):
					foreach($items as $k => $item): 
						echo '<div>'.$item['caption'].'</div>';
					endforeach; 
				endif; 
				?>
			</div>
		</div>
	<?php
	endif;
}

// Skills table -----------------------------------------------//

function ansimuz_skills(){
	if( get_option('ansimuz_skills_display') == ''):
	?>
		<h6 class="p-title"><?php echo get_option('ansimuz_skills_header') ?></h6>
		<ul class="skills">
		<?php
		$items = get_option('ansimuz_skills');
		if($items != "" ):
			foreach($items as $k => $item): 
				echo '<li class="stars-'.$item['star'].'"><span>'.$item['caption'].'</span></li>';
			endforeach; 
		endif; 
		?>
		</ul>
	<?php
	endif;
}

// Tagged ----------------------------------------------//

function ansimuz_tagged($id, $tax){ 
	$temp_n = get_the_terms($id , $tax); 
	
	if($temp_n > 0 ):
?>
		<span class="tagged">
			<?php _e('Tagged','caja') ?>
			<?php the_terms($id , $tax) ?> 
		</span>
	<?php
	endif;				
}

// Navigation slector ----------------------------------------------//

function ansimuz_nav(){ 
	global $loop_type;
	global $ppp;
	global $cat_type;
	
	// select the type of navigation
	if( (get_option('ansimuz_front_page_filterable') == '') OR (!is_front_page()) ):
		categoriesNav(__('Categories'), $cat_type);
		$loop_type = 'lib/loop.php';
		$ppp = "";
	else:
		filterNav(__('Filter Categories'), $cat_type);
		$loop_type = 'lib/filter-loop.php';
		$nposts = (get_option('ansimuz_front_page_filterable_nposts') == '')?999999:get_option('ansimuz_front_page_filterable_nposts');
		$ppp = "&posts_per_page=".$nposts;
	endif;			
}

// Seo functions -------------------------------------------------//

function ansimuz_seo(){
	// title
	echo '<title>';
	if(get_option('ansimuz_SEO') == '' ):
		 echo wp_title('', false) . ' | ' . get_bloginfo('name');
	else:
		ansimuz_seo_title();
	endif;
	echo '</title>';
	
	// metas
	if(get_option('ansimuz_SEO') != '' ) ansimuz_seo_metas();
}	


function ansimuz_seo_title(){
	$out = '';
	$out = get_option('ansimuz_SEO_page_title');
	
	// replace tags 
	$out = str_replace('%blog_title%', get_bloginfo('name'), $out);
	$out = str_replace('%blog_description%', get_bloginfo('description'), $out);
	$out = str_replace('%page_title%', wp_title('', false), $out);
	
	echo $out;

}

function ansimuz_seo_metas(){

	// only home page flag
	$only_home = (get_option('ansimuz_SEO_only_home') == 'checked' ) ? true : false;

	// If there are keywords...
	if(get_option('ansimuz_SEO_meta_keywords') != '' ):
		// show for all pages
		if(!$only_home):
			?>
			<meta name="keywords" content="<?php echo get_option('ansimuz_SEO_meta_keywords') ?>">
			<?php
		else:
			// show only on home page
			if(is_front_page()):
				?>
				<meta name="keywords" content="<?php echo get_option('ansimuz_SEO_meta_keywords') ?>">
				<?php
			endif;
		endif;
	endif;
	
	// If there are description...
	if(get_option('ansimuz_SEO_meta_description') != '' ):
		 ?>
		<meta name="description" content="<?php echo get_option('ansimuz_SEO_meta_description') ?>"> 
		<?php
	endif;
}

// Pagination ----------------------------------------------//

function ansimuz_pagination($pages = '', $range = 2){  

	global $wp_query;  
  
	$total_pages = $wp_query->max_num_pages;  
	  
	if ($total_pages > 1){  
	  
	  $current_page = max(1, get_query_var('paged'));  
	  
	  echo paginate_links(array(  
			'base' => get_pagenum_link(1) . '%_%',  
			'format' => '/page/%#%',  
			'current' => $current_page,  
			'total' => $total_pages, 
			'type' => 'list',
			'prev_text'    => __('&laquo;'),
			'next_text'    => __('&raquo;')
	    ));  
	}	
	
	echo '<br class="clear"></br>';
}

// Returns an array of dir items ----------------------------------------------------//

function getDirectoriesArray( $path = '.'){
	// Directories to ignore when listing output.
	$ignore = array( '.', '..' );
	
	// Open the directory to the handle $dh
	$dh = @opendir( $path );
	
	// array of dirs
	$out = array();
	
	// Loop through the directory
	while( false !== ( $file = readdir( $dh ) ) ){
		
		// Check that this file is not to be ignored
		if( !in_array( $file, $ignore ) ){
		
			// Show directories only
			if(is_dir( "$path/$file" ) ){
				array_push($out, $file);
			}
		}
	}
	// Close the directory handle
	closedir( $dh );
	
	return $out;
}


// List the folders of the given dir ----------------------------------------------------//

function getDirectory( $path = '.', $level = 0 ){
	// Directories to ignore when listing output.
	$ignore = array( '.', '..' );
	
	// Open the directory to the handle $dh
	$dh = @opendir( $path );
	
	// Loop through the directory
	while( false !== ( $file = readdir( $dh ) ) ){
		
		// Check that this file is not to be ignored
		if( !in_array( $file, $ignore ) ){
		
			// Indent spacing for better view
			$spaces = str_repeat( '&nbsp;', ( $level * 5 ) );
		
			// Show directories only
			if(is_dir( "$path/$file" ) ){
		
				// Re-call this same function but on a new directory.
				// this is what makes function recursive.
				echo "$spaces<a href='$path/$file/index.php'>$file</a><br />";
				getDirectory( "$path/$file", ($level+1) );
			}
		}
	}
	// Close the directory handle
	closedir( $dh );
}

// Print CSS google fonts ----------------------------------------------------//

function ansimuz_set_googleFonts(){
	$font = (get_option('ansimuz_fontfamily') == '') ? 'Yanone+Kaffeesatz:light' : ansimuzFontFamilyName();
?>
	<style type="text/css" >
		h1,h2,h3,h4,h5,h6,
		#header #headline,
		#nav>li>a,
		.content .button-download,
		.content .button-love,
		.blocks-thumbs li .header,
		#footer .title span.big{ 
			font-family: <?php echo $font ?>, arial, serif; 
		}
	</style>
<?php 	
}

// Returns the font family name  -------------------------------------------------//

function ansimuzFontFamily(){
	return (get_option('ansimuz_fontfamily') == '') ? 'Yanone+Kaffeesatz:light' : get_option('ansimuz_fontfamily');
}

// Returns the font family name without the + chars  ------------------------------------------//

function ansimuzFontFamilyName(){
	return str_replace('+', ' ', get_option('ansimuz_fontfamily'));
}

// Custom styles ----------------------------------------------------//

function ansimuz_custom_styles(){
?>
	<style type="text/css" >
		body {
			<?php 
				// set background
				$bg_path = get_option('ansimuz_bg_path');
				$bg_predefined = get_option('ansimuz_bg_predefined');
				$bg_color = get_option('ansimuz_bg_color');
				$bg_repeat = get_option('ansimuz_bg_repeat');
				if( $bg_path != ''){
					echo  "	background-image: url(".$bg_path.");";
					echo "background-position: top left;";
				}
				if( $bg_predefined != ''){
					echo  "	background-image: url(".$bg_predefined.");";
					echo "background-position: top left;";
				}
				if( $bg_color != ''){
					echo  "background-color: #".$bg_color.";";
				}
				if( $bg_repeat != ''){
					echo  "background-repeat: ".$bg_repeat.";";
				}
				if( $font_color != ''){
					echo  "color: #".$font_color.";";
				}
			?>
		}
		
	</style>
<?php
}

// List tag index by taxonomy --------------------------------------//

function list_tag_index($taxonomy){
	// List all the tags ordered by name
	$list = '';
	$tags = get_terms($taxonomy);
	$groups = array();

	if( $tags && is_array( $tags ) ) {
		foreach( $tags as $tag ) {
			$first_letter = strtoupper( $tag->name[0] );
			$groups[ $first_letter ][] = $tag;
		}

		if( !empty( $groups ) ) {
				{
				$index_row .='<ul id="tags-filter" class="tags">';
				$index_row .='<li><span>Index:</span> </li>';
				foreach ($groups as $letter => $tags) {
					$index_row .= '<li><a rel="nofollow" class="to-'.$letter.'" href="#">' . apply_filters( 'the_title', $letter ) . '</a></li>';
				}

				$index_row .='</ul><br class="clear">';
			}
			
			// tag let
			$list .= '<div>';
			foreach( $groups as $letter => $tags ) {
				$list .= '<ul id="letter-'.$letter.'" class="tags listing">';
				$list .= '<li><span>'.$letter.'</span></li>';
				foreach( $tags as $tag ) {
					$url = attribute_escape(get_bloginfo('url') . '/archives/' . $tag->taxonomy . '/' . $tag->slug);
					$name = apply_filters( 'the_title', $tag->name );
					$list .= '<li><a rel="nofollow" title="' . $name . '" href="' . $custom_taxonomy_parent . $url . '">' . $name . ' ('.$tag->count.')</a></li>';
				}
	
				$list .= '<li><a href="#" class="to-list">'.__('Return to list','caja').'</a></li>';
				$list .= '</ul>';
			}

			$list .= '</div>';
		}

	} else $list .= '<p>'.__('Sorry, but no tags were found','caja').'</p>';
	
	echo $index_row;
	echo $list;
}

// Dwonload link button ----------------------------------------------------//

function ansimuz_download_button($download_id){
	if($download_id != ''): 
		echo do_shortcode('[download id="'.$download_id.'" format="2"]');
	endif;
}

#--------------------------------------------------------------------
#
#	OPTIONS PANEL
#
#--------------------------------------------------------------------
	
function themeoptions_admin_menu(){
	// menu
	add_menu_page('Caja', __('Caja Settings','caja'), 'read', 'ansimuz-menu', 'load_edit_page', get_template_directory_uri() .'/admin/img/bag32.png');
	add_submenu_page( 'ansimuz-menu', __('General settings','caja'), __('General settings','caja'), 'read',  'ansimuz-menu', 'load_edit_page');
	add_submenu_page( 'ansimuz-menu', __('Appearance','caja'), __('Appearance','caja'), 'read', 'appearance', 'load_edit_page');
	add_submenu_page( 'ansimuz-menu', __('SEO','caja'), __('SEO','caja'), 'read', 'seo',  'load_edit_page');
	add_submenu_page( 'ansimuz-menu', __('Headline','caja'), __('Headline','caja'), 'read', 'headline', 'load_edit_page');
	add_submenu_page( 'ansimuz-menu', __('Social net','caja'), __('Social net','caja'), 'read', 'social', 'load_edit_page');
	add_submenu_page( 'ansimuz-menu', __('Contact','caja'), __('Contact','caja'), 'read', 'contact',  'load_edit_page');
	add_submenu_page( 'ansimuz-menu', __('Profile','caja'), __('Profile','caja'), 'read', 'profile',  'load_edit_page');
	add_submenu_page( 'ansimuz-menu', __('Skills','caja'), __('Skills','caja'), 'read', 'skills',  'load_edit_page');
}

// Load the corresponding editing page
function load_edit_page(){
	//default page
	if($_GET['page'] == 'ansimuz-menu'){
		include_once('admin/general.php');
	}else{
		include_once('admin/'.$_GET['page'].'.php');
	}
}

// init menu
add_action('admin_menu', 'themeoptions_admin_menu'); 


