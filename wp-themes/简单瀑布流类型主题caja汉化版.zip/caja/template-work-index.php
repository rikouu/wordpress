<?php
/*
Template name: Work tag index
*/
?>
<?php get_header() ?>

	<!-- search -->
	<?php ansimuz_searchform() ?>
					
	
	<!-- The tag index loop -->
	<?php list_tag_index('work_tags')?>
		
	<!-- pager -->	
	<?php ansimuz_pagination('',2); ?>
			


<?php get_footer() ?>