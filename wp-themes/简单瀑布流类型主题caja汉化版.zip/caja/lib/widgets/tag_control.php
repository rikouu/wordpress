<?php

// Update data

if($_POST['update_tag_widget']){
	
	update_option('tag_widget_title', stripslashes($_POST['tag_widget_title']));
	
	update_option('tag_widget_taxonomy', stripslashes($_POST['tag_widget_taxonomy']));
	
}
?>

<!-- Form -->
<input type="hidden" name="update_tag_widget" value="true" />

<p>
<label>Title</label>
<input type="text" name="tag_widget_title" size="27" value="<?php echo get_option('tag_widget_title') ?>" /> 
</p>

<p>
<label>Taxonomy</label>
<select name="tag_widget_taxonomy">
	<option value="post_tag" selected="selected">Post tags</option>
	<option value="category" <?php if(get_option('tag_widget_taxonomy')=='category') echo 'selected="selected"' ?> 
	>Post categories</option>
	
	<option value="work_tags" <?php if(get_option('tag_widget_taxonomy')=='work_tags') echo 'selected="selected"' ?>>Work tags</option>
	<option value="work_category" <?php if(get_option('tag_widget_taxonomy')=='work_category') echo 'selected="selected"' ?>>Work categories</option>
	
	<option value="downloads_tags" <?php if(get_option('tag_widget_taxonomy')=='downloads_tags') echo 'selected="selected"' ?>>Downloads tags</option>
	<option value="downloads_category" <?php if(get_option('tag_widget_taxonomy')=='downloads_category') echo 'selected="selected"' ?>>Downloads categories</option>
	
</select>
</p>

