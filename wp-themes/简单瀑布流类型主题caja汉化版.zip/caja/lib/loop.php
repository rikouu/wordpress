<?php $clear_counter = 0; ?>
<?php if( have_posts() ) : while ( have_posts() ) : the_post(); $clear_counter++; ?>
<li>
	<div class="thumb">
		<div class="clip-300x200-noclip"><?php the_post_thumbnail('work-thumb') ?></div>
	</div>
	
	<div class="excerpt">
		<a href="<?php the_permalink() ?>" class="header"><?php the_title() ?></a>
		<a href="<?php the_permalink() ?>" class="text"><?php the_excerpt() ?></a>
		<div class="meta">
		
			<?php if(function_exists(getILikeThis) and get_post_type( $post ) == "downloads" ) getILikeThis('get'); ?>
			<div class="time"><?php echo human_time_diff(get_the_time('U'), current_time('timestamp')).' &#x524D;.'; ?></div>
			
		</div>
	</div>
</li>
<?php if($clear_counter % 3 == 0) echo '<div class="clear"></div>' ?>


<?php endwhile; else:  ?>	
<h2>Woops...</h2>  
<p>Sorry, no posts we're found.</p> 
<?php endif; ?>