<?php

#--------------------------------------------------------------------
#
#	THEME WIDGETS
#
#--------------------------------------------------------------------

// Work Tag Cloud ----------------------------------------------------------//

function tag_labels_widget($args) {
	$taxonomy = (get_option('tag_widget_taxonomy') == '') ? 'post_tag' : get_option('tag_widget_taxonomy') ;
	$args = array(
			    'smallest'                  => 12, 
			    'largest'                   => 12,
			    'unit'                      => 'px', 
			    'number'                    => 45,  
			    'format'                    => 'list',
			    'separator'                 => '',
			    'link'                      => 'view', 
			    'taxonomy'                  => $taxonomy, 
			    'echo'                      => true ); 
			    
	echo '<h6 class="side-title"><span>'.get_option('tag_widget_title').'</span></h6>';
	wp_tag_cloud( $args ); 
}

function tag_labels_control() {
	include('widgets/tag_control.php');
}

wp_register_sidebar_widget(
    'tag_labels',        // your unique widget id
    'Tags navigation',          // widget name
    'tag_labels_widget',  // callback function
    array(                  // options
        'description' => 'A list of tags or categories for navigation'
    )
);

if(is_admin()){
	wp_register_widget_control(
	    'tag_labels',        // your unique widget id
	    'Tag Labels',          // widget name
	    'tag_labels_control'
	);
}




    
    
    
    
    
    
    
    
    
    
