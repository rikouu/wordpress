<?php

#--------------------------------------------------------------------
#
#	CUSTOM POST TYPE 'WORK'
#
#--------------------------------------------------------------------

add_action('init', 'ansimuz_work_post_type');

function ansimuz_work_post_type(){
	
	register_post_type('work', array(
		'labels' => array(
				'name' => __('&#x5DE5;&#x4F5C;'),
				'singular_name' => __('Project')
			),
		'public' => true,
		'show_ui' => true,
		'supports' => array('title', 'editor', 'thumbnail', 'excerpt', 'comments'),
		'menu_icon' => get_stylesheet_directory_uri() . '/admin/img/folder32.png',
		'rewrite' => array(
			'slug' => 'work',
			'with_front' => false
			),
		'has_archive' => 'work'
	) );
	
}

# TAXONOMIES -----------------------------------------------------------

// categories
add_action('init', 'build_taxonomies', 0);

function build_taxonomies(){
	
	// Categories
	register_taxonomy(
		'work_category',
		'work',
		array(
			'hierarchical' => true,
			'label' => '&#x5DE5;&#x4F5C;&#x7C7B;&#x522B;',
			'query_var' => true,
			'rewrite' => true
		)
	);
	
	// Tags
	register_taxonomy(
		'work_tags',
		'work',
		array(
			'hierarchical' => false,
			'label' => '&#x5DE5;&#x4F5C;&#x6807;&#x7B7E;',
			'query_var' => true,
			'rewrite' => true
		)
	);
}

# OPTIONS -----------------------------------------------------------

add_action("admin_init", "admin_simple_init");
add_action('save_post', 'ansimuz_work_save_data');

function admin_simple_init(){
	add_meta_box("work-meta", __("Work info"), "ansimuz_meta_work_options", "work", "normal", "low");
}

// options panel
function ansimuz_meta_work_options(){
	global $post;
	$custom = get_post_custom($post->ID);

	$client = $custom["client"][0];
	$date = $custom["date"][0];
	$skills = $custom["skills"][0];
	$link = $custom["link"][0];
	$project_gallery = $custom["project_gallery"][0];
	
?>
	<p>
		<label><strong><?php _e('Client name','caja') ?></strong></label><br/>
		<input name="client" value="<?php echo $client; ?>" size="73"/><br/>
		<span class="description"><?php _e('The name of the project client','caja') ?></span>
	</p>
	<p>
		<label><strong><?php _e('Project date','caja') ?></strong></label><br/>
		<input name="date" value="<?php echo $date; ?>" size="73" /><br/>
		<span class="description"><?php _e('The date of the completion of the project','caja') ?></span>
	</p>
	<p>
		<label><strong><?php _e('Project Link','caja') ?></strong></label><br/>
		<input name="link" value="<?php echo $link; ?>" size="73" /><br/>
		<span class="description"><?php _e('The url of the project. Include the http://','caja') ?></span>
	</p>
	<p>
		<label><strong><?php _e('Skills used','caja') ?></strong></label><br/>
		<input name="skills" value="<?php echo $skills; ?>" size="73" /><br/>
		<span class="description"><?php _e('Enter multiple skills separated by commas','caja') ?></span>
	</p>
	
	<p>
		<br/>
		<label class="selectit"><input type="checkbox" <?php echo $project_gallery ?> value="checked" id="project_gallery" name="project_gallery"> <?php _e('Show project gallery.','caja') ?> </label>
	</p>
	
	
	
	<input type="hidden" name="update_work" id="update_work" value="true" />
<?php
}

// dave data
function ansimuz_work_save_data(){
	global $post;
	if($_POST['update_work']){
		update_post_meta($post->ID, "client", $_POST['client']);
		update_post_meta($post->ID, "date", $_POST['date']);
		update_post_meta($post->ID, "link", $_POST['link']);
		update_post_meta($post->ID, "skills", $_POST['skills']);
		update_post_meta($post->ID, "project_gallery", $_POST['project_gallery']);
	}
}

# LISTING COLUMNS ------------------------------------------------


add_filter("manage_edit-work_columns", "work_edit_columns");
add_action("manage_posts_custom_column",  "work_custom_columns");

function work_edit_columns($columns){
	$columns = array(
		"cb" => "<input type='checkbox' />",
		"title" => "Title",
		"client" => "Client",
		"work_category" => "Category",
		"work_tags" => "Tags",
		"date" => "Date",
	);
	return $columns;
}

function work_custom_columns($column){
	global $post;
	switch ($column){
		case "client":
			$custom = get_post_custom();
			echo $custom["client"][0];
		break;
		case "work_category":
			echo get_the_term_list($post->ID, 'work_category', '', ', ','');
		break;
		case "work_tags":
			echo get_the_term_list($post->ID, 'work_tags', '', ', ','');
		break;
	}
}




