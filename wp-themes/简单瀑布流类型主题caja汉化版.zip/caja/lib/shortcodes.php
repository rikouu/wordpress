<?php

#--------------------------------------------------------------------
#
#	SHORTCODES
#
/*

PRE

	[pre]content[/pre]
				
LINK BUTTONS
	
	[link_button href="link" target="_self|_blank"]text[/link_button]
	
TABS
	[tabs]
	  [tab title="your title"]...[/tab]
	  [tab title="your title"]...[/tab]
	  ...
   [/tabs]

TWO COLUMNS
	
	[one_half]...[/one_half] [one_half_last]...[/one_half_last] 
	
THREE COLUMNS

	[one_third]...[/one_third] [one_third_last]...[/one_third_last]
	
FOUR COLUMNS

	[one_fourth]...[/one_fourth] [one_fourth_last]...[/one_fourth_last]


HEADERS

	[h1]...[/h1]...[h6]...[/h6]

PULLQUOTES

	[pullquote_left]...[/pullquote_left]
	
	[pullquote_right]...[/pullquote_right]
	
	
YOUTUBE

	 [youtube id="youtube_video_id" width="width" height="height" /]
	 
VIMEO

	 [vimeo id="vimeo_video_id" width="width" height="height" /]
	 
LINE DIVIDER
	
	[hr/]
	 
	 
#---------------------------------------------------------------------*/



// Clears <p> and <br> tags for the outputs ---------------------------*/

function uds_clear_autop($content){

    $content = str_ireplace('<p>', '', $content);
    $content = str_ireplace('</p>', '', $content);
    $content = str_ireplace('<br />', '', $content);
    return $content;
}
add_filter('uds_shortcode_out_filter', 'uds_clear_autop');

// PRE ---------------------------------------------------------------------*/

function pre($atts, $content=null){
	return '<pre>'.do_shortcode($content).'</pre>';
}
add_shortcode('pre', 'pre');


// LINK BUTTONS ---------------------------------------------------------------------*/

function link_button($atts, $content=null){
	extract(shortcode_atts( array( 
							'href' => 'HREF',
							'target' => 'TARGET' 
							), $atts ));
							
	if($target == 'TARGET'){ $target = '_self'; }
	return '<a href="'.$href.'" target="'.$target.'" class="link-button">'.do_shortcode($content).'</a><div class="clear"></div>';
}
add_shortcode('link_button', 'link_button');

// TABS ---------------------------------------------------------------------*/

function tabs($atts, $content=null){
	global $anzimus_tabs;
	$anzimus_tabs = array();
	do_shortcode($content);
	$out = '<ul class="tabs">';
	// titles
	foreach( $anzimus_tabs as $tab ) {
		$out .= '<li><a href="#'.$tab['id'].'"><span>' . $tab['title'] . '</span></a></li>';
	}
	$out .= '</ul><div class="panes">';
	// content
	foreach( $anzimus_tabs as $tab ) {
		$out .= '<div>' . $tab['content'] . '</div>';
	}
	$out .= '</div>';
	
	$anzimus_tabs = array();
	
	return $out;
}
//
function tab($atts, $content=null){
	global $anzimus_tabs;
	extract(shortcode_atts(array('title' => ''),$atts));
	
	// create random id between 0 and 10000
	$id = rand(0,10000);
	
	$anzimus_tabs[] = array('id'=>$id,
							'title'=>$title,
							'content'=>do_shortcode($content));
}
add_shortcode('tabs', 'tabs');
add_shortcode('tab', 'tab');

// TWO COLUMNS ---------------------------------------------------------------------*/

function one_half($atts, $content=null){
	return '<div class="one-half">'.do_shortcode($content).'</div>';
}
function one_half_last($atts, $content=null){
	return '<div class="one-half last" >'.do_shortcode($content).'</div><br class="clear" />';
}
add_shortcode('one_half', 'one_half');
add_shortcode('one_half_last', 'one_half_last');

// THREE COLUMNS ---------------------------------------------------------------------*/

function one_third($atts, $content=null){
	return '<div class="one-third">' .do_shortcode($content). '</div>';
}
function one_third_last($atts, $content=null){
	return '<div class="one-third last" >'.do_shortcode($content).'</div><br class="clear" />';
}
add_shortcode('one_third', 'one_third');
add_shortcode('one_third_last', 'one_third_last');

// FOUR COLUMNS ---------------------------------------------------------------------*/

function one_fourth($atts, $content=null){
	return '<div class="one-fourth">' .do_shortcode($content). '</div>';
}
function one_fourth_last($atts, $content=null){
	return '<div class="one-fourth last" >'.do_shortcode($content).'</div><br class="clear" />';
}
add_shortcode('one_fourth', 'one_fourth');
add_shortcode('one_fourth_last', 'one_fourth_last');


// HEADERS ---------------------------------------------------------------------*/

function h1($atts, $content=null){
	return '<h1 class="custom">'.do_shortcode($content).'</h1>';
}
function h2($atts, $content=null){
	return '<h2 class="custom">'.do_shortcode($content).'</h2>';
}
function h3($atts, $content=null){
	return '<h3 class="custom">'.do_shortcode($content).'</h3>';
}
function h4($atts, $content=null){
	return '<h4 class="custom">'.do_shortcode($content).'</h4>';
}
function h5($atts, $content=null){
	return '<h5 class="custom">'.do_shortcode($content).'</h5>';
}
function h6($atts, $content=null){
	return '<h6 class="custom">'.do_shortcode($content).'</h6>';
}
add_shortcode('h1', 'h1');
add_shortcode('h2', 'h2');
add_shortcode('h3', 'h3');
add_shortcode('h4', 'h4');
add_shortcode('h5', 'h5');
add_shortcode('h6', 'h6');

// PULLQUOTES ---------------------------------------------------------------------*/

function pullquote_left($atts, $content=null){
	return '<span class="pullquote-left">'.do_shortcode($content).'</span>';
}
add_shortcode('pullquote_left', 'pullquote_left');

function pullquote_right($atts, $content=null){
	return '<span class="pullquote-right">'.do_shortcode($content).'</span>';
}
add_shortcode('pullquote_right', 'pullquote_right');


// YOUTUBE ---------------------------------------------------------------------*/

function youtube( $atts, $content = null ) {
	
	extract(shortcode_atts(array('id' => '2Qd_IsxgAf8',
								 'width' => '489',
								 'height'  => '390'),$atts));
	
	return '<iframe title="YouTube video player" width="'.$width.'" height="'.$height.'" src="http://www.youtube.com/embed/'.$id.'" frameborder="0" allowfullscreen></iframe>';
	
}
add_shortcode('youtube', 'youtube');

// VIMEO ---------------------------------------------------------------------*/

function vimeo( $atts, $content = null ) {
	
	extract(shortcode_atts(array('id' => '14361690',
								 'width' => '400',
								 'height'  => '168'),$atts));
	
	return '<iframe src="http://player.vimeo.com/video/'.$id.'" width="'.$width.'" height="'.$height.'" frameborder="0"></iframe>';
	
}
add_shortcode('vimeo', 'vimeo');

// Line divider ---------------------------------------------------------------------*/

function hr( $atts, $content = null ) {
	return '<div class="line-divider" ></div>';	
}
add_shortcode('hr', 'hr');


