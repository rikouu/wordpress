<?php

#--------------------------------------------------------------------
#
#	CUSTOM POST TYPE 'DOWNLOADS'
#
#--------------------------------------------------------------------

add_action('init', 'ansimuz_downloads_post_type');

function ansimuz_downloads_post_type(){
	
	register_post_type('downloads', array(
		'labels' => array(
				'name' => __('&#x4E0B;&#x8F7D;'),
				'singular_name' => __('Download file')
			),
		'public' => true,
		'show_ui' => true,
		'supports' => array('title', 'editor', 'thumbnail', 'excerpt', 'comments'),
		'menu_icon' => get_stylesheet_directory_uri() . '/admin/img/boxdownload32.png',
		'rewrite' => array(
			'slug' => 'downloads',
			'with_front' => false
			),
		'has_archive' => 'downloads'
	) );
	
}

# TAXONOMIES -----------------------------------------------------------

// categories
add_action('init', 'build_taxonomies_downloads', 0);

function build_taxonomies_downloads(){
	
	// Categories
	register_taxonomy(
		'downloads_category',
		'downloads',
		array(
			'hierarchical' => true,
			'label' => '&#x4E0B;&#x8F7D;&#x7C7B;&#x522B;',
			'query_var' => true,
			'rewrite' => true
		)
	);
	
	// Tags
	register_taxonomy(
		'downloads_tags',
		'downloads',
		array(
			'hierarchical' => false,
			'label' => '&#x4E0B;&#x8F7D;&#x6807;&#x7B7E;',
			'query_var' => true,
			'rewrite' => true
		)
	);
}

# OPTIONS -----------------------------------------------------------

add_action("admin_init", "admin_downloads_init");
add_action('save_post', 'ansimuz_downloads_save_data');

function admin_downloads_init(){
	add_meta_box("donwloads-meta", __("Download data"), "ansimuz_meta_downloads_options", "downloads", "normal", "low");
}

// options panel
function ansimuz_meta_downloads_options(){
	global $post;
	$custom = get_post_custom($post->ID);

	$download_id = $custom["download_id"][0];
	$project_gallery = $custom["project_gallery"][0];
		
	// Download monitor activated plug in alert
	if(!is_plugin_active('download-monitor/wp-download_monitor.php')) {
		echo "<div id='setting-error-settings_updated' class='updated settings-error'> 
<p><strong>You dont have your Download Monitor Plug in activated. <a href='http://wordpress.org/extend/plugins/download-monitor/'>Visit Plugin Page</a></strong></p></div> ";
	}
	?>
		
		
	<p>
		<label><strong><?php _e('ID for this download','caja') ?></strong></label><br/>
		<input name="download_id" value="<?php echo $download_id; ?>" size="5"/><br/>
		<span class="description">Set the "ID" from the download file once you have set it up at the <a href="<?php echo home_url() ?>/wp-admin/admin.php?page=download-monitor/wp-download_monitor.php">Download Monitor</a>. If you don't enter a ID it wont display the "Download Button"<br/>Please paste the following format at the <a href="<?php echo home_url() ?>/wp-admin/admin.php?page=dlm_config&action=formats">Download Monitor Output formats</a></span>
	</p>
	
	<p>
		<br/>
		<label class="selectit"><input type="checkbox" <?php echo $project_gallery ?> value="checked" id="project_gallery" name="project_gallery"> <?php _e('Show project gallery.','caja') ?> </label>
	</p>
	
	
	<input type="hidden" name="update_download"  value="true" />
<?php
}

// dave data
function ansimuz_downloads_save_data(){
	global $post;
	if($_POST['update_download']){
		update_post_meta($post->ID, "download_id", $_POST['download_id']);
		update_post_meta($post->ID, "project_gallery", $_POST['project_gallery']);
	}
}


# LISTING COLUMNS ------------------------------------------------


add_filter("manage_edit-downloads_columns", "downloads_edit_columns");
add_action("manage_posts_custom_column",  "downloads_custom_columns");

function downloads_edit_columns($columns){
	$columns = array(
		"cb" => "<input type='checkbox' />",
		"title" => "Title",
		"client" => "Client",
		"downloads_category" => "Category",
		"downloads_tags" => "Tags",
		"date" => "Date",
	);
	return $columns;
}

function downloads_custom_columns($column){
	global $post;
	switch ($column){
		case "client":
			$custom = get_post_custom();
			echo $custom["client"][0];
		break;
		case "downloads_category":
			echo get_the_term_list($post->ID, 'downloads_category', '', ', ','');
		break;
		case "downloads_tags":
			echo get_the_term_list($post->ID, 'downloads_tags', '', ', ','');
		break;
	}
}


