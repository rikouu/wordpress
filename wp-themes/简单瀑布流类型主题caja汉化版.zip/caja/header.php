<!DOCTYPE html>
<html <?php language_attributes(); ?>>
	<head>
		
		<?php /* Always have wp_head() just before the closing </head> */ wp_head() ?>
		
		<!-- Allows replies in the comment list -->
		<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' );?>
		
		<meta http-equiv="Content-Type" content="<?php bloginfo('html_type') ?>; charset=<?php bloginfo('charset') ?>" />
		
		<?php ansimuz_seo() ?>
		
		<!-- JS -->
		<!--[if IE]>
			<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<![endif]-->
		<!-- ENDS JS -->
				
		<!-- CSS -->
		<!--[if IE 8]>
			<link rel="stylesheet" type="text/css" media="screen" href="css/ie8-hacks.css" />
		<![endif]-->
		<!-- ENDS CSS -->	
				
		<!-- CSS -->
		<!--[if IE 6]>
			<script type="text/javascript" src="<?php echo JSPATH ?>DD_belatedPNG.js"></script>
			<script>
	      		/* EXAMPLE */
	      		//DD_belatedPNG.fix('*');
	    	</script>
		<![endif]-->

		<!--[if IE 8]>
			<link rel="stylesheet" type="text/css" media="screen" href="<?php echo CSSPATH ?>ie8-hacks.css" />
		<![endif]-->
		<!-- ENDS CSS -->
		
		<!-- Set google fonts -->
		<?php ansimuz_set_googleFonts() ?>
		
		<!-- custom admin styles -->
		<?php ansimuz_custom_styles() ?>
		
	</head>
	
	
	<!-- BODY -->
	<body <?php body_class(); ?>> 
		
		<!-- TOP -->
		<?php if(get_option('ansimuz_top_message') != ''): ?>
		<div id="top">
			<div class="wrapper">
				<div class="box"><?php echo get_option('ansimuz_top_message') ?></div>
				<div class="close"><?php _e('close','caja') ?></div>
			</div>
		</div>
		<?php endif ?>
		<!-- ENDS TOP -->
				
				
	
		<!-- HEADER -->
		<div id="header">
			<!-- wrapper-header -->
			<div class="wrapper">
				
			
				<!-- Social -->
				<?php ansimuz_social_bar() ?>

				<!-- logo -->
				<a href="<?php bloginfo('url') ?>">
				<?php $src = (get_option('ansimuz_logo') != '') ? get_option('ansimuz_logo') : get_template_directory_uri() . '/img/logo.png'; ?>
				<img src="<?php echo $src ?>" alt="<?php bloginfo('name') ?>" id="logo" />
				</a>
				<!-- ENDS logo -->
				
				<!-- headline -->
				<?php ansimuz_headline() ?>
					
				<!-- Navigation -->
				<?php ansimuz_menu() ?>

			</div>
			<!-- ENDS wrapper-header -->
			<div id="top-torn"></div>	
		</div>
		<!-- ENDS HEADER -->
			
		<!-- MAIN -->
		<div id="main">
			<!-- wrapper-main -->
			<div class="wrapper">

