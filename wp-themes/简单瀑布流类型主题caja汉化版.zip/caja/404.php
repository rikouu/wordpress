<?php get_header() ?>
	
	<!-- Content -->		
	<div class="content-col">
		
		<?php echo get_option('ansimuz_404') ?>
		
	</div>
	<!-- ENDS Content -->

	<!-- SIDEBAR -->
	<?php get_sidebar('page') ?>


<?php get_footer() ?>