<!-- Sidebar -->		
<div class="sidebar">

			
	<!-- init sidebar -->
	<ul id="widget-sidebar">
	<?php if( !function_exists('dynamic_sidebar') || !dynamic_sidebar() ):endif;  ?>
	</ul>
			
	
	
</div>
<!-- ENDS Sidebar -->
