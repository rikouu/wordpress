<?php 
if($post->comment_status == 'open'):

	// removes the require message at themecheck
	$foo = false;
	if($foo) comment_form(); 
	
	// make user identity global
	global $user_identity;
	?>
	
	<!-- Respond -->				
	<div id="respond">
	
		<?php if(get_option('comment_registration') && !$user_ID) : ?>
				<p class="message">你必须<a href="<?php echo get_option('siteurl') ?>/wp-login.php?redirect_to<?php echo urlencode(get_permalink()) ?>" class="color2">登录</a>后才能发表评论</p>
		<?php else : ?>
			
		<h3 class="s-title"><?php _e('Leave a comment','caja') ?> <span> <?php _e('Spam not allowed','caja') ?></span></h3>
		<div class="cancel-comment-reply"><a rel="nofollow" id="cancel-comment-reply-link" href="#respond" style="display:none;"><?php _e('Cancel reply','caja') ?></a></div>
		<form action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post" id="commentform">
			<fieldset>
				
				<?php if($user_ID) : ?>
					<p class="logged-in-as">登录者 <a href="<?php echo get_option('siteurl') ?>/wp-admin/profile.php"><?php echo $user_identity ?></a>. <a href="<?php echo get_option('siteurl') ?>/wp-login.php?action=logout" title="log out of this account">退出 &raquo</a></p>
					
				<?php else : ?>
					
					<input type="text" name="author" id="author" value="" tabindex="1" />
					<label for="author"><?php _e('Name','caja') ?> <small><?php if($req) echo '*' ?></small></label>
				
					<input type="text" name="email" id="email" value="" tabindex="2" />
					<label for="email"><?php _e('Email','caja') ?> <small><?php if($req) echo '*' ?></small> <span>(保密)</span></label>
				
					<input type="text" name="url" id="url" value="<?php echo $comment_author_url ?>"  tabindex="3" />
					<label for="url"><?php _e('Website','caja') ?></label>
				<?php endif; ?>
			
					<textarea name="comment" id="comment"  tabindex="4"></textarea>
					
					<p><input name="submit" type="submit" id="submit" tabindex="5" value="<?php _e('Post','caja') ?>" /></p>
					<input type="hidden" name="comment_post_ID" value="<?php echo $id ?>" />
				<?php comment_id_fields(); ?>
			</fieldset>	
		</form>
		
		<?php endif; ?>
	</div>
	<div class="clear"></div>
	<!-- ENDS Respond -->
<?php endif; ?>







