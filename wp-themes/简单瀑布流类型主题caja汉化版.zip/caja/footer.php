			<div class="clear"></div>
			</div>
			<!-- ENDS wrapper-main -->
		</div>
		<!-- ENDS MAIN -->

			
		<!-- FOOTER -->
		<div id="footer">
			<!-- wrapper-footer -->
			<div class="wrapper">
			
				
				<!-- title -->
				<div class="title">
					<span class="big"><?php echo get_option('ansimuz_profile_header') ?></span> <span class="small"> <?php echo get_option('ansimuz_profile_subheader') ?></span>
					<div  class="to-top poshytip" title="<?php _e('to top', 'caja') ?>"><?php _e('to top', 'caja') ?></div>
				</div>
				<!-- Ends title -->
				
				<!-- left col -->
				<div class="footer-left">
					<!-- Profile -->
					<p><?php echo get_option('ansimuz_profile') ?></p>
					
					<!-- Skills -->	
					<?php ansimuz_skills() ?>
				</div>
				<!-- ENDS left col -->
				
				<!-- right col -->
				<div class="footer-right">
				
					<?php if(get_option('ansimuz_form_replace') == ''):  ?>
						<h6><?php echo get_option('ansimuz_form_label') ?></h6>
						<p><?php echo get_option('ansimuz_form_text') ?></p>
						
						<!-- Contact form -->
						<?php include_once('contact-form.php') ?>
					<?php else: ?>
						<?php
						$post_id = get_option('ansimuz_form_replace');
						$queried_post = get_post($post_id);
						$title = $queried_post->post_title;
						$content = $queried_post->post_content;
						$content = apply_filters('the_content', $content);
						$content = str_replace(']]>', ']]&gt;', $content);

						echo '<h6>'.$title.'</h6>';
						echo $content;
						?>
					<?php endif; ?>
				</div>
				<div class="clear"></div>
				<!-- ENDS right col -->
					
				
			</div>
			<!-- ENDS wrapper-footer -->
		</div>
		<!-- ENDS FOOTER -->
		
	
		<!-- Bottom -->
		<div id="bottom">
			<!-- wrapper-bottom -->
			<div class="wrapper">
				<div id="bottom-text"><?php echo get_option('ansimuz_footer') ?> </div>
				<div  class="to-top poshytip" title="<?php _e('to top', 'caja') ?>"><?php _e('to top', 'caja') ?></div>
			</div>
			<!-- ENDS wrapper-bottom -->
		</div>
		<!-- ENDS Bottom -->

	<?php wp_footer() ?>
	</body>
</html>