<?php get_header() ?>

	<!-- current -->
	<div class="curretly-viewing">
	<?php _e('Currently viewing', 'caja') ?> 
	<strong><?php echo getCurrentTaxName() ?></strong>
	</div>
	<!-- ENDS current -->
	
	<!-- search -->
	<?php ansimuz_searchform() ?>
	
	<!-- Posts -->
	<div>
	
		<!-- The loop -->
		<ul class="blocks-thumbs"><?php include_once('lib/loop.php') ?></ul>
			
		<!-- pager -->	
		<?php ansimuz_pagination('',2); ?>
			
	</div>
	<!-- ENDS posts -->


<?php get_footer() ?>