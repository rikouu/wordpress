<?php
/*
Template name: Front page
*/
?>
<?php get_header() ?>
	<?php
	// Select the kind of content (taxonomy) to show on the front page
	$cont_type = (get_option('ansimuz_front_page_content') == '') ? 'blog' : get_option('ansimuz_front_page_content');
	switch($cont_type):
		case 'work': $cat_type = 'work_category'; $cont_type = 'work'; break;
		case 'downloads': $cat_type = 'downloads_category'; $cont_type = 'downloads'; break;
		default: $cat_type = 'category'; $cont_type = 'post'; break;
	endswitch;
	?>
	
	<!-- nav -->
	<?php ansimuz_nav() ?>
	
	<!-- search -->
	<?php ansimuz_searchform() ?>
	
	<!-- Posts -->
	<div>
	
		<?php
		// Preserve the query on pagination
		global $query_string; 
		query_posts($query_string . "&post_type=".$cont_type . $ppp);
		?>

		<!-- The loop -->
		<ul class="blocks-thumbs" id="portfolio-list"><?php include_once($loop_type) ?></ul>
			
		<!-- pager -->	
		<?php if( (get_option('ansimuz_front_page_filterable') == '') ) ansimuz_pagination('',2); ?>
		
		

		
		<?php 
		// Reset Query
		wp_reset_query();
		?>
			
	</div>
	<!-- ENDS posts -->


<?php get_footer() ?>