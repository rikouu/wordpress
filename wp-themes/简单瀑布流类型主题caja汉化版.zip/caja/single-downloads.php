<?php get_header() ?>

	<!-- Categories nav -->
	<?php categoriesNav(__('Categories'), 'downloads_category') ?>
	
	
	<!-- search -->
	<?php ansimuz_searchform() ?>
				
	<!-- Content -->		
	<div class="content-col">
	<?php the_post() ?>
	
		<!-- content -->
		<div class="content">
			<?php $custom = get_post_custom($post->ID); ?>
			
			<!-- Feature image -->
			<?php if ( has_post_thumbnail($post->ID)): ?>
			<div class="feature-holder">
			<?php $large_image_url = wp_get_attachment_image_src( get_post_thumbnail_id($post->ID), 'featured-thumb'); ?>
			<a href="<?php echo $large_image_url[0] ?>" class="clip-620x300" rel="prettyPhoto">
				<img src="<?php echo $large_image_url[0] ?>" alt="<?php the_title() ?>" />
			</a>
			</div>
			<?php endif; ?>
			<!-- ENDS Feature image -->
			
			<div class="padding">
				<h3 class="p-title"><?php the_title() ?></h3>
				
				<div class="meta-tags">
					<?php the_author() ?>,
					<?php echo human_time_diff(get_the_time('U'), current_time('timestamp')).' &#x524D;'; ?>, 
					<?php ansimuz_tagged($post->ID, 'downloads_tags') ?>
				</div>
				
				<span class="pullquote-right"><?php the_excerpt() ?></span>
				
				<div class="content-box"><?php the_content() ?></div>
				
				<div class="buttons-holder">
					<?php ansimuz_download_button($custom["download_id"][0]); ?>
					<?php if(function_exists(getILikeThis)) getILikeThis('get'); ?>
				</div>
		
				
			</div>
		</div>
		<!-- ENDS content -->
		
		<!-- Project gallery -->
		<?php if($custom["project_gallery"][0] == 'checked'): ?>
		<h3 class="s-title"><?php _e('Gallery', 'caja') ?></h3>
		<?php echo do_shortcode('[gallery link="file" columns="4"]'); ?>
		<?php endif ?>
		<!-- ENDS Project gallery -->
		
		<!-- comments list -->
		<?php comments_template(); ?>
		
		<!-- Comments form -->
		<?php get_template_part('commentform') ?>	
				
	</div>
	<!-- ENDS Content -->

	<!-- SIDEBAR -->
	<?php get_sidebar('downloads') ?>


<?php get_footer() ?>