<?php
// update the DB
if($_POST['update_themeoptions'] == true){

	// skin
	update_option('ansimuz_skin', $_POST['ansimuz_skin']);
	
	// logo
	update_option('ansimuz_logo', $_POST['ansimuz_logo']);
	update_option('ansimuz_logo_left', $_POST['ansimuz_logo_left']);
	update_option('ansimuz_logo_top', $_POST['ansimuz_logo_top']);
		
	// font family
	update_option('ansimuz_fontfamily', $_POST['ansimuz_fontfamily']);
	
	// bg
	update_option('ansimuz_bg_path', $_POST['ansimuz_bg_path']);
	update_option('ansimuz_bg_color', $_POST['ansimuz_bg_color']);
	update_option('ansimuz_bg_repeat', $_POST['ansimuz_bg_repeat']);	
	
	// success message
	echo "<div id='setting-error-settings_updated' class='updated settings-error'> 
<p><strong>Settings saved.</strong></p></div> ";
}
?>

<div class="wrap">
		<div id="icon-themes" class="icon32">
			<br/>
		</div>
		<h2><?php echo THEME_NAME . ' <span class="description")>v.' . THEME_VERSION . '</span>' ?>  <?php _e("Contact Settings","caja") ?></h2>
		
		<div class="header-description"><?php _e("Use this page to configure the appearance of your theme. Change the skin, the font colors and background options","caja") ?></div>
		
		<form method="POST" action="" id="manager_form" >
		
		<table class="form-table ansimuz-table">
			
			<!-- Skins -->
			<tr valign="top">
				<th scope="row"><?php _e("Skin style","caja") ?></th>
				<td>			
					<select name="ansimuz_skin">
						<option value="" selected >- Default -</option>
						<?php $dirs = getDirectoriesArray('../wp-content/themes/caja/skins/'); 
							foreach($dirs as $dir => $v):
						?>
						<option value="<?php echo $v ?>" <?php if(get_option('ansimuz_skin')== $v) echo 'selected' ?>><?php echo $v ?></option>
						<?php endforeach ?>
					</select>
					<span class="description "><?php _e('Choose the skin for the whole site. You can add more skins at the "skins" folder.',"caja") ?></span>
				</td>
			</tr>
			<!-- ENDS Skins -->
			
			<!-- Logo -->
			<tr valign="top">
				<th scope="row"><?php _e("Logo","caja") ?></th>
				<td>
					<p><input type="text" name="ansimuz_logo" id="ansimuz_logo" size="60" value="<?php echo get_option('ansimuz_logo') ?>" /><br/><span class="description"> <?php _e("Enter an URL of an image file. It can be png, jpg or gif.","caja") ?></span></p>
				</td>
				<th>
				<?php $src = (get_option('ansimuz_logo') != '') ? get_option('ansimuz_logo') : get_template_directory_uri() . '/img/logo.png'; ?>
				<img src="<?php echo $src ?>" alt="<?php bloginfo('name') ?>"/>
				</th>
			</tr>
			<!-- Logo -->
			
			<!-- font family -->
			<tr valign="top">
				<th scope="row"><?php _e("Headers font family","caja") ?></th>
				<td>
					<p><input type="text" name="ansimuz_fontfamily"  size="60" value="<?php echo get_option('ansimuz_fontfamily') ?>"  />
					<br/><span class="description"> <?php _e('Enter the "Font API parameter name" for the "Google web font".',"caja") ?></span></p>
					
					<p><span class="description"><?php _e("View all the available fonts at","caja") ?> <a href="http://www.google.com/webfonts" target="_blank">http://www.google.com/webfonts</a></span></p>
					
					<p><span class="description"><a href="<?php echo get_template_directory_uri() ?>/admin/img/embed-google-fonts.png" target="_blank"><?php _e("Click here.","caja") ?></a> <?php _e('to learn where to get the "Parameter name" and the "Name"',"caja") ?> </span></p>
				</td>
			</tr>
			<!-- ENDS font family -->
			
			
			<!-- Background -->
			<tr valign="top">
				<th scope="row"><?php _e("Background","caja") ?></th>
				<td>
					<p><input type="text" name="ansimuz_bg_path" id="ansimuz_bg_path" size="60" value="<?php echo get_option('ansimuz_bg_path') ?>"  />
					<br/><span class="description"> <?php _e("Set the url for the background path. Leave blank to display default background.","caja") ?> </span></p>
					
					<p>#<input type="text" name="ansimuz_bg_color" id="ansimuz_bg_color" size="8" value="<?php echo get_option('ansimuz_bg_color') ?>"  /><span class="description"> <?php _e("Background solid color. Use hex value.","caja") ?></span></p>

					<p>
					<select name="ansimuz_bg_repeat" id="ansimuz_bg_repeat">
						<option value="" <?php if(get_option('ansimuz_bg_repeat')=='') echo 'selected' ?>>default</option>
		
						<option value="repeat" <?php if(get_option('ansimuz_bg_repeat')=='repeat') echo 'selected' ?>>repeat</option>
						<option value="no-repeat" <?php if(get_option('ansimuz_bg_repeat')=='no-repeat') echo 'selected' ?>>no-repeat</option>
						<option value="repeat-y" <?php if(get_option('ansimuz_bg_repeat')=='repeat-y') echo 'selected' ?>>repeat-y</option>
						<option value="repeat-x" <?php if(get_option('ansimuz_bg_repeat')=='repeat-x') echo 'selected' ?>>repeat-x</option>
					</select><span class="description"><?php _e("Background repeat","caja") ?></span>
					</p>
			
				</td>
			</tr>
			<!-- ENDS Background -->			
			
		</table>




			
			<p><input type="submit" name="search" value="&#x66F4;&#x65B0;&#x8BBE;&#x7F6E;" class="button-primary" /></p>
			<input type="hidden" name="update_themeoptions" value="true" />
			
		</form>
	</div> 