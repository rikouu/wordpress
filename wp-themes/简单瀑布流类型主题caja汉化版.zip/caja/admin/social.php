<?php

// make social global
global $social_links;
if(get_option('social_links') ){
	$social_links = get_option('social_links');
}

// update the DB
if($_POST['update_themeoptions'] == true){

	// Hide
	$display = ($_POST['ansimuz_social_bar_display'] == 'on') ? 'checked' : '';
	update_option('ansimuz_social_bar_display', $display);
	
	update_option('ansimuz_social_icon_style', stripslashes($_POST['ansimuz_social_icon_style']));
	
	
	// social manager
	$social_links = array();
	foreach($_POST['ansimuz_social_class'] as $k => $v){
		$social_links[] = array(
			'class' => $v,
			'link' => stripslashes($_POST['ansimuz_social_link'][$k]),
			'caption' => stripslashes($_POST['ansimuz_social_caption'][$k])
		);
	}// foreach
	update_option('social_links', $social_links);


	// success message
	echo "<div id='setting-error-settings_updated' class='updated settings-error'> 
<p><strong>Settings saved.</strong></p></div> ";
}

// number of slides
if(get_option('ansimuz_social_number') == ''){
	$n_social = 0;
}else{
	$n_social = get_option('ansimuz_social_number');
}

// list of icons
$icons_array = array(
					'addthis',
					'aim',
					'aim2',
					'apple',
					'bebo',
					'behance',
					'blogger',
					'brightkite',
					'cargo',
					'delicious',
					'design_bump',
					'designfloat',
					'designmoo',
					'deviantart',
					'digg',
					'dopplr',
					'dribbble',
					'email',
					'ember',
					'evernote',
					'facebook',
					'flickr',
					'friendfeed',
					'github',
					'google',
					'google_buzz',
					'google_talk',
					'googlemaps',
					'lastfm',
					'linkedin',
					'livejournal',
					'mixx',
					'mobileme',
					'msn',
					'myspace',
					'netvibes',
					'newsvine',
					'orkut',
					'pandora',
					'paypal',
					'picasa',
					'posterous',
					'qik',
					'reddit',
					'rss',
					'sharethis',
					'skype',
					'slashdot',
					'squidoo',
					'stumbleupon',
					'technorati',
					'tumblr',
					'twitter',
					'viddler',
					'vimeo',
					'virb',
					'windows',
					'wordpress',
					'xing',
					'yahoo',
					'yahoo_buzz',
					'yelp',
					'youtube');
?>



<div class="wrap">
		<div id="icon-themes" class="icon32">
			<br/>
		</div>
		
		<h2><?php echo THEME_NAME . ' <span class="description")>v.' . THEME_VERSION . '</span>' ?>  <?php _e("Social Settings","caja") ?></h2>
		
		
		<div class="header-description"><?php _e("Configure and add any links to your social network bar","caja") ?></div>
		
		<form method="POST" action="" id="manager_form" >
		
		<table class="form-table ansimuz-table">
			
			
			<!--  display -->
			<tr valign="top">
				<th scope="row"><?php _e("Social display","caja") ?></th>
				<td>
					<p><input type="checkbox" name="ansimuz_social_bar_display" <?php echo get_option('ansimuz_social_bar_display') ?> /> <span class="description"><?php _e("Check to hide the social bar","caja") ?></span> </p>
				</td>
			</tr>
			<!-- ENDS  display  -->
			
			
			<!--  style -->
			<tr valign="top">
				<th scope="row"><?php _e("Social icons style","caja") ?></th>
				<td>
					<p>
					<select name="ansimuz_social_icon_style" >
						<option value="" selected="selected">Circular</option>
						<option value="rounded" <?php if(get_option('ansimuz_social_icon_style') == 'rounded') echo ' selected="selected"' ?> >Rounded square</option>
					</select>
					<span class="description"><?php _e("Don't like the default circular style? Try the square style.","caja") ?></span>
					</p>
				</td>
			</tr>
			<!--  ENDS display -->
			
		</table>
		

			<h2><?php _e("Social network manager","caja") ?></h2>
			<!-- SOCIAL MANAGER -->
			<ul id="manager_form_wrap">
				
				<?php if(get_option('social_links')) :  ?>
					
					<?php foreach($social_links as $k => $link): ?>
				
					<li class="slide">
						<label> <?php _e("Social icon","caja") ?></label>
						<select name="ansimuz_social_class[]">
							<?php 
								for($j = 0; $j < count($icons_array); $j++){
									$temp = $icons_array[$j];
								?>
									<option value="<?php echo $temp ?>" <?php if($link['class'] == $temp) echo 'selected' ?>><?php echo $temp ?></option>
								<?php
								}
							 ?>
						</select>
						<label> <?php _e("Social link","caja") ?></label>
						<input type="text" name="ansimuz_social_link[]" id="slide_link" value="<?php echo $link['link']  ?>">
						<label> <?php _e("Social tooltip caption","caja") ?> </label>
						<input type="text" name="ansimuz_social_caption[]" id="slide_link" value="<?php echo $link['caption']  ?>">
						<button class="remove_slide button-secondary"><?php _e("Remove this link","caja") ?></button>
					</li>
					
					<?php endforeach; ?>
					
				<?php else: ?>
				
					<li class="slide">
						<label> <?php _e("Social icon","caja") ?></label>
						<select name="ansimuz_social_class[]">
							<?php 
								for($j = 0; $j < count($icons_array); $j++){
									$temp = $icons_array[$j];
								?>
									<option value="<?php echo $temp ?>" <?php if(get_option('ansimuz_social_class_'.$i) == $temp) echo 'selected' ?>><?php echo $temp ?></option>
								<?php
								}
							 ?>
						</select>
						<label> <?php _e("Social link","caja") ?></label>
						<input type="text" name="ansimuz_social_link[]" id="slide_link">
						<label> <?php _e("Social tooltip caption","caja") ?> </label>
						<input type="text" name="ansimuz_social_caption[]" id="slide_link">
						<button class="remove_slide button-secondary"><?php _e("Remove this link","caja") ?></button>
					</li>
					
				<?php endif; ?>
			</ul>
			<!-- ENDS SOCIAL MANAGER -->
			
			


						
			<p><input type="submit" name="search" value="&#x66F4;&#x65B0;&#x8BBE;&#x7F6E;" class="button-primary" /></p>
			<input type="hidden" name="update_themeoptions" value="true" />
			
		</form>
	</div>?