<?php

// make headline global
global $headline;
if(get_option('headline') ){
	$headline = get_option('headline');
}

// update the DB
if($_POST['update_themeoptions'] == true){

	//display
	$display = ($_POST['ansimuz_headline_display'] == 'on') ? 'checked' : '';
	update_option('ansimuz_headline_display', $display);
	
	// slide manager
	$headline = array();
	foreach($_POST['caption'] as $k => $v){
		$headline[] = array(
			'caption' => stripslashes($_POST['caption'][$k])
		);
	}// foreach
	
	update_option('headline', $headline);
			
				
	// success message
	echo "<div id='setting-error-settings_updated' class='updated settings-error'> 
<p><strong>Settings saved.</strong></p></div> ";
}


?>

<div class="wrap">
		<div id="icon-themes" class="icon32">
			<br/>
		</div>
		<h2><?php echo THEME_NAME . ' <span class="description")>v.' . THEME_VERSION . '</span>' ?>  <?php _e("headline Settings","caja") ?></h2>
		
		<div class="header-description"><?php _e("Add as many paragraphs as you want to your headline","caja") ?></div>
		
		<form method="POST" action="" id="manager_form" >
		
			<table class="form-table ansimuz-table">
				
				<tr valign="top">
					<th scope="row"><?php _e("Hide headline","caja") ?></th>
					<td><input type="checkbox" name="ansimuz_headline_display" id="ansimuz_headline_display" <?php echo get_option('ansimuz_headline_display') ?> /><span class="description"> <?php _e("Check to hide the headline","caja") ?></span></td>
				</tr>
				
			</table>

			
			<!-- SLIDER MANAGER -->
			<h2><?php _e("Slider Manager","caja") ?></h2>	<br/>
			
			<ul id="manager_form_wrap">
				
				<?php if(get_option('headline')) :  ?>
					
					<?php foreach($headline as $k => $item): ?>
				
					<li class="slide">
						<label> <?php _e("Paragraph text","caja") ?></label>
						<textarea name="caption[]" cols="20" rows="2" class="slidecaption"><?php echo $item['caption'] ?></textarea>
						<button class="remove_slide button-secondary"><?php _e("Remove this slide","caja") ?></button>
					</li>
					
					<?php endforeach; ?>
					
				<?php else: ?>
				
					<li class="slide">
						<label> <?php _e("Paragraph text","caja") ?></label>
						<textarea name="caption[]" cols="20" rows="2" class="slidecaption"></textarea>
						<button class="remove_slide button-secondary"><?php _e("Remove this slide","caja") ?></button>
					</li>
					
				<?php endif; ?>
			</ul>
			<!-- ENDS SLIDER MANAGER  -->
			
			<p><input type="submit" name="search" value="&#x66F4;&#x65B0;&#x8BBE;&#x7F6E;" class="button-primary" /></p>
			<input type="hidden" name="update_themeoptions" value="true" />
			
		</form>
		

</div>