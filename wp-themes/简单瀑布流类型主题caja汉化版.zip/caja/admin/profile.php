<?php
// update the DB
if($_POST['update_themeoptions'] == true){

	update_option('ansimuz_profile_link_label', stripslashes($_POST['ansimuz_profile_link_label']));
	update_option('ansimuz_profile_header', stripslashes($_POST['ansimuz_profile_header']));
	update_option('ansimuz_profile_subheader', stripslashes($_POST['ansimuz_profile_subheader']));
	update_option('ansimuz_profile', stripslashes($_POST['ansimuz_profile']));
	
	// success message
	echo "<div id='setting-error-settings_updated' class='updated settings-error'> 
<p><strong>Settings saved.</strong></p></div> ";
}
?>


<div class="wrap">
		<div id="icon-themes" class="icon32">
			<br/>
		</div>
		<h2><?php echo THEME_NAME . ' <span class="description")>v.' . THEME_VERSION . '</span>' ?>  <?php _e("Profile Settings","caja") ?></h2>
		
		<div class="header-description"><?php _e("Desription about you HTML mark up allowed","caja") ?></div>
		
		<form method="POST" action="" id="manager_form" >
		
		<table class="form-table ansimuz-table">
			
			<!-- Label -->
			<tr valign="top">
				<th scope="row"><?php _e("Profile link label","caja") ?></th>
				<td>
					<textarea name="ansimuz_profile_link_label" cols="60" rows="2" ><?php echo get_option('ansimuz_profile_link_label') ?></textarea>
					<span class="description"><?php _e("Text for the profile link at the right of the navigation menu","caja") ?></span>
				</td>
			</tr>
			<!-- ENDS Label -->
			
			<!-- Header -->
			<tr valign="top">
				<th scope="row"><?php _e("Profile header","caja") ?></th>
				<td>
					<textarea name="ansimuz_profile_header" cols="60" rows="2" ><?php echo get_option('ansimuz_profile_header') ?></textarea>
					<span class="description"><?php _e("Text over the profile at the bottom of the page","caja") ?></span>
				</td>
			</tr>
			<!-- ENDS Header -->
			
			<!-- Subheader -->
			<tr valign="top">
				<th scope="row"><?php _e("Profile subheader","caja") ?></th>
				<td>
					<textarea name="ansimuz_profile_subheader"  cols="60" rows="2" ><?php echo get_option('ansimuz_profile_subheader') ?></textarea>
					<span class="description"><?php _e("Text under the profile header at the bottom of the page","caja") ?></span>
				</td>
			</tr>
			<!-- ENDS Subheader -->
			
			<!-- Profile -->
			<tr valign="top">
				<th scope="row"><?php _e("Profile","caja") ?></th>
				<td>
					<textarea name="ansimuz_profile" id="ansimuz_profile" cols="60" rows="35" ><?php echo get_option('ansimuz_profile') ?></textarea>
					<span class="description"><?php _e("Content for your profile at the bottom of the page","caja") ?></span>
				</td>
			</tr>
			<!-- ENDS Profile -->
						
			
		</table>
		
		<input type="submit" name="search" value="&#x66F4;&#x65B0;&#x8BBE;&#x7F6E;" class="button-primary" /></p>
		<input type="hidden" name="update_themeoptions" value="true" />
			
		</form>
	</div> 