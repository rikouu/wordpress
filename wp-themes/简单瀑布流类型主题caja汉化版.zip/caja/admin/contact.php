<?php

// make fields global
global $fields;
if(get_option('contact_form_fields') ){
	$fields = get_option('contact_form_fields');
}

// update the DB
if($_POST['update_themeoptions'] == true){


	update_option('ansimuz_form_replace', $_POST['ansimuz_form_replace']);
	
	// Form data
	update_option('ansimuz_contact_subject', stripslashes($_POST['ansimuz_subject']));	
	update_option('ansimuz_contact_emails', $_POST['ansimuz_emails']);
	
	// Form label
	update_option('ansimuz_form_label', stripslashes($_POST['ansimuz_form_label']));
	update_option('ansimuz_form_text', stripslashes($_POST['ansimuz_form_text']));
	
	// Sent message
	update_option('ansimuz_contact_thanks', stripslashes($_POST['ansimuz_thanks']));
	
	
	
	// Contact form manager
	$fields = array();
	foreach($_POST['label'] as $k => $v){
		$fields[] = array(
			'label' => stripslashes($v),
			'tooltip' => stripslashes($_POST['tooltip'][$k]),
			'type' => stripslashes($_POST['type'][$k]),
			'required' => stripslashes($_POST['required'][$k])
		);
	}// foreach
	
	update_option('contact_form_fields', $fields);
		
	// success message
	echo "<div id='setting-error-settings_updated' class='updated settings-error'> 
<p><strong>Settings saved.</strong></p></div> ";
}

?>


<div class="wrap">
		<div id="icon-themes" class="icon32">
			<br/>
		</div>
		<h2><?php echo THEME_NAME . ' <span class="description")>v.' . THEME_VERSION . '</span>' ?>  <?php _e("Contact Settings","caja") ?></h2>
		
		
		<div class="header-description"><?php _e("Configure your contact form and your contact information.","caja") ?></div>
		
		<form method="POST" action="" id="manager_form" >
		
		<table class="form-table ansimuz-table">
		
			<!-- Replace form -->
			<tr valign="top">
				<th scope="row"><?php _e('Replace form','caja') ?></th>
				<td>
				
					<?php
						// get the pages
						$pages = get_pages();
					?>
					<select name="ansimuz_form_replace" >
						<option value="">- None -</option>
						<?php foreach($pages as $page): ?>
							<option value="<?php echo $page->ID ?>" <?php if(get_option('ansimuz_form_replace')== $page->ID) echo 'selected' ?>><?php echo $page->post_title ?></option>
						<?php endforeach; ?>
					</select>
					<br/><span class="description"><?php _e('Select a page to replace the contact form','caja') ?></span>
				</td>
			</tr>
			<!-- ENDS Replace form -->
			
			<!-- Form data -->
			<tr valign="top">
				<th scope="row"><?php _e("Contact form data","caja") ?></th>
				<td>
					<p><?php _e("Email subject","caja") ?>
					<input type="text" name="ansimuz_subject" id="ansimuz_subject" size="60" value="<?php echo get_option('ansimuz_contact_subject') ?>" /><span class="description"> <br/><?php _e("The subject for the sent form","caja") ?></span></p>
			
					<p><?php _e("Recipients emails","caja") ?>
					<input type="text" name="ansimuz_emails" id="ansimuz_emails" size="60" value="<?php echo get_option('ansimuz_contact_emails') ?>" /><span class="description"> <br/><?php _e("Enter multiple emails separated by commas.","caja") ?></span>
					</p>	
					
				</td>
			</tr>
			<!-- ENDS Form data -->
			
			<!-- Form label -->
			<tr valign="top">
				<th scope="row"><?php _e("Contact form header","caja") ?></th>
				<td>
					<p>
					<input type="text" name="ansimuz_form_label"  size="60" value="<?php echo get_option('ansimuz_form_label') ?>" /><span class="description"> <br/><?php _e("Header text over the contact form","caja") ?></span></p>
				</td>
			</tr>
			<!-- ENDS Form label -->
			
			<!-- Form text -->
			<tr valign="top">
				<th scope="row"><?php _e("Contact text","caja") ?></th>
				<td>
					<p>
					<textarea name="ansimuz_form_text" id="ansimuz_form_text" cols="58" rows="5"><?php echo get_option('ansimuz_form_text') ?></textarea>
					<br/><span class="description"><?php _e("Text/description over the contact form","caja") ?></span></p>
				</td>
			</tr>
			<!-- ENDS Form text -->
			
			<!-- Form Sent message -->
			<tr valign="top">
				<th scope="row"><?php _e("Sent form message","caja") ?></th>
				<td>
					<p><textarea name="ansimuz_thanks" id="ansimuz_thanks" cols="58" rows="5"><?php echo get_option('ansimuz_contact_thanks') ?></textarea>
					<br/><span class="description"><?php _e("Text displayed after message has benn sent.","caja") ?></span></p>

				</td>
			</tr>
			<!-- ENDS Form Sent message -->
			
			
		</table>

		<!-- SLIDER MANAGER -->
		<h2><?php _e("Contact Form Manager","caja") ?></h2>	<br/>
		<ul id="manager_form_wrap">
					
			<?php if(get_option('contact_form_fields')) :  ?>
				
				<?php foreach($fields as $k => $field):  ?>
			
				<li class="slide">
					<label> <?php _e("Label","caja") ?> <span>(<?php _e("required","caja") ?>)</span> </label>
					<input type="text" name="label[]" value="<?php echo $field['label'] ?>">
					<label> <?php _e("Tooltip caption","caja") ?>  </label>
					<input type="text" name="tooltip[]" value="<?php echo $field['tooltip'] ?>">
					<label> <?php _e("Type","caja") ?> </label>
					<select name="type[]">
						<option value="text" <?php if($field['type'] == 'text') echo 'selected="selected"' ?>><?php _e("Text field","caja") ?></option>
						<option value="password" <?php if($field['type'] == 'password') echo 'selected="selected"' ?>><?php _e("Password field","caja") ?></option>
						<option value="textarea" <?php if($field['type'] == 'textarea') echo 'selected="selected"' ?>><?php _e("Text area","caja") ?></option>
					</select>
					<select name="required[]">
						<option value="" <?php if($field['required'] == '') echo 'selected="selected"' ?>><?php _e("Not Required","caja") ?></option>
						<option value="1" <?php if($field['required'] == '1') echo 'selected="selected"' ?>><?php _e("Required","caja") ?></option>
					</select>
					<button class="remove_slide button-secondary"><?php _e("Remove this field","caja") ?></button>
				</li>
				
				<?php endforeach; ?>
				
			<?php else: ?>
			
				<li class="slide">
					<label> <?php _e("Label","caja") ?> <span>(<?php _e("required","caja") ?>)</span> </label>
					<input type="text" name="label[]" >
					<label> <?php _e("Tooltip caption","caja") ?>  </label>
					<input type="text" name="tooltip[]">
					<label> <?php _e("Type","caja") ?> </label>
					<select name="type[]">
						<option value="text"><?php _e("Text field","caja") ?></option>
						<option value="password"><?php _e("Password field","caja") ?></option>
						<option value="textarea"><?php _e("Text area","caja") ?></option>
					</select>
					<select name="required[]">
						<option value="" selected="selected" ><?php _e("Not Required","caja") ?></option>
						<option value="1" ><?php _e("Required","caja") ?></option>
					</select>
					<button class="remove_slide button-secondary"><?php _e("Remove this field","caja") ?></button>
				</li>
				
			<?php endif; ?>
		</ul>
		<!-- ENDS SLIDER MANAGER  -->

			
		<p><input type="submit" name="search" value="&#x66F4;&#x65B0;&#x8BBE;&#x7F6E;" class="button-primary" /></p>
		<input type="hidden" name="update_themeoptions" value="true" />
		
	</form>
</div> 