<?php
// update the DB
if($_POST['update_themeoptions'] == true){

	update_option('ansimuz_SEO', stripslashes($_POST['ansimuz_SEO']));
	update_option('ansimuz_SEO_page_title', stripslashes($_POST['ansimuz_SEO_page_title']));
	update_option('ansimuz_SEO_meta_keywords', stripslashes($_POST['ansimuz_SEO_meta_keywords']));
	update_option('ansimuz_SEO_meta_description', stripslashes($_POST['ansimuz_SEO_meta_description']));
	
	// Run on home page only
	$display = ($_POST['ansimuz_SEO_only_home'] == 'on') ? 'checked' : '';
	update_option('ansimuz_SEO_only_home', $display);
	
	// success message
	echo "<div id='setting-error-settings_updated' class='updated settings-error'> 
<p><strong>Settings saved.</strong></p></div> ";
}
?>


<div class="wrap">
		<div id="icon-themes" class="icon32">
			<br/>
		</div>
		<h2><?php echo THEME_NAME . ' <span class="description")>v.' . THEME_VERSION . '</span>' ?>  <?php _e('SEO settings','caja') ?></h2>
		
		<div class="header-description"><?php _e('This theme includes SEO (Search Engine Optimization) built-in options. You can customize your meta data and edit the display of the page titles.','caja') ?> </div>
		
		<form method="POST" action="" id="manager_form" >
		
		<table class="form-table ansimuz-table">
			
			
			
			<!-- Disable -->
			<tr valign="top">
				<th scope="row"><?php _e('Disable SEO','caja') ?></th>
				<td>
					<input type="radio" name="ansimuz_SEO" value="" <?php if(get_option('ansimuz_SEO') == '') echo 'checked' ?> > Disabled</input>
					
					<input type="radio" name="ansimuz_SEO" value="enabled" <?php if(get_option('ansimuz_SEO') == 'enabled') echo 'checked' ?>> Enabled</input>
					
					<br/>
					<span class="description"><?php _e('If you are using an external SEO plug-in you should disable this option.','caja') ?></span>
				</td>
			</tr>
			<!-- ENDS Disable -->
			
			<!-- Page title -->
			<tr valign="top">
				<th scope="row"><?php _e('Page title','caja') ?></th>
				<td>
					<input type="text" name="ansimuz_SEO_page_title"  size="60" value="<?php echo get_option('ansimuz_SEO_page_title') ?>" /><span class="description"> <br/><?php _e("Set the format for the page title at the top of the browser ","caja") ?></span></p>
					
					<div class="collapsed-container">
						<p><a href="#">View available format tags</a></p>
						<div class="collapsed-box">
							%blog_title% - Will display name of your blog<br/>
							%blog_description% - Will blog description<br/>
							%page_title% - Will display current page title<br/>
							<p><strong>Example</strong> %blog_title% | %blog_description%</p>
						</div>
					</div>
										
				</td>
			</tr>
			<!-- ENDS Page title -->
			
			<!-- Meta keywords -->
			<tr valign="top">
				<th scope="row"><?php _e('Meta keywords','caja') ?></th>
				<td>
					<textarea name="ansimuz_SEO_meta_keywords"  cols="60" rows="5" ><?php echo get_option('ansimuz_SEO_meta_keywords') ?></textarea>
					<span class="description"><?php _e("Enter a list of keywords you would like to associate to your home page separated by commas.",'caja') ?></span>
				</td>
			</tr>
			<!-- ENDS Meta keywords -->
			
			
			<!-- Meta description -->
			<tr valign="top">
				<th scope="row"><?php _e('Meta description','caja') ?></th>
				<td>
					<textarea name="ansimuz_SEO_meta_description"  cols="60" rows="5" ><?php echo get_option('ansimuz_SEO_meta_description') ?></textarea>
					<span class="description"><?php _e("Enter a description for your site. This will be displayed in most cases on the Search engine description.",'caja') ?></span>
				</td>
			</tr>
			<!-- ENDS Meta description -->
			
			<!-- Keywords run -->
			<tr valign="top">
				<th scope="row"><?php _e('Meta keywords run','caja') ?></th>
				<td>
					<input type="checkbox" name="ansimuz_SEO_only_home"  <?php echo get_option('ansimuz_SEO_only_home') ?> />
					<span class="description"><?php _e("Check this option if you want your keywords to run only on the home page.",'caja') ?></span>
				</td>
			</tr>
			<!-- ENDS Keywords run -->
			
			
			
		</table>
		
		<input type="submit" name="search" value="&#x66F4;&#x65B0;&#x8BBE;&#x7F6E;" class="button-primary" /></p>
		<input type="hidden" name="update_themeoptions" value="true" />
			
		</form>
	</div> 