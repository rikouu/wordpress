<?php
// update the DB
if($_POST['update_themeoptions'] == true){

	// front page
	update_option('ansimuz_front_page_content', $_POST['ansimuz_front_page_content']);
	$display = ($_POST['ansimuz_front_page_filterable'] == 'on') ? 'checked' : '';
	update_option('ansimuz_front_page_filterable', $display);
	update_option('ansimuz_front_page_filterable_nposts', $_POST['ansimuz_front_page_filterable_nposts']);
	
	// misc
	update_option('ansimuz_search_display', $_POST['ansimuz_search_display']);
	update_option('ansimuz_top_message', stripslashes($_POST['ansimuz_top_message']));
	update_option('ansimuz_footer', stripslashes($_POST['ansimuz_footer']));
	update_option('ansimuz_404', stripslashes($_POST['ansimuz_404']));
	
	// success message
	echo "<div id='setting-error-settings_updated' class='updated settings-error'> 
<p><strong>Settings saved.</strong></p></div> ";
}
?>


<div class="wrap">
		<div id="icon-themes" class="icon32">
			<br/>
		</div>
		<h2><?php echo THEME_NAME . ' <span class="description")>v.' . THEME_VERSION . '</span>' ?>  <?php _e('General Settings','caja') ?></h2>
		
		<div class="header-description"><?php _e('General settings for the entire theme','caja') ?> </div>
		
		<form method="POST" action="" id="manager_form" >
		
		<table class="form-table ansimuz-table">
			

			<!-- Front page -->
			<tr valign="top">
				<th scope="row"><?php _e('Front page','caja') ?></th>
				<td>
					<select name="ansimuz_front_page_content" id="ansimuz_front_page_content">
						<option value="" <?php if(get_option('ansimuz_front_page_content')=='') echo 'selected' ?>>Blog posts</option>
						<option value="work" <?php if(get_option('ansimuz_front_page_content')=='work') echo 'selected' ?>>Work posts</option>
						<option value="downloads" <?php if(get_option('ansimuz_front_page_content')=='downloads') echo 'selected' ?>>Downloads posts</option>
					</select>
					<span class="description"><?php _e('Select the type of content to display on the front page','caja') ?></span>
					
					<p>
						<input type="checkbox" name="ansimuz_front_page_filterable"  <?php echo get_option('ansimuz_front_page_filterable') ?> />
						<span class="description"><?php _e("I want to have filterable content instead of pagination",'caja') ?></span>
					</p>
					
					<p>	
						<?php _e("Home page show at most ",'caja') ?>
						<input type="text" name="ansimuz_front_page_filterable_nposts" size="5"  <?php echo get_option('ansimuz_front_page_filterable_nposts') ?> /><br/>
						<span class="description"><?php _e("How many post display on home. Only for filterable posts. Leave blank to show all posts.",'caja') ?></span>
					</p>
				</td>
			</tr>
			<!-- ENDS Front page -->
			
			
			
			
			<!-- Search box -->
			<tr valign="top">
				<th scope="row"><?php _e('Search box','caja') ?></th>
				<td>
					<select name="ansimuz_search_display" id="ansimuz_search_display">
						<option value="" <?php if(get_option('ansimuz_search_display')=='') echo 'selected' ?>><?php _e('Always','caja') ?></option>
						<option value="never" <?php if(get_option('ansimuz_search_display')=='never') echo 'selected' ?>><?php _e('Never','caja') ?></option>
					</select>
					<span class="description"><?php _e('Toggle the visibility for the search box','caja') ?></span>
				</td>
			</tr>
			<!-- ENDS Search box -->
			
			<!-- Top message -->
			<tr valign="top">
				<th scope="row"><?php _e('Top message','caja') ?></th>
				<td>
					<textarea name="ansimuz_top_message"  cols="60" rows="3" ><?php echo get_option('ansimuz_top_message') ?></textarea>
					<span class="description"><?php _e("Text displayed on the very top of the site. Leave blank if don't want to display it.",'caja') ?></span>
				</td>
			</tr>
			<!-- ENDS Top message -->
			
			<!-- 404 -->
			<tr valign="top">
				<th scope="row"><?php _e("404 page","caja") ?></th>
				<td>
					<textarea name="ansimuz_404" id="ansimuz_404" cols="60" rows="5" ><?php echo get_option('ansimuz_404') ?></textarea>
					<span class="description"><?php _e("Text displayed when error 404 pops","caja") ?></span>
				</td>
			</tr>
			<!-- ENDS 404 -->
			
			<!-- Footer -->
			<tr valign="top">
				<th scope="row"><?php _e("Footer text","caja") ?></th>
				<td>
					<textarea name="ansimuz_footer" id="ansimuz_footer" cols="60" rows="5" ><?php echo stripslashes(get_option('ansimuz_footer')) ?></textarea>
					<span class="description"><?php _e("Text displayed at the bottom of the footer","caja") ?></span>
				</td>
			</tr>
			<!-- ENDS Footer -->
			
			
		</table>
		
		<input type="submit" name="search" value="&#x66F4;&#x65B0;&#x8BBE;&#x7F6E;" class="button-primary" /></p>
		<input type="hidden" name="update_themeoptions" value="true" />
			
		</form>
	</div>