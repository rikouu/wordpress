<!-- Sidebar -->		
<div class="sidebar">

			
	<!-- Project info -->
	<h6 class="side-title"><span><?php _e('Project Info', 'caja') ?></span></h6>
	<table class="info-table">
	  <tbody>
	   <?php global $custom;  ?>
		<tr>
	      <td class="attr-name"><?php _e('Project date', 'caja') ?></td>
	      <td class="attr-detail"><?php echo $custom['date'][0] ?></td>
	    </tr>
	    			            
	    <tr class="">
	      <td class="attr-name"><?php _e('Client', 'caja') ?></td>
	      <td class="attr-detail"><?php echo $custom['client'][0] ?></td>
	    </tr>
	    
	    <tr class="">
	      <td class="attr-name"><?php _e('Skills used', 'caja') ?></td>
	      <td class="attr-detail"><?php echo $custom['skills'][0] ?></td>
	    </tr>
	    
	    <tr class="">
	      <td class="attr-name"><?php _e('Project url', 'caja') ?></td>
	      <td class="attr-detail"><a href="<?php echo $custom['link'][0] ?>" target="_blank"><?php echo $custom['link'][0] ?></a></td>
	    </tr>
	    			            
	  </tbody>
	</table>
	<!-- ENDS Project info -->
	
	<!-- init sidebar -->
	<ul id="widget-sidebar">
	<?php if( !function_exists('dynamic_sidebar') || !dynamic_sidebar('Work Sidebar') ):endif;  ?>
	</ul>
			
	
	
</div>
<!-- ENDS Sidebar -->
