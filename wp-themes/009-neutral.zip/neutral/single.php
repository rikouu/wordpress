<?php get_header(); $options = get_neutral_option(); ?>
  <div id="contents" class="clearfix">

   <div id="left_col">

    <?php if ($options['show_bread_crumb']) : ?>
    <div id="bread_crumb">
     <ul class="clearfix">
      <li id="bc_home"><a href="<?php echo esc_url(home_url('/')); ?>"><?php _e('HOME','neutral'); ?></a></li>
      <?php if ($options['show_category']): ?><li id="bc_cat"><?php the_category(' . '); ?></li><?php endif; ?>
      <li><?php the_title(); ?></li>
     </ul>
    </div>
    <?php endif; ?>

    <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>

    <div class="post">
     <h2 class="post_title"><?php the_title(); ?></h2>
     <?php if ($options['show_author'] or $options['show_date'] or $options['show_category'] or $options['show_tag'] or $options['show_comment']) { ?>
     <ul class="post_info">
      <?php if ($options['show_date']): ?><li><?php the_time(__('M jS. Y', 'neutral')) ?></li><?php endif; ?>
      <?php if ($options['show_category']): ?><li><?php _e('Posted in ','neutral'); ?><?php the_category(' . '); ?></li><?php endif; ?>
      <?php if ($options['show_tag']): ?><?php the_tags('<li>', ' . ', '</li>'); ?><?php endif; ?>
      <?php if ($options['show_author']) : ?><li><?php _e('By ','neutral'); ?><?php the_author_posts_link(); ?></li><?php endif; ?>
      <?php if ($options['show_comment']): ?><li class="write_comment"><a href="<?php the_permalink() ?>#comments"><?php _e('Write comment','neutral'); ?></a></li><?php endif; ?>
      <?php edit_post_link(__('[ EDIT ]', 'neutral'), '<li class="post_edit">', '</li>' ); ?>
     </ul>
     <?php }; ?>
     <div class="post_content clearfix">
      <?php the_content(__('Read more', 'neutral')); ?>
      <?php wp_link_pages(); ?>
     </div>
    </div>

    <?php endwhile; else: ?>

    <div class="post">
     <p><?php _e("Sorry, but you are looking for something that isn't here.","neutral"); ?></p>
    </div>

    <?php endif; ?>

    <?php if ($options['show_comment']): ?>
    <div id="comments_wrapper">
     <?php if (function_exists('wp_list_comments')) { comments_template('', true); } else { comments_template(); } ?>
    </div>
    <?php endif; ?>

    <?php if ($options['show_next_post']) : ?>
    <div id="prev_next_post" class="clearfix">
     <?php next_post_link( '<p class="prev_post">%link</p>' ); ?>
     <?php previous_post_link( '<p class="next_post">%link</p>' ); ?>
    </div>
    <?php endif; ?>

   </div><!-- END #left_col -->

   <?php if($options['layout'] == 'right') { ?>
    <?php get_sidebar(); ?>
   <?php }; ?>

  </div><!-- END #contents -->
<?php get_footer(); ?>