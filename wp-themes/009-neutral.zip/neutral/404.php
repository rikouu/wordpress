<?php get_header(); ?>
  <div id="contents" class="clearfix">

   <div id="left_col">

    <div class="post">
     <h2 class="post_title"><?php _e("Error 404 Not Found.","neutral"); ?></h2>
    </div>

   </div><!-- END #left_col -->

   <?php get_sidebar(); ?>

  </div><!-- END #contents -->
<?php get_footer(); ?>