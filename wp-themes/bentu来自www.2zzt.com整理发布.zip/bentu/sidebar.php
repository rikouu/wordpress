	<div class="sidebar">
		<div class="widget">
			<div class="googlead">
				<?php include(TEMPLATEPATH .'/google_ad.php');?>
			</div>
		</div>
		
		<div class="widget">
			<h3>行业标签</h3>
			<ul class="sideBarTags">
				<?php wp_tag_cloud('smallest=9&largest=9&number=18&orderby=count&order=DESC'); ?>
			</ul>
		</div>	
		
		<?php if(!is_home()) {?>
		<div class="widget">
			<h3>每周热门文章</h3>
			<?php query_posts('showposts=5'); ?> 
			<ul>
				<?php while (have_posts()) : the_post(); ?> 
				<li>					
					<h4><a href="<?php the_permalink();?>" target="_blank"><?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 80,"……"); ?></a></h4>
					<div class="postauthor">
					<a><?php the_author();?></a> 发表于 <?php the_time('Y-n-j'); ?>
					</div>
				</li>		
				<?php endwhile; wp_reset_query();?> 
			</ul>
		</div>
		<?php } ?>
		<?php if(is_home()) {?>
		<div class="widget">
			<h3>博文最新评论</h3>			
			<?php newcomment(10);?>		
		</div>
		<?php } ?>
		<div class="widget">
			<img src="<?php bloginfo('template_url'); ?>/images/toutiao.jpg">
		</div>
	</div>