<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhml" <?php language_attributes(); ?>>
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="x-ua-compatible" content="ie=7" />
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<title><?php if ( $paged > 1 ) { echo ('第'); echo ($paged); echo '页_';}?><?php if (is_home () ) {bloginfo('name'); echo "_"; bloginfo('description');} elseif ( is_category() ) { single_cat_title(); echo "_"; bloginfo('name'); } elseif (is_single() || is_page() ) { single_post_title(); echo "_"; bloginfo('name'); } elseif (is_search() ) { bloginfo('name'); echo "search results:"; echo wp_specialchars($s); } else { wp_title('',true); echo "_"; bloginfo('name'); } ?></title>
<meta name="keywords" content="" />
<meta name="description" content="" />
<link rel="stylesheet" type="text/css" href="<?php bloginfo('stylesheet_url'); ?>" media="screen" />
<script type="text/javascript" src="<?php bloginfo('template_url');?>/javascript/jquery.min.js"></script>
<script type="text/javascript">
$(function(){
	$('.widget ul li:first').css('border','none');
	$('.sidebarComment:first').css('border','none');
	if($.browser.msie && ($.browser.version == '6.0' || $.browser.version == '7.0')) {
	alert("您的浏览器版本过低，请尽快升级IE8或更高版本的浏览器，否则会影响网页性能和操作！");
	return;
	}
});
</script>
<?php wp_head();?>
</head>
<body>
<div id="wraphead">
	<div class="wrap">
		<div class="header">
			<div class="logo">
				<h1><a href="<?php bloginfo('home'); ?>"><?php bloginfo('name'); ?></a></h1>
			</div>
			<div class="banner">
<script type="text/javascript"><!--
google_ad_client = "ca-pub-9642311778195731";
/* 658x80, 创建于 10-1-6 */
google_ad_slot = "5819779136";
google_ad_width = 468;
google_ad_height = 60;
//-->
</script>
<script type="text/javascript"
src="//pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
			</div>
		</div>
		
		<div class="menu">
			<ul>
				<?php wp_nav_menu( array('theme_location' =>'header-menu','container' => '','container_class' => '','depth' => 0,'items_wrap' => '%3$s')); ?> 
				<div class="navSearchInput">
					<form method="get" id="searchform" action="<?php bloginfo('url'); ?>/">
						<input type="text" class="field" name="s" id="s" placeholder="输入搜索内容">
						<input type="submit" class="submit" name="submit" id="searchsubmit" value="">
					</form>	
				</div>
			</ul>
		</div>
	</div>
</div>