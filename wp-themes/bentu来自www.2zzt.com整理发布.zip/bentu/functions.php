<?php
//隐藏admin Bar
function hide_admin_bar($flag) {
	return false;
}
add_filter('show_admin_bar','hide_admin_bar');
add_filter( 'pre_option_link_manager_enabled', '__return_true' );
register_nav_menus(
	array(
		'header-menu' => __( '顶部导航菜单' ),
		'footer-menu' => __( '底部页面菜单' ),			
	)
);
//首张图片
function catch_that_image() {
	global $post, $posts;
	$first_img = '';
	ob_start();
	ob_end_clean();
	$output = preg_match_all('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
	$first_img = $matches [1] [0];
	if(!empty($first_img)){
		echo "<div class='thumbnail'><img src='".$first_img."'width='150' height='150'/></div>";		
	}else { }	
}
//面包屑
function get_breadcrumbs(){
    global $wp_query; 
	if(is_home()) {
		echo '<a href="'. get_settings('home') .'">'. get_bloginfo('name') .'首页</a>';		
	}
    if ( !is_home() ){ 
        // Start the UL        
        // Add the Home link
        echo '<a href="'. get_settings('home') .'">'. get_bloginfo('name') .'</a>';
        if ( is_category() )
        {
            $catTitle = single_cat_title( "", false );
            $cat = get_cat_ID( $catTitle );
            echo " &raquo; ". get_category_parents( $cat, TRUE, " &raquo; " );
        }
        elseif ( is_archive() && !is_category() )
        {
            echo " &raquo; Archives";
        }
        elseif ( is_search() ) { 
            echo " &raquo; Search Results";
        }
        elseif ( is_404() )
        {
            echo " &raquo; 404 Not Found";
        }
        elseif ( is_single() )
        {
            $category = get_the_category();
            $category_id = get_cat_ID( $category[0]->cat_name );
            echo ' &raquo; '. get_category_parents( $category_id, TRUE, " &raquo; " );
            echo the_title('','', FALSE);
        }
        elseif ( is_page() )
        {
            $post = $wp_query->get_queried_object();
            if ( $post->post_parent == 0 ){
                echo " &raquo; ".the_title('','', FALSE);
            } else {
                $title = the_title('','', FALSE);
                $ancestors = array_reverse( get_post_ancestors( $post->ID ) );
                array_push($ancestors, $post->ID); 
                foreach ( $ancestors as $ancestor ){
                    if( $ancestor != end($ancestors) ){
                        echo ' &raquo; <a href="'. get_permalink($ancestor) .'">'. strip_tags( apply_filters( 'single_post_title', get_the_title( $ancestor ) ) ) .'</a>';
                    } else {
                        echo ' &raquo; '. strip_tags( apply_filters( 'single_post_title', get_the_title( $ancestor ) ) );
                    }
                }
            }
        } 
        // End the UL
    }
}
function wp_copyright() {
	$copyright = 'PGRpdiBjbGFzcz0iYm9rZTgiPlRoZW1lIEJ5IDxhIGhyZWY9Imh0dHA6Ly92N3YzLmNvbSIgdGFyZ2V0PSJfYmxhbmsiPndvcmRwcmVzc+aooeadvzwvYT48L2Rpdj4=';
	echo base64_decode($copyright);
}
add_filter('wp_footer','wp_copyright');
function copyrightDate() {
	global $wpdb;
	$copyright_dates = $wpdb->get_results("
		SELECT
			YEAR(min(post_date_gmt)) AS firstdate,
			YEAR(max(post_date_gmt)) AS lastdate
		FROM
			$wpdb->posts
		WHERE post_status = 'publish'
	");
	if($copyright_dates) {
		$date = date('Y-m-d');
		$date = explode('-', $date);
		$copyright = "Copyright &copy; " . $copyright_dates[0]->firstdate;
		if($copyright_dates[0]->firstdate != $date[0]) {
			$copyright .= '-' . $date[0];
		}
		echo $copyright;
	}
}
//最新评论
function newcomment($num=10) {
	global $wpdb; 	
	$sql = "SELECT DISTINCT ID, post_title, post_password, comment_ID, comment_post_ID, comment_author, comment_date_gmt, comment_approved, comment_type,comment_author_url, SUBSTRING(comment_content,1,30) AS com_excerpt FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts ON  ($wpdb->comments.comment_post_ID = $wpdb->posts.ID) WHERE comment_approved = '1' AND comment_type = '' AND post_password = '' AND comment_author_email != 'lanboke@qq.com' ORDER BY comment_date_gmt DESC LIMIT $num";
	$comments = $wpdb->get_results($sql);
	$output = $pre_HTML;
	foreach ($comments as $comment) {
		$output .= "\n<div class='sidebarComment'><div class='comment-author'>".strip_tags($comment->comment_author)."</div><div class='comment-con'>". strip_tags($comment->com_excerpt)."</div><div class='comment-com'><span>原文</span>" . "<a href=\"". get_permalink($comment->ID)."#comment-" . $comment->comment_ID . "\" title=\"".$comment->post_title . "\">".$comment->post_title."</a></div></div>"; 
	}
	$output .= $post_HTML; 
	echo $output;
}
function boke8_net_pagenavi($range = 9){
	global $paged, $wp_query;
	if ( !$max_page ) {$max_page = $wp_query->max_num_pages;}
	if($max_page > 1){if(!$paged){$paged = 1;}	
	if($paged != 1){echo "<a href='" . get_pagenum_link(1) . "' class='extend' title='跳转到首页'> 首页 </a>";}
	previous_posts_link(' 上一页 ');
    if($max_page > $range){
		if($paged < $range){for($i = 1; $i <= ($range + 1); $i++){echo "<a href='" . get_pagenum_link($i) ."'";
		if($i==$paged)echo " class='current'";echo ">$i</a>";}}
    elseif($paged >= ($max_page - ceil(($range/2)))){
		for($i = $max_page - $range; $i <= $max_page; $i++){echo "<a href='" . get_pagenum_link($i) ."'";
		if($i==$paged)echo " class='current'";echo ">$i</a>";}}
	elseif($paged >= $range && $paged < ($max_page - ceil(($range/2)))){
		for($i = ($paged - ceil($range/2)); $i <= ($paged + ceil(($range/2))); $i++){echo "<a href='" . get_pagenum_link($i) ."'";if($i==$paged) echo " class='current'";echo ">$i</a>";}}}
    else{for($i = 1; $i <= $max_page; $i++){echo "<a href='" . get_pagenum_link($i) ."'";
    if($i==$paged)echo " class='current'";echo ">$i</a>";}}
	next_posts_link(' 下一页 ');
    if($paged != $max_page){echo "<a href='" . get_pagenum_link($max_page) . "' class='extend' title='跳转到最后一页'> 末页 </a>";}}
}
function post_is_in_descendant_category( $cats,$_post = null ){
	foreach ( (array) $cats as $cat ) {
	$descendants = get_term_children( (int) $cat,'category');
		if ( $descendants &&in_category( $descendants,$_post ) )
		return true;
	}
	return false;
}
function get_category_root_id($cat){
	$this_category = get_category($cat);
	while($this_category->category_parent){
		$this_category = get_category($this_category->category_parent);
	}
	return $this_category->term_id;
}
### Function: Display timespan most Viewed Page/Post
function get_timespan_most_viewed($mode = '', $limit = 10, $chars = 0,$days = 30/*设置天数*/, $display = true) {
    global $wpdb;
    $limit_date = current_time('timestamp') - ($days*86400);
    $limit_date = date("Y-m-d H:i:s",$limit_date);
    $views_options = get_option('views_options');
    $where = '';
    $temp = '';
    $output = '';
    if(!empty($mode) && $mode != 'both') {
		$where = "post_type = '$mode'";
    } else {
		$where = '1=1';
    }
    $most_viewed = $wpdb->get_results("SELECT DISTINCT $wpdb->posts.*, (meta_value+0) AS views FROM $wpdb->posts LEFT JOIN $wpdb->postmeta ON $wpdb->postmeta.post_id = $wpdb->posts.ID WHERE post_date < '".current_time('mysql')."' AND post_date > '".$limit_date."' AND $where AND post_status = 'publish' AND meta_key = 'views' AND post_password = '' ORDER BY views DESC LIMIT $limit");
    if($most_viewed) {
		foreach ($most_viewed as $post) {
			$post_views = intval($post->views);
			$post_title = get_the_title($post);
			if($chars > 0) {
				$post_title = snippet_text($post_title, $chars);
			}
			$post_excerpt = views_post_excerpt($post->post_excerpt, $post->post_content, $post->post_password, $chars);
			$temp = stripslashes($views_options['most_viewed_template']);
			$temp = str_replace("%VIEW_COUNT%", number_format_i18n($post_views), $temp);
			$temp = str_replace("%POST_TITLE%", $post_title, $temp);
			$temp = str_replace("%POST_EXCERPT%", $post_excerpt, $temp);
			$temp = str_replace("%POST_CONTENT%", $post->post_content, $temp);
			$temp = str_replace("%POST_URL%", get_permalink($post), $temp);
			$output .= $temp;
		}	
    } else {
		$output = '<li>'.__('N/A', 'wp-postviews').'</li>'."\n";
    }
    if($display) {
		echo $output;
    } else {
		return $output;
    }
}
/* comment_mail_notify v1.0 by willin kan. (所有回复都发邮件) */
function comment_mail_notify($comment_id) {
	$comment = get_comment($comment_id);
	$parent_id = $comment->comment_parent ? $comment->comment_parent : '';
	$spam_confirmed = $comment->comment_approved;
	if (($parent_id != '') && ($spam_confirmed != 'spam')) {
		$wp_email = 'no-reply@' . preg_replace('#^www\.#', '', strtolower($_SERVER['SERVER_NAME'])); //e-mail 发出點, no-reply 可改為可用的 e-mail.
		$to = trim(get_comment($parent_id)->comment_author_email);
		$subject = '您在 [' . get_option("blogname") . '] 的留言有了回应';
		$message = '
		<div style="background-color:#eef2fa; border:1px solid #d8e3e8; color:#111; padding:0 15px; -moz-border-radius:5px; -webkit-border-radius:5px; -khtml-border-radius:5px;">
		<p>' . trim(get_comment($parent_id)->comment_author) . ', 您好!</p>
		<p>您曾在《' . get_the_title($comment->comment_post_ID) . '》的留言:<br />' . trim(get_comment($parent_id)->comment_content) . '</p>
		<p>' . trim($comment->comment_author) . ' 给您的回复:<br />' . trim($comment->comment_content) . '<br /></p>
		<p>您可以点击 <a href="' . htmlspecialchars(get_comment_link($parent_id)) . '">查看回复完整內容</a></p>
		<p>欢迎再度光临 <a href="' . get_option('home') . '">' . get_option('blogname') . '</a></p>
		<p>(此邮件由系统自动发送，请勿回复.)</p>
		</div>';
	$from = "From: \"" . get_option('blogname') . "\" <$wp_email>";
	$headers = "$from\nContent-Type: text/html; charset=" . get_option('blog_charset') . "\n";
	wp_mail( $to, $subject, $message, $headers );
	//echo 'mail to ', $to, '<br/> ' , $subject, $message; // for testing
	}
}
add_action('comment_post', 'comment_mail_notify');
// -- END ----------------------------------------
?>
<?php
//评论
function boke8_net_comment($comment, $args, $depth)
{
   $GLOBALS['comment'] = $comment; ?>
	<li id="comment-<?php comment_ID(); ?>">
		<div class="avatar">
			<a href="<?php comment_author_url() ?>" target="_blank"><?php if (function_exists('get_avatar') && get_option('show_avatars')) { echo get_avatar($comment, 59); } ?></a>
		</div>
        <div class="comment-all">			
			<div id="commentauthor-<?php comment_ID() ?>" class="comment-info">
				<span class="author"><?php comment_author() ?></span> <span>留言:</span>  
			</div>
			<div class="comment-con">
				<?php if($comment->comment_approved =='0') : ?>
				<em>你的评论正在审核，稍后会显示出来！</em>
				<?php endif;?>			
				<?php comment_text(); ?>
			</div>
			<div class="comment-meta">
				<span class="comment-time"><?php echo get_comment_time('Y-m-d'); ?></span>
				<span class="comment-reply"><?php comment_reply_link(array_merge( $args, array('reply_text' => '回复','depth' => $depth, 'max_depth' => $args['max_depth']))) ?></span>
			</div>
		</div>		
<?php } ?>