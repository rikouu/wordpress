<?php get_header();?>
<div id="container">
	<div class="main">
	<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>
		<div class="post">
			<h2><?php the_title(); ?></h2>			
			<div class="entry">				
				<?php the_content();?>
			</div>			
		</div>		
		<?php endwhile; ?>
		<?php comments_template('',ture); ?>
		<?php else : ?>	
		<div class="post">
		你要找的页面已删除或不存在
		</div>
		<?php endif;?>
	</div>	
<?php get_sidebar();?>
</div>
<?php get_footer();?>