<script type="text/javascript"><!--
google_ad_client = "ca-pub-9642311778195731";
/* 300x250, 创建于 10-1-6 */
google_ad_slot = "7322768119";
google_ad_width = 300;
google_ad_height = 250;
//-->
</script>
<script type="text/javascript"
src="//pagead2.googlesyndication.com/pagead/show_ads.js">
</script>