<?php get_header();?>
<div id="container">
	<div class="main">	
		<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>
		<div class="post" id="post-<?php the_ID(); ?>">
			<h2><a target="_blank" href="<?php the_permalink(); ?>" title="Permalink to <?php the_title(); ?>" rel="bookmark"><?php the_title(); ?></a></h2>
			<div class="postmeta">
				<span class="author"><?php if (get_the_author_url()) { ?><a href="<?php the_author_url(); ?>"><?php the_author(); ?></a><?php } else { the_author(); } ?></span>
				<span class="time">发表于：<?php the_time('Y-n-j G:H'); ?></span>
				<span class="cats">分类：<?php the_category(' &bull; '); ?> </span>
				<span class="tags">标签：<?php the_tags('','，',''); ?></span>
				<span class="views"><?php if(function_exists('the_views')) { the_views(); } ?></span>
			</div>
			<div class="entry">				                
				<?php catch_that_image();?>
				<p> <?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 350,"……"); ?></p>
				<a target="_blank" class="readall" href="<?php the_permalink() ?>"> 阅读全文</a>
				<div class="clearfix"></div>
			</div>
		</div>
		<?php endwhile; ?>
		<div class="pagenavi">
			<?php boke8_net_pagenavi(6);?>
		</div>
		<?php else : ?>	
		<div class="post">
		你要找的页面已删除或不存在
		</div>
		<?php endif;?>		
	</div>	
<?php get_sidebar();?>
</div>
<?php get_footer();?>