<?php
	if(isset($_SERVER['SCRIPT_FILENAME']) && 'comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
	die('please do not load this page directly. Thanks!');
?>
<div class="comments">		
	<div class="commentform" id="respond">	
		<div class="comment-form">
		<?php
			if(!comments_open()):
				elseif (get_option('comment_registration') && !is_user_logged_in()) :
		?>
			<div>你必须 <a href="<?php echo wp_login_url( get_permalink() ); ?>">登录</a> 才能发表评论.</div>
		<?php else : ?>
			<form id="commentform" name="commentform" action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post">
			<?php if(!is_user_logged_in()) :?>
				<p>
				<input type="text" name="author" class="text" id="author" value="<?php echo $comment_author; ?>" placeholder="昵称" tabindex="1"/><label>昵称</label>
				</p>
				<p>
				<input type="text" name="email" class="text" id="email" value="<?php echo $comment_author_email; ?>"  placeholder="邮箱地址" tabindex="2"/><label>邮箱地址</label>
				</p>
				<p>
				<input type="text" name="url" class="text" id="url" value="<?php echo $comment_author_url; ?>" placeholder="网站地址" tabindex="3"/><label>网站地址</label>
				</p>
			<?php else : ?>
			<?php endif; ?>	
				<textarea name="comment" id="comment" class="textarea" placeholder="来说几句话，你有什么看法" tabindex="4"></textarea>
				<div class="face">
					<div class="face-top">
						<input type="submit" name="submit" id="submit" class="submit" tabindex="5" value="提交评论"/>
					</div>
				</div>
				<?php cancel_comment_reply_link(); ?>
				<?php comment_id_fields(); ?>
				<?php do_action('comment_form',$post->ID);?>
			</form>
		<?php endif;?>	
		</div>
	</div>
</div>
<div class="commentslist">
	<h3>已有<em><?php comments_number('0','1','%'); ?></em>条评论，您也掺合一下吧！</h3>	
	<ol>
	<?php if (!empty($post->post_password) && $_COOKIE['wp-postpass_' . COOKIEHASH] != $post->post_password) {?>
		<li><p>请输入密码再查看评论内容.</p></li>
	<?php } else if ( !comments_open() ) {?>
		<li><p>评论功能已经关闭!</p></li>
	<?php } else if ( !have_comments() ) { } else {?>
	<?php wp_list_comments('type=comment&callback=boke8_net_comment');?>
		<?php
			if (get_option('page_comments')) {
				$comment_pages = paginate_comments_links('echo=0');
				if ($comment_pages) {
					echo '<li class="page_navi">';
					echo $comment_pages;
					echo '</li>';
				}
			}		
		?>
	<?php } ?>
	</ol>
</div>