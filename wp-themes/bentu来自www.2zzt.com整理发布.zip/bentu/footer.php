<div id="footer">	
	<div class="foot">
		<div class="partners">
		<?php if(is_home()){?>
			<h3>合作伙伴：</h3>
			<ul>
			<?php wp_list_bookmarks('show_description=1&title_li=&categorize=0'); ?>
			</ul>
		<?php } ?>
		</div>
		<div class="copyright">
		<?php copyrightDate();?> <a href="<?php bloginfo('home'); ?>"><?php bloginfo('name'); ?></a>. Powered By <a href="http://www.2zzt.com" target="_blank" rel="nofollow">WordPress</a>
		</div>
	</div>
</div>
<?php wp_footer();?>
</body>
</html>