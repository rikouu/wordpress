<?php get_header();?>
<div id="container">
	<div class="main">
	<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>
		<div class="post">
			<h2><?php the_title(); ?></h2>
			<div class="postmeta">
				<span class="author"><?php if (get_the_author_url()) { ?><a href="<?php the_author_url(); ?>"><?php the_author(); ?></a><?php } else { the_author(); } ?></span>
				<span class="time">发表于：<?php the_time('Y-n-j G:H'); ?></span>
				<span class="cats">分类：<?php the_category(' &bull; '); ?> </span>
				<span class="tags">标签：<?php the_tags('','，',''); ?></span>
				<span class="views"><?php if(function_exists('the_views')) { the_views(); } ?></span>
			</div>
			<div class="entry">				
				<?php the_content();?>				
				<div class="clearfix"></div>
				<div class="post-tags">
					标签：<?php the_tags('','，',''); ?>
				</div>				
			</div>			
		</div>		
		<div class="related">		
			<h3><span>相关文章</span></h3>
			<ul>
			<?php
				$tags = wp_get_post_tags($post->ID);
				if ($tags) {
				$first_tag = $tags[0]->term_id;
				$args=array(
					'tag__in' => array($first_tag),
					'post__not_in' => array($post->ID),
					'showposts'=>10,
					'caller_get_posts'=>1
				);
				$my_query = new WP_Query($args);
				if( $my_query->have_posts() ) {
				while ($my_query->have_posts()) : $my_query->the_post(); ?>
				<li><span><?php the_time('Y-n-j G:H'); ?></span><a href="<?php the_permalink(); ?>" target="_blank"><?php the_title();?></a></li>
				<?php endwhile; } } wp_reset_query(); ?>				
			</ul>
		</div>
			<?php endwhile; ?>
			<?php comments_template('',ture); ?>
		<?php else : ?>	
		<div class="post">
		你要找的页面已删除或不存在
		</div>
		<?php endif;?>
	</div>	
<?php get_sidebar();?>
</div>
<?php get_footer();?>