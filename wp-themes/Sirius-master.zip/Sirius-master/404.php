<?php get_header();?>
<div id="main">
   <section>
        <div class="container">
            <div class="err404">
                <img class="err404" src="<?php echo get_template_directory_uri(); ?>/images/404.gif" />
            </div>
        </div>
    </section>
</div>
<?php get_footer(); ?>