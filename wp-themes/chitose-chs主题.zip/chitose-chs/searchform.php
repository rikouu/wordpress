<form id="searchform" class="searchform" action="<?php bloginfo('url'); ?>" method="get" role="Search">
	<input id="s" type="text" name="s" value="搜　索"></input>
	<div id="searchsubmit"></div>
</form>