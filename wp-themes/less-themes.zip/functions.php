<?php

// Define the version as a constant so we can easily replace it throughout the theme
define( 'LESS_VERSION', 1.1 );

/*-----------------------------------------------------------------------------------*/
/* Add Rss to Head */
/*-----------------------------------------------------------------------------------*/
add_theme_support( 'automatic-feed-links' );


/*-----------------------------------------------------------------------------------*/
/* register main menu */
/*-----------------------------------------------------------------------------------*/
register_nav_menus(
	array(
		'primary'	=>	__( '导航菜单', 'less' ),
	)
);


add_filter('show_admin_bar', 'hide_admin_bar');
add_filter('pre_option_link_manager_enabled', '__return_true');
add_action('wp_print_scripts', 'deel_disable_autosave');
function deel_disable_autosave() {
    wp_deregister_script('autosave');
}
remove_action('pre_post_update', 'wp_save_post_revision');
add_filter( 'max_srcset_image_width', create_function( '', 'return 1;' ) );

function less_avatar_cache($avatar) {
    $avatar = preg_replace('/.*\/avatar\/(.*)\?s=([\d]+)&.*/','<img src="https://secure.gravatar.com/avatar/$1?s=$2" class="avatar avatar-$2" height="50px" width="50px">',$avatar);

    return $avatar;
}
add_filter('get_avatar', 'less_avatar_cache', 10, 3);

function refused_spam_comments($comment_data) {
    $pattern = '/[一-龥]/u';
    $jpattern = '/[ぁ-ん]+|[ァ-ヴ]+/u';
    if (!preg_match($pattern, $comment_data['comment_content'])) {
        err(__('写点汉字吧，博主外语很捉急！You should type some Chinese word!'));
    }
    if (preg_match($jpattern, $comment_data['comment_content'])) {
        err(__('日文滚粗！Japanese Get out！日本语出て行け！ You should type some Chinese word！'));
    }
    return ($comment_data);
}
    add_filter('preprocess_comment', 'refused_spam_comments');

function less_remove_open_sans_from_wp_core() {
        wp_deregister_style('open-sans');
        wp_register_style('open-sans', false);
        wp_enqueue_style('open-sans', '');
    }
add_action('init', 'less_remove_open_sans_from_wp_core');

function less_upload_filter($file) {
    $time = date("YmdHis");
    $file['name'] = $time . "" . mt_rand(1, 100) . "." . pathinfo($file['name'], PATHINFO_EXTENSION);
    return $file;
}
add_filter('wp_handle_upload_prefilter', 'less_upload_filter');
/*-----------------------------------------------------------------------------------*/
/* Enque Styles and Scripts */
/*-----------------------------------------------------------------------------------*/

function less_scripts()  {

	// theme styles
	wp_enqueue_style( 'less-style', get_template_directory_uri() . '/style.css', '10000', 'all' );

	// add fitvid
	wp_enqueue_script( 'less-fitvid', get_template_directory_uri() . '/js/jquery.fitvids.js', array( 'jquery' ), LESS_VERSION, true );

	// add theme scripts
	wp_enqueue_script( 'less', get_template_directory_uri() . '/js/theme.min.js', array(), LESS_VERSION, true );

}
add_action( 'wp_enqueue_scripts', 'less_scripts' );