<!DOCTYPE HTML>
<HTML>
<HEAD>
<meta charset="UTF-8" />
<meta name="robots" content="none" />
<TITLE>404 Not Found</TITLE>
<style>
*{color:#333;font-family:"Microsoft Yahei","宋体",Tahoma,Helvetica,Arial,"SimSun",sans-serif;font-weight:normal;margin:0;}
html,body{height:100%;background:#fff;}
h1{font-size:100px;}
table{width:100%;height:100%;border:0px;}
td{text-align:center;}
a{text-decoration:none;}
a:hover{text-decoration: underline;}
</style>
</HEAD>
<BODY>
<table cellspacing="0" cellpadding="0">
<tr>
<td><table cellspacing="0" cellpadding="0">
<tr>
<td><h1>404</h1>
<h3>大事不妙啦！</h3><br/>
你访问的页面好像不小心被博主给弄丢了~<br/><br/>
<a href="<?php bloginfo('siteurl'); ?>">惩罚博主 ></a><br/><br/>
</td>
</tr>
</table></td>
</tr>
</table>
</BODY>
</HTML>