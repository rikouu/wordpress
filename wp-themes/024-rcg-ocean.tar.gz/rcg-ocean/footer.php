<div id="footer">
<!-- If you'd like to support WordPress, having the "powered by" link somewhere on your blog is the best way; it's our only promotion or advertising. -->
	<p>
		<?php printf(__('%1$s is proudly powered by %2$s', 'rcg-forest'), get_bloginfo('name'),
		'<a href="http://wordpress.org/">WordPress</a>'); ?>
                <br/>
                <?php _e('Theme:','rcg-forest'); ?> <a href="http://blog.rcg-pt.net/rcg-forest/">RCG Forest</a>,
                <?php _e('by','rcg-forest'); ?> <a href="http://rcg-pt.net">Rui Carlos A. Gonçalves</a>
	</p>
</div>
</div>
<?php wp_footer(); ?>
</body>
</html>
