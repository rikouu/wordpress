<?php get_header(); ?>

	<div id="content" class="twocolumns">

		<h2 class="center"><?php _e('Error 404 - Not Found', 'rcg-forest'); ?></h2>

	</div>

<?php get_sidebar(); ?>

<?php get_footer(); ?>
