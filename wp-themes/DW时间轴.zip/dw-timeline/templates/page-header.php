<div class="page-header">
  <h1>
    <?php echo dw_timeline_title(); ?>
  </h1>
</div>
