<?php
/*
Template Name: Blog
*/
?>			

<?php get_header(); ?> 
	<div class="main-content">
		<?php colabs_breadcrumbs();?>
		
		<div class="wrap-post">	
			<?php
			query_posts( array(
							'paged' => $paged,
							'post_type' => 'post',
						));
			?>
			
			<?php if (have_posts()) : ?> 

				<?php while (have_posts()) : the_post(); ?>						
					<?php get_template_part('content','post');?>
				<?php endwhile; ?>	
						
			<?php endif; ?>	
								
		</div><!-- .wrap-post -->
		<?php colabs_pagination();?>
	</div><!-- .main-content -->
<?php get_footer(); ?>