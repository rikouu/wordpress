</div>
			</div>
	</div>

</div>
	<div class="footer row">
		<p><?php colabs_credit();?></p>
	</div>
</div>
<?php wp_footer(); ?>
</body>
</html>