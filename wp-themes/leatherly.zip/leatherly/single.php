<?php get_header();  global $colabs_options; ?> 
	<div class="main-content">
		<div class="wrap-post">			
			<?php if (have_posts()) : ?> 
							
				<?php while (have_posts()) : the_post(); ?>
				<div <?php post_class('post latest-post');?>>	
					<div class="post-icon"><span id="icon-post"></span></div>
					<div class="entry-content">
						<h3 class="post-title"><?php the_title(); ?></h3>
						<p class="entry-meta">
						  <span class="entry-author">
						  <?php 
							_e('By ','colabsthemes');
							the_author_posts_link();
						  ?>
						  </span>&nbsp;/&nbsp;
						  <span class="entry-date"><?php the_time(get_option('date_format'));?></span>&nbsp;/&nbsp;
						  <span class="entry-category"><?php the_category(', ');?></span>&nbsp;/&nbsp;
						  <a class="entry-comment-count" href="<?php comments_link(); ?>" title=""><?php comments_number( __('No Comment','colabsthemes'), __('1 Comment','colabsthemes'), __('% Comments','colabsthemes') ); ?></a>
						</p>
						<?php   
						$single_top = get_post_custom_values("colabs_single_top");
						if (($single_top[0]!='')||($single_top[0]=='none')){
						?>
							<p class="entry-image">				
							<?php 
							if ($single_top[0]=='single_video'){
								$embed = colabs_get_embed('colabs_embed',590,332,'single_video',$post->ID);
								if ($embed!=''){
									echo $embed; 
								}
							}elseif($single_top[0]=='single_image'){
								colabs_image('width=590');				
							}										
							?>
							</p>
						<?php }?>		
						<?php the_content(); ?>

						<?php wp_link_pages(); ?>
					</div>
					<?php echo colabs_share();?>
					<?php comments_template( '', true ); ?><!-- #comments -->	
				</div><!-- .latest post -->	
				<?php endwhile; ?>	
							
			<?php endif; ?>	
													
		</div><!-- .wrap-post -->
	</div><!-- .main-content -->
<?php get_footer(); ?>