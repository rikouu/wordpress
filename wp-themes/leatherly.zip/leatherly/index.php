<?php get_header();?> 
	<div class="main-content">
		<div class="wrap-post">			
		<?php 
		$home = get_option('colabs_post_order');
		$portfolio = get_option('colabs_portfolio_order');
		$social = get_option('colabs_social_order');
		$author = get_option('colabs_author_order');
		$contact = get_option('colabs_contact_order');
		$content = array(
						$home => 'home',
						$portfolio => 'portfolio',
						$social => 'social',
						$author => 'author',
						$contact => 'contact',
						);
		for($i=1;$i<=5;$i++):
			get_template_part('content',$content[$i]);
		endfor;
		?>	
								
		</div><!-- .wrap-post -->
	</div><!-- .main-content -->
<?php get_footer(); ?>