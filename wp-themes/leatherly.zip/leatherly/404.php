<?php get_header();?> 
	<div class="main-content">
		<div class="wrap-post">			
			<?php if (have_posts()) : ?> 
							
					<div class="post latest-post">
						<?php while (have_posts()) : the_post(); ?>
							
							<div class="post-icon"><span id="home"></span></div>
							<div class="entry-content">
								<h3 class="post-title"><?php _e('Page Not Found','colabsthemes');?>	
								<p><?php _e('It seems that page you were looking for doesn\'t exist.','colabsthemes');?></p>
							</div>

						<?php endwhile; ?>	
						
					</div><!-- .latest post -->
			<?php endif; ?>	
													
		</div><!-- .wrap-post -->
	</div><!-- .main-content -->
<?php get_footer(); ?>