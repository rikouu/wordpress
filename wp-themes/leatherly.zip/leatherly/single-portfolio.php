<?php get_header();?> 
	<div class="main-content">
		<div class="wrap-post">			
			<?php if (have_posts()) : ?> 
								
				<?php while (have_posts()) : the_post(); ?>
				<div <?php post_class('post latest-post');?>>	
					<div class="post-icon"><span id="portfolio"></span></div>
					<div class="entry-content">
						<h3 class="post-title"><?php the_title(); ?></h3>
						<p class="entry-meta">
						  <span class="entry-author">
						  <?php 
							_e('By ','colabsthemes');
							the_author_posts_link();
						  ?>
						  </span>
						  <span class="entry-date"><?php the_time(get_option('date_format'));?></span>		 
						</p>

						<p class="entry-image">				
							<?php colabs_image('width=590');?>
						</p>
		
						<?php the_content(); ?>
					</div>
					<?php echo colabs_share();?>
				</div><!-- .latest post -->	
				<?php endwhile; ?>	
						
	
			<?php endif; ?>	
													
		</div><!-- .wrap-post -->
	</div><!-- .main-content -->
<?php get_footer(); ?>