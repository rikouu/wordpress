<div id="comments">

	<?php if ( have_comments() ) : ?>
		<h3 class="comment-header">
			<?php
			printf( _n( '%1$s Comment', '%1$s Comments', get_comments_number(), 'colabsthemes' ), '<span class="comment-count">' . number_format_i18n( get_comments_number() ) . '</span>' );
			?>
		</h3>

		<ol class="commentlist">
			<?php wp_list_comments( array(
				'type'			=> 'all',
				'callback' 	=> 'colabs_list_comments',
				'max_depth'	=> 4
			) ); ?>
		</ol>

		<?php
			// Are there comments to navigate through?
			if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) :
		?>
		<nav class="navigation comment-navigation" role="navigation">
			<div class="nav-previous"><?php previous_comments_link( __( '&larr; Older Comments', 'colabsthemes' ) ); ?></div>
			<div class="nav-next"><?php next_comments_link( __( 'Newer Comments &rarr;', 'colabsthemes' ) ); ?></div>
		</nav>
		<?php endif; // Check for comment navigation ?>
		
	<?php
		/* If there are no comments and comments are closed, let's leave a little note, shall we?
		 * But we don't want the note on pages or post types that do not support comments.
		 */
		elseif ( ! comments_open() && ! is_page() && post_type_supports( get_post_type(), 'comments' ) ) :
	?>
		<p class="nocomments"><?php _e( 'Comments are closed.', 'colabsthemes' ); ?></p>
	<?php endif; ?>

	<?php
	// Custom comment form
	$req = get_option( 'require_name_email' );
	$aria_req = ( $req ? " aria-required='true'" : '' );
	$fields = array(
		'author'	=> '<p class="comment-form-author">
							<label>'. __('Name:','colabsthemes') .'</label>
							<input id="author" name="author" type="text" value="' . esc_attr( $commenter['comment_author'] ) . '" size=""' . $aria_req . ' />' . ( $req ? '' : '' ) . '
						</p>',
		'email'		=> '<p class="comment-form-email">
							<label>'. __('Email:','colabsthemes') .'</label>
							<input id="email" name="email" type="text" value="' . esc_attr(  $commenter['comment_author_email'] ) . '" size=""' . $aria_req . ' />' . ( $req ? '' : '' ) .'
						</p>',
		'url'		=> '<p class="comment-form-url">
							<label>'. __('Website:','colabsthemes') .'</label>
							<input id="url" name="url" type="text" value="' . esc_attr( $commenter['comment_author_url'] ) . '" size="" />
						</p>'
	);

	comment_form(array(
		'comment_field'        => '<p class="comment-form-comment">
										<label>'. __('Comment','colabsthemes') .'</label>
										<textarea id="comment" name="comment" cols="45" rows="8" aria-required="true"></textarea>
									</p>',
		'fields'               => apply_filters( 'comment_form_default_fields', $fields ),
		'comment_notes_before' => '',
		'comment_notes_after' => '',
		'title_reply'          => __( 'Add comment','colabsthemes' ),
		'title_reply_to'       => __( '' ),
		'label_submit'         => __( 'Post Comment' ,'colabsthemes'),
		'cancel_reply_link'    => __( 'Cancel' ,'colabsthemes'),
	));
	?>
	
</div><!-- #comments -->