<div class="post contact">
<?php if(isset($emailSent) && $emailSent == true) { ?>
            
		<p class="info"><?php _e('Your email was successfully sent.', 'colabsthemes'); ?>&nbsp;<?php _e('We will reply your message immediately.', 'colabsthemes'); ?></p>

		<?php } else { ?>

		<?php if(isset($hasError) || isset($captchaError) ) { ?>
			<div class="errordiv"><?php _e('There was an error submitting the form.', 'colabsthemes'); ?></div>
		<?php } ?>
		
		<?php if ( get_option('colabs_contactform_email') == '' ) { ?>
			<div class="errordiv"><?php _e('E-mail has not been setup properly. Please add your contact e-mail.', 'colabsthemes'); ?></div>
		<?php } ?>

		<div class="home-icon"><span id="contact"> </span></div>
		<form method="post" action="" id="frmcontact" >
			<p class="title">Let's Work Together</p>
			<p class="left">
				<span>
				<input type="text" name="name" placeholder="Name" value="<?php if(isset($_POST['name'])) echo $_POST['name'];?>" ></span>
				<?php if($nameError != '') { ?>
					<span class="error"><?php echo $nameError;?></span> 
				<?php } ?>
				
				<?php 
				$need = get_option('colabs_you_need');
				$array_needs = split(',',$need);
				if($array_needs){
				?>
				<span>
					<select name="need">
						<option value=""><?php _e('What do you need?','colabsthemes');?></option>
						<?php foreach ($array_needs as $need_item){?>
						<option value="<?php echo trim($need_item);?>"><?php echo trim($need_item);?></option>
						<?php }?>
					</select>
					<?php if($needError != '') { ?>
						<span class="error"><?php echo $needError;?></span> 
					<?php } ?>
				</span>
				<?php }?>
			</p>
			<p class="right">
				<span>
				<input type="text" name="email" placeholder="Email Address" value="<?php if(isset($_POST['email'])) echo $_POST['email'];?>" > </span>
				<?php if($nameError != '') { ?>
					<span class="error"><?php echo $emailError;?></span> 
				<?php } ?>
				
				<?php 
				$budget = get_option('colabs_budget');
				$array_budgets = split(',',$budget);
				if($array_budgets){
				?>
				<span>
					<select name="budget">
						<option value=""><?php _e('Budget','colabsthemes');?></option>
						<?php foreach ($array_budgets as $budget_item){?>
						<option value="<?php echo trim($budget_item);?>"><?php echo trim($budget_item);?></option>
						<?php }?>
					</select>
					<?php if($budgetError != '') { ?>
						<span class="error"><?php echo $budgetError;?></span> 
					<?php } ?>
				</span>
				<?php }?>
			</p>
			
			<p>
				<textarea name="message" rows="10" placeholder="Your Message"><?php if(isset($_POST['message'])) { if(function_exists('stripslashes')) { echo stripslashes($_POST['message']); } else { echo $_POST['message']; } } ?></textarea>
				<?php if($messageError != '') { ?>
					<span class="error"><?php echo $messageError;?></span> 
				<?php } ?>
			</p>
			
			<p class="alignright">
				<input type="hidden" name="submitted" id="submitted" value="true" >
				<input type="submit" name="submit" value="Send Now">
			</p>
		</form>
	<?php }?>
</div><!-- Contact -->