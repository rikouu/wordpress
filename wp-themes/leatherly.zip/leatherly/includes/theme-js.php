<?php
if (!is_admin()) add_action( 'wp_enqueue_scripts', 'colabsthemes_add_javascript' );

if (!function_exists('colabsthemes_add_javascript')) {

  function colabsthemes_add_javascript () {
    
    wp_enqueue_style('googlefont', 'http://fonts.googleapis.com/css?family=Lora:400,700' );
    wp_enqueue_style('fancybox-css', get_template_directory_uri() . '/includes/js/fancybox/jquery.fancybox-1.2.6.css' );
    wp_enqueue_style('colabs-css', get_template_directory_uri() . '/includes/css/colabs-css.css' );
    wp_enqueue_style('style', get_bloginfo( 'stylesheet_url' ) );
    
    wp_enqueue_script('jquery');  
    wp_enqueue_script('jquery-ui-core');
    wp_enqueue_script('jquery-ui-widget');
    wp_enqueue_script('jquery-ui-mouse');
    wp_enqueue_script('jquery-ui-draggable');
    wp_enqueue_script('jquery-ui-sortable');
      
    wp_enqueue_script( 'fancy-box', trailingslashit( get_template_directory_uri() ) . 'includes/js/fancybox/jquery.fancybox-1.2.6.pack.js', array('jquery') );
    wp_enqueue_script( 'zero', trailingslashit( get_template_directory_uri() ) . 'includes/js/zero.js', array('jquery') );
  
    $data = array(
      'ajaxurl' => admin_url('admin-ajax.php')
    );
    wp_localize_script('zero','config', $data);
  
    /* We add some JavaScript to pages with the comment form to support sites with threaded comments (when in use). */        
    if ( is_singular() && get_option( 'thread_comments' ) ) wp_enqueue_script( 'comment-reply' );
    
  } /* // End colabsthemes_add_javascript() */
  
} /* // End IF Statement */


/**
 * Send Contact via Ajax
 */
add_action( 'wp_ajax_send-contact', 'send_contact_message' );
add_action( 'wp_ajax_nopriv_send-contact', 'send_contact_message' );

function send_contact_message() {
  $response = array(
    'error' => true
  );
  $errors = array();
  $hasError = false;

  //If the form is submitted
  if( isset($_POST['submitted']) ) {

    //Check to make sure that the name field is not empty
    if( trim($_POST['name']) === '' ) {
      $errors[] = __('You forgot to enter your name.', 'colabsthemes');
      $hasError = true;
    } else {
      $name = trim($_POST['name']);
    }

    //Check to make sure sure that a valid email address is submitted
    if(trim($_POST['email']) === '')  {
      $errors[] = __('You forgot to enter your email .', 'colabsthemes');
      $hasError = true;
    } else if (!eregi("^[A-Z0-9._%-]+@[A-Z0-9._%-]+\.[A-Z]{2,4}$", trim($_POST['email']))) {
      $errors[] = __('You entered an invalid email .', 'colabsthemes');
      $hasError = true;
    } else {
      $email = trim($_POST['email']);
    }

    //Check to make sure message were entered 
    if(trim($_POST['message']) === '') {
      $errors[] = __('You forgot to enter your message.', 'colabsthemes');
      $hasError = true;
    } else {
      if(function_exists('stripslashes')) {
        $message = stripslashes(trim($_POST['message']));
      } else {
        $message = trim($_POST['message']);
      }
    }

    //Check to make sure need were entered  
    if(function_exists('stripslashes')) {
      $need = stripslashes(trim($_POST['need']));
    } else {
      $need = trim($_POST['need']);
    }

    //Check to make sure budget were entered  
    if(function_exists('stripslashes')) {
      $budget = stripslashes(trim($_POST['budget']));
    } else {
      $budget = trim($_POST['budget']);
    }

    //If there is no error, send the email
    if(!$hasError) {
      
      $emailTo = get_option('colabs_contactform_email'); 
      $subject = __('Contact Form Submission from ', 'colabsthemes').$name;
      $sendCopy = trim($_POST['sendCopy']);
      $body = __("Name: $name \n\nEmail: $email \n\nMessage: $message \n\nNeed: $need \n\nBudget : $budget", 'colabsthemes');
      $headers = __('From: ', 'colabsthemes') .'"'.$name.'" <'.$email.'>' . "\r\n" . __('Reply-To: ','colabsthemes') . $email;

      $send_mail = wp_mail($emailTo, $subject, $body, $headers);

      if( !is_wp_error($send_mail) ) {
        $response['error'] = false;
        $response['messages'] = array(
          __('Message sent successfully', 'colabsthemes')
        );
        $response['debug'] = array(
          'name' => $name,
          'email' => $email
        );
      }

      else {
        $response['messages'] = array(
          __('Failed to send email, please try again later', 'colabsthemes')
        );
      }
    }

    else {
      $response['messages'] = $errors;
    }

    header("Content-Type: application/json");
    echo json_encode( $response );
  }
  exit;
}
