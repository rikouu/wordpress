<?php
// Register Custom Post Type
function colabs_portfolio_register() {

	$labels = array(
		'name'                => _x( 'Portfolios', 'Post Type General Name', 'colabsthemes' ),
		'singular_name'       => _x( 'Portfolio', 'Post Type Singular Name', 'colabsthemes' ),
		'menu_name'           => __( 'Portfolio', 'colabsthemes' ),
		'parent_item_colon'   => __( 'Parent Portfolio:', 'colabsthemes' ),
		'all_items'           => __( 'All Portfolios', 'colabsthemes' ),
		'view_item'           => __( 'View Portfolio', 'colabsthemes' ),
		'add_new_item'        => __( 'Add New Portfolio', 'colabsthemes' ),
		'add_new'             => __( 'Add New', 'colabsthemes' ),
		'edit_item'           => __( 'Edit Portfolio', 'colabsthemes' ),
		'update_item'         => __( 'Update Portfolio', 'colabsthemes' ),
		'search_items'        => __( 'Search Portfolio', 'colabsthemes' ),
		'not_found'           => __( 'Not found', 'colabsthemes' ),
		'not_found_in_trash'  => __( 'Not found in Trash', 'colabsthemes' ),
	);
	$args = array(
		'label'               => __( 'Portfolio', 'colabsthemes' ),
		'description'         => __( 'Portfolio Post Type', 'colabsthemes' ),
		'labels'              => $labels,
		'supports'            => array( 'title', 'editor', 'author', 'thumbnail', ),
		'hierarchical'        => false,
		'public'              => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'menu_position'       => 5,
		'can_export'          => true,
		'has_archive'         => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'capability_type'     => 'page',
    'rewrite'             => array( 'slug' => 'portfolio-item'),
	);
	register_post_type( 'portfolio', $args );

}

// Hook into the 'init' action
add_action( 'init', 'colabs_portfolio_register', 0 );

add_filter("manage_edit-portfolio_columns", "portfolio_edit_columns");   
  
function portfolio_edit_columns($columns){  
  $columns = array(  
      "cb" => "<input type=\"checkbox\" />",  
      "title" => __("Portfolio","colabsthemes"),  
      "featured" => __("Featured","colabsthemes"),
      "date" => __("Date","colabsthemes"),
        
  );  
  
  return $columns;  
}  

add_action("manage_portfolio_posts_custom_column",  "portfolio_custom_columns"); 
  
function portfolio_custom_columns($column){  
  global $post;  
  switch ($column)  
  {      
		case "featured" :
			if (get_post_meta($post->ID,'colabs_featured',true)=='true') echo '<a href="'.$url.'"><img src="'.get_template_directory_uri().'/includes/images/featured.png" alt="yes" />';
			else echo '<img src="'.get_template_directory_uri().'/includes/images/featured-off.png" alt="no" />';
		break;	
  }  
}  
?>