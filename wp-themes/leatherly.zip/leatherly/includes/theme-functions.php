<?php 
/*-----------------------------------------------------------------------------------

TABLE OF CONTENTS

- Excerpt
- Page navigation
- CoLabsTabs - Popular Posts
- CoLabsTabs - Latest Posts
- CoLabsTabs - Latest Comments
- Post Meta
- Dynamic Titles
- WordPress 3.0 New Features Support
- using_ie - Check IE
- post-thumbnail - WP 3.0 post thumbnails compatibility
- automatic-feed-links Features
- Twitter button - twitter
- Facebook Like Button - fblike
- Facebook Share Button - fbshare
- Google +1 Button - [google_plusone]
-- Load Javascript for Google +1 Button
- colabs_link - Alternate Link & RSS URL
- Open Graph Meta Function
- colabs_share - Twitter, FB & Google +1
- Post meta Portfolio
- WordPress Customizer

-----------------------------------------------------------------------------------*/

/*-----------------------------------------------------------------------------------*/
/* SET GLOBAL CoLabs VARIABLES
/*-----------------------------------------------------------------------------------*/

// Slider Tags
	$GLOBALS['slide_tags_array'] = array();
// Duplicate posts 
	$GLOBALS['shownposts'] = array();

/*-----------------------------------------------------------------------------------*/
/* Excerpt
/*-----------------------------------------------------------------------------------*/

//Add excerpt on pages
if(function_exists('add_post_type_support'))
add_post_type_support('page', 'excerpt');

/** Excerpt character limit */
/* Excerpt length */
function colabs_excerpt_length($length) {
if( get_option('colabs_excerpt_length') != '' ){
        return get_option('colabs_excerpt_length');
    }else{
        return 45;
    }
}
add_filter('excerpt_length', 'colabs_excerpt_length');

/** Add excerpt more */
function colabs_excerpt_more($more) {
    global $post;
	return '<span class="more"><a href="'. get_permalink($post->ID) . '">'. __( 'Read more', 'colabsthemes' ) . '&hellip;</a></span>';
}
add_filter('excerpt_more', 'colabs_excerpt_more');


/*-----------------------------------------------------------------------------------*/
/* using_ie - Check IE */
/*-----------------------------------------------------------------------------------*/
//check IE
function using_ie()
{
    if (isset($_SERVER['HTTP_USER_AGENT']) && 
    (strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE') !== false))
        return true;
    else
        return false;    
}
	
/*-----------------------------------------------------------------------------------*/	
/* Search Form*/
/*-----------------------------------------------------------------------------------*/
function custom_search( $form ) {

    $form = '<form role="search" method="get" id="searchform" action="' . home_url( '/' ) . '" >
    <input type="text" placeholder="Search" value="' . get_search_query() . '" name="s" id="s" />
    </form>';

    return $form;
}

add_filter( 'get_search_form', 'custom_search' );

/*-----------------------------------------------------------------------------------*/
/* CoLabs - Footer Credit */
/*-----------------------------------------------------------------------------------*/
function colabs_credit(){
global $themename,$colabs_options;
if( $colabs_options['colabs_footer_credit'] != 'true' ){ 
  $theme_data = wp_get_theme();
  $theme_author = $theme_data->get('Author');?>
  Copyright &copy; <?php echo date('Y'); ?> <a href="http://colorlabsproject.com/themes/<?php echo get_option('colabs_themename'); ?>/" title="<?php echo esc_attr( get_bloginfo( 'name', 'display' ) ); ?>" rel="home"><?php echo get_option('colabs_themename'); ?></a> by <a href="http://colorlabsproject.com/" title="Colorlabs"><?php echo $theme_author; ?></a>. All rights reserved.
<?php }else{ echo stripslashes( get_option('colabs_footer_credit_txt') ); } 
}


/*-----------------------------------------------------------------------------------*/
/*  colabs_share - Twitter, FB & Google +1    */
/*-----------------------------------------------------------------------------------*/

if ( !function_exists( 'colabs_share' ) ) {
function colabs_share() {
    
$return = '';


$colabs_share_twitter = get_option('colabs_share_twitter');
$colabs_share_fblike = get_option('colabs_share_fblike');
$colabs_share_google_plusone = get_option('colabs_share_google_plusone');
$colabs_share_pinterest = get_option('colabs_share_pinterest');
$colabs_share_linkedin = get_option('colabs_share_linkedin');

    //Share Button Functions 
    global $colabs_options;
    $url = get_permalink();
    $share = '';
    
    //Twitter Share Button
    if(function_exists('colabs_shortcode_twitter') && $colabs_share_twitter == "true"){
        $tweet_args = array(  'url' => $url,
   							'style' => 'horizontal',
   							'source' => ( get_option('colabs_twitter_username') )? $colabs_options['colabs_twitter_username'] : '',
   							'text' => '',
   							'related' => '',
   							'lang' => '',
   							'float' => 'fl'
                        );

        $share .= colabs_shortcode_twitter($tweet_args);
    }
    
   
        
    //Google +1 Share Button
    if( function_exists('colabs_shortcode_google_plusone') && $colabs_share_google_plusone == "true"){
        $google_args = array(
						'size' => 'medium',
						'language' => '',
						'count' => '',
						'href' => $url,
						'callback' => '',
						'annotation' => 'bubble',
						'float' => 'left'
					);        

        $share .= colabs_shortcode_google_plusone($google_args);       
    }
	
	 //Facebook Like Button
    if(function_exists('colabs_shortcode_fblike') && $colabs_share_fblike == "true"){
    $fblike_args = 
    array(	
        'float' => 'left',
        'url' => '',
        'style' => 'button_count',
        'showfaces' => 'false',
        'width' => '82',
        'height' => '',
        'verb' => 'like',
        'colorscheme' => 'light',
        'font' => 'arial'
        );
        $share .= colabs_shortcode_fblike($fblike_args);    
    }
	 
	global $post;
	if (is_attachment()){
	$att_image = wp_get_attachment_image_src( $post->id, "thumbnail");
	$image = $att_image[0];
	}else{
    $image = colabs_image('return=true&link=url&id='.$post->ID);
	}
	//Pinterest Share Button
    if( function_exists('colabs_shortcode_pinterest') && $colabs_share_pinterest == "true"){
        $pinterest_args = array(
						'count' => 'horizontal',
						'float' => 'left',  
						'use_post' => 'true',
						'image_url' => $image,
						'url' => $url
					);        

        $share .= colabs_shortcode_pinterest($pinterest_args);       
    }
	
	//Linked Share Button
    if( function_exists('colabs_shortcode_linkedin_share') && $colabs_share_linkedin == "true"){
        $linkedin_args = array(
						'style' => 'right', 
						'float' => 'left'
					);        

        $share .= colabs_shortcode_linkedin_share($linkedin_args);       
    }
	
    $return .= '<div class="social_share">'.$share.'</div><div class="clear"></div>';
    
    return $return;
}
}

/*-----------------------------------------------------------------------------------*/
//Custom Background
/*-----------------------------------------------------------------------------------*/
add_custom_background();


/*-----------------------------------------------------------------------------------*/
/*  colabs_social_net - Add social network icon */
/*-----------------------------------------------------------------------------------*/
if(!function_exists('colabs_social_net')){
function colabs_social_net($class){
?>
    
      <div class="soc-net <?php if($class) echo $class; ?>">

		<a class="rss" href="<?php if(get_option("colabs_feed_url") != ''){ echo 'http://feeds.feedburner.com/'.get_option("colabs_feed_url");	}else{ bloginfo("rss2_url"); }?>">
		<i class="icon-rss"></i></a>
		
		<?php if (get_option("colabs_social_facebook")!='') : ?>
    	<a class="facebook" href="<?php echo get_option("colabs_social_facebook"); ?>"><i class="icon-facebook"></i></a>
    	<?php endif; ?>

    	<?php if (get_option("colabs_social_twitter")!='') : ?>
    	<a class="twitter" href="<?php echo get_option("colabs_social_twitter"); ?>"><i class="icon-twitter"></i></a>
    	<?php endif; ?>
		
		<?php if (get_option("colabs_social_google") != '' ) : ?>
    	<a class="google" href="<?php echo get_option("colabs_social_google");?>"><i class="icon-google"></i></a>
    	<?php endif; ?>
        
		<?php if (get_option("colabs_social_picasa") != '' ) : ?>
    	<a class="picasa" href="<?php echo get_option("colabs_social_picasa");?>"><i class="icon-picasa"></i></a>
    	<?php endif; ?>
		
		<?php if (get_option("colabs_social_youtube") != '' ) : ?>
    	<a class="vimeo" href="<?php echo get_option("colabs_social_youtube");?>"><i class="icon-vimeo"></i></a>
    	<?php endif; ?>
    	
		<?php if (get_option("colabs_social_flickr") != '' ) : ?>
    	<a class="flickr" href="<?php echo get_option("colabs_social_flickr");?>"><i class="icon-flickr"></i></a>
    	<?php endif; ?>
		
		<?php if (get_option("colabs_social_linked") != '' ) : ?>
    	<a class="linked" href="<?php echo get_option("colabs_social_linked");?>"><i class="icon-linked"></i></a>
    	<?php endif; ?>
		
		<?php if (get_option("colabs_social_delicious") != '' ) : ?>
    	<a class="deli" href="<?php echo get_option("colabs_social_delicious");?>"><i class="icon-deli"></i></a>
    	<?php endif; ?>
		
		<?php if (get_option("colabs_social_lastfm") != '' ) : ?>
    	<a class="lastfm" href="<?php echo get_option("colabs_social_lastfm");?>"><i class="icon-lastdm"></i></a>
    	<?php endif; ?>
		
		<?php if (get_option("colabs_social_stumbleupon") != '' ) : ?>
    	<a class="stumble" href="<?php echo get_option("colabs_social_stumbleupon");?>"><i class="icon-stumble"></i></a>
    	<?php endif; ?>
		
		<?php if (get_option("colabs_social_techno") != '' ) : ?>
    	<a class="techno" href="<?php echo get_option("colabs_social_techno");?>"><i class="icon-techno"></i></a>
    	<?php endif; ?>
		
		<?php if (get_option("colabs_social_wordpress") != '' ) : ?>
    	<a class="social-wp" href="<?php echo get_option("colabs_social_wordpress");?>"><i class="icon-wp"></i></a>
    	<?php endif; ?>
		
		<?php if (get_option("colabs_social_yahoo") != '' ) : ?>
    	<a class="yahoo" href="<?php echo get_option("colabs_social_yahoo");?>"><i class="icon-yahoo"></i></a>
    	<?php endif; ?>
      </div>
    
<?php
}}

/*-----------------------------------------------------------------------------------*/
/* Custom Functions */
/*-----------------------------------------------------------------------------------*/

function fb_add_custom_user_profile_fields( $user ) {
?>
	<h3><?php _e('Extra Profile Information', 'your_textdomain'); ?></h3>
	<table class="form-table">
		<tr>
			<th>
			<label for="dob"><?php _e("Date Of Birth", 'your_textdomain'); ?></label>
			</th>
			<td>
				<input type="text" name="dob" id="dob" rows="6" value="<?php echo esc_attr( get_the_author_meta( 'dob', $user->ID ) ); ?>" class="regular-text" /><br />
				<span class="description"><?php _e("Please enter your Date Of Birth, ex: 13/06/1983"); ?></span>
			</td>
		</tr>
		<tr>
			<th>
				<label for="address"><?php _e('Address', 'your_textdomain'); ?>
			</label></th>
			<td>
				<textarea name="address" id="address" class="regular-text" /><?php echo esc_attr( get_the_author_meta( 'address', $user->ID ) ); ?></textarea><br />
				<span class="description"><?php _e('Please enter your address.', 'your_textdomain'); ?></span>
			</td>
		</tr>
		<tr>
			<th>
				<label for="nationality"><?php _e('Country', 'your_textdomain'); ?>
			</label></th>
			<td>
				<input type="text" name="nationality" id="nationality" value="<?php echo esc_attr( get_the_author_meta( 'nationality', $user->ID ) ); ?>" class="regular-text" /><br/>
				<span class="description"><?php _e('Enter your country.', 'your_textdomain'); ?></span>
			</td>
		</tr>
		<tr>
			<th>
			<h3><?php _e('Skill Bar Information', 'your_textdomain'); ?></h3>
			</th>
		</tr>
		<tr>
			<th>
				<label for="creativity"><?php _e('Creativity', 'your_textdomain'); ?>
			</label></th>
			<td>
				<input type="text" name="creativity" id="creativity" value="<?php echo esc_attr( get_the_author_meta( 'creativity', $user->ID ) ); ?>" class="regular-text" /><br/>
				<span class="description"><?php _e('Enter your skill 0 - 100.', 'your_textdomain'); ?></span>
			</td>
		</tr>
		<tr>
			<th>
				<label for="work_speed"><?php _e('Work Speed', 'your_textdomain'); ?>
			</label></th>
			<td>
				<input type="text" name="work_speed" id="work_speed" value="<?php echo esc_attr( get_the_author_meta( 'work_speed', $user->ID ) ); ?>" class="regular-text" /><br/>
				<span class="description"><?php _e('Enter your skill 0 - 100.', 'your_textdomain'); ?></span>
			</td>
		</tr>
		<tr>
			<th>
				<label for="details"><?php _e('Attention to Details', 'your_textdomain'); ?>
			</label></th>
			<td>
				<input type="text" name="details" id="details" value="<?php echo esc_attr( get_the_author_meta( 'details', $user->ID ) ); ?>" class="regular-text" /><br/>
				<span class="description"><?php _e('Enter your skill 0 - 100.', 'your_textdomain'); ?></span>
			</td>
		</tr>
		
	</table>
<?php }

function fb_save_custom_user_profile_fields( $user_id ) {
	if ( !current_user_can( 'edit_user', $user_id ) )
		return FALSE;
	update_usermeta( $user_id, 'address', $_POST['address'] );
	update_usermeta( $user_id, 'nationality', $_POST['nationality'] );
	update_usermeta( $user_id, 'dob', $_POST['dob'] );
	update_usermeta( $user_id, 'creativity', $_POST['creativity'] );
	update_usermeta( $user_id, 'work_speed', $_POST['work_speed'] );
	update_usermeta( $user_id, 'details', $_POST['details'] );
}
add_action( 'show_user_profile', 'fb_add_custom_user_profile_fields' );
add_action( 'edit_user_profile', 'fb_add_custom_user_profile_fields' );
add_action( 'personal_options_update', 'fb_save_custom_user_profile_fields' );
add_action( 'edit_user_profile_update', 'fb_save_custom_user_profile_fields' );

/*-----------------------------------------------------------------------------------*/
/* WordPress Customizer
/*-----------------------------------------------------------------------------------*/
function colabs_customize_register( $wp_customize ) {
  $wp_customize->get_setting( 'blogname' )->transport = 'postMessage';
  $wp_customize->get_setting( 'blogdescription' )->transport = 'postMessage';

  //Access the WordPress Categories via an Array
  $colabs_categories = array();  
  $colabs_categories_obj = get_categories('hide_empty=0');
  foreach ($colabs_categories_obj as $colabs_cat) {
      $colabs_categories[$colabs_cat->cat_ID] = $colabs_cat->cat_name;}


  // Logo Settings
  // -------------
  $wp_customize->add_section( 'logo_settings', array(
    'title'    => __( 'Logo Settings', 'colabsthemes' ),
    'priority' => 50,
  ) );

  $wp_customize->add_setting( 'colabs_logo', array(
    'type'        => 'option',
    'capability'  => 'manage_options',
  ) );

  $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'colabs_logo', array(
    'label'    => __( 'Header Logo', 'colabsthemes' ),
    'section'  => 'logo_settings',
    'settings' => 'colabs_logo',
    'priority' => 1,
  ) ) );

}
add_action( 'customize_register', 'colabs_customize_register' );

/**
 * Bind JS handlers to make Theme Customizer preview reload changes asynchronously.
 * Used with blogname and blogdescription.
 *
 */
function colabs_customize_preview_js() {
  wp_enqueue_script( 'colabs-customizer', get_template_directory_uri() . '/includes/js/theme-customizer.js', array( 'customize-preview' ), '20120620', true );
}
add_action( 'customize_preview_init', 'colabs_customize_preview_js' );


?>