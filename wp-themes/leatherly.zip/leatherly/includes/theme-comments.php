<?php
/*-----------------------------------------------------------------------------------*/
/* CoLabs - List Comment */
/*-----------------------------------------------------------------------------------*/
function colabs_list_comments($comment, $args, $depth) {
  $GLOBALS['comment'] = $comment;
	$GLOBALS['comment_depth'] = $depth;
?>

	<li <?php comment_class(); ?>>
		<div id="comment-<?php comment_ID(); ?>" class="comment-entry">
			<?php if ( $comment->comment_approved == '0' ) : ?>
				<em class="comment-awaiting-moderation"><?php _e( 'Your comment is awaiting moderation.', 'colabsthemes' ); ?></em>
				<br />
			<?php endif; ?>

      <div class="comment-content-wrapper">
        <?php 
          if( $comment->comment_type != 'pingback' ) {
            $avatar_email = get_comment_author_email();
            $avatar = str_replace( "class='avatar", "class='photo avatar", get_avatar( $avatar_email, 50 ) );
            echo $avatar;
          }
        ?>

  			<div class="comment-author">
  				<p class="author-name"><?php echo get_comment_author_link(); ?></p>
  				<p class="comment-meta"><?php printf( __( '%1$s', 'colabsthemes' ), get_comment_date() ) ?></p>
  			</div>

  			<div class="comment-content">
  				<?php comment_text() ?>
  				<?php comment_reply_link( array_merge( $args, array(
  					'reply_text' => __( 'Reply', 'colabsthemes' ),
  					'depth' => $depth,
  					'max_depth' => $args['max_depth']
  				) ) ); ?>
  			</div>
      </div>
			
		</div>
  
<?php }
?>