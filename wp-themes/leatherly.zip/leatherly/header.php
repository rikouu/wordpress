<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>"/>
<meta http-equiv="X-UA-Compatible" content="<?php bloginfo('html_type'); ?>"/>
<title><?php colabs_title(); ?></title>
<?php global $colabs_options;  ?>

<?php wp_head();
  global $site_title,$site_url;
  $site_title = get_bloginfo( 'name' );
  $site_url = home_url( '/' );
  $site_description = get_bloginfo( 'description' );
  ?>
<?php if(get_option('colabs_disable_mobile')=='false'){?>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
 <?php }?>
</head>
<body <?php body_class(); ?>>
<div class="container">
	<div class="layout row">
			<div class="wrap-content">
				<div class="content">
					<div class="header">
  					<h1 class="logo"><a href="<?php echo $site_url;?>">
  					<?php
  					if (get_option('colabs_logotitle')=='logo'){
  						if ( isset( $colabs_options['colabs_logo'] ) && $colabs_options['colabs_logo'] ) {
  							echo '<img src="' . get_option('colabs_logo') . '" alt="' . $site_title . '" />';
  						} 
  					}else {
  							echo $site_title;
  					} // End IF Statement
  										
  					?>
  					</a></h1>
            <div class="bullet bullet-tl"></div>
            <div class="bullet bullet-tr"></div>
            <div class="bullet bullet-br"></div>
            <div class="bullet bullet-bl"></div>
					</div>
					