<?php get_header();?> 
	<div class="main-content">
		<div class="wrap-post">			
			<?php if (have_posts()) : ?> 							
					
				<?php while (have_posts()) : the_post(); ?>
				<div <?php post_class('post latest-post');?>>	
					<div class="post-icon"><span id="-icon-post"></span></div>
					<div class="entry-content">
						<h3 class="post-title"><?php the_title(); ?></h3>
						
						<?php   
						$single_top = get_post_custom_values("colabs_single_top");
						if (($single_top[0]!='')||($single_top[0]=='none')){
						?>
							<p class="entry-image">				
							<?php 
							if ($single_top[0]=='single_video'){
								$embed = colabs_get_embed('colabs_embed',590,332,'single_video',$post->ID);
								if ($embed!=''){
									echo $embed; 
								}
							}elseif($single_top[0]=='single_image'){
								colabs_image('width=590');				
							}										
							?>
							</p>
						<?php }?>		
						<?php the_content(); ?>
					</div>
				</div><!-- .latest post -->
				<?php endwhile; ?>	
										
			<?php endif; ?>	
													
		</div><!-- .wrap-post -->
	</div><!-- .main-content -->
<?php get_footer(); ?>