<?php
/*-----------------------------------------------------------------------------------*/
/* Start ColorLabs Functions - Please refrain from editing this section */
/*-----------------------------------------------------------------------------------*/
error_reporting(0);

// Set path to ColorLabs Framework and theme specific functions
$functions_path = get_template_directory() . '/functions/';
$includes_path = get_template_directory() . '/includes/';
$custom_path = get_template_directory() . '/custom/';

// ColorLabs Admin
require_once ($functions_path . 'admin-init.php');			// Admin Init

// Theme specific functionality
$includes = array(
				'includes/theme-functions.php', 		// Custom theme functions
        'includes/theme-options.php', 			// Options panel settings and custom settings
				'includes/theme-comments.php', 			// Custom comments/pingback loop
				'includes/theme-js.php',
				'includes/theme-custom-type.php',			// Theme Post Type
				);

// Include the user's custom_functions file, but only if it exists
if (file_exists($custom_path . '/custom_functions.php'))
	$includes[] = 'custom/custom_functions.php';

// Allow child themes/plugins to add widgets to be loaded.
$includes = apply_filters( 'colabs_includes', $includes );
			
foreach ( $includes as $i ) {
	locate_template( $i, true );
}

?>