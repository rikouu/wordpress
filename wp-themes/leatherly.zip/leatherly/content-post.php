<div class="post latest-post">
	<div class="home-icon"><span id="icon-post"></span></div>
	<div class="entry-content">
		<h3 class="post-title"><a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></h3>
		<p class="entry-meta">
			<span class="entry-author">
			<?php 
				_e('By ','colabsthemes');
				the_author_posts_link();
			?>
			</span>&nbsp;/&nbsp;
			<span class="entry-date"><?php the_time(get_option('date_format'));?></span>&nbsp;/&nbsp;
			<span class="entry-category"><?php the_category(', ');?></span>&nbsp;/&nbsp;
			<a class="entry-comment-count" href="<?php comments_link(); ?>" title=""><?php comments_number( __('No Comment','colabsthemes'), __('1 Comment','colabsthemes'), __('% Comments','colabsthemes') ); ?></a>
		</p>
		<?php the_excerpt(); ?>
	</div>
</div>