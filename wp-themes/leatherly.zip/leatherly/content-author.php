<?php
$b   = get_option('colabs_user_home');
$max = count($b);
for ($i = 0; $i < $max; $i++) {
  $user_info = get_userdata($b[$i]); ?>
  <div class="post author">
    <div class="home-icon">
      <span href="" id="author"></span>
    </div>
    <p class="line">
      <span class="left"><? _e('Name', 'colabsthemes'); ?></span>
      <span class="right"><?php echo $user_info->display_name . "\n";?></span>
    </p>
    <p class="line">
      <span class="left"><? _e('Day of Birth', 'colabsthemes');?></span>
      <span class="right"><?php echo $user_info->dob; ?></span>
    </p>
    <p class="line">
      <span class="left"><? _e('Nationality', 'colabsthemes'); ?></span>
      <span class="right"><?php echo $user_info->nationality; ?></span>
    </p>
    <p class="line">
      <span class="left"><? _e('Address', 'colabsthemes'); ?></span>
      <span class="right"><?php echo $user_info->address; ?></span>
    </p>
    <p class="line resume">
      <span class="left"><? _e('Resume', 'colabsthemes'); ?></span>
      <span class="right"><?php echo $user_info->description; ?></span>
    </p>
    <div class="skill-bar">
      <?php if ($user_info->creativity !== ''): ?>
        <p class="entry-skill">
          <?php _e('Creativity', 'colabsthemes'); ?>
        </p>
        <div class="meter blue">
          <span style="width: <?php echo ($user_info->creativity > 100) ? 100 : $user_info->creativity; ?>%"></span>
        </div>
      <?php endif; ?>
      
      <?php if ($user_info->work_speed !== ''): ?>
        <p class="entry-skill"><?php _e('Work Speed', 'colabsthemes'); ?></p>
        <div class="meter orange">
          <span style="width: <?php echo ($user_info->work_speed > 100) ? 100 : $user_info->work_speed; ?>%"></span>
        </div>
      <?php endif; ?>
      
      <?php if ($user_info->details !== ''): ?>
        <p class="entry-skill"><?php _e('Attention to Details', 'colabsthemes');?></p>
        <div class="meter">
          <span style="width: <?php echo ($user_info->details > 100) ? 100 : $user_info->details; ?>%"></span>
        </div>
      <?php endif; ?>
    </div><!-- .skill-bar -->
      
  </div>
<?php } ?>  