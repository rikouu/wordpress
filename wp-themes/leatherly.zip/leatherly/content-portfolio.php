<?php query_posts( array(
					'showposts' => -1,
					'post_type' => 'portfolio'
				));?>
	<?php if (have_posts()) : ?>
            <div class="post portfolio latest-portfolio">
<div class="home-icon"><span id="portfolio"></span></div>
    <ul class="entry-content">
        <?php while (have_posts()) : the_post(); ?>
        <li class="entry-portfolio">
            <a href="<?php echo colabs_image('link=url&size=large');?>" rel="portflio-gallery" title="<?php the_title();?>">
                <?php colabs_image('width=150&height=100&link=img');?>
            </a>
            <div class="portfolio-content"><?php the_content(); ?></div>
        </li>
        <?php endwhile; ?>
    </ul>
	<div class="clearfix"></div>
</div><!-- .Portfolio -->
	<?php endif; ?>	