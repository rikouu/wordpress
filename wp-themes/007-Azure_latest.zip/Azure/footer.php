<blockquote>
    &copy;
    <?php the_date( 'Y'); ?>
        <a href="<?php bloginfo('url');?>">
             <?php bloginfo('title');?>
        </a>
        . 由
        <a href="http://cn.wordpress.org" rel="external nofollow">
            WordPress
        </a>
        强力驱动 | Theme By
        <a href="http://jimmycai.org">
            Jimmy
        </a> & <a href="http://www.mywpku.com" target="_blank">PCDotFan</a>
</blockquote>
</div>
<?php wp_footer(); ?>
<!--请勿删除此统计代码-->
<script type='text/javascript'>
(function() {
    var c = document.createElement('script'); 
    c.type = 'text/javascript';
    c.async = true;
    c.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'www.clicki.cn/boot/50277';
    var h = document.getElementsByTagName('script')[0];
    h.parentNode.insertBefore(c, h);
})();
</script>

</body>
</html>