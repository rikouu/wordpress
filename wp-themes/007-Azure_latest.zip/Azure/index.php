﻿<?php get_header(); ?>    
        <div class="content grid-u-1 grid-u-med-3-4">
            <div class="posts">
                <h1 class="content-subhead">
                    <a href="<?php bloginfo('url'); ?>">
                        主页
                    </a>
                    &raquo; 最新文章
                </h1>
				 <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                    <article class="post" id="<?php the_ID(); ?>">
						 <?php if ( has_post_format( 'status' )): ?>
                            <a href="<?php the_permalink(); ?>" title="<?php the_time('Y年m月j日'); ?>">
                                <div class="post-content">
                                    <blockquote>
                                        <?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 500,"......","utf-8"); ?>
                                    </blockquote>
                                </div>
                            </a>
                            <?php else: ?>
                                <header class="post-header">
                                    <a href="<?php the_permalink(); ?>" class="post-title">
                                        <?php the_title(); ?>
                                    </a>
                                    <p class="post-meta">
                                        <span class="date">
                                            <?php the_time('Y年m月j日'); ?>
                                        </span>
                                        <span class="commentsnum">
                                            <a href="<?php the_permalink(); ?>#comments">
												<?php comments_number('快抢沙发','沙发被抢','% 条评论');?>
											</a>
                                        </span>
                                    </p>
                                </header>
                                <div class="post-content">
                                    <p>
                                        <?php echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 500,"......","utf-8"); ?>
                                    </p>
                                </div>
								<?php endif; ?>
                    </article>
                    <hr>
                    <?php endwhile; endif; ?>
            </div>
            <div class="page-nav">
				<?php pagination($query_string); ?>
            </div>
			<?php get_footer(); ?>
            </div>
            