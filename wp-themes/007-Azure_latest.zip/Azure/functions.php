<?php 
	function ms_comment($comment, $args, $depth) {
	   $GLOBALS['comment'] = $comment;
	?>
			<li id="comment-<?php comment_ID(); ?>" <?php comment_class(); ?>>
				<div class="comment-author">
					<?php echo get_avatar( $comment, $size = '32'); ?>
					<cite class="fn"><?php printf(__('%s'), get_comment_author_link()) ?></cite>
    			</div>
    			<div class="comment-meta">
					<?php printf(__('%s'), get_comment_date("Y/m/d") ) ?>
            	</div>
    			<div class="comment-content">
    				<p><?php comment_text() ?></p>
    			</div>
    			<div class="comment-reply">
    				<?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth'], 'reply_text' => __('回复')))) ?>
    			</div>
			</li>
			
	<?php
	}	

?>
<?php
//检测主题更新
require_once(TEMPLATEPATH . '/theme-updates/theme-update-checker.php'); 
$wpdaxue_update_checker = new ThemeUpdateChecker(
	'theme_aaa', //主题名字
	'http://img.mywpku.com/Azure-info.json'  //info.json 的访问地址
);
add_theme_support( 'post-formats', array('status') );
register_nav_menus(
array(
'sidebar-nav' => __( '左侧导航' ),
)
);
function pagination($query_string){
global $posts_per_page, $paged;
$my_query = new WP_Query($query_string ."&posts_per_page=-1");
$total_posts = $my_query->post_count;
if(empty($paged))$paged = 1;
$prev = $paged - 1;
$next = $paged + 1;
$range = 2; // only edit this if you want to show more page-links
$showitems = ($range * 2)+1;
 
$pages = ceil($total_posts/$posts_per_page);
if(1 != $pages){
echo "<div class='page-nav'>";
echo "<ul class='page-navigator'>";
echo ($paged > 1 && $showitems < $pages)? "
<a href='".get_pagenum_link($prev)."'>上一页</a>":"";
 
for ($i=1; $i <= $pages; $i++){
if (1 != $pages &&( !($i >= $paged+$range+1 ||
    $i <= $paged-$range-1) || $pages <= $showitems )){
echo ($paged == $i)? "<li class='current'>"."<a href='".get_pagenum_link($i)."' >".$i."</a>"."</li>":
"<li><a href='".get_pagenum_link($i)."' >".$i."</a></li>";
}
}
 
echo ($paged < $pages && $showitems < $pages) ?
"<li><a href='".get_pagenum_link($next)."' class='next'>下一页</a></li>" :"";
echo "</ul>";
echo "</div>\n";
}
}

