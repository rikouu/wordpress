<?php
/**
 * Framework options.
 * @package MaidenHair
 * @since MaidenHair 1.0.0
*/   
      
$maidenhair_options = array (

array( "name" => $maidenhair_themename ." Options",
	"type" => "title"),

array( "type" => "open"),

// Start Tabs
array( "name" => "Start Tabs",
		"type" => "tabs-open",
		"icon" => "layout"),

	// Home
	array( "name" => "Welcome",
			"id" => "tab_menu_0",
			"type" => "tab",
			"icon" => "layout",
			"class" => " selected first"),
	
	// General Settings
	array( "name" => "General Settings",
			"id" => "tab_menu_1",
			"type" => "tab",
			"icon" => "layout",
			"class" => ""),
      
	// Header Settings
	array( "name" => "Header Settings",
			"id" => "tab_menu_2",
			"type" => "tab",
			"icon" => "layout",
			"class" => ""),
      
	// Posts/Pages Settings
	array( "name" => "Posts/Pages Settings",
			"id" => "tab_menu_3",
			"type" => "tab",
			"icon" => "layout",
			"class" => ""),
      
  // Post Entries Settings
	array( "name" => "Post Entries Settings",
			"id" => "tab_menu_4",
			"type" => "tab",
			"icon" => "layout",
			"class" => ""),
		
	// Colors
	array( "name" => "Colors",
			"id" => "tab_menu_5",
			"type" => "tab",
			"icon" => "layout",
			"class" => ""),
      
	// Fonts
	array( "name" => "Fonts",
			"id" => "tab_menu_6",
			"type" => "tab",
			"icon" => "layout",
			"class" => ""),
	
	// Social Networking Tab
	array( "name" => "Social Networking",
			"id" => "tab_menu_7",
			"type" => "tab",
			"icon" => "layout",
			"class" => ""),
	
	// Other settings Tab
	array( "name" => "Other Settings",
			"type" => "tab",
			"id" => "tab_menu_8",
			"class" => ""),
	

// General setting Tab
array( "name" => "Close Tabs",
		"type" => "tabs-close",
		"icon" => "layout"),


array( "name" => "Start Container",
		"type" => "container-open",
		"icon" => "layout"),

// Home Container 0
array( "name" => "tab_content_0",
		"type" => "tabcontent-open",
		"display" => "block",
		"icon" => "layout"),

	// Home
	array( "name" => "Welcome to MaidenHair!",
		"type" => "heading",
		"icon" => "layout"),
	
	array("name" => "First of all, I would like to thank you for choosing MaidenHair! I firmly believe that you will be satisfied with this theme.",
		"type" => "infotext"),
	
		array( "name" => "About MaidenHair",
		"type" => "heading",
		"icon" => "layout"),
	
	array("name" => "MaidenHair is an easily customizable WordPress multipurpose theme. It is a fully responsive theme that allows for easy viewing on any device.",
		"type" => "infotext"),

array( "name" => "tab_content_0",
		"type" => "tabcontent-close",
		"icon" => "layout"),
// Close Home

// General setting Tab Container 1
array( "name" => "tab_content_1",
		"type" => "tabcontent-open",
		"display" => "none",
		"icon" => "layout"),

	// General settings
	array( "name" => "General Settings",
		"type" => "heading",
		"icon" => "layout"),		

	array( "name" => "Color Scheme",
		"desc" => "Select one of the preconfigured Color Schemes. You can set your own color scheme under the tab Color.",
		"id" => $maidenhair_shortname."_css",
		"std" => "",
		"class" => "hidden",
		"options" => array(	'a' => 'Green (default)',
							'b' => 'Blue',
							'c' => 'Orange',
							'd' => 'Pink',
              'e' => 'Purple',
              'f' => 'Red',
              'g' => 'Turquoise',),
		"type" => "select"),
    
  array( "name" => "Layout Style",
		"desc" => "Choose the layout style of your website.",
		"id" => $maidenhair_shortname."_layout",
		"std" => "",
		"class" => "hidden",
		"options" => array(	'a' => 'Boxed',
							'b' => 'Wide'),
		"type" => "select"),
    
	array( "name" => "Favicon URL",
		"desc" => "Upload your own favicon image (16x16px) or directly insert its URL. If you are using WordPress 4.3 or above, you can set a 'Site Icon' in 'Appearance - Customize - Site Identity' instead.",
		"id" => $maidenhair_shortname."_favicon_url",
		"type" => "upload-favicon",
		"std" => ""),
    
  array( "name" => "Display Breadcrumb Navigation",
		"desc" => "Set the Breadcrumb Navigation to be visible or not. The Breadcrumb NavXT plugin has to be installed for displaying it.",
		"id" => $maidenhair_shortname."_display_breadcrumb",
		"std" => "",
		"class" => "hidden",
		"options" => array(	'a' => 'Display',
							'b' => 'Hide'),
		"type" => "select"),
    
	array( "name" => "Background Settings (for Boxed layout)",
		"type" => "heading",
		"icon" => "layout"),
  
  array( "name" => "Background Image Size",
		"desc" => "Choose if the main Background Image should completely cover its area (Cover) or if it should preserve its dimensions (Auto). This option works only in the Boxed layout.",
		"id" => $maidenhair_shortname."_background_image_size",
		"std" => "",
		"class" => "hidden",
		"options" => array(	'a' => 'Auto',
							'b' => 'Cover'),
		"type" => "select"),
    
  array( "name" => "Background Pattern",
		"desc" => "Set the main background pattern (dots) to be visible or not. This option works only in the Boxed layout.",
		"id" => $maidenhair_shortname."_display_background_pattern",
		"std" => "",
		"class" => "hidden",
		"options" => array(	'a' => 'Display',
							'b' => 'Hide'),
		"type" => "select"),
    
	array( "name" => "Background Pattern Opacity",
		"desc" => "Select transparency of the main background pattern (10 = greatest transparency, 100 = opaque background pattern). This option works only in the Boxed layout.",
		"id" => $maidenhair_shortname."_background_pattern_opacity",
		"std" => "",
		"class" => "hidden",
		"options" => array(	'a' => 'Default',
							'b' => '100',
							'c' => '90',
							'd' => '80',
              'e' => '70',
              'f' => '60',
              'g' => '50',
              'h' => '40',
              'i' => '30',
              'j' => '20',
              'k' => '10',),
		"type" => "select"),
    
	array( "name" => "Sidebar Settings",
		"type" => "heading",
		"icon" => "layout"),
    
  array( "name" => "Display Sidebar on Posts/Pages",
		"desc" => "Set the right sidebar to be visible or not on the single posts and pages.",
		"id" => $maidenhair_shortname."_display_sidebar",
		"std" => "",
		"class" => "hidden",
		"options" => array(	'a' => 'Display',
							'b' => 'Hide'),
		"type" => "select"),
    
  array( "name" => "Display Sidebar on Archives",
		"desc" => "Set the right sidebar to be visible or not on the archive pages (including all archives, homepage and search results).",
		"id" => $maidenhair_shortname."_display_sidebar_archives",
		"std" => "",
		"class" => "hidden",
		"options" => array(	'a' => 'Hide',
							'b' => 'Display'),
		"type" => "select"),	
    
array( "name" => "tab_content_1",
		"type" => "tabcontent-close",
		"icon" => "layout"),
// Close General settings 	

// Open Header settings
  array( "name" => "tab_content_2",
		"type" => "tabcontent-open",
		"display" => "none",
		"icon" => "layout"),
    
	array( "name" => "Header Settings",
		"type" => "heading",
		"icon" => "layout"),
    
  array( "name" => "Display Header Image",
		"desc" => "Set the <a href='themes.php?page=custom-header'>Header Image</a> to be visible on all pages or only on the homepage.",
		"id" => $maidenhair_shortname."_display_header_image",
		"std" => "",
		"class" => "hidden",
		"options" => array(	'a' => 'Everywhere',
							'b' => 'Only on Homepage'),
		"type" => "select"),
    
	array( "name" => "Logo URL",
		"desc" => "Upload your own logo in .jpg, .gif or .png format or directly insert its URL. The logo will automatically replace the Site Title.",
		"id" => $maidenhair_shortname."_logo_url",
		"type" => "upload-logo",
		"std" => ""),
    
  array( "name" => "Display Site Description",
		"desc" => "Set the Site Description to be visible or not in your header.",
		"id" => $maidenhair_shortname."_display_site_description",
		"std" => "",
		"class" => "hidden",
		"options" => array(	'a' => 'Display',
							'b' => 'Hide'),
		"type" => "select"),
    
  array( "name" => "Display Search Form",
		"desc" => "Set the header Search Form to be visible or not.",
		"id" => $maidenhair_shortname."_display_search_form",
		"std" => "",
		"class" => "hidden",
		"options" => array(	'a' => 'Display',
							'b' => 'Hide'),
		"type" => "select"),
    
	array( "name" => "Carousel Box Settings",
		"type" => "heading",
		"icon" => "layout"),
    
  array( "name" => "Display Carousel Box",
		"desc" => "Set the Carousel Box to be visible or not in your header.",
		"id" => $maidenhair_shortname."_display_carousel",
		"std" => "",
		"class" => "hidden",
		"options" => array(	'a' => 'Display',
							'b' => 'Hide'),
		"type" => "select"),
    
  array( "name" => "Carousel Content",
		"desc" => "Set what to display in the Carousel Box. You can set the Carousel Menu in <a href='nav-menus.php'>Menus</a> panel.",
		"id" => $maidenhair_shortname."_carousel_content",
		"std" => "",
		"class" => "hidden",
		"options" => array(	'a' => 'Latest Posts',
							'b' => 'Carousel Menu'),
		"type" => "select"),
    
  array( "name" => "Number of Latest Posts in Carousel",
	"desc" => "Fill here the number of latest posts to be displayed in the Carousel Box.",
		"id" => $maidenhair_shortname."_carousel_posts_number",
		"type" => "text",
		"std" => "6"), 
    
array( "name" => "tab_content_2",
		"type" => "tabcontent-close",
		"icon" => "layout"),
// Close Header settings
  
// Open Posts/Pages settings
  array( "name" => "tab_content_3",
		"type" => "tabcontent-open",
		"display" => "none",
		"icon" => "layout"),
    
	array( "name" => "Post Settings",
		"type" => "heading",
		"icon" => "layout"),
    
  array( "name" => "Display Featured Image on single posts",
		"desc" => "Set the Featured Image to be visible or not on the single posts.",
		"id" => $maidenhair_shortname."_display_image_post",
		"std" => "",
		"class" => "hidden",
		"options" => array(	'a' => 'Display',
							'b' => 'Hide'),
		"type" => "select"),
    
  array( "name" => "Display Meta Box on posts",
		"desc" => "Set the Meta Box (with publish date, author, comments, category and tags) to be visible or not on the single posts and the post entries.",
		"id" => $maidenhair_shortname."_display_meta_post",
		"std" => "",
		"class" => "hidden",
		"options" => array(	'a' => 'Display',
							'b' => 'Hide'),
		"type" => "select"),
    
	array( "name" => "Next/Previous Post Navigation",
		"desc" => "This feature gives the possibility to easy navigate between the posts in chronological order.",
		"id" => $maidenhair_shortname."_next_preview_post",
		"std" => "",
		"class" => "hidden",
		"options" => array(	'a' => 'Display',
							'b' => 'Hide'),
		"type" => "select"),
    
  array( "name" => "Display Related Posts on single posts",
		"desc" => "Set the Related Posts box to be visible or not on the single posts.",
		"id" => $maidenhair_shortname."_display_related_posts",
		"std" => "",
		"class" => "hidden",
		"options" => array(	'a' => 'Display',
							'b' => 'Hide'),
		"type" => "select"),
    
  array( "name" => "Related Posts headline",
	"desc" => "Fill here the headline of Related Posts box.",
		"id" => $maidenhair_shortname."_related_posts_headline",
		"type" => "text",
		"std" => "Related Posts"),
    
  array( "name" => "Number of Related Posts",
	"desc" => "Fill here the number of related posts to be displayed on the single posts.",
		"id" => $maidenhair_shortname."_related_posts_number",
		"type" => "text",
		"std" => "6"),
    
  array( "name" => "Related Posts format",
		"desc" => "Set here if you want to display the Related Posts as a Slider or as an Unordered List.",
		"id" => $maidenhair_shortname."_related_posts_format",
		"std" => "",
		"class" => "hidden",
		"options" => array(	'a' => 'Slider',
							'b' => 'Unordered List'),
		"type" => "select"),

// PAGES
	array( "name" => "Page Settings",
		"type" => "heading",
		"icon" => "layout"),
    
  array( "name" => "Display Featured Image on pages",
		"desc" => "Set the Featured Image to be visible or not on the pages.",
		"id" => $maidenhair_shortname."_display_image_page",
		"std" => "",
		"class" => "hidden",
		"options" => array(	'a' => 'Display',
							'b' => 'Hide'),
		"type" => "select"),
    
array( "name" => "tab_content_3",
		"type" => "tabcontent-close",
		"icon" => "layout"),
// Close Posts/Pages settings

// Open Post Entries settings
array( "name" => "tab_content_4",
		"type" => "tabcontent-open",
		"display" => "none",
		"icon" => "layout"), 
       
  array( "name" => "Post Entries Settings",
		"type" => "heading",
		"icon" => "layout"),
    
  array( "name" => "Post Entries Format",
		"desc" => "Set the way how the post entries to be displayed.",
		"id" => $maidenhair_shortname."_post_entry_format",
		"std" => "",
		"class" => "hidden",
		"options" => array(	'a' => 'Grid - Masonry',
              'b' => 'One Column'),
		"type" => "select"),
    
  array( "name" => "Number of Columns in the Grid",
		"desc" => "Set the number of columns to be displayed in the Grid - Masonry format.",
		"id" => $maidenhair_shortname."_grid_columns",
		"std" => "",
		"class" => "hidden",
		"options" => array(	'a' => '3',
              'b' => '4',
              'c' => '2'),
		"type" => "select"),
    
  array( "name" => "Display Meta Box on Post Entries",
		"desc" => "Set the Meta Box (with publish date, author, comments, category and tags) to be visible or not on the post entries.",
		"id" => $maidenhair_shortname."_display_meta_post_entry",
		"std" => "",
		"class" => "hidden",
		"options" => array(	'a' => 'Display',
							'b' => 'Hide'),
		"type" => "select"),  
    
  array( "name" => "Featured Images Hover Effect",
		"desc" => "Select an effect for the Featured Images after placing the mouse cursor on them.",
		"id" => $maidenhair_shortname."_featured_image_hover",
		"std" => "",
		"class" => "hidden",
		"options" => array(	'a' => 'None',
              'b' => 'Fade',
              'c' => 'Focus',
              'd' => 'Shadow',
              'e' => 'Tilt'),
		"type" => "select"),
    
  array( "name" => "Content/Excerpt Displaying",
		"desc" => "Select whether you want to display the full content or the post excerpts on your archive pages (including all archives, homepage and search results).",
		"id" => $maidenhair_shortname."_content_archives",
		"std" => "",
		"class" => "hidden",
		"options" => array(	'a' => 'Excerpt',
							'b' => 'Content',),
		"type" => "select"),
    
  array( "name" => "Blog Page",
		"type" => "heading",
		"icon" => "layout"),
  
  array( "name" => "Latest Posts section headline",
	"desc" => "Fill here the headline of the Latest Posts section displayed on your Blog page.",
		"id" => $maidenhair_shortname."_latest_posts_headline",
		"type" => "text",
		"std" => "Latest Posts"),    

array( "name" => "tab_content_4",
		"type" => "tabcontent-close",
		"icon" => "layout"),
// Close Post Entries settings

// Colors Tab Container
array( "name" => "tab_content_5",
		"type" => "tabcontent-open",
		"display" => "none",
		"icon" => "layout"),
       
  array( "name" => "Color Settings",
		"type" => "heading",
		"icon" => "layout"), 
    
	array("name" => "Since version 2.0.0, the Color settings have been moved to the <a href='customize.php'>Customizer</a>.",
		"type" => "infotext"),
	
	array( "name" => "tab_content_5",
		"type" => "tabcontent-close",
		"icon" => "layout"),
// Close Colors

// Open Fonts
array( "name" => "tab_content_6",
		"type" => "tabcontent-open",
		"display" => "none",
		"icon" => "layout"),

	array( "name" => "Font Settings",
		"type" => "heading",
		"icon" => "layout"),	
    
	array("name" => "Since version 2.0.0, the Font settings have been moved to the <a href='customize.php'>Customizer</a>.",
		"type" => "infotext"),	

array( "name" => "tab_content_6",
		"type" => "tabcontent-close",
		"icon" => "layout"),
// Close Fonts

// Open Social Networking
array( "name" => "tab_content_7",
		"type" => "tabcontent-open",
		"display" => "none",
		"icon" => "layout"),

	array( "name" => "Share Buttons",
		"type" => "heading",
		"icon" => "layout"),
    
  array( "name" => "Share Buttons Language",
		"desc" => "Set here a language of the Facebook Like and Share buttons.",
		"id" => $maidenhair_shortname."_share_buttons_language",
		"std" => "",
		"class" => "hidden",
		"options" => array(	'a' => 'en_US',
							'b' => 'cs_CZ',
              'c' => 'da_DK',
              'd' => 'de_DE',
              'e' => 'el_GR',
              'f' => 'es_ES',
              'g' => 'fr_FR', 
              'h' => 'hi_IN',
              'i' => 'it_IT',
              'j' => 'nl_NL',
              'k' => 'pl_PL',
              'l' => 'pt_BR',
              'm' => 'ru_RU',
              'n' => 'sk_SK'),
		"type" => "select"),
	
	array( "name" => "Share Buttons on Pages",
		"desc" => "This shows Facebook, Twitter and Google '+1' share buttons below your pages content.",
		"id" => $maidenhair_shortname."_share_buttons_page",
		"std" => "",
		"class" => "hidden",
		"options" => array(	'a' => 'Display',
							'b' => 'Hide'),
		"type" => "select"),
	
	array( "name" => "Share Buttons on Posts",
		"desc" => "This shows Facebook, Twitter and Google '+1' share buttons below your posts content.",
		"id" => $maidenhair_shortname."_share_buttons_post",
		"std" => "",
		"class" => "hidden",
		"options" => array(	'a' => 'Display',
							'b' => 'Hide'),
		"type" => "select"),
    
	array( "name" => "Share Buttons on Post Entries",
		"desc" => "This shows Facebook, Twitter and Google '+1' share buttons on the Post Entries (on homepage/archive pages). Note: share buttons are displayed only in the One Column layout, not in the Grid - Masonry layout.",
		"id" => $maidenhair_shortname."_share_buttons_post_entry",
		"std" => "",
		"class" => "hidden",
		"options" => array(	'a' => 'Display',
							'b' => 'Hide'),
		"type" => "select"),
    
  array( "name" => "Share Buttons on Products",
		"desc" => "This shows Facebook, Twitter and Google '+1' share buttons on the individual WooCommerce Products.",
		"id" => $maidenhair_shortname."_share_buttons_products",
		"std" => "",
		"class" => "hidden",
		"options" => array(	'a' => 'Display',
							'b' => 'Hide'),
		"type" => "select"),
    
	array( "name" => "Social Networks Links in Header",
		"type" => "heading",
		"icon" => "layout"),
    
	array( "name" => "Facebook Link",
		"desc" => "Insert here the full URL address of your Facebook profile or page. Example: http://www.facebook.com/mypage",
		"id" => $maidenhair_shortname."_header_facebook_link",
		"type" => "text",
		"std" => ""),  
    
	array( "name" => "Twitter Link",
		"desc" => "Insert here the full URL address of your Twitter profile. Example: http://www.twitter.com/myprofile",
		"id" => $maidenhair_shortname."_header_twitter_link",
		"type" => "text",
		"std" => ""), 
    
	array( "name" => "Google+ Link",
		"desc" => "Insert here the full URL address of your Google+ profile or page. Example: http://plus.google.com/myprofile",
		"id" => $maidenhair_shortname."_header_google_link",
		"type" => "text",
		"std" => ""), 
    
	array( "name" => "Pinterest Link",
		"desc" => "Insert here the full URL address of your Pinterest profile. Example: http://www.pinterest.com/myprofile",
		"id" => $maidenhair_shortname."_header_pinterest_link",
		"type" => "text",
		"std" => ""), 


array( "name" => "tab_content_7",
		"type" => "tabcontent-close",
		"icon" => "layout"),
// Close Social Networking

// Open Other settings
array( "name" => "tab_content_8",
		"type" => "tabcontent-open",
		"display" => "none",
		"icon" => "layout"),

	array( "name" => "Other Settings",
		"type" => "heading",
		"icon" => "layout"),
		

array( "type" => "infotext",
		"name" => "OPTIONS: <a href='widgets.php'>Widgets</a> | <a href='nav-menus.php'>Menus</a> | <a href='themes.php?page=custom-header'>Header Image</a> | <a href='themes.php?page=custom-background'>Background Settings</a>"),
    
  array( "name" => "Custom CSS",
		"desc" => "Fill here your own cascading style sheet information (CSS).<br />Example: #content p {font-size: 15px;} #sidebar p {font-size: 14px;}",
		"id" => $maidenhair_shortname."_own_css",
		"type" => "textarea",
		"std" => ""),
    
  array( "name" => "Custom JavaScript - Header",
		"desc" => "Fill here your custom JavaScript code which will appear in the 'head' section. <br />Please do not forget to wrap your JavaScript code between the &lt;script type='text/javascript'&gt;&lt;/script&gt; tags!",
		"id" => $maidenhair_shortname."_own_javascript_header",
		"type" => "textarea",
		"std" => ""),
    
  array( "name" => "Custom JavaScript - Footer",
		"desc" => "Fill here your custom JavaScript code which will appear just before the closing 'body' tag. <br />Please do not forget to wrap your JavaScript code between the &lt;script type='text/javascript'&gt;&lt;/script&gt; tags!",
		"id" => $maidenhair_shortname."_own_javascript_footer",
		"type" => "textarea",
		"std" => ""),

array( "name" => "tab_content_8",
		"type" => "tabcontent-close",
		"icon" => "layout"),
// Close Other settings

array("name" => "Close Container",
		"type" => "container-close",
		"icon" => "layout"),

array( "type" => "close") 
); 

add_action('admin_head', 'maidenhair_admin_css');

function maidenhair_admin_css() { ?>
     
	<script language="JavaScript">
		jQuery.noConflict();
		jQuery(document).ready(function($) {
	
		$(".tabs .tab[id^=tab_menu]").click(function() {
			var curMenu=$(this);
			$(".tabs .tab[id^=tab_menu]").removeClass("selected");
			curMenu.addClass("selected");
	
			var index=curMenu.attr("id").split("tab_menu_")[1];
			$(".curvedContainer .tabcontent").css("display","none");
			$(".curvedContainer #tab_content_"+index).css("display","block");
		});
	});
	</script>

<?php }
function maidenhair_add_admin() {
	global $maidenhair_options; global $maidenhair_themename; global $maidenhair_shortname;
	if ( isset ( $_GET['page'] ) && ( $_GET['page'] == basename(__FILE__) ) ) {
		if ( isset ($_REQUEST['action']) && ( 'save' == $_REQUEST['action'] ) ){
      if ( !empty($_POST) && check_admin_referer('maidenhair_save_options','maidenhair_save_options_field' ) ) {
			foreach ( $maidenhair_options as $value ) {
				if ( array_key_exists('id', $value) ) {
					if ( isset( $_REQUEST[ $value['id'] ] ) ) {
						update_option( $value['id'], $_REQUEST[ $value['id'] ]  );
					}
					else {
						delete_option( $value['id'] );
					}
				}
			}
			header("Location: themes.php?page=".basename(__FILE__)."&saved=true");
		}
    }else if ( isset ($_REQUEST['action']) && ( 'reset' == $_REQUEST['action'] ) ) {
			foreach ($maidenhair_options as $value) {
				if ( array_key_exists('id', $value) ) {
					delete_option( $value['id'] );
				}
			}
			header("Location: themes.php?page=".basename(__FILE__)."&reset=true");
		}
	}
	add_theme_page($maidenhair_themename." Options", 'Theme Options', 'edit_theme_options', 'fw-options.php', 'maidenhair_admin', '', '1');
}

function maidenhair_admin() {
	global $maidenhair_themename, $maidenhair_shortname, $maidenhair_options, $maidenhair_themever, $fwver, $maidenhair_manualurl; 
	if (isset($_REQUEST["saved"]) && !empty($_REQUEST["saved"])) echo '<div id="message" class="updated fade"><p><strong>'.$maidenhair_themename.' settings saved.</strong></p></div>';
	if (isset($_REQUEST["reset"]) && !empty($_REQUEST["reset"])) echo '<div id="message" class="error fade"><p><strong>'.$maidenhair_themename.' '.__( 'settings reset.', 'maidenhair' ).'</strong></p></div>';
  wp_enqueue_style('maidenhair-framework-style', get_template_directory_uri() . '/functions/be/css.css');
?>

	<div id="wrap_fm"><!-- [ Header ]-->
		<div class="header_fm">
			<div class="logo_fm">Theme Options</div>
			<div class="frame_vers_fm">
				<div class="theme_version_fm"><?php echo $maidenhair_themename;?> <strong><?php echo $maidenhair_themever;?></strong></div>
				<div class="clear"></div>
			</div>
		</div>

		<!-- [ Top Menu ]-->
		<div class="top_menu_fm">
			<a title="Theme Documentation" target="_blank"class="doc_fm" href="<?php echo $maidenhair_manualurl; ?>">Documentation</a><a title="Theme Support" target="_blank" class="support_fm" href="http://themes.tomastoman.cz/support">Support</a>
		</div>


	<form method="post">
	<?php 
	foreach ($maidenhair_options as $value) {
	switch ( $value['type'] ) {
	case "open":
	?> 
	<?php break; case "title": ?> 

	<!-- [ Body ]-->
	<div id="wrap_body_fm">
	<div class="tabscontainer">


	<?php break; case "close": ?> 

	<!-- start form -->
	<div class="col_100">
		<div class="col_50">
			<input id="submit" class="button-primary" name="save" type="submit" value="Save all changes" /> <input type="hidden" name="action" value="save" />
      <?php wp_nonce_field( 'maidenhair_save_options','maidenhair_save_options_field' ); ?>
			</form>
		</div>
	 	<div class="col_50">
		 	<form method="post">
				<input class="reset" name="reset" type="submit" value="Reset to default settings" />
				<input type="hidden" name="action" value="reset" />
			</form>
		</div>	
		<div class="clear"></div>
	</div>
	<!-- end form -->
</div></div>


<?php break;case 'text': ?>
	<div class="name_fm"><?php echo $value['name']; ?></div>
	<div class="input_fm"><input name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" type="<?php echo $value['type']; ?>" value="<?php if ( get_option( $value['id'] ) != "") { echo stripslashes(get_option( $value['id'] )); } else { echo $value['std']; } ?>" /></div>
	<div class="desc_fm"><small><?php echo $value['desc']; ?></small></div>
  
<?php break;case 'upload-favicon': ?>
<?php wp_enqueue_media();
wp_enqueue_script('maidenhair-my-admin-js-favicon', get_template_directory_uri() . '/js/custom-uploader-favicon.js', array('jquery')); ?>
	<div class="name_fm"><?php echo $value['name']; ?></div>
  <input class="upload_image" type="text" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" value="<?php if ( get_option( $value['id'] ) != "") { echo stripslashes(get_option( $value['id'] )); } else { echo $value['std']; } ?>" /> 
  <input class="upload_image_button button" type="button" value="Upload Image" />
	<div class="desc_fm"><small><?php echo $value['desc']; ?></small></div>
  
<?php break;case 'upload-logo': ?>
<?php wp_enqueue_script('maidenhair-my-admin-js-logo', get_template_directory_uri() . '/js/custom-uploader-logo.js', array('jquery')); ?>
	<div class="name_fm"><?php echo $value['name']; ?></div>
  <input class="upload_logo" type="text" name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>" value="<?php if ( get_option( $value['id'] ) != "") { echo stripslashes(get_option( $value['id'] )); } else { echo $value['std']; } ?>" /> 
  <input class="upload_logo_button button" type="button" value="Upload Image" />
	<div class="desc_fm"><small><?php echo $value['desc']; ?></small></div>

<?php break; case 'textarea':?>
	<div class="name_fm"><?php echo $value['name']; ?></div>
	<div class="input_fm"><textarea name="<?php echo $value['id']; ?>" style="height: 100px;" type="<?php echo $value['type']; ?>" cols="" rows=""><?php if ( get_option( $value['id'] ) != "") { echo stripslashes(get_option( $value['id'] )); } else { echo $value['std']; } ?></textarea></div>
	<div class="desc_fm"><small><?php echo $value['desc']; ?></small></div>

<?php break; case 'select': ?>
	<div class="name_fm"><?php echo $value['name']; ?></div>
	<div class="input_fm"><select name="<?php echo $value['id']; ?>" id="<?php echo $value['id']; ?>"><?php foreach ($value['options'] as $option) { ?>
	<option <?php if ( get_option( $value['id'] ) == $option) { echo ' selected="selected"'; } elseif ($option == $value['std']) { echo ' selected="selected"'; } ?>><?php echo $option; ?></option>
	<?php } ?>
	</select></div>
	<div class="desc_fm"><small><?php echo $value['desc']; ?></small></div>
	
	<?php break; case "heading":?>
	<h1><?php echo $value['name']; ?></h1>
	
	<?php break; case "subheader":?>
	<div class="name_fm"><?php echo $value['name']; ?></div>
	
  <?php break; case "infotext":?>
	<div class="infotext"><?php echo $value['name']; ?></div>
	
	<?php break; case "paragraph":?>
	<div class="desc_fm"><small><?php echo $value['name']; ?></small></div>
  	
	<?php break; case "tabs-open":?>	
	<div class="tabs">
	
	<?php break; case "tabs-close":?>	
	</div>	
	
	<?php break; case "tab":?>	
	<div class="tab<?php echo $value['class']; ?>" id="<?php echo $value['id']; ?>">
	<div class="link"><?php echo $value['name']; ?></div>
	<div class="arrow"></div>
	</div>
 	
 	<?php break; case "container-open":?>	
	<div class="curvedContainer">
 	
 	<?php break; case "container-close":?>	
	</div>	
 	
	<?php break; case "tabcontent-open":?>	
	<div class="tabcontent" id="<?php echo $value['name']; ?>" style="display:<?php echo $value['display']; ?>" >
	
	<?php break; case "tabcontent-close":?>	
	</div>
	
 	
<?php break;

}
}
?>

<?php
}

add_action('admin_menu', 'maidenhair_add_admin'); ?>