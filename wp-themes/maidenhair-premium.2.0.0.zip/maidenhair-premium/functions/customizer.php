<?php
/**
 * MaidenHair Theme Customizer.
 * @package MaidenHair
 * @since MaidenHair 2.0.0
*/
function maidenhair_customize_register($wp_customize){

$maidenhair_fonts = array(
			'default' => 'default',	
			'Abel' => 'Abel',			
			'Aclonica' => 'Aclonica',
			'Actor' => 'Actor',
			'Adamina' => 'Adamina',
			'Aldrich' => 'Aldrich',
			'Alice' => 'Alice',
			'Alike' => 'Alike',
			'Allan' => 'Allan',
			'Allerta' => 'Allerta',
      'Amarante' => 'Amarante',
			'Amaranth' => 'Amaranth',
      'Andika' => 'Andika',
			'Antic' => 'Antic',
			'Arimo' => 'Arimo',	
			'Artifika' => 'Artifika',
			'Arvo' => 'Arvo',
			'Brawler' => 'Brawler',
			'Buda' => 'Buda',	
      'Butcherman' => 'Butcherman',	
			'Cantarell' => 'Cantarell',	
      'Cherry Swash' => 'Cherry Swash',				
			'Chivo' => 'Chivo',			
			'Coda' => 'Coda',	
      'Concert One' => 'Concert One',		
			'Copse' => 'Copse',
			'Corben' => 'Corben',
			'Cousine' => 'Cousine',			
			'Coustard' => 'Coustard',
			'Covered By Your Grace' => 'Covered By Your Grace',
			'Crafty Girls' => 'Crafty Girls',
			'Crimson Text' => 'Crimson Text',
			'Crushed' => 'Crushed',
			'Cuprum' => 'Cuprum',
			'Damion' => 'Damion',
			'Dancing Script' => 'Dancing Script',
			'Dawning of a New Day' => 'Dawning of a New Day',
			'Days One' => 'Days One',
			'Delius' => 'Delius',
			'Delius Swash Caps' => 'Delius Swash Caps',
			'Delius Unicase' => 'Delius Unicase',
			'Didact Gothic' => 'Didact Gothic',
			'Dorsa' => 'Dorsa',
			'Droid Sans' => 'Droid Sans',
			'Droid Sans Mono' => 'Droid Sans Mono',
      'Droid Serif' => 'Droid Serif',
			'EB Garamond' => 'EB Garamond',
			'Expletus Sans' => 'Expletus Sans',
			'Fanwood Text' => 'Fanwood Text',
			'Federo' => 'Federo',
			'Fontdiner Swanky' => 'Fontdiner Swanky',
			'Forum' => 'Forum',
			'Francois One' => 'Francois One',
			'Gentium Basic' => 'Gentium Basic',
			'Gentium Book Basic' => 'Gentium Book Basic',
			'Geo' => 'Geo',
			'Geostar' => 'Geostar',
			'Geostar Fill' => 'Geostar Fill',
      'Gilda Display' => 'Gilda Display',
			'Give You Glory' => 'Give You Glory',
			'Gloria Hallelujah' => 'Gloria Hallelujah',
			'Goblin One' => 'Goblin One',
			'Goudy Bookletter 1911' => 'Goudy Bookletter 1911',
			'Gravitas One' => 'Gravitas One',
			'Gruppo' => 'Gruppo',
			'Hammersmith One' => 'Hammersmith One',
			'Holtwood One SC' => 'Holtwood One SC',
			'Homemade Apple' => 'Homemade Apple',
			'Inconsolata' => 'Inconsolata',
			'Indie Flower' => 'Indie Flower',
      'IM Fell English' => 'IM Fell English',
			'Irish Grover' => 'Irish Grover',
			'Irish Growler' => 'Irish Growler',
			'Istok Web' => 'Istok Web',
			'Judson' => 'Judson',
			'Julee' => 'Julee',
			'Just Another Hand' => 'Just Another Hand',
			'Just Me Again Down Here' => 'Just Me Again Down Here',
			'Kameron' => 'Kameron',
			'Kelly Slab' => 'Kelly Slab',
			'Kenia' => 'Kenia',
			'Kranky' => 'Kranky',
			'Kreon' => 'Kreon',
			'Kristi' => 'Kristi',
			'La Belle Aurore' => 'La Belle Aurore',
      'Lato' => 'Lato',
			'League Script' => 'League Script',
			'Leckerli One' => 'Leckerli One',
			'Lekton' => 'Lekton',
      'Lily Script One' => 'Lily Script One',
			'Limelight' => 'Limelight',
			'Lobster' => 'Lobster',
			'Lobster Two' => 'Lobster Two',
			'Lora' => 'Lora',
			'Love Ya Like A Sister' => 'Love Ya Like A Sister',
			'Loved by the King' => 'Loved by the King',
      'Lovers Quarrel' => 'Lovers Quarrel',
			'Luckiest Guy' => 'Luckiest Guy',
			'Maiden Orange' => 'Maiden Orange',
			'Mako' => 'Mako',
			'Marvel' => 'Marvel',
			'Maven Pro' => 'Maven Pro',
			'Meddon' => 'Meddon',
			'MedievalSharp' => 'MedievalSharp',
      'Medula One' => 'Medula One',
			'Megrim' => 'Megrim',
			'Merienda One' => 'Merienda One',
			'Merriweather' => 'Merriweather',
			'Metrophobic' => 'Metrophobic',
			'Michroma' => 'Michroma',
			'Miltonian Tattoo' => 'Miltonian Tattoo',
			'Miltonian' => 'Miltonian',
			'Modern Antiqua' => 'Modern Antiqua',
			'Molengo' => 'Molengo',
      'Monofett' => 'Monofett',
			'Monoton' => 'Monoton',
      'Montaga' => 'Montaga',
			'Montez' => 'Montez',
      'Montserrat' => 'Montserrat',
			'Mountains of Christmas' => 'Mountains of Christmas',
			'Muli' => 'Muli',
			'Neucha' => 'Neucha',
			'Neuton' => 'Neuton',
			'News Cycle' => 'News Cycle',
			'Nixie One' => 'Nixie One',
			'Nobile' => 'Nobile',
			'Nova Cut' => 'Nova Cut',
			'Nova Flat' => 'Nova Flat',
			'Nova Mono' => 'Nova Mono',
			'Nova Oval' => 'Nova Oval',
			'Nova Round' => 'Nova Round',
			'Nova Script' => 'Nova Script',
			'Nova Slim' => 'Nova Slim',
			'Nova Square' => 'Nova Square',
			'Numans' => 'Numans',
			'Nunito' => 'Nunito',
      'Open Sans' => 'Open Sans',
			'Oswald' => 'Oswald',
			'Over the Rainbow' => 'Over the Rainbow',
			'Ovo' => 'Ovo',
			'Pacifico' => 'Pacifico',
			'Passero One' => 'Passero One',
			'Patrick Hand' => 'Patrick Hand',
			'Paytone One' => 'Paytone One',
			'Permanent Marker' => 'Permanent Marker',
			'Philosopher' => 'Philosopher',
			'Play' => 'Play',
			'Playfair Display' => 'Playfair Display',
			'Podkova' => 'Podkova',
			'Poller One' => 'Poller One',
			'Pompiere' => 'Pompiere',
			'Prata' => 'Prata',
			'Prociono' => 'Prociono',
			'PT Sans' => 'PT Sans',
			'PT Sans Caption' => 'PT Sans Caption',
			'PT Sans Narrow' => 'PT Sans Narrow',
			'PT Serif' => 'PT Serif',
			'PT Serif Caption' => 'PT Serif Caption',
			'Puritan' => 'Puritan',
			'Quattrocento' => 'Quattrocento',
			'Quattrocento Sans' => 'Quattrocento Sans',
			'Questrial' => 'Questrial',
			'Radley' => 'Radley',
			'Raleway' => 'Raleway', 
      'Rationale' => 'Rationale',
			'Redressed' => 'Redressed',
      'Reenie Beanie' => 'Reenie Beanie', 
      'Roboto' => 'Roboto',
      'Roboto Condensed' => 'Roboto Condensed',
			'Rock Salt' => 'Rock Salt',
			'Rochester' => 'Rochester',
			'Rokkitt' => 'Rokkitt',
			'Rosario' => 'Rosario',
			'Ruslan Display' => 'Ruslan Display',
      'Sancreek' => 'Sancreek',
			'Sansita One' => 'Sansita One',
			'Schoolbell' => 'Schoolbell',
			'Shadows Into Light' => 'Shadows Into Light',
			'Shanti' => 'Shanti',
			'Short Stack' => 'Short Stack',
			'Sigmar One' => 'Sigmar One',
			'Six Caps' => 'Six Caps',
			'Slackey' => 'Slackey',
			'Smokum' => 'Smokum',
			'Smythe' => 'Smythe',
			'Sniglet' => 'Sniglet',
			'Snippet' => 'Snippet',
			'Sorts Mill Goudy' => 'Sorts Mill Goudy',
			'Special Elite' => 'Special Elite',
			'Spinnaker' => 'Spinnaker',
			'Stardos Stencil' => 'Stardos Stencil',
			'Sue Ellen Francisco' => 'Sue Ellen Francisco',
			'Sunshiney' => 'Sunshiney',
			'Swanky and Moo Moo' => 'Swanky and Moo Moo',
			'Syncopate' => 'Syncopate',
			'Tangerine' => 'Tangerine',
			'Tenor Sans' => 'Tenor Sans',
			'Terminal Dosis Light' => 'Terminal Dosis Light',
			'Tinos' => 'Tinos',
			'Tulpen One' => 'Tulpen One',
			'Ubuntu' => 'Ubuntu',
			'Ultra' => 'Ultra',
      'UnifrakturCook' => 'UnifrakturCook',
			'UnifrakturMaguntia' => 'UnifrakturMaguntia',
      'Unkempt' => 'Unkempt',
			'Unna' => 'Unna',
			'Varela' => 'Varela',
			'Varela Round' => 'Varela Round',
			'Vibur' => 'Vibur',
			'Vidaloka' => 'Vidaloka',
			'Volkhov' => 'Volkhov',
			'Vollkorn' => 'Vollkorn',
			'Voltaire' => 'Voltaire',
			'VT323' => 'VT323',
			'Waiting for the Sunrise' => 'Waiting for the Sunrise',
			'Wallpoet' => 'Wallpoet',
			'Walter Turncoat' => 'Walter Turncoat',
			'Wire One' => 'Wire One',
			'Yanone Kaffeesatz' => 'Yanone Kaffeesatz',
			'Yellowtail' => 'Yellowtail',
			'Yeseva One' => 'Yeseva One',
			'Zeyada' => 'Zeyada');

    $wp_customize->add_section('maidenhair_header_color_settings', array(
        'title'    => __('MaidenHair Header Color Settings', 'maidenhair'),
        'description' => '',
        'priority' => 120,
    ));
    $wp_customize->add_section('maidenhair_content_color_settings', array(
        'title'    => __('MaidenHair Main Content Color Settings', 'maidenhair'),
        'description' => '',
        'priority' => 130,
    ));
    $wp_customize->add_section('maidenhair_sidebar_color_settings', array(
        'title'    => __('MaidenHair Sidebar Color Settings', 'maidenhair'),
        'description' => '',
        'priority' => 140,
    ));
    $wp_customize->add_section('maidenhair_footer_color_settings', array(
        'title'    => __('MaidenHair Footer Color Settings', 'maidenhair'),
        'description' => '',
        'priority' => 150,
    ));
    $wp_customize->add_section('maidenhair_html_color_settings', array(
        'title'    => __('MaidenHair Form/HTML Elements Color Settings', 'maidenhair'),
        'description' => '',
        'priority' => 160,
    ));
    $wp_customize->add_section('maidenhair_font_settings', array(
        'title'    => __('MaidenHair Font Settings', 'maidenhair'),
        'description' => '',
        'priority' => 170,
    ));
    
    //  ==============================
    //  = Character Set              =
    //  ==============================
    $wp_customize->add_setting('maidenhair_character_set', array(
        'default'        => get_option('maidenhair_character_set', 'latin'),
        'capability'     => 'edit_theme_options',
        'type'           => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control('maidenhair_character_set_control', array(
        'label'      => __('Character Set', 'maidenhair'),
        'section'    => 'maidenhair_font_settings',
        'settings'   => 'maidenhair_character_set',
        'type'       => 'radio',
        'choices'    => array(
            'latin' => __( 'Latin' , 'maidenhair' ),
            'latin-ext' => __( 'Latin Extended' , 'maidenhair' ),
            'cyrillic' => __( 'Cyrillic' , 'maidenhair' ),
            'cyrillic-ext' => __( 'Cyrillic Extended' , 'maidenhair' ),
            'greek' => __( 'Greek' , 'maidenhair' ),
            'greek-ext' => __( 'Greek Extended' , 'maidenhair' ),
            'vietnamese' => __( 'Vietnamese' , 'maidenhair' ),
        ),
    ));
 
    //  =============================
    //  = Body font                 =
    //  =============================
     $wp_customize->add_setting('maidenhair_body_google_fonts', array(
        'default'        => get_option('maidenhair_body_google_fonts', 'default'),
        'capability'     => 'edit_theme_options',
        'type'           => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
 
    ));
    $wp_customize->add_control( 'maidenhair_body_google_fonts_control', array(
        'settings' => 'maidenhair_body_google_fonts',
        'label'   => __('Body font', 'maidenhair'),
        'section' => 'maidenhair_font_settings',
        'type'    => 'select',
        'choices'    => $maidenhair_fonts,
    ));
    
    //  ==========================
    //  = Body font size         =
    //  ==========================
    $wp_customize->add_setting('maidenhair_body_google_fonts_size', array(
        'default'        => get_option('maidenhair_body_google_fonts_size', '13'),
        'capability'     => 'edit_theme_options',
        'type'           => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control('maidenhair_body_google_fonts_size_control', array(
        'label'      => __('Body font size', 'maidenhair'),
        'section'    => 'maidenhair_font_settings',
        'settings'   => 'maidenhair_body_google_fonts_size',
    ));
    
    //  =============================
    //  = Site Title font           =
    //  =============================
     $wp_customize->add_setting('maidenhair_headings_google_fonts', array(
        'default'        => get_option('maidenhair_headings_google_fonts', 'default'),
        'capability'     => 'edit_theme_options',
        'type'           => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
 
    ));
    $wp_customize->add_control( 'maidenhair_headings_google_fonts_control', array(
        'settings' => 'maidenhair_headings_google_fonts',
        'label'   => __('Site Title font', 'maidenhair'),
        'section' => 'maidenhair_font_settings',
        'type'    => 'select',
        'choices'    => $maidenhair_fonts,
    ));
    
    //  ==========================
    //  = Site Title font size   =
    //  ==========================
    $wp_customize->add_setting('maidenhair_headings_google_fonts_size', array(
        'default'        => get_option('maidenhair_headings_google_fonts_size', '48'),
        'capability'     => 'edit_theme_options',
        'type'           => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control('maidenhair_headings_google_fonts_size_control', array(
        'label'      => __('Site Title font size', 'maidenhair'),
        'section'    => 'maidenhair_font_settings',
        'settings'   => 'maidenhair_headings_google_fonts_size',
    ));
    
    //  =============================
    //  = Site Description font     =
    //  =============================
     $wp_customize->add_setting('maidenhair_description_google_fonts', array(
        'default'        => get_option('maidenhair_description_google_fonts', 'default'),
        'capability'     => 'edit_theme_options',
        'type'           => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
 
    ));
    $wp_customize->add_control( 'maidenhair_description_google_fonts_control', array(
        'settings' => 'maidenhair_description_google_fonts',
        'label'   => __('Site Description font', 'maidenhair'),
        'section' => 'maidenhair_font_settings',
        'type'    => 'select',
        'choices'    => $maidenhair_fonts,
    ));
    
    //  ==============================
    //  = Site Description font size =
    //  ==============================
    $wp_customize->add_setting('maidenhair_description_google_fonts_size', array(
        'default'        => get_option('maidenhair_description_google_fonts_size', '20'),
        'capability'     => 'edit_theme_options',
        'type'           => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control('maidenhair_description_google_fonts_size_control', array(
        'label'      => __('Site Description font size', 'maidenhair'),
        'section'    => 'maidenhair_font_settings',
        'settings'   => 'maidenhair_description_google_fonts_size',
    ));
    
    //  =============================
    //  = Page/Post Headlines font  =
    //  =============================
     $wp_customize->add_setting('maidenhair_headline_google_fonts', array(
        'default'        => get_option('maidenhair_headline_google_fonts', 'default'),
        'capability'     => 'edit_theme_options',
        'type'           => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
 
    ));
    $wp_customize->add_control( 'maidenhair_headline_google_fonts_control', array(
        'settings' => 'maidenhair_headline_google_fonts',
        'label'   => __('Page/Post Headlines (h1 - h6) font', 'maidenhair'),
        'section' => 'maidenhair_font_settings',
        'type'    => 'select',
        'choices'    => $maidenhair_fonts,
    ));
    
    //  ==========================
    //  = H1 Headlines font size =
    //  ==========================
    $wp_customize->add_setting('maidenhair_headline_h1_size', array(
        'default'        => get_option('maidenhair_headline_h1_size', '27'),
        'capability'     => 'edit_theme_options',
        'type'           => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control('maidenhair_headline_h1_size_control', array(
        'label'      => __('H1 Headlines font size', 'maidenhair'),
        'section'    => 'maidenhair_font_settings',
        'settings'   => 'maidenhair_headline_h1_size',
    ));
    
    //  ==========================
    //  = H2 Headlines font size =
    //  ==========================
    $wp_customize->add_setting('maidenhair_headline_h2_size', array(
        'default'        => get_option('maidenhair_headline_h2_size', '21'),
        'capability'     => 'edit_theme_options',
        'type'           => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control('maidenhair_headline_h2_size_control', array(
        'label'      => __('H2 Headlines font size', 'maidenhair'),
        'section'    => 'maidenhair_font_settings',
        'settings'   => 'maidenhair_headline_h2_size',
    ));
    
    //  ==========================
    //  = H3 Headlines font size =
    //  ==========================
    $wp_customize->add_setting('maidenhair_headline_h3_size', array(
        'default'        => get_option('maidenhair_headline_h3_size', '18'),
        'capability'     => 'edit_theme_options',
        'type'           => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control('maidenhair_headline_h3_size_control', array(
        'label'      => __('H3 Headlines font size', 'maidenhair'),
        'section'    => 'maidenhair_font_settings',
        'settings'   => 'maidenhair_headline_h3_size',
    ));
    
    //  ==========================
    //  = H4 Headlines font size =
    //  ==========================
    $wp_customize->add_setting('maidenhair_headline_h4_size', array(
        'default'        => get_option('maidenhair_headline_h4_size', '16'),
        'capability'     => 'edit_theme_options',
        'type'           => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control('maidenhair_headline_h4_size_control', array(
        'label'      => __('H4 Headlines font size', 'maidenhair'),
        'section'    => 'maidenhair_font_settings',
        'settings'   => 'maidenhair_headline_h4_size',
    ));
    
    //  ==========================
    //  = H5 Headlines font size =
    //  ==========================
    $wp_customize->add_setting('maidenhair_headline_h5_size', array(
        'default'        => get_option('maidenhair_headline_h5_size', '14'),
        'capability'     => 'edit_theme_options',
        'type'           => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control('maidenhair_headline_h5_size_control', array(
        'label'      => __('H5 Headlines font size', 'maidenhair'),
        'section'    => 'maidenhair_font_settings',
        'settings'   => 'maidenhair_headline_h5_size',
    ));
    
    //  ==========================
    //  = H6 Headlines font size =
    //  ==========================
    $wp_customize->add_setting('maidenhair_headline_h6_size', array(
        'default'        => get_option('maidenhair_headline_h6_size', '13'),
        'capability'     => 'edit_theme_options',
        'type'           => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control('maidenhair_headline_h6_size_control', array(
        'label'      => __('H6 Headlines font size', 'maidenhair'),
        'section'    => 'maidenhair_font_settings',
        'settings'   => 'maidenhair_headline_h6_size',
    ));
    
    //  =============================================
    //  = MaidenHair Posts Widgets headlines font =
    //  =============================================
     $wp_customize->add_setting('maidenhair_headline_box_google_fonts', array(
        'default'        => get_option('maidenhair_headline_box_google_fonts', 'default'),
        'capability'     => 'edit_theme_options',
        'type'           => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
 
    ));
    $wp_customize->add_control( 'maidenhair_headline_box_google_fonts_control', array(
        'settings' => 'maidenhair_headline_box_google_fonts',
        'label'   => __('MaidenHair Posts Widgets headlines font', 'maidenhair'),
        'section' => 'maidenhair_font_settings',
        'type'    => 'select',
        'choices'    => $maidenhair_fonts,
    ));
    
    //  ==================================================
    //  = MaidenHair Posts Widgets headlines font size =
    //  ==================================================
    $wp_customize->add_setting('maidenhair_headline_box_google_fonts_size', array(
        'default'        => get_option('maidenhair_headline_box_google_fonts_size', '27'),
        'capability'     => 'edit_theme_options',
        'type'           => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control('maidenhair_headline_box_google_fonts_size_control', array(
        'label'      => __('MaidenHair Posts Widgets headlines font size', 'maidenhair'),
        'section'    => 'maidenhair_font_settings',
        'settings'   => 'maidenhair_headline_box_google_fonts_size',
    ));
    
    //  =============================
    //  = Post Entry Headline font  =
    //  =============================
     $wp_customize->add_setting('maidenhair_postentry_google_fonts', array(
        'default'        => get_option('maidenhair_postentry_google_fonts', 'default'),
        'capability'     => 'edit_theme_options',
        'type'           => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
 
    ));
    $wp_customize->add_control( 'maidenhair_postentry_google_fonts_control', array(
        'settings' => 'maidenhair_postentry_google_fonts',
        'label'   => __('Post Entry Headline font', 'maidenhair'),
        'section' => 'maidenhair_font_settings',
        'type'    => 'select',
        'choices'    => $maidenhair_fonts,
    ));
    
    //  =================================
    //  = Post Entry Headline font size =
    //  =================================
    $wp_customize->add_setting('maidenhair_postentry_google_fonts_size', array(
        'default'        => get_option('maidenhair_postentry_google_fonts_size', '21'),
        'capability'     => 'edit_theme_options',
        'type'           => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control('maidenhair_postentry_google_fonts_size_control', array(
        'label'      => __('Post Entry Headline font size', 'maidenhair'),
        'section'    => 'maidenhair_font_settings',
        'settings'   => 'maidenhair_postentry_google_fonts_size',
    ));
    
    //  ========================================
    //  = Sidebar/Footer Widget Headlines font =
    //  ========================================
     $wp_customize->add_setting('maidenhair_sidebar_google_fonts', array(
        'default'        => get_option('maidenhair_sidebar_google_fonts', 'default'),
        'capability'     => 'edit_theme_options',
        'type'           => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
 
    ));
    $wp_customize->add_control( 'maidenhair_sidebar_google_fonts_control', array(
        'settings' => 'maidenhair_sidebar_google_fonts',
        'label'   => __('Sidebar/Footer Widget Headlines font', 'maidenhair'),
        'section' => 'maidenhair_font_settings',
        'type'    => 'select',
        'choices'    => $maidenhair_fonts,
    ));
    
    //  ======================================
    //  = Sidebar Widget Headlines font size =
    //  ======================================
    $wp_customize->add_setting('maidenhair_sidebar_google_fonts_size', array(
        'default'        => get_option('maidenhair_sidebar_google_fonts_size', '19'),
        'capability'     => 'edit_theme_options',
        'type'           => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control('maidenhair_sidebar_google_fonts_size_control', array(
        'label'      => __('Sidebar Widget Headlines font size', 'maidenhair'),
        'section'    => 'maidenhair_font_settings',
        'settings'   => 'maidenhair_sidebar_google_fonts_size',
    ));
    
    //  ======================================
    //  = Footer Widget Headlines font size  =
    //  ======================================
    $wp_customize->add_setting('maidenhair_footer_google_fonts_size', array(
        'default'        => get_option('maidenhair_footer_google_fonts_size', '19'),
        'capability'     => 'edit_theme_options',
        'type'           => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control('maidenhair_footer_google_fonts_size_control', array(
        'label'      => __('Footer Widget Headlines font size', 'maidenhair'),
        'section'    => 'maidenhair_font_settings',
        'settings'   => 'maidenhair_footer_google_fonts_size',
    ));
    
    //  =============================
    //  = Main Header Menu font     =
    //  =============================
     $wp_customize->add_setting('maidenhair_menu_google_fonts', array(
        'default'        => get_option('maidenhair_menu_google_fonts', 'default'),
        'capability'     => 'edit_theme_options',
        'type'           => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
 
    ));
    $wp_customize->add_control( 'maidenhair_menu_google_fonts_control', array(
        'settings' => 'maidenhair_menu_google_fonts',
        'label'   => __('Main Header Menu font', 'maidenhair'),
        'section' => 'maidenhair_font_settings',
        'type'    => 'select',
        'choices'    => $maidenhair_fonts,
    ));
    
    //  ==============================
    //  = Main Header Menu font size =
    //  ==============================
    $wp_customize->add_setting('maidenhair_menu_google_fonts_size', array(
        'default'        => get_option('maidenhair_menu_google_fonts_size', '15'),
        'capability'     => 'edit_theme_options',
        'type'           => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control('maidenhair_menu_google_fonts_size_control', array(
        'label'      => __('Main Header Menu font size', 'maidenhair'),
        'section'    => 'maidenhair_font_settings',
        'settings'   => 'maidenhair_menu_google_fonts_size',
    ));
    
    //  =============================
    //  = Top Header Menu font      =
    //  =============================
     $wp_customize->add_setting('maidenhair_top_menu_google_fonts', array(
        'default'        => get_option('maidenhair_top_menu_google_fonts', 'default'),
        'capability'     => 'edit_theme_options',
        'type'           => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
 
    ));
    $wp_customize->add_control( 'maidenhair_top_menu_google_fonts_control', array(
        'settings' => 'maidenhair_top_menu_google_fonts',
        'label'   => __('Top Header Menu font', 'maidenhair'),
        'section' => 'maidenhair_font_settings',
        'type'    => 'select',
        'choices'    => $maidenhair_fonts,
    ));
    
    //  ==============================
    //  = Top Header Menu font size  =
    //  ==============================
    $wp_customize->add_setting('maidenhair_top_menu_google_fonts_size', array(
        'default'        => get_option('maidenhair_top_menu_google_fonts_size', '13'),
        'capability'     => 'edit_theme_options',
        'type'           => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control('maidenhair_top_menu_google_fonts_size_control', array(
        'label'      => __('Top Header Menu font size', 'maidenhair'),
        'section'    => 'maidenhair_font_settings',
        'settings'   => 'maidenhair_top_menu_google_fonts_size',
    ));
    
//  ===========================================================================
//  = COLOR SETTINGS                                                          =
//  ===========================================================================
    
    //  =================================
    //  = Carousel Box background color =
    //  =================================
    $wp_customize->add_setting('maidenhair_carousel_background_color', array(
        'default'           => get_option('maidenhair_carousel_background_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_carousel_background_color_control', array(
        'label'    => __('Carousel Box background color', 'maidenhair'),
        'section'  => 'maidenhair_header_color_settings',
        'settings' => 'maidenhair_carousel_background_color',
    )));
    
    //  =================================
    //  = Carousel Arrows color         =
    //  =================================
    $wp_customize->add_setting('maidenhair_arrows_background_color', array(
        'default'           => get_option('maidenhair_arrows_background_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_arrows_background_color_control', array(
        'label'    => __('Carousel Arrows color', 'maidenhair'),
        'section'  => 'maidenhair_header_color_settings',
        'settings' => 'maidenhair_arrows_background_color',
    )));
    
    //  =================================
    //  = Carousel Box Links color      =
    //  =================================
    $wp_customize->add_setting('maidenhair_carousel_links_color', array(
        'default'           => get_option('maidenhair_carousel_links_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_carousel_links_color_control', array(
        'label'    => __('Carousel Box Links color', 'maidenhair'),
        'section'  => 'maidenhair_header_color_settings',
        'settings' => 'maidenhair_carousel_links_color',
    )));
    
    //  ==================================
    //  = Carousel Box Links hover color =
    //  ==================================
    $wp_customize->add_setting('maidenhair_carousel_links_hover_color', array(
        'default'           => get_option('maidenhair_carousel_links_hover_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_carousel_links_hover_color_control', array(
        'label'    => __('Carousel Box Links hover color', 'maidenhair'),
        'section'  => 'maidenhair_header_color_settings',
        'settings' => 'maidenhair_carousel_links_hover_color',
    )));

    //  =====================================
    //  = Social Networks Links hover color =
    //  =====================================
    $wp_customize->add_setting('maidenhair_social_icons_background_color', array(
        'default'           => get_option('maidenhair_social_icons_background_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_social_icons_background_color_control', array(
        'label'    => __('Social Networks Links hover color', 'maidenhair'),
        'section'  => 'maidenhair_header_color_settings',
        'settings' => 'maidenhair_social_icons_background_color',
    )));
    
    //  =============================
    //  = Top Menu background color =
    //  =============================
    $wp_customize->add_setting('maidenhair_top_menu_background_color', array(
        'default'           => get_option('maidenhair_top_menu_background_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_top_menu_background_color_control', array(
        'label'    => __('Top Menu background color', 'maidenhair'),
        'section'  => 'maidenhair_header_color_settings',
        'settings' => 'maidenhair_top_menu_background_color',
    )));
    
    //  ======================================================
    //  = Top Menu Links color                               =
    //  ======================================================
    $wp_customize->add_setting('maidenhair_top_header_menu_color', array(
        'default'           => get_option('maidenhair_top_header_menu_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_top_header_menu_color_control', array(
        'label'    => __('Top Menu Links color', 'maidenhair'),
        'section'  => 'maidenhair_header_color_settings',
        'settings' => 'maidenhair_top_header_menu_color',
    )));
    
    //  ======================================================
    //  = Top Menu Links hover color                         =
    //  ======================================================
    $wp_customize->add_setting('maidenhair_top_header_menu_hover_color', array(
        'default'           => get_option('maidenhair_top_header_menu_hover_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_top_header_menu_hover_color_control', array(
        'label'    => __('Top Menu Links hover color', 'maidenhair'),
        'section'  => 'maidenhair_header_color_settings',
        'settings' => 'maidenhair_top_header_menu_hover_color',
    )));
    
    //  ======================================================
    //  = Top Menu Links hover background-color              =
    //  ======================================================
    $wp_customize->add_setting('maidenhair_top_header_menu_hover_background_color', array(
        'default'           => get_option('maidenhair_top_header_menu_hover_background_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_top_header_menu_hover_background_color_control', array(
        'label'    => __('Top Menu Links hover background-color', 'maidenhair'),
        'section'  => 'maidenhair_header_color_settings',
        'settings' => 'maidenhair_top_header_menu_hover_background_color',
    )));
    
    //  ======================================================
    //  = Active Top Menu Links color                        =
    //  ======================================================
    $wp_customize->add_setting('maidenhair_active_top_header_menu_color', array(
        'default'           => get_option('maidenhair_active_top_header_menu_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_active_top_header_menu_color_control', array(
        'label'    => __('Active Top Menu Links color', 'maidenhair'),
        'section'  => 'maidenhair_header_color_settings',
        'settings' => 'maidenhair_active_top_header_menu_color',
    )));
    
    //  =========================================================
    //  = Top Menu drop-down submenus background color          =
    //  =========================================================
    $wp_customize->add_setting('maidenhair_top_submenu_background_color', array(
        'default'           => get_option('maidenhair_top_submenu_background_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_top_submenu_background_color_control', array(
        'label'    => __('Top Menu drop-down submenus background color', 'maidenhair'),
        'section'  => 'maidenhair_header_color_settings',
        'settings' => 'maidenhair_top_submenu_background_color',
    )));
    
    //  =========================================================
    //  = Top Menu drop-down submenus items border color        =
    //  =========================================================
    $wp_customize->add_setting('maidenhair_top_submenu_border_color', array(
        'default'           => get_option('maidenhair_top_submenu_border_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_top_submenu_border_color_control', array(
        'label'    => __('Top Menu drop-down submenus items border color', 'maidenhair'),
        'section'  => 'maidenhair_header_color_settings',
        'settings' => 'maidenhair_top_submenu_border_color',
    )));
    
    //  =========================================================
    //  = Top Menu drop-down submenus items text color          =
    //  =========================================================
    $wp_customize->add_setting('maidenhair_top_submenu_text_color', array(
        'default'           => get_option('maidenhair_top_submenu_text_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_top_submenu_text_color_control', array(
        'label'    => __('Top Menu drop-down submenus items text color', 'maidenhair'),
        'section'  => 'maidenhair_header_color_settings',
        'settings' => 'maidenhair_top_submenu_text_color',
    )));
    
    //  =========================================================
    //  = Top Menu drop-down submenus items hover color         =
    //  =========================================================
    $wp_customize->add_setting('maidenhair_top_submenu_hover_color', array(
        'default'           => get_option('maidenhair_top_submenu_hover_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_top_submenu_hover_color_control', array(
        'label'    => __('Top Menu drop-down submenus items hover color', 'maidenhair'),
        'section'  => 'maidenhair_header_color_settings',
        'settings' => 'maidenhair_top_submenu_hover_color',
    )));
    
    //  ====================================
    //  = Main Menu background color       =
    //  ====================================
    $wp_customize->add_setting('maidenhair_main_menu_background_color', array(
        'default'           => get_option('maidenhair_main_menu_background_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_main_menu_background_color_control', array(
        'label'    => __('Main Menu background color', 'maidenhair'),
        'section'  => 'maidenhair_header_color_settings',
        'settings' => 'maidenhair_main_menu_background_color',
    )));
    
    //  ====================================
    //  = Main Menu border-bottom color    =
    //  ====================================
    $wp_customize->add_setting('maidenhair_main_menu_border_color', array(
        'default'           => get_option('maidenhair_main_menu_border_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_main_menu_border_color_control', array(
        'label'    => __('Main Menu border-bottom color', 'maidenhair'),
        'section'  => 'maidenhair_header_color_settings',
        'settings' => 'maidenhair_main_menu_border_color',
    )));
    
    //  ====================================
    //  = Main Menu Links border color     =
    //  ====================================
    $wp_customize->add_setting('maidenhair_main_menu_links_border_color', array(
        'default'           => get_option('maidenhair_main_menu_links_border_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_main_menu_links_border_color_control', array(
        'label'    => __('Main Menu Links border color', 'maidenhair'),
        'section'  => 'maidenhair_header_color_settings',
        'settings' => 'maidenhair_main_menu_links_border_color',
    )));
    
    //  ====================================
    //  = Main Menu Links color            =
    //  ====================================
    $wp_customize->add_setting('maidenhair_main_header_menu_color', array(
        'default'           => get_option('maidenhair_main_header_menu_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_main_header_menu_color_control', array(
        'label'    => __('Main Menu Links color', 'maidenhair'),
        'section'  => 'maidenhair_header_color_settings',
        'settings' => 'maidenhair_main_header_menu_color',
    )));
    
    //  ====================================
    //  = Main Menu Links hover color      =
    //  ====================================
    $wp_customize->add_setting('maidenhair_main_header_menu_hover_color', array(
        'default'           => get_option('maidenhair_main_header_menu_hover_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_main_header_menu_hover_color_control', array(
        'label'    => __('Main Menu Links hover color', 'maidenhair'),
        'section'  => 'maidenhair_header_color_settings',
        'settings' => 'maidenhair_main_header_menu_hover_color',
    )));
    
    //  ==========================================
    //  = Main Menu Links hover background color =
    //  ==========================================
    $wp_customize->add_setting('maidenhair_main_header_menu_hover_background_color', array(
        'default'           => get_option('maidenhair_main_header_menu_hover_background_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_main_header_menu_hover_background_color_control', array(
        'label'    => __('Main Menu Links hover background color', 'maidenhair'),
        'section'  => 'maidenhair_header_color_settings',
        'settings' => 'maidenhair_main_header_menu_hover_background_color',
    )));
    
    //  ==========================================
    //  = Active Main Menu Links color           =
    //  ==========================================
    $wp_customize->add_setting('maidenhair_active_main_header_menu_color', array(
        'default'           => get_option('maidenhair_active_main_header_menu_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_active_main_header_menu_color_control', array(
        'label'    => __('Active Main Menu Links color', 'maidenhair'),
        'section'  => 'maidenhair_header_color_settings',
        'settings' => 'maidenhair_active_main_header_menu_color',
    )));
    
    //  ===========================================
    //  = Active Main Menu Links background color =
    //  ===========================================
    $wp_customize->add_setting('maidenhair_active_main_header_menu_background_color', array(
        'default'           => get_option('maidenhair_active_main_header_menu_background_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_active_main_header_menu_background_color_control', array(
        'label'    => __('Active Main Menu Links background color', 'maidenhair'),
        'section'  => 'maidenhair_header_color_settings',
        'settings' => 'maidenhair_active_main_header_menu_background_color',
    )));
    
    //  =================================================
    //  = Main Menu drop-down submenus background color =
    //  =================================================
    $wp_customize->add_setting('maidenhair_main_submenu_background_color', array(
        'default'           => get_option('maidenhair_main_submenu_background_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_main_submenu_background_color_control', array(
        'label'    => __('Main Menu drop-down submenus background color', 'maidenhair'),
        'section'  => 'maidenhair_header_color_settings',
        'settings' => 'maidenhair_main_submenu_background_color',
    )));
    
    //  ===================================================
    //  = Main Menu drop-down submenus items border color =
    //  ===================================================
    $wp_customize->add_setting('maidenhair_main_submenu_border_color', array(
        'default'           => get_option('maidenhair_main_submenu_border_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_main_submenu_border_color_control', array(
        'label'    => __('Main Menu drop-down submenus items border color', 'maidenhair'),
        'section'  => 'maidenhair_header_color_settings',
        'settings' => 'maidenhair_main_submenu_border_color',
    )));
    
    //  ===================================================
    //  = Main Menu drop-down submenus items hover color  =
    //  ===================================================
    $wp_customize->add_setting('maidenhair_main_submenu_hover_color', array(
        'default'           => get_option('maidenhair_main_submenu_hover_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_main_submenu_hover_color_control', array(
        'label'    => __('Main Menu drop-down submenus items hover background color', 'maidenhair'),
        'section'  => 'maidenhair_header_color_settings',
        'settings' => 'maidenhair_main_submenu_hover_color',
    )));
    
    //  ==========================================
    //  = Header Content background color        =
    //  ==========================================
    $wp_customize->add_setting('maidenhair_header_content_background_color', array(
        'default'           => get_option('maidenhair_header_content_background_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_header_content_background_color_control', array(
        'label'    => __('Header Content background color', 'maidenhair'),
        'section'  => 'maidenhair_header_color_settings',
        'settings' => 'maidenhair_header_content_background_color',
    )));
    
    //  ==========================================
    //  = Site Title color                       =
    //  ==========================================
    $wp_customize->add_setting('maidenhair_site_title_color', array(
        'default'           => get_option('maidenhair_site_title_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_site_title_color_control', array(
        'label'    => __('Site Title color', 'maidenhair'),
        'section'  => 'maidenhair_header_color_settings',
        'settings' => 'maidenhair_site_title_color',
    )));
    
    //  ==========================================
    //  = Site Title hover color                 =
    //  ==========================================
    $wp_customize->add_setting('maidenhair_site_title_hover_color', array(
        'default'           => get_option('maidenhair_site_title_hover_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_site_title_hover_color_control', array(
        'label'    => __('Site Title hover color', 'maidenhair'),
        'section'  => 'maidenhair_header_color_settings',
        'settings' => 'maidenhair_site_title_hover_color',
    )));
    
    //  ==========================================
    //  = Site Description color                 =
    //  ==========================================
    $wp_customize->add_setting('maidenhair_site_description_color', array(
        'default'           => get_option('maidenhair_site_description_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_site_description_color_control', array(
        'label'    => __('Site Description color', 'maidenhair'),
        'section'  => 'maidenhair_header_color_settings',
        'settings' => 'maidenhair_site_description_color',
    )));
    
    //  ==========================================
    //  = Main Content background color          =
    //  ==========================================
    $wp_customize->add_setting('maidenhair_main_content_background_color', array(
        'default'           => get_option('maidenhair_main_content_background_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_main_content_background_color_control', array(
        'label'    => __('Main Content background color', 'maidenhair'),
        'section'  => 'maidenhair_content_color_settings',
        'settings' => 'maidenhair_main_content_background_color',
    )));
    
    //  ==========================================
    //  = Main Content Text color                =
    //  ==========================================
    $wp_customize->add_setting('maidenhair_body_color', array(
        'default'           => get_option('maidenhair_body_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_body_color_control', array(
        'label'    => __('Main Content Text color', 'maidenhair'),
        'section'  => 'maidenhair_content_color_settings',
        'settings' => 'maidenhair_body_color',
    )));
    
    //  ==========================================
    //  = Page/Post Title color                  =
    //  ==========================================
    $wp_customize->add_setting('maidenhair_main_headlines_color', array(
        'default'           => get_option('maidenhair_main_headlines_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_main_headlines_color_control', array(
        'label'    => __('Page/Post Title color', 'maidenhair'),
        'section'  => 'maidenhair_content_color_settings',
        'settings' => 'maidenhair_main_headlines_color',
    )));
    
    //  ==========================================
    //  = Page/Post Headlines color              =
    //  ==========================================
    $wp_customize->add_setting('maidenhair_headlines_color', array(
        'default'           => get_option('maidenhair_headlines_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_headlines_color_control', array(
        'label'    => __('H1 - H6 Headlines color', 'maidenhair'),
        'section'  => 'maidenhair_content_color_settings',
        'settings' => 'maidenhair_headlines_color',
    )));
    
    //  ===============================================
    //  = MaidenHair Posts Widgets headlines color  =
    //  ===============================================
    $wp_customize->add_setting('maidenhair_homepage_headlines_color', array(
        'default'           => get_option('maidenhair_homepage_headlines_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_homepage_headlines_color_control', array(
        'label'    => __('MaidenHair Posts Widgets headlines color', 'maidenhair'),
        'section'  => 'maidenhair_content_color_settings',
        'settings' => 'maidenhair_homepage_headlines_color',
    )));
    
    //  ===============================================
    //  = Post Entry Headline color                   =
    //  ===============================================
    $wp_customize->add_setting('maidenhair_post_entry_color', array(
        'default'           => get_option('maidenhair_post_entry_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_post_entry_color_control', array(
        'label'    => __('Post Entry Headline color', 'maidenhair'),
        'section'  => 'maidenhair_content_color_settings',
        'settings' => 'maidenhair_post_entry_color',
    )));
    
    //  ===============================================
    //  = Post Entry Headline hover color             =
    //  ===============================================
    $wp_customize->add_setting('maidenhair_post_entry_hover_color', array(
        'default'           => get_option('maidenhair_post_entry_hover_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_post_entry_hover_color_control', array(
        'label'    => __('Post Entry Headline hover color', 'maidenhair'),
        'section'  => 'maidenhair_content_color_settings',
        'settings' => 'maidenhair_post_entry_hover_color',
    )));
    
    //  ===============================================
    //  = Main Content Links color                    =
    //  ===============================================
    $wp_customize->add_setting('maidenhair_content_links_color', array(
        'default'           => get_option('maidenhair_content_links_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_content_links_color_control', array(
        'label'    => __('Main Content Links color', 'maidenhair'),
        'section'  => 'maidenhair_content_color_settings',
        'settings' => 'maidenhair_content_links_color',
    )));
    
    //  =================================================
    //  = Post Author's Comments background color       =
    //  =================================================
    $wp_customize->add_setting('maidenhair_author_comments_background_color', array(
        'default'           => get_option('maidenhair_author_comments_background_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_author_comments_background_color_control', array(
        'label'    => __('Post Author&#8217;s Comments background color', 'maidenhair'),
        'section'  => 'maidenhair_content_color_settings',
        'settings' => 'maidenhair_author_comments_background_color',
    )));
    
    //  =================================================
    //  = Sticky Post background color                  =
    //  =================================================
    $wp_customize->add_setting('maidenhair_sticky_post_background_color', array(
        'default'           => get_option('maidenhair_sticky_post_background_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_sticky_post_background_color_control', array(
        'label'    => __('Sticky Post background color', 'maidenhair'),
        'section'  => 'maidenhair_content_color_settings',
        'settings' => 'maidenhair_sticky_post_background_color',
    )));
    
    //  ==================================================
    //  = MaidenHair Posts-Thumbnail items hover color =
    //  ==================================================
    $wp_customize->add_setting('maidenhair_posts_thumbnail_background_color', array(
        'default'           => get_option('maidenhair_posts_thumbnail_background_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_posts_thumbnail_background_color_control', array(
        'label'    => __('MaidenHair Posts-Thumbnail items hover color', 'maidenhair'),
        'section'  => 'maidenhair_content_color_settings',
        'settings' => 'maidenhair_posts_thumbnail_background_color',
    )));
    
    //  =================================================
    //  = Highlighted text background color             =
    //  =================================================
    $wp_customize->add_setting('maidenhair_highlight_background_color', array(
        'default'           => get_option('maidenhair_highlight_background_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_highlight_background_color_control', array(
        'label'    => __('Highlighted text background color', 'maidenhair'),
        'section'  => 'maidenhair_content_color_settings',
        'settings' => 'maidenhair_highlight_background_color',
    )));
    
    //  ==========================================
    //  = Sidebar Widget Headlines color         =
    //  ==========================================
    $wp_customize->add_setting('maidenhair_sidebar_widget_color', array(
        'default'           => get_option('maidenhair_sidebar_widget_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_sidebar_widget_color_control', array(
        'label'    => __('Sidebar Widget Headlines color', 'maidenhair'),
        'section'  => 'maidenhair_sidebar_color_settings',
        'settings' => 'maidenhair_sidebar_widget_color',
    )));
    
    //  ==========================================
    //  = Sidebar Text color                     =
    //  ==========================================
    $wp_customize->add_setting('maidenhair_sidebar_text_color', array(
        'default'           => get_option('maidenhair_sidebar_text_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_sidebar_text_color_control', array(
        'label'    => __('Sidebar Text color', 'maidenhair'),
        'section'  => 'maidenhair_sidebar_color_settings',
        'settings' => 'maidenhair_sidebar_text_color',
    )));
    
    //  ==========================================
    //  = Sidebar Links color                    =
    //  ==========================================
    $wp_customize->add_setting('maidenhair_sidebar_links_color', array(
        'default'           => get_option('maidenhair_sidebar_links_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_sidebar_links_color_control', array(
        'label'    => __('Sidebar Links color', 'maidenhair'),
        'section'  => 'maidenhair_sidebar_color_settings',
        'settings' => 'maidenhair_sidebar_links_color',
    )));
    
    //  ==========================================
    //  = Footer background color                =
    //  ==========================================
    $wp_customize->add_setting('maidenhair_footer_background_color', array(
        'default'           => get_option('maidenhair_footer_background_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_footer_background_color_control', array(
        'label'    => __('Footer background color', 'maidenhair'),
        'section'  => 'maidenhair_footer_color_settings',
        'settings' => 'maidenhair_footer_background_color',
    )));
    
    //  ==========================================
    //  = Footer Notices background color        =
    //  ==========================================
    $wp_customize->add_setting('maidenhair_footer_notices_background_color', array(
        'default'           => get_option('maidenhair_footer_notices_background_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_footer_notices_background_color_control', array(
        'label'    => __('Footer Notices background color', 'maidenhair'),
        'section'  => 'maidenhair_footer_color_settings',
        'settings' => 'maidenhair_footer_notices_background_color',
    )));
    
    //  ==========================================
    //  = Footer Widget Headlines color          =
    //  ==========================================
    $wp_customize->add_setting('maidenhair_footer_widget_color', array(
        'default'           => get_option('maidenhair_footer_widget_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_footer_widget_color_control', array(
        'label'    => __('Footer Widget Headlines color', 'maidenhair'),
        'section'  => 'maidenhair_footer_color_settings',
        'settings' => 'maidenhair_footer_widget_color',
    )));
    
    //  ==========================================
    //  = Footer Text color                      =
    //  ==========================================
    $wp_customize->add_setting('maidenhair_footer_text_color', array(
        'default'           => get_option('maidenhair_footer_text_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_footer_text_color_control', array(
        'label'    => __('Footer Text color', 'maidenhair'),
        'section'  => 'maidenhair_footer_color_settings',
        'settings' => 'maidenhair_footer_text_color',
    )));
    
    //  ==========================================
    //  = Footer Notices Text color              =
    //  ==========================================
    $wp_customize->add_setting('maidenhair_footer_notices_text_color', array(
        'default'           => get_option('maidenhair_footer_notices_text_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_footer_notices_text_color_control', array(
        'label'    => __('Footer Notices Text color', 'maidenhair'),
        'section'  => 'maidenhair_footer_color_settings',
        'settings' => 'maidenhair_footer_notices_text_color',
    )));
    
    //  ==========================================
    //  = Footer Links color                     =
    //  ==========================================
    $wp_customize->add_setting('maidenhair_footer_links_color', array(
        'default'           => get_option('maidenhair_footer_links_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_footer_links_color_control', array(
        'label'    => __('Footer Links color', 'maidenhair'),
        'section'  => 'maidenhair_footer_color_settings',
        'settings' => 'maidenhair_footer_links_color',
    )));
    
    //  ==========================================
    //  = Footer Notices Links color             =
    //  ==========================================
    $wp_customize->add_setting('maidenhair_footer_notices_links_color', array(
        'default'           => get_option('maidenhair_footer_notices_links_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_footer_notices_links_color_control', array(
        'label'    => __('Footer Notices Links color', 'maidenhair'),
        'section'  => 'maidenhair_footer_color_settings',
        'settings' => 'maidenhair_footer_notices_links_color',
    )));
    
    //  ==========================================
    //  = Searchform border color                =
    //  ==========================================
    $wp_customize->add_setting('maidenhair_searchform_border_color', array(
        'default'           => get_option('maidenhair_searchform_border_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_searchform_border_color_control', array(
        'label'    => __('Searchform border color', 'maidenhair'),
        'section'  => 'maidenhair_html_color_settings',
        'settings' => 'maidenhair_searchform_border_color',
    )));
    
    //  ==========================================
    //  = Search Button background color         =
    //  ==========================================
    $wp_customize->add_setting('maidenhair_searchform_button_background_color', array(
        'default'           => get_option('maidenhair_searchform_button_background_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_searchform_button_background_color_control', array(
        'label'    => __('Search Button background color', 'maidenhair'),
        'section'  => 'maidenhair_html_color_settings',
        'settings' => 'maidenhair_searchform_button_background_color',
    )));
    
    //  ==========================================
    //  = Search Button hover color              =
    //  ==========================================
    $wp_customize->add_setting('maidenhair_searchform_button_hover_color', array(
        'default'           => get_option('maidenhair_searchform_button_hover_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_searchform_button_hover_color_control', array(
        'label'    => __('Search Button hover background color', 'maidenhair'),
        'section'  => 'maidenhair_html_color_settings',
        'settings' => 'maidenhair_searchform_button_hover_color',
    )));
    
    //  ==========================================
    //  = Form Fields background color           =
    //  ==========================================
    $wp_customize->add_setting('maidenhair_form_fields_background_color', array(
        'default'           => get_option('maidenhair_form_fields_background_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_form_fields_background_color_control', array(
        'label'    => __('Form Fields background color', 'maidenhair'),
        'section'  => 'maidenhair_html_color_settings',
        'settings' => 'maidenhair_form_fields_background_color',
    )));
    
    //  ==========================================
    //  = Form Fields border color               =
    //  ==========================================
    $wp_customize->add_setting('maidenhair_form_fields_border_color', array(
        'default'           => get_option('maidenhair_form_fields_border_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_form_fields_border_color_control', array(
        'label'    => __('Form Fields border color', 'maidenhair'),
        'section'  => 'maidenhair_html_color_settings',
        'settings' => 'maidenhair_form_fields_border_color',
    )));
    
    //  ==========================================
    //  = Buttons background color               =
    //  ==========================================
    $wp_customize->add_setting('maidenhair_form_buttons_background_color', array(
        'default'           => get_option('maidenhair_form_buttons_background_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_form_buttons_background_color_control', array(
        'label'    => __('Buttons background color', 'maidenhair'),
        'section'  => 'maidenhair_html_color_settings',
        'settings' => 'maidenhair_form_buttons_background_color',
    )));
    
    //  ==========================================
    //  = Buttons hover color                    =
    //  ==========================================
    $wp_customize->add_setting('maidenhair_form_buttons_hover_color', array(
        'default'           => get_option('maidenhair_form_buttons_hover_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_form_buttons_hover_color_control', array(
        'label'    => __('Buttons hover background color', 'maidenhair'),
        'section'  => 'maidenhair_html_color_settings',
        'settings' => 'maidenhair_form_buttons_hover_color',
    )));
    
    //  ==========================================
    //  = Table Headers background color         =
    //  ==========================================
    $wp_customize->add_setting('maidenhair_table_headers_background_color', array(
        'default'           => get_option('maidenhair_table_headers_background_color', ''),
        'capability'        => 'edit_theme_options',
        'type'              => 'theme_mod',
        'sanitize_callback' => 'maidenhair_sanitize_text',
    ));
 
    $wp_customize->add_control( new WP_Customize_Color_Control($wp_customize, 'maidenhair_table_headers_background_color_control', array(
        'label'    => __('Table Headers background color', 'maidenhair'),
        'section'  => 'maidenhair_html_color_settings',
        'settings' => 'maidenhair_table_headers_background_color',
    )));
}
 
add_action('customize_register', 'maidenhair_customize_register');

/**
 * Sanitize URIs
*/
function maidenhair_sanitize_uri($uri) {
	if('' === $uri){
		return '';
	}
	return esc_url_raw($uri);
}

/**
 * Sanitize Texts
*/
function maidenhair_sanitize_text($str) {
	if('' === $str){
		return '';
	}
	return sanitize_text_field($str);
} ?>