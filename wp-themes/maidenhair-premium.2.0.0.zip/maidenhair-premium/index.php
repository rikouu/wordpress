<?php
/**
 * The main template file.
 * @package MaidenHair
 * @since MaidenHair 1.0.0
*/
get_header(); ?> 
<h2 class="entry-headline"><span class="entry-headline-text"><?php echo esc_attr($maidenhair_latest_posts_headline); ?></span></h2> 
    <section class="home-latest-posts<?php if ($maidenhair_post_entry_format != 'One Column') { ?> js-masonry<?php } ?>">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<?php if ($maidenhair_post_entry_format != 'One Column') {
get_template_part( 'content', 'grid' ); } else {
get_template_part( 'content', 'archives' ); } ?>
<?php endwhile; endif; ?>
   </section>   
<?php maidenhair_content_nav( 'nav-below' ); ?>
  </div> <!-- end of content -->
<?php if ($maidenhair_display_sidebar_archives == 'Display') { ?>
<?php get_sidebar(); ?>
<?php } ?>
<?php get_footer(); ?>