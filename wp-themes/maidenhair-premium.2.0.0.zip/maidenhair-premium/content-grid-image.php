<?php
/**
 * The template for displaying content of Image Post entries as Grid - Masonry.
 * @package MaidenHair
 * @since MaidenHair 1.0.0
*/
?>
<?php global $maidenhair_options;
foreach ($maidenhair_options as $value) {
	if (isset($value['id']) && get_option( $value['id'] ) === FALSE && isset($value['std'])) {
		${$value['id']} = $value['std'];
	}
	elseif (isset($value['id'])) { ${$value['id']} = get_option( $value['id'] ); }
} ?>
      <article <?php post_class('grid-entry'); ?>>
      <div class="grid-entry-inner">
        <a href="<?php echo get_permalink(); ?>" title="<?php the_title(); ?>"><?php if ( has_post_thumbnail() ) { the_post_thumbnail(); } else {
echo '<img class="attachment-post-thumbnail" src="';
echo maidenhair_catch_that_image();
echo '" alt="';
echo the_title();
echo '" />';
} ?></a>
<?php if ( $maidenhair_display_meta_post_entry != 'Hide' ) { ?>
<?php if ( has_category() ) { ?>
        <p class="grid-category"><?php the_category(', '); ?></p>
<?php } ?>
<?php if ( has_tag() ) { ?>
        <p class="grid-tags"><?php the_tags('', ', ', ''); ?></p>
<?php }} ?>
      </div>
      </article>