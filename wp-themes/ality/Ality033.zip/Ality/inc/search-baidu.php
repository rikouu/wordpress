<form action="http://zhannei.baidu.com/cse/search" target="_blank">
	<input type="hidden" value="<?php echo get_option('cx_baidu_s'); ?>" name="s">
	<input type="hidden" value="1" name="entry">
	<input class="swap_value" placeholder="请输入关键词" name="q">
	<input type="submit" class="submit" name="submit" id="searchsubmit" value="百度">
</form>