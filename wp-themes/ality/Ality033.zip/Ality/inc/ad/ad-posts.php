<div id="g-posts">
	<div class="g-posts-main g-main" style="text-align: center;">
		<?php echo stripslashes( get_option('cx_posts-ad') ); ?>
	</div>
</div>