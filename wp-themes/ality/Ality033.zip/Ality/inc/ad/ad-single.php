<div id="g-single">
	<div class="g-single-main g-main" style="text-align: center;">
		<?php echo stripslashes( get_option('cx_single-ad') ); ?>
	</div>
</div>