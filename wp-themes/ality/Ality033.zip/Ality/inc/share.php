<div id="share">
	<h4>分享到：</h4>
	<div class="bdsharebuttonbox">
		<a title="分享到QQ空间" href="#" class="icon-qzone" class="bds_qzone" data-cmd="qzone"></a>
		<a title="分享到新浪微博" href="#" class="icon-tsina" class="bds_tsina" data-cmd="tsina"></a>
		<a title="分享到腾讯微博" href="#" class="icon-tqq" class="bds_tqq" data-cmd="tqq"></a>
		<a title="分享到人人网" href="#" class="icon-renren" class="bds_renren" data-cmd="renren"></a>
		<a title="分享到微信" href="#" class="icon-weixin" class="bds_weixin" data-cmd="weixin"></a>
		<a href="#" class="icon-more" class="bds_more" data-cmd="more"></a>
	</div>
</div>
<script>window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"1","bdSize":"16"},"share":{"bdSize":16}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];</script>