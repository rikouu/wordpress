<?php get_header(); ?>
<article id="primary" class="site-content">
	<section class="content">
		<header class="single-header">
			<h1 class="single-title" style="margin: 100px 0 300px 0;text-align: center;">亲，你迷路了！</h1>
		</header>
	</section>
</article>
<?php get_sidebar(); ?>
<?php get_footer(); ?> 