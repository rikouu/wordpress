<!DOCTYPE html>
<html>
<?php get_header(); ?>
<body>
<div class="wrap">
	<div class="header">
		<h1><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a></h1>
		<span><?php bloginfo( 'description' ); ?></span>
	</div>
	<div class="content">
		<?php while (have_posts()) : the_post(); ?>
		<div class="post box">
			<div class="meta">
                <span class="post-time"><?php the_time('Y m/d D') ?>
				</span>
				<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?>
				</a></h2>
			</div>
			<div class="post-content">
                <?php the_content('Read the rest of this entry &raquo;'); ?>
			</div>
			<div class="meta">
                <span class="info-post"><?php the_tags('Tags: ', ', ', '<br />'); ?> Posted in <?php the_category(', ') ?> | <?php edit_post_link('Edit', '', ' | '); ?>  <?php comments_popup_link('No Comments &#187;', '1 Comment &#187;', '% Comments &#187;'); ?></span>
			</div>
		</div>
		<?php endwhile; ?>
		<div class="loading" id="load_posts">
			<div class="link-load">
                <?php next_posts_link(__('Load More')); ?>
			</div>
		</div>
	</div>
    <div class="area_sidebar">
        <?php get_sidebar(); ?>
		<?php get_sidebar( '2' ); ?>
    </div>
    <?php get_footer(); ?>
</div>
</body>
</html>