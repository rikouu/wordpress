<?php
register_sidebars(2);
?>