<!DOCTYPE html>
<html>
<?php include "header.php"; ?>
<body>
<div class="wrap">
	<div class="header">
		<h1><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a></h1>
		<span><?php bloginfo( 'description' ); ?></span>
	</div>
	<div class="content">
		<?php while (have_posts()) : the_post(); ?>
		<div class="post box">
			<div class="meta">
				<h2><a href="<?php the_permalink() ?>"><?php the_title(); ?>
				</a></h2>
			</div>
			<div class="post-content">
                <?php the_content('Read the rest of this entry &raquo;'); ?>
			</div>
		</div>
		<?php endwhile; ?>
        <?php comments_template(); ?>
	</div>
    <div class="area_sidebar">
        <?php get_sidebar(); ?>
		<?php get_sidebar( '2' ); ?>
    </div>
	<?php include "footer.php"; ?>
</div>
</body>
</html>