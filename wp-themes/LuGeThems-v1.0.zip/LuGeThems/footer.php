			<div class="footer">
				Copyright © 2014
				<a href="http://lujunda.cn" target="_blank">
					卢俊达
				</a>
				. All rights reserved.
				<br />
                MEMORY PEAK : <?php echo memory_get_peak_usage(true)/1024; ?> KB | 
					<a href="/admin" target="_blank">
						Administrator
					</a>
			</div>