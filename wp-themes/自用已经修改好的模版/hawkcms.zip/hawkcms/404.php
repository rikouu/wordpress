<?php get_header(); ?>
		<center>抱歉，沒有找到您需要的文章！！！404 NOT FOUND!</center>
<?php get_footer(); ?>