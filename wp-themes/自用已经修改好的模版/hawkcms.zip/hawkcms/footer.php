<div id="footer">
<p>© 2010－2015 <a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a>, all rights reserved.<a href="http://www.miitbeian.gov.cn">赣ICP备15001178号<a/></p>
</div>
</body>
</html>