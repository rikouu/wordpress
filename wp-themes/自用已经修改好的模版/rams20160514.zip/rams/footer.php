	</div> <!-- /wrapper -->
	
</div> <!-- /wrapper-inner -->

<?php wp_footer(); ?>

</body>
</html>