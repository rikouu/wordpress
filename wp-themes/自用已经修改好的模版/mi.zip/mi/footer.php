 
  <div class="footer">
   <div class="copyright">&copy; 2011-2013 <a href="<?php bloginfo('url'); ?>"><?php bloginfo('name'); ?></a></div>

    <div class="right">
	<ul></ul>
	
	<<?php $options = get_option('xiaohan_options'); echo($options['copyinfo']); ?></div>
    
	
	<div class="clear"></div>
  </div>
  <div class="space"></div>
</div>
</body>
</html>