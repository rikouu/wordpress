<?php
/**
 * footer.php
 *
 * @subpackage LordSir
 * @since LordSir 0.01
 */
?>
</div>

	<div id="footer" role="contentinfo">
		<div id="colophon">
<center>&copy; 2015 思苑 <a href="http://www.miitbeian.gov.cn">赣ICP备15001178号<a/> LordSir 0.01 Beta</center>
<?php
	get_sidebar( 'footer' );
?>
		</div>
	</div>
</div>

<?php
	wp_footer();
?>
</body>
</html>