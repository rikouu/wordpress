<?php
/****************
Theme Name: BYMT-free
Theme URL: http://www.yuxiaoxi.com/2013-08-03-wordpress-theme-bymt.html
Author: 麦田一根葱
Author URI: http://www.yuxiaoxi.com
Version: 1.0.1.4 (Final)
****************/
?>
<div id="sidebar">
<div class="widget" id="widget_tab">
<?php include('includes/widget_tab.php'); ?>
</div>

<div class="widget" id="widget_tcomments">
<?php include('includes/widget_tcomments.php'); ?>
</div>

<div class="widget" id="widget_rcomments">
<?php include('includes/widget_rcomments.php'); ?>
</div>

<div class="widget" id="widget_statistics">
<?php include('includes/widget_statistics.php'); ?>
</div>
</div>