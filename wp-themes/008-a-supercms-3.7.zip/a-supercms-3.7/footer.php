<div class="clear"></div><?php echo c();?>
<div class="footbar">
<?php if ( !dynamic_sidebar('Footbar') ){ ?>
<h3 class="sub">标签云</h3>
<ul><?php wp_tag_cloud('number=40&smallest=10&largest=16');?></ul>
<?php } ?></div>

<div class="copyright">
<h3 class="sub">版权声明</h3>
版权所有 &copy; <?php echo date("Y");?> <a href="<?php bloginfo('url'); ?>" target="_blank" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a>. 保留所有权.<br /><br />
<h3 class="sub">网站开发</h3>
<?php echo e();echo 'a>';function c(){echo base64_decode('PC9kaXY+PGRpdiBpZD0nZm9vdGVyJz4=');};if(get_option('T_tongji') != "") {?><div class="clear"></div><?php echo stripslashes(get_option('T_tongji'));?><?php } ?>
</div>
<div class="clear"></div>
<ul id="floater">
<li class="floaticon" id="gototop"><a href="#" title="返回顶部">返回顶部</a></li>
<?php if ( is_single() ) :?>
<?php next_post_link( '<li id="next" class="floaticon">%link</li>', '下一篇：%title' ); ?>
<?php previous_post_link( '<li id="prev" class="floaticon">%link</li>', '上一篇：%title' ); ?>
<?php elseif ( $wp_query->max_num_pages > 1 && ( is_home() || is_archive() || is_search() ) ) : ?>
<?php if ( get_previous_posts_link() ) : ?><li id="next" class="floaticon" title="下一页"><?php previous_posts_link( '下一页' ); ?></li><?php endif; ?>
<?php if ( get_next_posts_link() ) : ?><li id="prev" class="floaticon" title="上一页"><?php next_posts_link( '上一页' ); ?></li><?php endif; ?>
<?php endif; ?>
<?php $rand_posts = get_posts('numberposts=1&orderby=rand');
foreach( $rand_posts as $post ) : ?>
<li class="floaticon" id="rand"><a href="<?php the_permalink(); ?>" title="随机阅读">随机阅读</a></li>
<?php endforeach; ?>
</ul>
</div>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.min.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/scripts.js"></script>
<?php if(get_option('T_slider') == "On" && is_home()) {?>
<script type="text/javascript">
eval(function(p,a,c,k,e,d){e=function(c){return c};if(!''.replace(/^/,String)){while(c--)d[c]=k[c]||c;k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('$(4).3(2(){$(\'#1\').0()});',5,5,'nivoSlider|slider|function|load|window'.split('|'),0,{}))
</script>
<?php } ?>
<?php if(get_option('T_share') == "On") {?>
<script>window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"1","bdSize":"24"},"share":{},"selectShare":{"bdContainerClass":null,"bdSelectMiniList":["qzone","tsina","tqq","renren","weixin","douban"]}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?cdnversion='+~(-new Date()/36e5)];</script>
<?php } ?>
<?php if ( is_single() ){ ?>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/comments-ajax.js"></script>
<?php } ?>
<?php wp_footer(); // Designed By JeffStudio.Net ?>
<script type="text/javascript">
var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3F0647424acd57405d783311f0f48b73b2' type='text/javascript'%3E%3C/script%3E"));
//Designed By JeffStudio.Net
</script>
</body>
</html>