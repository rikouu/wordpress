<div class="sidebar" id="static_sidebar">
	<ul>
		<?php dynamic_sidebar(); ?>
	</ul>
</div>