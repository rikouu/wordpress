<div class="sidebar" id="float_sidebar">
	<ul>
		<?php dynamic_sidebar(2); ?>
	</ul>
</div>