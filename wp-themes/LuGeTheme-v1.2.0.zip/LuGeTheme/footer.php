			<div class="footer">
				Copyright © 2014
				<a class="authorLink" href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>. All rights reserved.
				<br />
                MEMORY PEAK : <?php echo memory_get_peak_usage(true)/1024; ?> KB | 
                <a href="<?php echo esc_url(site_url('/')); ?>wp-admin/" target="_blank">
						Administrator
					</a> |  Theme powered by <a href="http://lujunda.cn/">LuJunda</a>.
			</div>
<?php if(get_option('loadPlugins')=='YES') wp_footer(); ?>