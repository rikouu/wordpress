<?php
/**
 * Display the loop for Home
 *
 * @package Isca
 */

//the_post_format_quote();
echo '<div class="entry">';
the_content();
echo '</div>';