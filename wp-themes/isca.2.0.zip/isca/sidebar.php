<?php
/**
 * Sidebar widgets
 *
 * @package Isca
 */

	$sidebar = isca_sidebar();

	if ( '' !== $sidebar ) {

		echo '<aside id="sidebar">';
		dynamic_sidebar( $sidebar );
		echo '</aside>';

	}
