<?php
/**
 * Include theme helpers that improve the theming experience.
 *
 * @package isca
 */

if ( is_admin() ) {

    require_once( 'getting-started/index.php' );

}
