/////////////////////////////////////////////////////////////////////////////////
/**
 * Theme by yefengs
 * 
 * @package Yfolio Theme 
 * @author yefengs
 * @version 1.0
 * @link http://yefengs.com/theme/yfolio
 */


$(window).load(function() {
// Create the dropdown base
      $("<select />").appendTo("nav#main-nav");
      // Create default option "Go to..."
      $("<option />", {
         "selected": "selected",
         "value"   : "",
         "text"    : "菜单"
      }).appendTo("nav select");
      // Populate dropdown with menu items
      $("nav#main-nav a").each(function() {
       var el = $(this);
       $("<option />", {
       "class"  : "menu",
           "value"   : el.attr("href"),
           "text"    : el.text()
       }).appendTo("nav select");
      });
      
      $("nav#main-nav select").change(function() {
        window.location = $(this).find("option:selected").val();
      });
$("a img").hover(function() {
      $(this).stop().animate({opacity: "0.8"}, 'slow');
    },
    function() {
      $(this).stop().animate({opacity: "1"}, 'slow');
    });

$("#logo a").hover(function() {
      $(this).stop().animate({opacity: "0.8"}, 'slow');
    },
    function() {
      $(this).stop().animate({opacity: "1"}, 'slow');
}); 
}); // END  of $(function(){
