<?php 

/**
 * Theme by yefengs
 * 
 * @package Yfolio Theme 
 * @author yefengs
 * @version 1.0
 * @link http://yefengs.com/theme/yfolio
 */

  // Do not delete these lines
  if (!empty($_SERVER['SCRIPT_FILENAME']) && 'comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
    die ('Please do not load this page directly. Thanks!');
  if (!empty($post->post_password)) { // if there's a password
    if ($_COOKIE['wp-postpass_' . COOKIEHASH] != $post->post_password) {  // and it doesn't match the cookie
      ?>
      <p class="nocomments"><?php _e('密码保护，输入密码查看留言' ) ?>.</p>
      <?php
      return;
    }
  }
  ?>
<?php if ( have_comments() ) : ?>
      <h4><?php comments_number(__('暂无评论'), __('有1条评论'), __('有% 条评论')) ;?> &raquo;</h4>
      <ul id="post_comment">
        <?php wp_list_comments('type=comment&callback=yefengscomment'); ?>
      </ul>
      <?php if ( get_comment_pages_count() > 1 && get_option('page_comments') ) {  ?>
        <div id="commentnav">
          <?php paginate_comments_links('prev_text=上页&next_text=下页');?>
        </div>
        <?php  }?>
  <?php endif; ?>

<?php if ( comments_open() ) : ?>
  <h4 id="response"><?php _e('来 评论吧~'); ?></h4>
<div class="comment" id="respond">
 <form method="post" action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" id="comment_form">
      <fieldset>
<?php if ( is_user_logged_in() ) : ?>
    <p><?php printf(__('Logged in as <a href="%1$s">%2$s</a>.'), get_option('siteurl') . '/wp-admin/profile.php', $user_identity); ?> <a href="<?php echo wp_logout_url(get_permalink()); ?>" title="Logout"><?php _e('退出'); ?> &raquo;</a></p>
    <?php else: ?>
    <input type="text" name="author" id="author" size="30" value="<?php echo $comment_author; ?>" class="input" /><label>Name (required)</label>
     <br style="clear:both">
     <input type="text" name="email" id="email" class="input" size="30" value="<?php echo $comment_author_email; ?>" /><label>E-mail (required)</label>
     <br style="clear:both">
     <input type="text" name="url" id="url" class="input" size="15" value="<?php echo $comment_author_url; ?>" /><label>Web Site</label>
     <br style="clear:both">
     <?php endif; ?>
     <textarea rows="5" cols="50" name="comment" class="textarea" id="comment" onkeydown="if(event.ctrlKey&&event.keyCode==13){document.getElementById('submitcomment').click();return false};"></textarea>
    <br style="clear:both">
  <input  id="submitcomment" type="submit" class="button" value="<?php _e('Post Comment'); ?>"/><?php comment_id_fields(); ?>
     <?php cancel_comment_reply_link('取消回复') ?>
        <?php do_action('comment_form', $post->ID); ?>
</fieldset>
    </form>
</div>
      <?php else: ?>
  <h4 id="response"><?php _e('%>_<% 评论关闭了~'); ?> &raquo;</h4>
 <?php endif; ?>
