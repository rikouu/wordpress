<?php
/**
 * Theme by yefengs
 * 
 * @package Yfolio Theme 
 * @author yefengs
 * @version 1.0
 * @link http://yefengs.com/theme/yfolio
 */
get_header(); ?>
  <section id="main">
      <div id="blog" class="content">
      	<div class="page_title">
          <h3><span>Love is a carefully designed lie.</span></h3>
        </div>
<?php if (have_posts()) : ?>
		<?php while (have_posts()) : the_post(); ?>
		<div class="blog" id="post-<?php the_ID(); ?>">
		  <h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
        <div class="first">
          <a href="<?php the_permalink() ?>">
          <?php post_thumbnail(610,171);?>
          </a><span class="date"><?php the_time('M') ?><br><?php the_time('d') ?></span>
        </div>
          <ul class="single-one-fourth">
          	<li>作者：<?php the_author_posts_link(); ?></li>
            <li>评论：<?php comments_popup_link(__('没有评论'), __('1 条评论'), __('% 条评论'), '', __('评论被关闭了') ); ?></li>
            <li>分类：<?php the_category('，') ?></li>
            <?php the_tags( '<li>标签：', '，', '</li>'); ?>
          </ul>
          <div class="single-third">
          	<?php the_content('<span>继续阅读 »</span>'); ?>
          </div>
          <?php presscore_relatedpost();?>
          <?php comments_template(); ?>
       </div>
	<?php endwhile; ?>
	<?php else : ?>
     <div class="blog" id="post-<?php the_ID(); ?>">
        <h2>这里面居然什么都没有~</h2>
          <div class="third">
            <p class="homeindex">这个里面居然什么都没有~~看看别的吧~</p>
          </div>
      </div>
    <?php endif; ?>
      </div>
      <!-- END: .content -->
    </section>
<?php get_footer(); ?>