
<?php
/**
 * Theme by yefengs
 * 
 * @package Yfolio Theme 
 * @author yefengs
 * @version 1.0
 * @link http://yefengs.com/theme/yfolio
 */ 
get_header(); ?>
    <section id="main">
      <div id="blog" class="content">
      	<div class="page_title">
          <h3><span>Read Our Blog</span></h3>
        </div>
	<?php if (have_posts()) : ?>
 	  <?php $post = $posts[0];  ?>
 	  <?php  if (is_category()) { ?>
		<h2 class="pagetitle">在分类目录《<?php single_cat_title(); ?>》中有如下文章</h2>
 	  <?php  } elseif( is_tag() ) { ?>
		<h2 class="pagetitle">含有标签『<?php single_tag_title(); ?>』的文章如下</h2>
 	  <?php  } elseif (is_day()) { ?>
		<h2 class="pagetitle">在这一天的<?php the_time('F jS, Y'); ?>文章有如下</h2>
 	  <?php  } elseif (is_month()) { ?>
		<h2 class="pagetitle">在<?php the_time('F, Y'); ?>这段时间里的文章如下</h2>
 	  <?php } elseif (is_year()) { ?>
		<h2 class="pagetitle">在这<?php the_time('Y'); ?>一年里的文章如下</h2>
	  <?php  } elseif (is_author()) { ?>
	   <h2 class="pagetitle">这些年来博主写了如下文章</h2>
 	  <?php  } elseif (isset($_GET['paged']) && !empty($_GET['paged'])) { ?>
		<h2 class="pagetitle">博客存档文章</h2>
 	  <?php } 
endif; ?>
 	  <?php if (have_posts()) { ?>
    <?php while (have_posts()) : the_post(); ?>
        <div class="blog" id="post-<?php the_ID(); ?>">
        <h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
        <div class="first">
          <a href="<?php the_permalink() ?>">
          <?php post_thumbnail(610,171);?>
          </a>
            <span class="date"><?php the_time('M') ?><br><?php the_time('d') ?></span>
        </div>
          <ul class="one-fourth">
            <li>作者: <?php the_author_posts_link(); ?></li>
            <li>分类: <?php the_category('，') ?></li>
            <li>评论: <?php comments_popup_link(__('无评论'), __('1 条评论'), __('% 条评论'), '', __('评论关闭了') ); ?></li>
            <?php the_tags( '<li>标签: ', '，', '</li>'); ?>
          </ul>
          <div class="third">
            <?php //the_content('<span>继续阅读 »</span>'); ?>
            <p class="homeindex"><?php echo cut_str(strip_tags(apply_filters('the_content',$post->post_content)),180); ?>   <a href="<?php the_permalink() ?>">全文阅读</a></p>
          </div>
        </div>
  <?php endwhile; ?>
  <?php global $wp_query, $paged;$max_page = $wp_query->max_num_pages;if ( $max_page != 1 ){?>
        <div class="pagination">
                <?php pagenavi(); ?> 
        </div>
  <?php }} else { ?>
     <div class="blog" id="post-<?php the_ID(); ?>">
        <h2>这里面居然什么都没有~</h2>
          <div class="third">
            <p class="homeindex">这个里面居然什么都没有~~看看别的吧~</p>
          </div>
      </div>
  <?php } ?>  
      </div>
      <!-- END: .content -->
    </section>
<?php get_footer(); ?>