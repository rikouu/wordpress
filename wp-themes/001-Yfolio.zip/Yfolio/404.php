<?php
/**
 * Theme by yefengs
 * 
 * @package Y-say Theme 
 * @author yefengs
 * @version 1.0
 * @link http://yefengs.org/theme/y-say
 */  
get_header(); ?>
    <section id="main">
      <div id="blog" class="content">
        <div class="page_title">
          <h3><span>404 Error</span></h3>
        </div>
      <div class="blog" id="post-<?php the_ID(); ?>">
            <h2>404 Error - Not found</h2>
          <div class="third">
             <h3>Sorry, but you are looking for something that isn't here.</h3>
             <p class="homeindex">对不起！ 你访问的页面不存在，可能被博主删除或页面地址被修改~请尝试搜索或者联系博主~</p>
          </div>
        </div>
      </div>
    </section>
<?php get_footer(); ?> 