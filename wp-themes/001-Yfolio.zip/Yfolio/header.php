<?php 
/**
 * Theme by yefengs
 * 
 * @package Yfolio Theme 
 * @author yefengs
 * @version 1.0
 * @link http://yefengs.com/theme/yfolio
 */
?>
<!DOCTYPE HTML>
<html>
<head>
   <meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
   <title><?php if ( is_tag() ) { echo wp_title('Tag:');if($paged > 1) printf(' - 第%s页',$paged);echo ' | '; bloginfo( 'name' );} elseif ( is_archive() ) {echo wp_title('');  if($paged > 1) printf(' - 第%s页',$paged);    echo ' | ';    bloginfo( 'name' );} elseif ( is_search() ) {echo '&quot;'.wp_specialchars($s).'&quot;的搜索结果 | '; bloginfo( 'name' );} elseif ( is_home() ) {bloginfo( 'name' );$paged = get_query_var('paged'); if($paged > 1) printf(' - 第%s页',$paged);}  elseif ( is_404() ) {echo '404错误 页面不存在！ | '; bloginfo( 'name' );} else {echo wp_title( ' | ', false, right )  ; bloginfo( 'name' );} ?></title>
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="all" />
   <!--[if lt IE 9]>
   <script src="<?php bloginfo('template_directory'); ?>/js/html5.js" type="text/javascript"></script>
   <![endif]-->
   <script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/yfolio.js"></script>
   <link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
   <?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?><?php wp_head(); ?>
</head>
<body>
<div id="page">
  <div id="page_container">
    <aside id="header">
      <h1 id="logo"><a class="menu" href="<?php echo get_option('home'); ?>/" title="<?php bloginfo('description'); ?>" ><?php bloginfo('name'); ?></a></h1>
      <nav id="main-nav">
        <ul>
        <?php wp_nav_menu(array('container' => 'false', 'items_wrap' => '%3$s', 'theme_location' => 'topbar')); ?>
        </ul>
      </nav>
      <div class="widget">
        <ul class="social">
          <li><a href="http://weibo.com" rel="external nofollow" class="sina" title="新浪微博">sina</a></li>
          <li><a href="http://t.qq.com" rel="external nofollow" class="tweibo" title="腾讯微博">QQweibo</a></li>
          <li><a href="http://qzone.qq.com" rel="external nofollow" class="qzone" title="QQ空间">QQzone</a></li>
          <li><a href="http://renren.com" rel="external nofollow" class="renren" title="人人网">Renren</a></li>
          <li><a href="<?php bloginfo('rss2_url'); ?>"  rel="external nofollow" class="rss" title="Rss订阅">Rss</a></li>
        </ul>
      </div>
      <div id="searchbox">
        <form method="get" id="searchform" action="<?php echo esc_url( home_url( '/' ) ); ?>">
            <input type="text" value="" name="s" id="s" placeholder="Search.." x-webkit-speech="x-webkit-speech">
        </form>
      </div>
      <div id="copy-right">
        <p>&copy; 2013.<a target="_blank" href="<?php echo get_option('home'); ?>/"><?php bloginfo('name'); ?></a>.<br />Power by Wordpress,<a href="http://yefengs.com/theme/YFOLIO">YFOLIO</a></p>
      </div>
    </aside>