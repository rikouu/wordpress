<?php
/**
 * Theme by yefengs
 * 
 * @package Y-say Theme 
 * @author yefengs
 * @version 1.0
 * @link http://yefengs.org/theme/y-say
 */  
get_header(); ?>
    <section id="main">
      <div id="blog" class="content">
      	<div class="page_title">
          <h3><span><?php bloginfo('description'); ?></span></h3>
        </div>
  <?php if (have_posts()) { ?>
    <?php while (have_posts()) : the_post(); ?>
        <div class="blog" id="post-<?php the_ID(); ?>">
		    <h2><a href="<?php the_permalink() ?>"><?php the_title(); ?></a></h2>
        <div class="first">
          <a href="<?php the_permalink() ?>">
          <?php post_thumbnail(610,171);?>
          </a>
            <span class="date"><?php the_time('M') ?><br><?php the_time('d') ?></span>
        </div>
          <ul class="one-fourth">
          	<li>作者: <?php the_author_posts_link(); ?></li>
            <li>分类: <?php the_category('，') ?></li>
            <li>评论: <?php comments_popup_link(__('无评论'), __('1 条评论'), __('% 条评论'), '', __('评论关闭了') ); ?></li>
            <?php the_tags( '<li>标签: ', '，', '</li>'); ?>
          </ul>
          <div class="third">
          	<?php //the_content('<span>继续阅读 »</span>'); ?>
            <p class="homeindex"><?php echo cut_str(strip_tags(apply_filters('the_content',$post->post_content)),180); ?>   <a href="<?php the_permalink() ?>">全文阅读</a></p>
          </div>
        </div>
  <?php endwhile; ?>
  <?php global $wp_query, $paged;$max_page = $wp_query->max_num_pages;if ( $max_page != 1 ){?>
        <div class="pagination">
                <?php pagenavi(); ?> 
        </div>
  <?php }} else { ?>
           <div class="blog" id="post-<?php the_ID(); ?>">
        <h2>这里面居然什么都没有~</h2>
          <div class="third">
            <p class="homeindex">这个里面居然什么都没有~~看看别的吧~</p>
          </div>
      </div>
  <?php } ?>  
      </div>
      <!-- END: .content -->
    </section>
<?php get_footer(); ?>  