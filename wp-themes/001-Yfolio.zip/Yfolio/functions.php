<?php
/**
 * Theme by yefengs
 * 
 * @package Yfolio Theme 
 * @author yefengs
 * @version 1.0
 * @link http://yefengs.com/theme/yfolio
 */

wp_enqueue_script( 'jquerylib', get_bloginfo('template_directory'). '/js/jquery.js', array(), '1.7.2', false);
register_nav_menus( array('topbar' => __( 'topmenu'),));
/* Mini Pagenavi v1.0 by Willin Kan. */
if ( !function_exists('pagenavi') ) {
function pagenavi( $p = 3 ) { 
if ( is_singular() ) return; 
global $wp_query, $paged;
$max_page = $wp_query->max_num_pages;
if ( $max_page == 1 ) return; 
if ( empty( $paged ) ) $paged = 1;
echo "<ul>";
$navof='<span>Page ' . $paged . ' of ' . $max_page . '</span>'; 
if ( $paged > $p + 1 ) p_link( 1, '第一页' );
if ( $paged > $p + 2 ) echo '<li class="page-numbers">... </li>';
for( $i = $paged - $p; $i <= $paged + $p; $i++ ) { // 中間頁
if ( $i > 0 && $i <= $max_page ) $i == $paged ? print "<li class='page-numbers current'>{$i}</li> " : p_link( $i );
}
if ( $paged < $max_page - $p - 1 ) echo '<li class="page-numbers more">... </li>';
if ( $paged < $max_page - $p ) p_link( $max_page, '最后一页' );
echo "</ul>";
echo $navof;
}
function p_link( $i, $title = '' ) {
if ( $title == '' ) $title = "第 {$i} 页";
echo "<li class='page-numbers'><a class='page-link' href='", esc_html( get_pagenum_link( $i ) ), "' title='{$title}'>{$i}</a> </li>";} }

add_theme_support( 'post-thumbnails' );
function post_thumbnail( $width = 255,$height = 130 ){
    global $post;
    if( has_post_thumbnail() ){
        $timthumb_src = wp_get_attachment_image_src(get_post_thumbnail_id($post->ID),'full');
        $post_timthumb = '<a href="'.get_permalink().'"><img src="'.get_bloginfo("template_url").'/timthumb.php?src='.$timthumb_src[0].'&amp;h='.$height.'&amp;w='.$width.'&amp;zc=1" alt="'.$post->post_title.'" class="thumb" title="'.get_the_title().'"/></a>';
        echo $post_timthumb;
    } else {
			$content = $post->post_content;
			preg_match_all('/<img.*?(?: |\\t|\\r|\\n)?src=[\'"]?(.+?)[\'"]?(?:(?: |\\t|\\r|\\n)+.*?)?>/sim', $content, $strResult, PREG_PATTERN_ORDER);
			$n = count($strResult[1]);
			if($n > 0){
				echo '<img src="'.get_bloginfo("template_url").'/timthumb.php?w='.$width.'&amp;h='.$height.'&amp;src='.$strResult[1][0].'" title="'.get_the_title().'" alt="'.get_the_title().'"/>';
			} else {
			
			$category = get_the_category(); 
				echo '<img src="'.get_bloginfo('template_url').'/images/no-thum.jpg" title="'.get_the_title().'" alt="'.get_the_title().'"/>';
			}
		}
	}


function presscore_relatedpost() { 

echo '<div id="rlt-post"><h4>RelatedPost</h4><ul>';
	$post_num = 8;
$exclude_id = $post->ID;
$posttags = get_the_tags(); $i = 0;
if ( $posttags ) {
	$tags = ''; foreach ( $posttags as $tag ) $tags .= $tag->term_id . ',';
	$args = array(
		'post_status' => 'publish',
		'tag__in' => explode(',', $tags),
		'post__not_in' => explode(',', $exclude_id),
		'ignore_sticky_posts' => 1,
		'orderby' => 'comment_date',
		'posts_per_page' => $post_num
	);
	query_posts($args);
	while( have_posts() ) { the_post(); ?>
		<li>
			
			<a href="<?php the_permalink(); ?>" ><?php the_title(); ?></a>
		</li>
	<?php
		$exclude_id .= ',' . $post->ID; $i ++;
	} wp_reset_query();
}
if ( $i < $post_num ) {
	$cats = ''; foreach ( get_the_category() as $cat ) $cats .= $cat->cat_ID . ',';
	$args = array(
		'category__in' => explode(',', $cats),
		'post__not_in' => explode(',', $exclude_id),
		'ignore_sticky_posts' => 1,
		'orderby' => 'comment_date',
		'posts_per_page' => $post_num - $i
	);
	query_posts($args);
	while( have_posts() ) { the_post(); ?>
		<li>
			
			<a href="<?php the_permalink(); ?>" ><?php the_title(); ?></a>
		</li>
 
	<?php $i++;
	} wp_reset_query();
}
if ( $i  == 0 )  echo '<li>没有相关文章!</li>';
	echo '</ul></div><div class="clearfix"></div>';
}

// 中文截断文字
function cut_str($string, $sublen, $start = 0, $code = 'UTF-8'){if($code == 'UTF-8'){$pa = "/[\x01-\x7f]|[\xc2-\xdf][\x80-\xbf]|\xe0[\xa0-\xbf][\x80-\xbf]|[\xe1-\xef][\x80-\xbf][\x80-\xbf]|\xf0[\x90-\xbf][\x80-\xbf][\x80-\xbf]|[\xf1-\xf7][\x80-\xbf][\x80-\xbf][\x80-\xbf]/";preg_match_all($pa, $string, $t_string);if(count($t_string[0]) - $start > $sublen) return join('', array_slice($t_string[0], $start, $sublen))."...";return join('', array_slice($t_string[0], $start, $sublen));}else{$start = $start*2;$sublen = $sublen*2;$strlen = strlen($string);$tmpstr = '';for($i=0; $i<$strlen; $i++){ if($i>=$start && $i<($start+$sublen)){if(ord(substr($string, $i, 1))>129) $tmpstr.= substr($string, $i, 2);else $tmpstr.= substr($string, $i, 1);}if(ord(substr($string, $i, 1))>129) $i++;}if(strlen($tmpstr)<$strlen ) $tmpstr.= "...";return $tmpstr;}};

function time_ago( $type = 'commennt', $day = 30 ) {$d = $type == 'post' ? 'get_post_time' : 'get_comment_time';$timediff = time() - $d('U');if ($timediff <= 60*60*24*$day){echo  human_time_diff($d('U'), strtotime(current_time('mysql', 0))), '前';}if ($timediff > 60*60*24*$day){echo  date('Y/m/d',get_comment_date('U')), ' ', get_comment_time('H:i');};}

function yefengscomment($comment, $args, $depth) {$GLOBALS['comment'] = $comment;?><li  <?php comment_class('commenttips',$comment_id,$comment_post_ID); ?> ><?php echo get_avatar( get_comment_author_email(), '38'); ?><div class="commentdiv" id="comment-<?php comment_ID() ?>"><span><strong><?php comment_author_link();?></strong>Says：　</span><small><?php echo time_ago(); ?>  <?php edit_comment_link('[编辑]'); ?></small><?php if ($comment->comment_approved == '0') : ?><small>亲~你是第一次来~你的评论需要审核哦~</small><?php endif; ?><span class="replylink"><?php comment_reply_link(array_merge( $args, array('reply_text' => '回复','depth' => $depth, 'max_depth' => $args['max_depth']))) ?></span><?php comment_text() ?></div><?php }

// NO Fuck Code!  lalala ~~~~~~~~
?>