<?php
/**
 * The Header for our theme.
 *
 * Displays all of the <head> section and everything up till <div id="content">
 *
 * @package seabye_blue
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<title><?php
if (is_home () ) { bloginfo('name'); print " - "; bloginfo('description'); }
elseif (is_category() ) { single_cat_title(); print " - "; bloginfo('name'); }
elseif (is_single() ) { single_post_title(); print " - "; bloginfo('name'); }
elseif (is_page() ) { single_post_title(); print " - "; bloginfo('name'); }
elseif (is_tag() ) { single_tag_title(); print " - "; bloginfo('name'); }
elseif (is_year() ) { the_time(Y); print " - "; bloginfo('name'); }
elseif (is_month() ) { the_time(Y); print "."; the_time(m); print " - "; bloginfo('name'); }
elseif (is_day() ) { the_time(Y); print "."; the_time(m); print "."; the_time(d); print " - "; bloginfo('name'); }
elseif (is_404() ) { print "404 Not Found - "; bloginfo('name'); }
else { wp_title('',true); print " - "; bloginfo('name'); }
?></title>
<link rel="shortcut icon" href="/favicon.ico">
<link rel="apple-touch-icon" href="/apple-touch-icon.png">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">

<!-- search engine -->
<?php if (is_home()){
	$description = "标题";
	$keywords = "关键字,关键字,关键字";
} elseif (is_single()){
	$description = substr(strip_tags($post->post_content),0,220);
	$description = str_replace(array("\r\n", "\r", "\n"), "", $description);
	$keywords = "";
	$tags = wp_get_post_tags($post->ID);
	foreach ($tags as $tag ) {
	$keywords = $keywords . $tag->name . ",";
	}
	$keywords = substr($keywords,0,-1);
}
?>
<meta name="keywords" content="<?=$keywords?>">
<meta name="description" content="<?=$description?>">

<!-- jquery -->
<script src="<?php esc_url('home_url'); ?>/wp-includes/js/jquery/jquery.js"></script>

<!-- wp head -->
<?php wp_head(); ?>

<!-- seabye js -->
<script src="<?php bloginfo('template_url'); ?>/js/seabye.js"></script>

<!-- keyboard page -->
<?php wp_reset_query();if (is_home() || is_archive() || is_search()) { ?>
<script>
	document.onkeydown = chang_page;function chang_page(e) {
		var e = e || event,
		keycode = e.which || e.keyCode;
		if (keycode == 37) location = '<?php echo get_previous_posts_page_link(); ?>';
		if (keycode == 39) location = '<?php echo get_next_posts_page_link(); ?>';
	}
</script>
<?php } ?>
</head>

<body <?php body_class(); ?>>

<div id="page" class="hfeed site">
	<a class="skip-link screen-reader-text" href="#content"><?php _e( 'Skip to content', 'seabye_blue' ); ?></a>

	<header id="masthead" class="site-header" role="banner">

		<nav id="site-navigation" class="main-navigation" role="navigation">
			<button class="menu-toggle"><?php _e( 'Primary Menu', 'seabye_blue' ); ?></button>
			<div class="follow-menu">
				<div class="site-logo">
					<a href="<?php bloginfo( 'url' ); ?>" title="<?php bloginfo( 'name' ); ?>"><img src="<?php bloginfo( 'url' ); ?>/logo.png"></a>
				</div>
			<?php wp_nav_menu( array( 'theme_location' => 'primary', 'walker' => new description_walker ) ); ?>
			<?php get_search_form(); ?>
			</div>
		</nav><!-- #site-navigation -->

	</header><!-- #masthead -->

	<div id="content" class="site-content">