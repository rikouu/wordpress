<?php
/**
 * Jetpack Compatibility File
 * See: http://jetpack.me/
 *
 * @package seabye_blue
 */

/**
 * Add theme support for Infinite Scroll.
 * See: http://jetpack.me/support/infinite-scroll/
 */
function seabye_blue_jetpack_setup() {
	add_theme_support( 'infinite-scroll', array(
		'container' => 'main',
		'footer'    => 'page',
	) );
}
add_action( 'after_setup_theme', 'seabye_blue_jetpack_setup' );
