<?php
/**
 * Custom template tags for this theme.
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package seabye_blue
 */

if ( ! function_exists( 'seabye_blue_paging_nav' ) ) :
/**
 * Display navigation to next/previous set of posts when applicable.
 */
function seabye_blue_paging_nav() {
	// Don't print empty markup if there's only one page.
	if ( $GLOBALS['wp_query']->max_num_pages < 2 ) {
		return;
	}
	?>
	<nav class="site-nav-links">
		<?php par_pagenavi(9); ?>
	</nav><!-- .navigation -->
	<?php
}
endif;

if ( ! function_exists( 'seabye_blue_post_nav' ) ) :
/**
 * Display navigation to next/previous post when applicable.
 */
function seabye_blue_post_nav() {
	// Don't print empty markup if there's nowhere to navigate.
	$previous = ( is_attachment() ) ? get_post( get_post()->post_parent ) : get_adjacent_post( false, '', true );
	$next     = get_adjacent_post( false, '', false );

	if ( ! $next && ! $previous ) {
		return;
	}
	?>
	<nav class="navigation post-navigation" role="navigation">
		<h1 class="screen-reader-text"><?php _e( 'Post navigation', 'seabye_blue' ); ?></h1>
		<div class="nav-links">
			<?php
				$current_category=get_the_category(); // All Categories: the_category // Same classification: get_the_category
				$previous_post_link = get_previous_post($current_category,'');
    				$next_post_link = get_next_post($current_category,'');
			?>
			<?php if (!empty( $previous_post_link )): ?>
				<div class="nav-previous">
					<span class="meta-nav">&lsaquo;</span>
					<a href="<?php echo get_permalink( $previous_post_link->ID ); ?>" class="steam_prev" title="<?php echo $previous_post_link->post_title; ?>"><?php echo $previous_post_link->post_title; ?></a>
				</div>
			<?php endif; ?>
			<?php if (!empty( $next_post_link )): ?>
				<div class="nav-next">
					<a href="<?php echo get_permalink( $next_post_link->ID ); ?>" class="steam_next" title="<?php echo $next_post_link->post_title; ?>"><?php echo $next_post_link->post_title; ?></a>
					<span class="meta-nav">&rsaquo;</span>
				</div>
			<?php endif; ?>
		</div><!-- .nav-links -->
	</nav><!-- .navigation -->
	<div class="single_related_posts">
		<h1 class="rel-text"><?php _e( 'Referrals', 'seabye_blue' ); ?></h1>
		<div class="rel-links">
			<?php single_related_posts(); ?>
		</div><!-- .rel-links -->
	</div><!-- .single_related_posts -->
	
	<?php if ( is_active_sidebar( 'custom-single-pc' ) ) : ?>
		<?php dynamic_sidebar( 'custom-single-pc' ); ?>
	<?php else : ?>
	<?php endif; ?>

	<?php if ( is_active_sidebar( 'custom-single-phone' ) ) : ?>
		<?php dynamic_sidebar( 'custom-single-phone' ); ?>
	<?php else : ?>
	<?php endif; ?>

	<?php
}
endif;

if ( ! function_exists( 'seabye_blue_posted_on' ) ) :
/**
 * Prints HTML with meta information for the current post-date/time and author.
 */
function seabye_blue_posted_on() {
	$time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time>';
	if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
		$time_string .= '<time class="updated" datetime="%3$s">%4$s</time>';
	}

	$time_string = sprintf( $time_string,
		esc_attr( get_the_date( 'c' ) ),
		esc_html( get_the_date() ),
		esc_attr( get_the_modified_date( 'c' ) ),
		esc_html( get_the_modified_date() )
	);

	$posted_on = sprintf(
		_x( 'Posted on %s', 'post date', 'seabye_blue' ),
		'<a href="' . esc_url( get_permalink() ) . '" rel="bookmark">' . $time_string . '</a>'
	);

	$byline = sprintf(
		_x( 'by %s', 'post author', 'seabye_blue' ),
		'<span class="author vcard"><a class="url fn n" href="' . esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ) . '">' . esc_html( get_the_author() ) . '</a></span>'
	);

	echo '<span class="posted-on">' . $posted_on . '</span><span class="byline"> ' . $byline . '</span>';

}
endif;

/**
 * Returns true if a blog has more than 1 category.
 *
 * @return bool
 */
function seabye_blue_categorized_blog() {
	if ( false === ( $all_the_cool_cats = get_transient( 'seabye_blue_categories' ) ) ) {
		// Create an array of all the categories that are attached to posts.
		$all_the_cool_cats = get_categories( array(
			'fields'     => 'ids',
			'hide_empty' => 1,

			// We only need to know if there is more than one category.
			'number'     => 2,
		) );

		// Count the number of categories that are attached to the posts.
		$all_the_cool_cats = count( $all_the_cool_cats );

		set_transient( 'seabye_blue_categories', $all_the_cool_cats );
	}

	if ( $all_the_cool_cats > 1 ) {
		// This blog has more than 1 category so seabye_blue_categorized_blog should return true.
		return true;
	} else {
		// This blog has only 1 category so seabye_blue_categorized_blog should return false.
		return false;
	}
}

/**
 * Flush out the transients used in seabye_blue_categorized_blog.
 */
function seabye_blue_category_transient_flusher() {
	// Like, beat it. Dig?
	delete_transient( 'seabye_blue_categories' );
}
add_action( 'edit_category', 'seabye_blue_category_transient_flusher' );
add_action( 'save_post',     'seabye_blue_category_transient_flusher' );