<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package seabye_blue
 */
?>

	</div><!-- #content -->
</div><!-- #page -->

	<footer id="colophon" class="site-footer" role="contentinfo">
		<div class="footer-width">
		<div class="menu-footer">
			<?php wp_nav_menu( array( 'theme_location' => 'menu_footer', 'depth' => 1 ) ); ?>
		</div>

		<div class="site-info">
			<a href="<?php echo esc_url( __( 'http://wordpress.org/', 'seabye_blue' ) ); ?>"><?php printf( __( 'Proudly powered by %s', 'seabye_blue' ), 'WordPress' ); ?></a><span class="sep">. </span>
			<?php printf( __( 'Theme: %1$s by %2$s.', 'seabye_blue' ), 'seabye_blue', '<a href="http://meiri.me" rel="designer">seabye</a>.' ); ?>
		</div><!-- .site-info -->
		<div id="returnTop" class="returnTop" style="width:36px;">
			<span class="s"></span>
			<span class="ss"></span>
			<span class="b"></span>
		</div><!-- returnTop -->
		</div><!-- #footer -->
	</footer><!-- #colophon -->


<?php wp_footer(); ?>

<script src="<?php bloginfo('template_url'); ?>/js/media.js"></script><!-- media -->

</body>

</html>
