<?php
/**
 * Template Name: Page Tags
 *
 * @package seabye_blue
 */

get_header(); ?>

	<section id="primary" class="content-area page-tags">
		<main id="main" class="site-main" role="main">

		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

			<header class="page-header">
				<h1 class="page-title"><?php the_title(); ?></h1>
			</header><!-- .entry-header -->

			<div class="entry-content">
				<!-- ASC+ DESC- RAND -->
				<?php wp_tag_cloud( 'number=0' ); ?>
				<?php // wp_tag_cloud( 'smallest=12&largest=18&unit=px&number=0&orderby=count&order=DESC' ); ?>
			</div><!-- .entry-content -->

			<footer class="entry-footer">
				<?php edit_post_link( __( 'Edit', 'seabye_blue' ), '<span class="edit-link">', '</span>' ); ?>
			</footer><!-- .entry-footer -->

		</article><!-- #article -->

		</main><!-- #main -->
	</section><!-- #primary -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>
