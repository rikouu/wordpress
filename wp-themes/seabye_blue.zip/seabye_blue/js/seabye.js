/**
 * seabye.js
 *
 * Short script collection.
 */

// open external links in a new window
jQuery(document).ready(function($){
    $("a[href*='http://']:not([href*='"+location.hostname+"']),[href*='https://']:not([href*='"+location.hostname+"'])")
    .addClass("external")
	.attr("target","_blank");
});

// scroll follow
jQuery(window).scroll(function(){
    if (jQuery(window).scrollTop()>127){
		jQuery(".main-navigation").addClass('follow-open');
	}else{
		jQuery(".main-navigation").removeClass('follow-open');
	}
});

// wrong images
jQuery(document).ready(function(){
	jQuery('img').attr('onError','this.src="/wp-content/themes/seabye_blue/images/error.png"');
});

// returnTop
jQuery(function(){
	// 给 window 对象绑定 scroll 事件
	jQuery(window).bind("scroll", function(){

		// 获取网页文档对象滚动条的垂直偏移
		var scrollTopNum = jQuery(document).scrollTop(),
			// 获取浏览器当前窗口的高度
			winHeight = jQuery(window).height(),
			returnTop = jQuery("div.returnTop");

		// 滚动条的垂直偏移大于 0 时显示，反之隐藏
		(scrollTopNum > 0) ? returnTop.fadeIn("fast") : returnTop.fadeOut("fast");

	});

	// 点击按钮后，滚动条的垂直方向的值逐渐变为 0，也就是滑动向上的效果
	jQuery("div.returnTop").click(function() {
		jQuery("html, body").animate({ scrollTop: 0 }, 100);
	});

});

/* // xxx prohibited actions
function stop(){
return false;
}
document.oncontextmenu=stop; // right
document.ondragstart=stop; // drag
document.onselectstart=stop; // selected
document.onkeydown = function (e) {
	var ev = window.event || e;
	var code = ev.keyCode || ev.which;
	if (code == 116) {
	ev.keyCode ? ev.keyCode = 0 : ev.which = 0;
	cancelBubble = true;
	return false;
	}
} // refresh */
