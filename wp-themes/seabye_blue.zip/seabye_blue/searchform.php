<form role="search" method="get" class="search-form" action="<?php echo home_url( '/' ); ?>">
	<fieldset>
		<label>
			<span class="screen-reader-text"><?php _e( 'Search:', 'seabye_blue' ); ?></span>
			<input type="search" class="search-field" placeholder="<?php _e( 'Search...', 'seabye_blue' ); ?>" value="<?php the_search_query(); ?>" name="s" title="<?php _e( 'Search:', 'seabye_blue' ); ?>" autocomplete="off" />
			<input type="submit" class="search-submit" value="<?php _e( 'Search', 'seabye_blue' ); ?>" />
		</label>
	</fieldset>
</form>