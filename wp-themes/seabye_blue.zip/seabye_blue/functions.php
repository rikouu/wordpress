<?php
/**
 * seabye_blue functions and definitions
 *
 * @package seabye_blue
 */

/**
 * Set the content width based on the theme's design and stylesheet.
 */
if ( ! isset( $content_width ) ) {
	$content_width = 640; /* pixels */
}

if ( ! function_exists( 'seabye_blue_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function seabye_blue_setup() {

	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on seabye_blue, use a find and replace
	 * to change 'seabye_blue' to the name of your theme in all the template files
	 */
	load_theme_textdomain( 'seabye_blue', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link http://codex.wordpress.org/Function_Reference/add_theme_support#Post_Thumbnails
	 */
	add_theme_support( 'post-thumbnails' );

	// This theme uses wp_nav_menu() in one location.
	register_nav_menus( array(
		'primary' => __( 'Primary Menu', 'seabye_blue' ),
		'menu_footer' => '底部菜单',
	) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form', 'comment-form', 'comment-list', 'gallery', 'caption'
	) );

	/*
	 * Enable support for Post Formats.
	 * See http://codex.wordpress.org/Post_Formats
	 */
//	add_theme_support( 'post-formats', array(
//		'aside', 'image', 'video', 'quote', 'link'
//	) );

	// Setup the WordPress core custom background feature.
//	add_theme_support( 'custom-background', apply_filters( 'seabye_blue_custom_background_args', array(
//		'default-color' => 'ffffff',
//		'default-image' => '',
//	) ) );
}
endif; // seabye_blue_setup
add_action( 'after_setup_theme', 'seabye_blue_setup' );

/**
 * Register widget area.
 *
 * @link http://codex.wordpress.org/Function_Reference/register_sidebar
 */
/* function seabye_blue_widgets_init() {
	register_sidebar( array(
		'name'          => __( 'Sidebar', 'seabye_blue' ),
		'id'            => 'sidebar-1',
		'description'   => '',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<h1 class="widget-title">',
		'after_title'   => '</h1>',
	) );
}
add_action( 'widgets_init', 'seabye_blue_widgets_init' ); */

/**
 * Enqueue scripts and styles.
 */
function seabye_blue_scripts() {
	wp_enqueue_style( 'seabye_blue-style', get_stylesheet_uri() );

	wp_enqueue_script( 'seabye_blue-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20120206', true );

	wp_enqueue_script( 'seabye_blue-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20130115', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'seabye_blue_scripts' );

/**
 * Implement the Custom Header feature.
 */
//require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Custom functions that act independently of the theme templates.
 */
require get_template_directory() . '/inc/extras.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
require get_template_directory() . '/inc/jetpack.php';

// seabye start

// 小工具 custom
register_sidebar(array(
	'id' => 'custom-sidebar-search-pc',
	'name' => '边栏 搜索下方: 电脑',
	'before_widget' => '<aside id="custom-sidebar-search-pc" class="widget custom custom-sidebar-search pc">',
	'after_widget' => '</aside>',
	'before_title' => '<h1 class="widget-title custom custom-sidebar-search">',
	'after_title' => '</h1><span class="widget-hr"></span>',
));
register_sidebar(array(
	'id' => 'custom-sidebar-comment-pc',
	'name' => '边栏 评论下方: 电脑',
	'before_widget' => '<aside id="custom-sidebar-comment-pc" class="widget custom custom-sidebar-comment pc">',
	'after_widget' => '</aside>',
	'before_title' => '<h1 class="widget-title custom custom-sidebar-comment">',
	'after_title' => '</h1><span class="widget-hr"></span>',
));
register_sidebar(array(
	'id' => 'custom-page-pc',
	'name' => '页面 引荐下方: 电脑',
	'before_widget' => '<aside id="custom-single-pc" class="widget custom custom-single pc">',
	'after_widget' => '</aside>',
	'before_title' => '<h1 class="widget-title custom custom-single">',
	'after_title' => '</h1><span class="widget-hr"></span>',
));
register_sidebar(array(
	'id' => 'custom-page-phone',
	'name' => '页面 引荐下方: 手机 ( 无效 )',
	'before_widget' => '<aside id="custom-single-phone" class="widget custom custom-single phone">',
	'after_widget' => '</aside>',
	'before_title' => '<h1 class="widget-title custom custom-single">',
	'after_title' => '</h1><span class="widget-hr"></span>',
));
register_sidebar(array(
	'id' => 'custom-text-pc',
	'name' => '文章 正文底部: 电脑',
	'before_widget' => '<aside id="custom-text-pc" class="widget custom custom-text pc">',
	'after_widget' => '</aside>',
	'before_title' => '<h1 class="widget-title custom custom-text">',
	'after_title' => '</h1><span class="widget-hr"></span>',
));
register_sidebar(array(
	'id' => 'custom-text-phone',
	'name' => '文章 正文底部: 手机 ( 无效 )',
	'before_widget' => '<aside id="custom-text-phone" class="widget custom custom-text phone">',
	'after_widget' => '</aside>',
	'before_title' => '<h1 class="widget-title custom custom-text">',
	'after_title' => '</h1><span class="widget-hr"></span>',
));
register_sidebar(array(
	'id' => 'custom-single-pc',
	'name' => '文章 引荐下方: 电脑',
	'before_widget' => '<aside id="custom-single-pc" class="widget custom custom-single pc">',
	'after_widget' => '</aside>',
	'before_title' => '<h1 class="widget-title custom custom-single">',
	'after_title' => '</h1><span class="widget-hr"></span>',
));
register_sidebar(array(
	'id' => 'custom-single-phone',
	'name' => '文章 引荐下方: 手机 ( 无效 )',
	'before_widget' => '<aside id="custom-single-phone" class="widget custom custom-single phone">',
	'after_widget' => '</aside>',
	'before_title' => '<h1 class="widget-title custom custom-single">',
	'after_title' => '</h1><span class="widget-hr"></span>',
));

// admin footer text
add_filter('admin_footer_text', 'seabye_custom_admin_footer');
function seabye_custom_admin_footer() {
	echo '<span id="footer-thankyou"></span>Theme by <a href="http://meiri.me" target="_blank">seabye</a>. Thank <a href="http://underscores.me" target="_blank">Underscores</a>.';
}

// 强化菜单 调用代码 (php) wp_nav_menu( array( 'theme_location' => 'primary', 'walker' => new description_walker ) ); (/php)
// 强化菜单 结构
class description_walker extends Walker_Nav_Menu
{
	function start_el(&$output, $item, $depth, $args)
	{
		global $wp_query;
		$indent = ( $depth ) ? str_repeat( "\t", $depth ) : '';

		$class_names = $value = '';

		$classes = empty( $item->classes ) ? array() : (array) $item->classes;

		$class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item ) );
		$class_names = ' class="'. esc_attr( $class_names ) . '"';

		$output .= $indent . '<li id="menu-item-'. $item->ID . '"' . $value . $class_names .'>';

		$attributes  = ! empty( $item->attr_title ) ? ' title="'  . esc_attr( $item->attr_title ) .'"' : '';
		$attributes .= ! empty( $item->target )     ? ' target="' . esc_attr( $item->target     ) .'"' : '';
		$attributes .= ! empty( $item->xfn )        ? ' rel="'    . esc_attr( $item->xfn        ) .'"' : '';
		$attributes .= ! empty( $item->url )        ? ' href="'   . esc_attr( $item->url        ) .'"' : '';

		$prepend = '<span>';
		$append = '</span>';
		$description  = ! empty( $item->description ) ? '<span>'.esc_attr( $item->description ).'</span>' : '';

		if($depth != 0)
		{
			$description = $append = $prepend = "";
		}

		$item_output = $args->before;
		$item_output .= '<a'. $attributes .'>';
		$item_output .= $args->link_before .$prepend.apply_filters( 'the_title', $item->title, $item->ID ).$append;
		/* // seabye++
		if ( $item->description<=0 ) { $item_output .= $description; }
			else { $item_output .= '<span class="day">+'.get_this_week_post_count_by_category($item->description).'</span>'; }
		$item_output .= $args->link_after;
		// seabye++ end
		// $item_output .= $description.$args->link_after; */
		$item_output .= '</a>';
		$item_output .= $args->after;

		$output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
	}
}
/* // 强化菜单 代表时间
// 一日 today
// 一周 1 week ago
// 一年 1 year ago
// 一千年 1000 year ago
function get_this_week_post_count_by_category($id) {

	$date_query = array(
		array(
			'after' => 'today'
			)
		);
	$tax_query = array(
		array(
			'taxonomy' => 'category',
				'field' => 'id',
				'terms' => $id
			)
		);

	$args = array(
		'post_type' => 'post',
		'post_status' => 'publish',
		'tax_query' => $tax_query,
		'date_query' => $date_query,
		'no_found_rows' => true,
		'suppress_filters' => true,
		'fields' => 'ids',
		'posts_per_page' => -1
		);

	$query = new WP_Query( $args );

	return $query->post_count;
} */

/* // 24小时内更新数 调用代码 (php) echo num_posts(); (/php)
function num_posts($days=1) { // $days 设定时间1天
	global $wpdb;
	$today = gmdate('Y-m-d H:i:s', time() + 3600 * 8); // 获取当前时间
	$daysago = date( "Y-m-d H:i:s", strtotime($today) - ($days * 24 * 60 * 60) );  // Today - $days
	$result = $wpdb->get_results("SELECT ID FROM $wpdb->posts WHERE post_date BETWEEN '$daysago' AND '$today' AND post_status='publish' AND post_type='post' ORDER BY post_date DESC ");         
		foreach ($result as $Item) {
			$post_ID[] = $Item->ID; // 已发布的文章ID 写入数组
		}
	$post_num = count($post_ID); // 输出数组中元素个数 文章ID数量
	$output .= '<span class="new-days">+'.$post_num.'</span>'; // 输出文章数量
	echo $output;
} */

// 添加更多按钮到 HTML 编辑器 
function appthemes_add_quicktags() {
	if (wp_script_is('quicktags')){
?>
	<script>
	QTags.addButton( 'eg_hr', 'hr', '<hr>', '', 'hr', '<hr>', 500 );
	QTags.addButton( 'eg_paging', 'Paging', '<!--nextpage-->', '', 'Paging', '<!--nextpage-->', 501 );
	QTags.addButton( 'eg_audio_author', 'audio-author', '<span class="audio-author">', '</span>', 'audio-author', 'Author -', 502 );
	QTags.addButton( 'eg_audio_title', 'audio-title', '<span class="audio-title">', '</span>', 'audio-title', '- Title', 503 );
	QTags.addButton( 'eg_code_php', 'php', '[php]', '[/php]', 'php', '[php] code [/php]', 504 );
	</script>
<?php
	}
}
add_action( 'admin_print_footer_scripts', 'appthemes_add_quicktags' );

// 添加分页符按钮到 可视化 编辑器 
add_filter('mce_buttons','paging_add_next_page_button');
function paging_add_next_page_button($mce_buttons) {
	$pos = array_search('wp_more',$mce_buttons,true);
	if ($pos !== false) {
		$tmp_buttons = array_slice($mce_buttons, 0, $pos+1);
		$tmp_buttons[] = 'wp_page';
		$mce_buttons = array_merge($tmp_buttons, array_slice($mce_buttons, $pos+1));
	}
	return $mce_buttons;
}

// 网站分页 调用代码 (php) par_pagenavi(9); (/php)
function par_pagenavi($range = 9){
	global $paged, $wp_query;
	if ( !$max_page ) {$max_page = $wp_query->max_num_pages;}
	if($max_page > 1){if(!$paged){$paged = 1;}
	if($paged != 1){echo "<a href='" . get_pagenum_link(1) . "' class='extend'>&laquo;</a>";}
	previous_posts_link('&lsaquo;');
    if($max_page > $range){
		if($paged < $range){for($i = 1; $i <= ($range + 1); $i++){echo "<a href='" . get_pagenum_link($i) ."'";
		if($i==$paged)echo " class='current'";echo ">$i</a>";}}
    elseif($paged >= ($max_page - ceil(($range/2)))){
		for($i = $max_page - $range; $i <= $max_page; $i++){echo "<a href='" . get_pagenum_link($i) ."'";
		if($i==$paged)echo " class='current'";echo ">$i</a>";}}
	elseif($paged >= $range && $paged < ($max_page - ceil(($range/2)))){
		for($i = ($paged - ceil($range/2)); $i <= ($paged + ceil(($range/2))); $i++){echo "<a href='" . get_pagenum_link($i) ."'";if($i==$paged) echo " class='current'";echo ">$i</a>";}}}
    else{for($i = 1; $i <= $max_page; $i++){echo "<a href='" . get_pagenum_link($i) ."'";
    if($i==$paged)echo " class='current'";echo ">$i</a>";}}
	next_posts_link('&rsaquo;');
    if($paged != $max_page){echo "<a href='" . get_pagenum_link($max_page) . "' class='extend'>&raquo;</a>";}}
}

// 近期评论 调用代码 (php) recent_comments( $outer='', $limit='5' ); (/php)
function recent_comments( $outer, $limit ) {
	global $wpdb;
	$sql = "SELECT DISTINCT ID, post_title, post_password, comment_ID,comment_post_ID, comment_author,comment_author_email,comment_date_gmt, comment_approved, comment_type,comment_author_url, SUBSTRING(comment_content,1,15) AS com_excerpt FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts ON ($wpdb->comments.comment_post_ID = $wpdb->posts.ID) WHERE comment_approved = '1' AND comment_type = '' AND post_password = '' AND comment_author != '$outer' ORDER BY comment_date_gmt DESC LIMIT $limit";
	$comments = $wpdb->get_results($sql);
	$output = $pre_HTML;
	foreach ($comments as $comment) {
		$output .= "\n<li>".get_avatar($comment, 32)."" . "<a href=\"" . get_permalink($comment->ID) . "#comment-" . $comment->comment_ID . "\" title=\"". $comment->comment_author . " : " . $comment->com_excerpt . "&hellip;" . "\">" . strip_tags($comment->post_title) ."</a></li>";
	}
	$output .= $post_HTML;
	echo $output;
};

// thumbnail 缩略图
add_image_size( 'seabye', 384, 216, true );

// 自动调用 特色图片 thumbnail 缩略图
function autoset_featured() {
		global $post;
		$already_has_thumb = has_post_thumbnail($post->ID);
			if (!$already_has_thumb) {
			$attached_image = get_children( "post_parent=$post->ID&post_type=attachment&post_mime_type=image&numberposts=1" );
				if ($attached_image) {
					foreach ($attached_image as $attachment_id => $attachment) {
					set_post_thumbnail($post->ID, $attachment_id);
					}
				}
			}
	}  // end function
add_action('the_post', 'autoset_featured');
add_action('save_post', 'autoset_featured');
add_action('draft_to_publish', 'autoset_featured');
add_action('new_to_publish', 'autoset_featured');
add_action('pending_to_publish', 'autoset_featured');
add_action('future_to_publish', 'autoset_featured');

// 别名 忘记是啥
function the_slug() {
	$post_data = get_post($post->ID, ARRAY_A);
	$slug = $post_data['post_name'];
	return $slug;
}

// 上传图片自动更名
function up_wp_handle_upload_prefilter($file){
	$time=date("YmdHis");
	$file['name'] = $time."".mt_rand(1,100).".".pathinfo($file['name'] , PATHINFO_EXTENSION);
	return $file;
}
add_filter( 'wp_handle_upload_prefilter', 'up_wp_handle_upload_prefilter' );

// 图片 alt 强制标题
function image_alt($c) {
	global $post; // 全局量
	$title = $post->post_title; // 文章标题
	$s = array('/src="(.+?.(jpg|jepg|png|gif|bmp))"/i' => 'src="$1" alt="'.$title.'"');
	foreach($s as $p => $r){
	$c = preg_replace($p,$r,$c);
}
return $c;
}
add_filter( 'the_content', 'image_alt' );

// 移除前台工具栏
add_filter( 'show_admin_bar', '__return_false' );

/* // 固定后台管理侧边栏
function Bing_fixed_adminmenuwrap(){
	echo '<style type="text/css">#adminmenuwrap{position:fixed;left:0px;z-index:2;}</style>';
};
add_action('admin_head', 'Bing_fixed_adminmenuwrap'); */

// 更改后台字体
function Bing_admin_lettering(){
	echo'<style type="text/css">
		* { font-family: "Microsoft YaHei" !important; }
		i, .ab-icon, .mce-close, i.mce-i-aligncenter, i.mce-i-alignjustify, i.mce-i-alignleft, i.mce-i-alignright, i.mce-i-blockquote, i.mce-i-bold, i.mce-i-bullist, i.mce-i-charmap, i.mce-i-forecolor, i.mce-i-fullscreen, i.mce-i-help, i.mce-i-hr, i.mce-i-indent, i.mce-i-italic, i.mce-i-link, i.mce-i-ltr, i.mce-i-numlist, i.mce-i-outdent, i.mce-i-pastetext, i.mce-i-pasteword, i.mce-i-redo, i.mce-i-removeformat, i.mce-i-spellchecker, i.mce-i-strikethrough, i.mce-i-underline, i.mce-i-undo, i.mce-i-unlink, i.mce-i-wp-media-library, i.mce-i-wp_adv, i.mce-i-wp_fullscreen, i.mce-i-wp_help, i.mce-i-wp_more, i.mce-i-wp_page, .qt-fullscreen, .star-rating .star { font-family: dashicons !important; }
		.mce-ico { font-family: tinymce, Arial !important; }
		.fa { font-family: FontAwesome !important; }
		.genericon { font-family: "Genericons" !important; }
		.appearance_page_scte-theme-editor #wpbody *, .ace_editor * { font-family: Monaco, Menlo, "Ubuntu Mono", Consolas, source-code-pro, monospace !important; }
		.post-type-post #advanced-sortables, .post-type-post #autopaging .description { display: none !important; }
		.form-field input, .form-field textarea { width: inherit; border-width: 0; }
		</style>';
}
add_action('admin_head', 'Bing_admin_lettering');

// 更改登录页面 Logo 图片
function custom_loginlogo() {
	echo'<style type="text/css">
		h1 a {background-image: url('.get_bloginfo('siteurl').'/apple-touch-icon.png) !important; }
		</style>';
}
add_action('login_head', 'custom_loginlogo');

// 更改登录页面 Logo 链接
add_filter("login_headerurl", create_function(false,"return get_bloginfo('siteurl');"));

// 更改登录页面 Logo 描述
add_filter("login_headertitle", create_function(false,"return get_bloginfo('description');"));

// 更改登录页面字体
function custom_login() {
	echo'<style type="text/css">*{font-family:"Microsoft YaHei" !important;}</style>';
}
add_action('login_head', 'custom_login');

// 阻止站内文章互相 Pingback
function Bing_noself_ping($links) {
	$home = get_option( 'home' );
	foreach ( $links as $l => $link )
	if ( 0 === strpos( $link, $home ) )
	unset($links[$l]);
}
add_action('pre_ping','Bing_noself_ping');

// 选择分类提示
add_action('admin_footer-post.php', 'choose_a_category_before_publish');
add_action('admin_footer-post-new.php', 'choose_a_category_before_publish');
function choose_a_category_before_publish(){
	global $post_type;
	if($post_type=='post'){
		echo "<script>
jQuery(function($){
	$('#publish, #save-post').click(function(e){
		if($('#taxonomy-category input:checked').length==0){
			alert('抱歉，在发布文章前，请选择一个分类！');
			e.stopImmediatePropagation();
			return false;
		}else{
			return true;
		}
	});
	var publish_click_events = $('#publish').data('events').click;
	if(publish_click_events){
		if(publish_click_events.length>1){
			publish_click_events.unshift(publish_click_events.pop());
		}
	}
	if($('#save-post').data('events') != null){
		var save_click_events = $('#save-post').data('events').click;
		if(save_click_events){
		  if(save_click_events.length>1){
			  save_click_events.unshift(save_click_events.pop());
		  }
		}
	}
});
</script>";
	}
}

// 允许 投稿用户 上传文件
if ( current_user_can('contributor') && !current_user_can('upload_files') )
	add_action('admin_init', 'allow_contributor_uplocustom');

	function allow_contributor_uplocustom() {
	$contributor = get_role('contributor');
	$contributor->add_cap('upload_files');
}

// 在文章编辑页面的 添加媒体 只显示用户自己上传的文件
function my_upload_media( $wp_query_obj ) {
	global $current_user, $pagenow;
	if( !is_a( $current_user, 'WP_User') )
		return;
	if( 'admin-ajax.php' != $pagenow || $_REQUEST['action'] != 'query-attachments' )
		return;
	if( !current_user_can( 'manage_options' ) && !current_user_can('manage_media_library') )
		$wp_query_obj->set('author', $current_user->ID );
	return;
}
add_action('pre_get_posts','my_upload_media');
// 在 媒体库 只显示用户上传的文件 // 数量显示错误
function my_media_library( $wp_query ) {
	if ( strpos( $_SERVER[ 'REQUEST_URI' ], '/wp-admin/upload.php' ) !== false ) {
		if ( !current_user_can( 'manage_options' ) && !current_user_can( 'manage_media_library' ) ) {
			global $current_user;
			$wp_query->set( 'author', $current_user->id );
		}
	}
}
add_filter('parse_query', 'my_media_library' );

// 访问计数 调用代码 (php) post_views('', '/'); (/php) // 附评论数 (php) comments_number('0', '1', '%'); (php)
function record_visitors() {
	if (is_singular()) {
		global $post;
		$post_ID = $post->ID;
		if($post_ID) {
			$post_views = (int)get_post_meta($post_ID, 'views', true);
			if(!update_post_meta($post_ID, 'views', ($post_views+1))) {
				add_post_meta($post_ID, 'views', 1, true);
				}
			}
		}
	}
add_action('wp_head', 'record_visitors');
// 函数名称 post_views
// 函数作用 取得文章的阅读次数
function post_views($before = '(点击 ', $after = ' 次)', $echo = 1) {
	global $post;
	$post_ID = $post->ID;
	$views = (int)get_post_meta($post_ID, 'views', true);
	if ($echo) echo $before, number_format($views), $after;
	else return $views;
}

// 引荐 相关文章 调用代码 (php) single_related_posts(); (/php)
function single_related_posts() {
	echo '<ul id="bones-related-posts">';
	global $post;
	$tags = wp_get_post_tags($post->ID);
	if($tags) {
		foreach($tags as $tag) { $tag_arr .= $tag->slug . ','; }
        $args = array(
        	'tag' => $tag_arr,
        	'numberposts' => 6, // 数量
        	'post__not_in' => array($post->ID)
     	);
        $related_posts = get_posts($args);
        if($related_posts) {
        	foreach ($related_posts as $post) : setup_postdata($post); ?>
	           	<li class="related_post"><a href="<?php the_permalink() ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a></li>
	        <?php endforeach; } 
	    else { ?>
            <li class="related_post air_related_post"></li>
		<?php }
	}
	wp_reset_query();
	echo '</ul>';
}

/* // 调用热门 调用代码 (php) if(function_exists('most_comm_posts')) most_comm_posts(30, 10); (/php) // 天数, 数量
function most_comm_posts($days=7, $nums=10) { // $days 参数限制时间值 单位为 日 默认是7日 $nums 是要显示文章数量
	global $wpdb;
	$today = date("Y-m-d H:i:s"); // 获取今日日期时间
	$daysago = date( "Y-m-d H:i:s", strtotime($today) - ($days * 24 * 60 * 60) );  //Today - $days
	$result = $wpdb->get_results("SELECT comment_count, ID, post_title, post_date FROM $wpdb->posts WHERE post_date BETWEEN '$daysago' AND '$today' ORDER BY comment_count DESC LIMIT 0 , $nums");
	$output = '';
	if(empty($result)) {
		$output = '<li>None data.</li>';
	} else {
		foreach ($result as $topten) {
			$postid = $topten->ID;
			$title = $topten->post_title;
			$commentcount = $topten->comment_count;
			if ($commentcount != 0) {
				$output .= '<li><span id="f12">'.$commentcount.'c</span> <a href="'.get_permalink($postid).'">'.$title.'</a></li>';
			}
		}
	}
	echo $output;
} */

// 分类描述编辑强化 移除 HTML 过滤
remove_filter( 'pre_term_description', 'wp_filter_kses' );
remove_filter( 'term_description', 'wp_kses_data' );
// 分类描述编辑强化 添加可视化编辑器
add_filter('edit_category_form_fields', 'cat_description');
function cat_description($tag)
{
	?>
	<table class="form-table">
		<tr class="form-field">
			<th scope="row" valign="top"><label for="description"><?php _ex('Description', 'Taxonomy Description'); ?></label></th>
			<td>
				<?php
				$settings = array('wpautop' => true, 'media_buttons' => true, 'quicktags' => true, 'textarea_rows' => '15', 'textarea_name' => 'description' );
				wp_editor(wp_kses_post($tag->description , ENT_QUOTES, 'UTF-8'), 'cat_description', $settings);
				?>
				<br />
				<span class="description"><?php _e('The description is not prominent by default; however, some themes may show it.'); ?></span>
			</td>
		</tr>
	</table>
	<?php
}
// 分类描述编辑强化 移除默认 描述 框
add_action('admin_head', 'remove_default_category_description');
function remove_default_category_description()
{
	global $current_screen;
	if ( $current_screen->id == 'edit-category' )
	{
		?>
		<script>
			jQuery(function($) {
				$('textarea#description').closest('tr.form-field').remove();
			});
		</script>
		<?php
	}
}

/* // 自动为文章添加已使用过的标签
add_action('save_post', 'auto_add_tags');
function auto_add_tags(){
	$tags = get_tags( array('hide_empty' => false) );
	$post_id = get_the_ID();
	$post_content = get_post($post_id)->post_content;
	if ($tags) {
		foreach ( $tags as $tag ) {
			// 如果文章内容出现了已使用过的标签，自动添加这些标签
			if ( strpos($post_content, $tag->name) !== false)
				wp_set_post_tags( $post_id, $tag->name, true );
		}
	}
} */

/* // Feed RSS 更新频率 1800 为半小时
add_filter( 'wp_feed_cache_transient_lifetime', create_function('$fixrss', 'return 1800;') ); */

/* // xxx 移除评论内链接
remove_filter('comment_text', 'make_clickable', 9); */
// xxx 内页加 转载请注明
function tedlfie_copyright($content) {
	if( is_singular("post") ){
		$content.= '<p class="post-copy"><a href="'.get_permalink().'" rel="external nofollow" target="_blank">'.get_the_title().'</a> &middot; <a href="'.get_bloginfo('url').'" rel="external nofollow" target="_blank">'.get_bloginfo('name').'</a></p>';
	}
	return $content;
}
// xxx 防采集
$ua = $_SERVER['HTTP_USER_AGENT'];
$now_ua = array('FeedDemon ','ZmEu','Indy Library','oBot','jaunty'); // 将恶意 USER_AGENT 存入数组
if(!$ua) { // 禁止空 USER_AGENT
	header("Content-type: text/html; charset=utf-8");
	wp_die('System Error!');
} else {
	foreach($now_ua as $value )
	if(eregi($value,$ua)) {
	header("Content-type: text/html; charset=utf-8");
	wp_die('System Error!');
	}
}
add_filter('the_content','tedlfie_copyright');
/* // xxx 关闭 Feed RSS
function tedlife_disable_feed() {
	wp_die(__('Feed OFF'));
}
add_action('do_feed', 'tedlife_disable_feed', 1);
add_action('do_feed_rdf', 'tedlife_disable_feed', 1);
add_action('do_feed_rss', 'tedlife_disable_feed', 1);
add_action('do_feed_rss2', 'tedlife_disable_feed', 1);
add_action('do_feed_atom', 'tedlife_disable_feed', 1); */

/* short code [] 短代码 1边栏，2评论，3摘要 */
add_filter('widget_text','do_shortcode');
add_filter('comment_text','do_shortcode');
add_filter('the_excerpt','do_shortcode');

/* 小工具 文本 */
/**
 * Text widget class
 *
 * @since 2.8.0
 */
class WP_Widget_Text_seabye extends WP_Widget {

	public function __construct() {
		$widget_ops = array('classname' => 'widget_text_seabye', 'description' => '缩进的，任意 文本 或 HTML；更换主题时请注意另存内容。');
		$control_ops = array('width' => 400, 'height' => 350);
		parent::WP_Widget(false,$name='seabye 文本', $widget_ops, $control_ops);
	}

	public function widget( $args, $instance ) {

		/** This filter is documented in wp-includes/default-widgets.php */
		$title = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );

		/**
		 * Filter the content of the Text widget.
		 *
		 * @since 2.3.0
		 *
		 * @param string    $widget_text The widget content.
		 * @param WP_Widget $instance    WP_Widget instance.
		 */
		$text = apply_filters( 'widget_text', empty( $instance['text'] ) ? '' : $instance['text'], $instance );
		echo $args['before_widget'];
		if ( ! empty( $title ) ) {
			echo $args['before_title'] . $title . $args['after_title'];
		} ?>
			<div class="text_widget_seabye"><?php echo !empty( $instance['filter'] ) ? wpautop( $text ) : $text; ?></div>
		<?php
		echo $args['after_widget'];
	}

	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		if ( current_user_can('unfiltered_html') )
			$instance['text'] =  $new_instance['text'];
		else
			$instance['text'] = stripslashes( wp_filter_post_kses( addslashes($new_instance['text']) ) ); // wp_filter_post_kses() expects slashed
		$instance['filter'] = isset($new_instance['filter']);
		return $instance;
	}

	public function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array( 'title' => '', 'text' => '' ) );
		$title = strip_tags($instance['title']);
		$text = esc_textarea($instance['text']);
?>
		<p><label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:'); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>

		<textarea class="widefat" rows="16" cols="20" id="<?php echo $this->get_field_id('text'); ?>" name="<?php echo $this->get_field_name('text'); ?>"><?php echo $text; ?></textarea>

		<p><input id="<?php echo $this->get_field_id('filter'); ?>" name="<?php echo $this->get_field_name('filter'); ?>" type="checkbox" <?php checked(isset($instance['filter']) ? $instance['filter'] : 0); ?> />&nbsp;<label for="<?php echo $this->get_field_id('filter'); ?>"><?php _e('Automatically add paragraphs'); ?></label></p>
<?php
	}
}
register_widget('WP_Widget_Text_seabye');

/* 小工具 功能 */
/**
 * Meta widget class
 *
 * Displays log in/out, RSS feed links, etc.
 *
 * @since 2.8.0
 */
class WP_Widget_Meta_seabye extends WP_Widget {

	public function __construct() {
		$widget_ops = array('classname' => 'widget_meta_seabye', 'description' => '登录、RSS、去除了 评论RSS 和 WordPress.org 链接。');
		parent::WP_Widget(false,$name='seabye 功能', $widget_ops, $control_ops);
	}

	public function widget( $args, $instance ) {

		/** This filter is documented in wp-includes/default-widgets.php */
		$title = apply_filters( 'widget_title', empty($instance['title']) ? __( 'Meta' ) : $instance['title'], $instance, $this->id_base );

		echo $args['before_widget'];
		if ( $title ) {
			echo $args['before_title'] . $title . $args['after_title'];
		}
?>
			<ul>
			<?php wp_register(); ?>
			<li><?php wp_loginout(); ?></li>
			<li><a href="<?php bloginfo('rss2_url'); ?>"><?php _e('RSS Feed'); ?></a></li>
<?php
			/**
			 * Filter the "Powered by WordPress" text in the Meta widget.
			 *
			 * @since 3.6.0
			 *
			 * @param string $title_text Default title text for the WordPress.org link.
			 */

			wp_meta();
?>
			</ul>
<?php
		echo $args['after_widget'];
	}

	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);

		return $instance;
	}

	public function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array( 'title' => '' ) );
		$title = strip_tags($instance['title']);
?>
			<p><label for="<?php echo $this->get_field_id('title'); ?>"><?php _e('Title:'); ?></label> <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>
<?php
	}
}
register_widget('WP_Widget_Meta_seabye');

// seabye end