<?php
/**
 * Template Name: Page Random
 *
 * @package seabye_blue
 */

	$my_random_post = get_posts( array( 'numberposts' => 1, 'orderby' =>'rand' ) );
	foreach ( $my_random_post as $post ) {
		wp_redirect( get_permalink( $post->ID ) );
		exit;
	}

?>
