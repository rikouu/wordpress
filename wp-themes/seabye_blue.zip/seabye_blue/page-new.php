<?php
/**
 * Template Name: Page New 100+
 *
 * @package seabye_blue
 */

get_header(); ?>

	<section id="primary" class="content-area page-new">
		<main id="main" class="site-main" role="main">

		<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

			<header class="page-header">
				<h1 class="page-title"><?php the_title(); ?></h1>
			</header><!-- .entry-header -->

			<div class="entry-content">
				<?php while( have_posts() ) : the_post(); ?>
				<ul>
					<?php $totalposts = get_posts( 'numberposts=100&offset=0' ); foreach( $totalposts as $post ) : ?>
					<li>
						<span class="new new-time"><?php the_time( 'm.d' ); ?></span>
						<span class="new new-">|&nbsp;</span>
						<span class="new new-title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></span>
						<!-- <span class="new new-archive">[ <?php // the_category(', '); ?> ]</span> -->
						<span class="new new-comment">[ <a href="<?php the_permalink() ?>#comment" title="<?php _e( 'Leave a comment', 'seabye_blue' ); ?>"><?php comments_number( '0', '1', '%' ); ?></a> ]</span>
					</li>
					<?php endforeach; ?>
				</ul>
				<?php endwhile; ?>
			</div><!-- .entry-content -->

			<footer class="entry-footer">
				<?php edit_post_link( __( 'Edit', 'seabye_blue' ), '<span class="edit-link">', '</span>' ); ?>
			</footer><!-- .entry-footer -->

		</article><!-- #article -->

		</main><!-- #main -->
	</section><!-- #primary -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>