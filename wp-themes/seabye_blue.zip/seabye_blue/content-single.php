<?php
/**
 * @package seabye_blue
 */
?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
	<header class="entry-header">
		<?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>

		<div class="entry-meta">
			<?php seabye_blue_posted_on(); ?>
		</div><!-- .entry-meta -->
	</header><!-- .entry-header -->

	<div class="entry-content">
		<?php the_content(); ?>
		<div class="page-links">
			<?php wp_link_pages(array('before'=>''. __( 'Pages:', 'seabye_blue' ),'after'=>'','next_or_number'=>'next','previouspagelink'=>'<span>'. __( 'Previous', 'seabye_blue' ),'</span>','nextpagelink'=>"")); ?>
			<?php wp_link_pages(array('before'=>'','after'=>'','next_or_number'=>'number','link_before'=>'<span>','link_after'=>'</span>')); ?>
			<?php wp_link_pages(array('before'=>'','after'=>'','next_or_number'=>'next','previouspagelink'=>'','nextpagelink'=>"<span>". __( 'Next', 'seabye_blue' ),"</span>")); ?>
		</div>
	</div><!-- .entry-content -->

	<footer class="entry-footer">
		<?php
			/* translators: used between list items, there is a space after the comma */
			$category_list = get_the_category_list( __( ', ', 'seabye_blue' ) );

			/* translators: used between list items, there is a space after the comma */
			$tag_list = get_the_tag_list( '', __( ', ', 'seabye_blue' ) );

			if ( ! seabye_blue_categorized_blog() ) {
				// This blog only has 1 category so we just need to worry about tags in the meta text
				if ( '' != $tag_list ) {
					$meta_text = __( 'This entry was tagged %2$s. Bookmark the <a href="%3$s" rel="bookmark">permalink</a>.', 'seabye_blue' );
				} else {
					$meta_text = __( 'Bookmark the <a href="%3$s" rel="bookmark">permalink</a>.', 'seabye_blue' );
				}

			} else {
				// But this blog has loads of categories so we should probably display them here
				if ( '' != $tag_list ) {
					$meta_text = __( 'This entry was posted in %1$s and tagged %2$s. Bookmark the <a href="%3$s" rel="bookmark">permalink</a>.', 'seabye_blue' );
				} else {
					$meta_text = __( 'This entry was posted in %1$s. Bookmark the <a href="%3$s" rel="bookmark">permalink</a>.', 'seabye_blue' );
				}

			} // end check for categories on this blog

			printf(
				$meta_text,
				$category_list,
				$tag_list,
				get_permalink()
			);
		?>

		<?php edit_post_link( __( 'Edit', 'seabye_blue' ), '<span class="edit-link">', '</span>' ); ?>
	</footer><!-- .entry-footer -->

	<?php if ( is_active_sidebar( 'custom-text-pc' ) ) : ?>
		<?php dynamic_sidebar( 'custom-text-pc' ); ?>
	<?php else : ?>
	<?php endif; ?>

	<?php if ( is_active_sidebar( 'custom-text-phone' ) ) : ?>
		<?php dynamic_sidebar( 'custom-text-phone' ); ?>
	<?php else : ?>
	<?php endif; ?>

</article><!-- #post-## -->
