<?php
/**
 * The Sidebar containing the main widget areas.
 *
 * @package seabye_blue
 */
?>
	<div id="secondary" class="widget-area" role="complementary">
		<?php if ( ! dynamic_sidebar( 'sidebar-1' ) ) : ?>

			<aside id="search" class="widget widget_search widget_search_phone phone">
				<?php get_search_form(); ?>
			</aside>

			<?php if ( is_active_sidebar( 'custom-sidebar-search-pc' ) ) : ?>
				<?php dynamic_sidebar( 'custom-sidebar-search-pc' ); ?>
			<?php else : ?>
			<?php endif; ?>

			<aside id="recent-comments" class="widget">
				<h1 class="widget-title"><?php _e( 'Recent Comments', 'seabye_blue' ); ?></h1>
				<span class="widget-hr"></span>
				<ul>
					<?php recent_comments( $outer='', $limit='5' ); ?>
				</ul>
			</aside>

			<?php if ( is_active_sidebar( 'custom-sidebar-comment-pc' ) ) : ?>
				<?php dynamic_sidebar( 'custom-sidebar-comment-pc' ); ?>
			<?php else : ?>
			<?php endif; ?>

		<?php endif; // end sidebar widget area ?>
	</div><!-- #secondary -->
