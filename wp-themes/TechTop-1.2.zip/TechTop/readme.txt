TechTop theme by FlexiThemes, https://flexithemes.com
Online Demo: https://flexithemes.com/demo/TechTop/
Theme URI: https://flexithemes.com/techtop-wordpress-theme/