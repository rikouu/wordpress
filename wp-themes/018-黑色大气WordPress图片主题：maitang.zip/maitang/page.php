<?php get_header(); ?>
	<div class="container">
		<div class="row">
			<div class="col-md-9">
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
				<?php setPostViews(get_the_ID()); ?>
				<div class="panel panel-default">
					<div class="panel-body">
						<div class="page-header">
							<h1>
								<?php the_title(); ?>
							</h1>
						</div>
						<?php the_content(); ?>
					</div>
				</div>
				<div class="panel panel-default">
					<div class="panel-heading">
						<h4>发表新的回复</h4>
					</div>
					<div class="panel-body">
						<div id="comment">
							<?php comments_template(); ?>
						</div>
					</div>
				</div>
				<?php endwhile; endif; ?>
			</div>
			<div class="col-md-3 hidden-sm" id="sidebar">
				<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('side') ) : ?><?php endif; ?>
			</div>
		</div>
	</div>
<?php get_footer(); ?>