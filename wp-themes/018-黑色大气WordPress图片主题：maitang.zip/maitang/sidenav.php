<ul class="list-group">
	<a class="list-group-item" href="#">
		这是1个导航链接
	</a>
	<!-- 需要多个链接就复制以上a标签多次 自己编辑文字、链接即可。-->
</ul>
<div class="panel-body">
	<img src="<?php bloginfo('template_directory'); ?>/img/code.png">
</div>