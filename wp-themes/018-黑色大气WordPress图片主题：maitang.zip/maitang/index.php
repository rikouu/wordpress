<?php get_header(); ?>
	<div class="container">
		<div class="row">
			<div class="col-md-2 hidden-sm hidden-xs" id="sidenav">
				<div id="fixedbar">
					<div class="panel panel-default">
						<!-- Default panel contents -->
						<div class="panel-heading">
							快捷导航
						</div>
						<!-- List group -->
						<?php get_template_part('sidenav'); ?>
					</div>
				</div>
			</div>
			<div class="col-sm-12 col-md-10">
				<div class="row">
					<?php if(!is_paged()) { ?>
					<div class="col-sm-12 hidden-xs">
						<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
							<!-- Indicators -->
							<ol class="carousel-indicators">
								<li data-target="#carousel-example-generic" data-slide-to="0" class="active">
								</li>
								<li data-target="#carousel-example-generic" data-slide-to="1">
								</li>
								<li data-target="#carousel-example-generic" data-slide-to="2">
								</li>
							</ol>
							<!-- Wrapper for slides -->
							<div class="carousel-inner">
								<div class="item active">
									<a href="<?php echo get_option('mao10_homelink1'); ?>"><img src="<?php echo get_option('mao10_homeimg1'); ?>"></a>
								</div>
								<div class="item">
									<a href="<?php echo get_option('mao10_homelink2'); ?>"><img src="<?php echo get_option('mao10_homeimg2'); ?>"></a>
								</div>
								<div class="item">
									<a href="<?php echo get_option('mao10_homelink3'); ?>"><img src="<?php echo get_option('mao10_homeimg3'); ?>"></a>
								</div>
							</div>
							<!-- Controls -->
							<a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
								<span class="glyphicon glyphicon-chevron-left">
								</span>
							</a>
							<a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
								<span class="glyphicon glyphicon-chevron-right">
								</span>
							</a>
						</div>
					</div>
					<div class="clearfix"></div>
					<?php $cat00=get_option( 'mao10_cat00'); ?>
					<?php $cat01=get_option( 'mao10_cat01'); ?>
					<?php $cat02=get_option( 'mao10_cat02'); ?>
					<div class="col-md-12 hidden-xs" id="home-tab">
						<ul class="nav nav-tabs nav-justified">
							<li class="active">
								<a href="#home-1" data-toggle="tab">
									<?php echo get_cat_name(''. $cat00 .'') ?>
								</a>
							</li>
							<li>
								<a href="#home-2" data-toggle="tab">
									<?php echo get_cat_name(''. $cat01 .'') ?>
								</a>
							</li>
							<li>
								<a href="#home-3" data-toggle="tab">
									<?php echo get_cat_name(''. $cat02 .'') ?>
								</a>
							</li>
						</ul>
						<!-- Tab panes -->
						<div class="tab-content">
							<div class="tab-pane active" id="home-1">
								<div class="row">
									<?php query_posts('showposts=8&cat='.$cat00.''); ?>
									<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
										<?php $num1++; ?>
										<div class="col-sm-4 col-lg-3 <?php if($num1==7 || $num1==8) echo 'visible-lg'; ?>">
											<div class="thumbnail">
												<a href="<?php the_permalink(); ?>" class="img-div">
													<img src="<?php echo img(); ?>" alt="<?php the_title(); ?>">
												</a>
												<div class="caption">
													<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
												</div>
											</div>
										</div>
									<?php endwhile; endif; wp_reset_query(); ?>
								</div>
							</div>
							<div class="tab-pane" id="home-2">
								<div class="row">
									<?php query_posts('showposts=8&cat='.$cat01.''); ?>
									<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
										<?php $num2++; ?>
										<div class="col-sm-4 col-lg-3 <?php if($num2==7 || $num2==8) echo 'visible-lg'; ?>">
											<div class="thumbnail">
												<a href="<?php the_permalink(); ?>" class="img-div">
													<img src="<?php echo img(); ?>" alt="<?php the_title(); ?>">
												</a>
												<div class="caption">
													<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
												</div>
											</div>
										</div>
									<?php endwhile; endif; wp_reset_query(); ?>
								</div>
							</div>
							<div class="tab-pane" id="home-3">
								<div class="row">
									<?php query_posts('showposts=8&cat='.$cat02.''); ?>
									<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
										<?php $num3++; ?>
										<div class="col-sm-4 col-lg-3 <?php if($num3==7 || $num3==8) echo 'visible-lg'; ?>">
											<div class="thumbnail">
												<a href="<?php the_permalink(); ?>" class="img-div">
													<img src="<?php echo img(); ?>" alt="<?php the_title(); ?>">
												</a>
												<div class="caption">
													<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
												</div>
											</div>
										</div>
									<?php endwhile; endif; wp_reset_query(); ?>
								</div>
							</div>
						</div>
					</div>
					<?php } ?>
					<div class="col-md-12" id="post-list">
						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
							<?php get_template_part('loop-list'); ?>
						<?php endwhile; endif; wp_reset_query(); ?>
						<ul id="pager" class="pagination">
							<?php par_pagenavi(9); ?>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php get_footer(); ?>