<footer>
	<div class="container">
		<div class="row">
			<div class="col-sm-8">
				<h3>无意与众不同，只因品位出众！</h3>
				Copyright 2011-2013 www.mao01.com allright reserved. 网站设计 <a href="http://www.mao01.com/" title="wordpress建站">猫猫工作室</a>
			</div>
			<div class="col-sm-4">
				<img class="pull-right" src="<?php bloginfo('template_directory'); ?>/img/mt-bottom.png">
			</div>
		</div>
	</div>
</footer>
<a href="#"></a>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="<?php bloginfo('template_directory'); ?>/js/jquery.min.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="<?php bloginfo('template_directory'); ?>/js/bootstrap.min.js"></script>
<script src="<?php bloginfo('template_directory'); ?>/js/jquery.pin.js"></script>
<script src="<?php bloginfo('template_directory'); ?>/js/cat.js"></script>
</body>
</html>