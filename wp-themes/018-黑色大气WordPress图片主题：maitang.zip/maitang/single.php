<?php get_header(); ?>
	<div class="container">
		<div class="row">
			<div class="col-md-9">
				<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
				<?php setPostViews(get_the_ID()); ?>
				<div class="panel panel-default">
					<div class="panel-body">
						<div class="page-header">
							<h1>
								<?php the_title(); ?>
							</h1>
						</div>
						<?php the_content(); ?>
					</div>
					<div class="panel-footer">
						<?php the_tags('<i class="glyphicon glyphicon-tags"></i>标签： ',',',''); ?>
						<i class="glyphicon glyphicon-th-list"></i>分类： <?php the_category(','); ?>
						<i class="glyphicon glyphicon-eye-open"></i>浏览： <?php echo getPostViews(get_the_ID()); ?>
						<i class="glyphicon glyphicon-comment"></i>评论： <?php comments_number('0', '1', '%' );?>
					</div>
				</div>
				<div class="panel panel-default">
					<div class="panel-heading">
						<h4>发表新的回复</h4>
					</div>
					<div class="panel-body">
						<div id="comment">
							<?php comments_template(); ?>
						</div>
					</div>
				</div>
				<?php endwhile; endif; ?>
			</div>
			<div class="col-md-3 hidden-sm" id="sidebar">
				<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('side') ) : ?><?php endif; ?>
			</div>
		</div>
	</div>
<?php get_footer(); ?>