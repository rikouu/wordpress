<?php get_header(); ?>
	<div class="container">
		<div class="row">
			<div class="col-md-2 hidden-sm hidden-xs" id="sidenav">
				<div id="fixedbar">
					<div class="panel panel-default">
						<!-- Default panel contents -->
						<div class="panel-heading">
							快捷导航
						</div>
						<!-- List group -->
						<?php get_template_part('sidenav'); ?>
					</div>
				</div>
			</div>
			<div class="col-sm-12 col-md-10">
				<div class="row">
					<div class="col-md-12" id="post-list">
						<h1>搜索结果</h1>
						<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
							<?php get_template_part('loop-list'); ?>
						<?php endwhile; endif; wp_reset_query(); ?>
						<ul id="pager" class="pagination">
							<?php par_pagenavi(9); ?>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php get_footer(); ?>