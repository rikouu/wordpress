<div class="panel panel-default">
	<div class="panel-body">
		<div class="media">
			<a class="pull-left" href="<?php the_permalink(); ?>">
				<img class="media-object" src="<?php echo img(); ?>" alt="<?php the_title(); ?>">
			</a>
			<div class="clearfix visible-xs"></div>
			<div class="media-body">
				<h2 class="media-heading">
					<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
				</h2>
				<?php the_excerpt(); ?>
			</div>
		</div>
	</div>
	<div class="panel-footer">
		<?php the_tags('<i class="glyphicon glyphicon-tags"></i>标签： ',',',''); ?>
		<i class="glyphicon glyphicon-th-list"></i>分类： <?php the_category(','); ?>
		<i class="glyphicon glyphicon-eye-open"></i>浏览： <?php echo getPostViews(get_the_ID()); ?>
		<i class="glyphicon glyphicon-comment"></i>评论： <?php comments_number('0', '1', '%' );?>
	</div>
</div>