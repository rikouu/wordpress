<div class="share2">
<ul class="drop-menu">
<li>
<!-- Baidu Button BEGIN -->
    <div id="bdshare" class="bdshare_t bds_tools get-codes-bdshare">
		<a class="bds_qzone"></a>
		<a class="bds_tsina"></a>
		<a class="bds_tqq"></a>
		<a class="bds_renren"></a>
		<a class="bds_kaixin001"></a>
		<a class="bds_tqf"></a>
		<a class="bds_douban"></a>
		<a class="bds_tsohu"></a>
		<a class="bds_taobao"></a>
		<a class="bds_sohu"></a>
		<a class="bds_t163"></a>
		<a class="bds_tfh"></a>
		<a class="bds_hx"></a>
		<a class="bds_ff"></a>
		<a class="bds_xg"></a>
		<a class="bds_ty"></a>
		<a class="bds_hi"></a>
		<a class="bds_msn"></a>
		<a class="bds_deli"></a>
		<a class="bds_fbook"></a>
		<a class="bds_mshare"></a>
		<a class="bds_bdhome"></a>
		<a class="bds_tieba"></a>
		<a class="bds_diandian"></a>
		<a class="bds_huaban"></a>
		<a class="bds_youdao"></a>
		<a class="bds_mail"></a>
		<a class="bds_copy"></a>
		<span class="bds_more"></span>
		<a class="shareCount"></a>
    </div>
<script type="text/javascript" id="bdshare_js" data="type=tools&amp;uid=" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
	document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?t=" + new Date().getHours();
</script>
<!-- Baidu Button END -->
</li>
</ul>
</div>