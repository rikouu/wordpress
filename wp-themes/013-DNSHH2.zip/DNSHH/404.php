<?php get_header(); ?>
	<div class="content">
		<?php include('404page.php'); ?>
	</div>
<?php get_footer(); ?>