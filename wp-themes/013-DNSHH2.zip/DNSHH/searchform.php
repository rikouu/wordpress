<form role="search" method="get" id="searchform" class="right" action="<?php bloginfo('url');?>">
	<div class="right"><input type="text" name="s" id="s" onblur="if(this.value =='')this.value='回车以搜索...';" onfocus="this.value='';" onclick="if(this.value=='回车以搜索...')this.value=''" value="回车以搜索..."></div>
</form>