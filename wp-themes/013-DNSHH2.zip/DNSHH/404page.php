
<div class="content">
	<img style="display:block;margin:0 auto" src="<?php bloginfo('template_directory') ?>/images/404.gif" />
	<p style="margin:15px 0 43px 0;text-align:center;">啊哦！这个页面貌似被无节操的外星人带走了呢！你可以<a href="javascript:history.go(-1)">返回上一页</a>。如果是博主把你带到这里的话，请向博主报告~</p>
</div>