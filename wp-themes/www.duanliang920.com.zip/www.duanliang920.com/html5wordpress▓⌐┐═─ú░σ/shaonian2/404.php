<?php get_header(); ?>
<div class="content-wrap">
	<div style="text-align:center;padding:10px 0;font-size:16px;background-color:#ffffff;">
		<h2 style="font-size:36px;margin-bottom:10px;">哎哟～404了～休息一下，玩个游戏吧！</h2><script type="text/javascript">
/*漂浮120*270，创建于2013-3-12*/
var cpro_id = "u1232049";
</script>
<script src="http://cpro.baidustatic.com/cpro/ui/f.js" type="text/javascript"></script>
<script type="text/javascript">
/*580*90，创建于2013-3-17*/
var cpro_id = "u1236691";
</script>
	
</div>
<?php get_footer(); ?>