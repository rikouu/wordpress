﻿<!-- //底部模板 -->
<div class="footer">
		<div class="bottom_nav  clearfix"><?php wp_nav_menu(array( 'theme_location' => 'footer-menu' ) ); ?></div>		<div class="footer_nav clearfix" >
        <p>版权所有&copy;个人博客 2013-2014<a href="#" title="百度地图" target="_blank">站点地图</a> </p>  
		</div>
	</div>
<!-- Generated in 2.498 seconds. Made 71 queries to database and 21 cached queries. Memory used - 34.13MB -->
<!-- Cached by DB Cache Reloaded Fix -->
</div><!--wrapmain-->
 <?php wp_footer(); ?>
		<div id="shangxia"><div id="shang" title="↑ 返回顶部"></div>
		<?php if ( is_singular() ){ ?>
		<div id="comt" title="查看评论"><div align="center"><?php comments_number('0','1','%'); ?></div></div>
		<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/comments-ajax.js"></script>
		<!-- Baidu Button END -->
		<script type="text/javascript" id="bdshare_js" data="type=button&amp;uid=6632901" ></script>
		<script type="text/javascript" id="bdshell_js"></script>
		<script type="text/javascript">
document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + Math.ceil(new Date()/3600000);
		</script>
		<!-- Baidu Button END -->
		<?php } ?>
		<div id="xia" title="↓ 移至底部"></div>
		
</div>



<script>window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"0","bdSize":"16"},"slide":{"type":"slide","bdImg":"1","bdPos":"right","bdTop":"100"},"image":{"viewList":["qzone","tsina","tqq","renren","weixin"],"viewText":"分享到：","viewSize":"16"},"selectShare":{"bdContainerClass":null,"bdSelectMiniList":["qzone","tsina","tqq","renren","weixin"]}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];</script>

</body>
</html>