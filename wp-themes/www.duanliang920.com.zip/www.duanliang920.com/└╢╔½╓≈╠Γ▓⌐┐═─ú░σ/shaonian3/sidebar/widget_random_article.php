<div class="widget widget_random_article">		<h3>随便看看</h3>		<ul>
<?php random_posts(); ?>
				</ul>
		</div>