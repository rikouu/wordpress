<div class="con_box hot_box" id="tuijian">
	<h3>为您推荐</h3>
		<div class="ads">
		<?php echo stripslashes(get_option('swt_ad_s')); ?>
		</div>
</div>