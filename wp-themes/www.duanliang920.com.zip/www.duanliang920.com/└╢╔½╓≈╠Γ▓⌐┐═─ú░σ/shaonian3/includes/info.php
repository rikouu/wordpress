﻿<div class="gg">
<p>  &nbsp; &nbsp; &nbsp; &nbsp;==<strong>博主QQ:947580181</strong>==<br/>
<div style="padding-left:60px;">
<img src="/wp/wp-content/themes/shaonian/images/fs5.jpg" alt="博主" width="122" height="122" style="text-shadow: 0 0 3px #585858;"></div>
<div style="line-height:22px;letter-spacing: 1px;margin-bottom:7px;padding-left:60px;">
<b>博主</b>：少年<br/>
<b>行业</b>：IT<br/>
<b>简介</b>：个人博客，<br/>不间断地给大家分享:web前端、SEO等互联网上最前沿的技术。<br/>

</div>

			<div class="clear"></div>
</div>
