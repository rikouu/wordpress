﻿<div class="widget feed-mail">


	<div class="box">
		<ul id="contact-li">
			<li class="qq"><a rel="nofollow" target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=947580181&site=qq&menu=yes" title="有急事请Q我">QQ联系</a></li>
			<li class="email"><a rel="nofollow" target="_blank" href="http://list.qq.com/cgi-bin/qf_invite?id=68785ef736e28c0de644cd61ed7c95fe7ef5e612d6c4cd03" style="text-decoration:none;" title="订阅博客">订阅博客</a></li>
			<li class="qqmblog"><a rel="nofollow" target="_blank" href="<?php echo stripslashes(get_option('swt_qqmblog')); ?>" title="收听我的腾讯微博">腾讯微博</a></li>
			<li class="sinamblog"><a rel="nofollow" target="_blank" href="<?php echo stripslashes(get_option('swt_sinamblog')); ?>" title="收听我的新浪微博">新浪微博</a></li>
			<li class="rss"><a rel="nofollow" target="_blank" href="<?php echo get_option('swt_blogrss'); ?>" title="通过RSS订阅我的博客">RSS订阅</a></li>
		</ul>
	</div>
		
		<?php if (get_option('swt_info') == '关闭') { ?>
		<?php { echo ''; } ?>
		<?php } else { include(TEMPLATEPATH . '/includes/info.php'); } ?>
		<div class="clear"></div>
</div>