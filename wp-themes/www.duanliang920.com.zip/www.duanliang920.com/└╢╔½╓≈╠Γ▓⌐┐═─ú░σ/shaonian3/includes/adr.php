<div class="adr">
	<div class="ad_r"><?php echo stripslashes(get_option('swt_adrc')); ?>
	<div class="clear"></div>
	</div>
</div>