<?php get_header(); ?>
<div id="roll"><div title="回到顶部" id="roll_top"></div><div title="查看评论" id="ct"></div><div title="转到底部" id="fall"></div></div>
<div id="content">
<div class="main">
<div id="map">
<div class="site">当前位置： <a title="返回首页" href="<?php echo get_settings('Home'); ?>/">首页</a> &gt;
    <?php the_category(', ') ?>
    &gt; 正文&nbsp;&nbsp;&nbsp;<span style="color:red;font-weight: bold;"></span></div>
    </div>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="article article_c">
<div class="article_head">
<div class="author_pic"><img src="<?php bloginfo('template_directory'); ?>/images/author_pic.png" alt="关于Seven" width="40" height="40" /></div>
<h2 class="entry-title"><?php the_title(); ?></h2>
<div class="article_info">
		<span class="comm">作者：<span class="vcard author"><span class="fn"><?php the_author(); ?></span></span></span><span class="comm">发布：<?php the_time('Y-m-d H:i') ?></span><span class="comm">分类：<?php the_category(', ') ?></span><span class="comm">阅读：<?php post_views('','次'); ?></span><span class="comm">评论：<?php comments_number('0 条评论', '1 条评论', '% 条评论','', 'number'); ?></span><span><?php edit_post_link('编辑'); ?></span>
</div>
</div>
<div class="clear"></div>
 <div class="context entry-content">
        <?php if (get_option('swt_adb') == 'Display') { ?>
        <div id="adb"><?php echo stripslashes(get_option('swt_adbcode')); ?></div>
        <?php { echo ''; } ?>
        <?php } else { } ?>
        <?php the_content('Read more...'); ?>
        <?php if (function_exists('wp_today')) {print wp_today();} ?>
        <?php wp_link_pages(); ?>
<!--<a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>">-->
          <div class="clear"></div>
           <div class="article_info_bottom2"><?php the_tags('标签： ', ' ', ''); ?></div>
      <?php include('includes/baidushare.php'); ?>
      </div>
        <div class="clear"></div>
  </div>
<div class="article article_c">

<ul class="pre_nex">
<li><?php previous_post_link('上一篇：%link') ?></li>
<li><?php next_post_link('下一篇：%link') ?></li>
</ul>
</div>

<!--div class="article article_c">
<?php include('includes/related.php'); ?>
<div class="clear"></div>
</div-->
<div class="article article_c article_b"> 
<?php comments_template(); ?>
</div>
	<?php endwhile; else: ?>
	<?php endif; ?>
</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>