<div id="sidebar">

<!--读者墙-->
<?php if (get_option('swt_ada') == 'Hide') { ?>
<div id="ada">
<?php echo stripslashes(get_option('swt_adacode')); ?></div>

<?php { echo ''; } ?>
<?php } else { } ?>


<?php if (get_option('swt_wallreaders') == 'Hide') { ?>
<?php { echo ''; } ?>
<?php } else { include(TEMPLATEPATH . '/includes/top_comment.php'); } ?>


<!--最新评论-->
<div style="display:none;">
<div class="clear"></div>
<div class="widget">
<?php include('includes/r_comment.php'); ?>
</div>
</div>

<!--关于博主-->
<?php if ( is_home() ) { ?>
<div class="widget">
<h3>关于博主</h3>
<div style="float:left;margin-right:3px;"><img src="/wp/wp-content/themes/shaonian/images/fs5.jpg" alt="博主" width="122" height="122" style="text-shadow: 0 0 3px #585858;"></div>
<div style="line-height:22px;letter-spacing: 1px;margin-bottom:7px;">
<b>博主</b>：少年<br/>
<b>行业</b>：IT<br/>
<b>简介</b>：个人博客，不间断地给大家分享:web前端、SEO等互联网上最前沿的技术。<br/>
</div>

</div>
<?php } ?>

<!--网站统计数据-->
<?php if (get_option('swt_r_statistics') == 'Hide') { ?>
<?php { echo ''; } ?>
<?php } else { include(TEMPLATEPATH . '/includes/r_statistics.php'); } ?>

<!--热评 随机 最新--> 
<div class="clear"></div>
<div id="tab-title">
<?php include('includes/r_tab.php'); ?>
</div>

<!--标签-->
<div class="widget" >
<?php include('includes/r_tags.php'); ?>
</div>

<!--友情链接-->
<?php if (get_option('swt_r_links') == 'Hide') { ?>
<?php { echo ''; } ?>
<?php } else { include(TEMPLATEPATH . '/includes/r_links.php'); } ?>

 <?php if ( is_single() ) { ?>
 
<div id="rollstart"></div>
<div class="hotarticle" >
<div class="widget widget1">
<h3>热门日志</h3>
<?php
$numberposts = 10; 
$most_viewd_posts = new WP_Query(); 
$most_viewd_posts->query('showposts='.$numberposts.'&orderby=meta_value&meta_key=views');
?>
<ul>
<?php while ($most_viewd_posts->have_posts()): $most_viewd_posts->the_post();?>
<li><a href="<?php echo the_permalink(); ?>"  rel="bookmark" title="详细阅读：<?php the_title(); ?>">
<?php the_title(); ?>
</a></li>
<?php endwhile; ?>
</ul>
<div class="clear"></div>
</div>
<?php } ?>
</div>
</div>
</div>