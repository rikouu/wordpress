<div class="clear"></div>
<div id="footer">
Power by 少年 版权所有 &copy 2013-2014 <a href="http://www.yangliuyun.com" title="段亮个人博客">段亮个人博客 </a>&nbsp; <span style="color:#56BFEF;">web前端、seo交流学习群： 群号是347240981</span>&nbsp; <span><a href="#" title="博客地图" target="_blank">博客地图</a></span> 
<?php if (get_option('swt_tj') == 'Display') { ?><?php echo stripslashes(get_option('swt_tjcode')); ?><?php } else { } ?></span>
 </div>
</div>


<?php wp_footer(); ?>
</body>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/comments-ajax.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/realgravatar.js"></script>
<!--<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/fancybox.js"></script>-->
<script type="text/javascript" src="<?php bloginfo('stylesheet_directory'); ?>/js/hoveraccordion.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/creekoo.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory');?>/js/lazyload.js"></script>
</html>