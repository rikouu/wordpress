<ol id="side_slide">
<?php echo stripslashes(get_option('swt_side_slider_code')); ?>
</ol>