<div class="tags">
<h3>标签云集</h3>	
<?php wp_tag_cloud('smallest=12&largest=12&unit=px&number=39&orderby=count&order=RAND');?>

</div><div class="clear"></div>