<!-- Baidu Button BEGIN -->
<div id="baidushare">
<div id="bdshare" class="bdshare_b">
<img src="http://bdimg.share.baidu.com/static/images/type-button-1.jpg?cdnversion=20120831" />
</div>
<script type="text/javascript" id="bdshare_js" data="type=button&amp;uid=6621540" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + Math.ceil(new Date()/3600000);
</script>
</div>
<!-- Baidu Button END -->