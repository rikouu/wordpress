<?php if ( is_home() ) { ?>
  <div class="widget widget1">
    <h3>友情链接</h3>
    <div class="v-links">
      <ul>
        <?php wp_list_bookmarks('orderby=link_id&categorize=0&category='.get_option('swt_links').'&title_li='); ?>
      </ul>
    </div><div class="clear"></div>
  </div>
<?php } ?>