<?php
$hosturl = $_SERVER['HTTP_HOST'];
$indexurl = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
$indexurl = strtolower($indexurl); 

if($indexurl=="/index.php") 
{
$indexurl=""; 
}

if($hosturl == 'duanliang920.com')
{
header('HTTP/1.1 301 Moved Permanently'); 
Header('Location: http://www.duanliang920.com'.$indexurl); 
}
?>
<!DOCTYPE html>
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<meta name="baidu-site-verification" content="wv4aPwmLOE" />
<?php include('includes/seo.php'); ?>
 <meta name="robots" content="noarchive">
<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/style.css" />
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="alternate" type="application/atom+xml" title="<?php bloginfo('name'); ?> Atom Feed" href="<?php bloginfo('atom_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<link rel="shortcut icon" href="<?php bloginfo('template_directory'); ?>/images/favicon.ico" type="image/x-icon" />
<?php wp_enqueue_script('jquery'); ?>
<?php wp_head(); ?>
<?php if ( is_singular() ){ ?>
<?php } ?>
<script type="text/javascript">
  jQuery(function() {          
      jQuery(".article img, .articles img").not("#respond_box img").lazyload({
          placeholder:"<?php bloginfo('template_url'); ?>/images/image-pending.gif",
            effect:"fadeIn"
          });
      });
</script>
</head>

<body>
<div id="page">
<div id="head">
  <div id="header">
    <div class="subpage">
      
      
    </div>
    <div class="logo">
      <div id="blogname">
<div style="width:100%;height:26px;"></div>
        <h1><a href="<?php echo get_option('home'); ?>/">
          <?php bloginfo('name'); ?>
          </a></h1>
        <div id="blogtitle">
          <h2>
            <?php bloginfo('description'); ?>
          </h2>
        </div>

      </div>
    </div>
    <div class="clear"></div>
    <!-- end of header --> 
  </div>
  <!-- end of head --> 
</div>
<div class="mainmenus">
<div class="mainmenu">
  <div class="topnav">
     
         <?php
if(function_exists('wp_nav_menu')) {
    wp_nav_menu(array('theme_location'=>'primary','menu_id'=>'nav','container'=>'ul'));
}
?>
      
  </div>
  <div class="search">
    <div class="search_site addapted" style="overflow: hidden; width: 150px;">
      <form method="get" id="searchform" action="<?php bloginfo('url'); ?>/">
        <fieldset id="search">
        
          <input value="搜索博文内容" onclick="this.value='';" name="s" id="s" type="text" />
          <input name="searchsubmit" value="" id="searchsubmit" class="button" type="submit" />
          
        </fieldset>
      </form>
    </div>
  </div>
  <div class="clear"></div>
</div>
<!-- end of mainmenus --> 
</div>