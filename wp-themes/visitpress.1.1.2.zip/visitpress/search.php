<?php
/**
 * The search results template file.
 * @package WordPress
 * @subpackage VisitPress
 * @since VisitPress 1.0
*/
get_header(); ?>
<div id="wrapper-main">
  <div id="container">  
  <div id="content">
  <div class="content-inside">
<?php visitpress_get_breadcrumb(); ?>
<?php if ( get_header_image() != '' ) { ?>
  <div class="header-image"><img src="<?php header_image(); ?>" alt="<?php bloginfo( 'name' ); ?>" /></div>
<?php } ?> 
      
      <?php if ( have_posts() ) : ?>
				<h1 class="archive-title"><?php printf( __( 'Search Results for: %s', 'visitpress' ), '<span>' . get_search_query() . '</span>' ); ?></h1> 
        <p class="search-results"><?php _e( 'Number of Results: ', 'visitpress' ); ?><?php echo $wp_query->found_posts; ?></p>     
 
<?php $args = array(
	'post_status' => 'publish'
);
$query = new WP_Query( $args ); 
                
while (have_posts()) : the_post(); ?> 
<?php get_template_part( 'content' ); ?>
<?php endwhile; ?>
      
      <?php else : ?>
      <h1 class="archive-title"><?php _e( 'Nothing Found', 'visitpress' ); ?></h1>
      <p><?php _e( 'Sorry, but nothing matched your search criteria. Please try again with some different keywords.', 'visitpress' ); ?></p>
<?php endif; ?>
<?php if ( $wp_query->max_num_pages > 1 ) : ?>
		<div class="navigation" role="navigation">
			<h3 class="navigation-headline section-heading"><?php _e( 'Search results navigation', 'visitpress' ); ?></h3>
      <p class="navigation-links">
<?php $big = 999999999;
echo paginate_links( array(
	'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
	'format' => '?paged=%#%',
	'current' => max( 1, get_query_var('paged') ),
  'prev_text' => __( '&larr; Previous', 'visitpress' ),
	'next_text' => __( 'Next &rarr;', 'visitpress' ),
	'total' => $wp_query->max_num_pages
) );
?>
      </p>
		</div>
<?php endif; ?>
  
  </div><!-- end of content-inside -->
  </div><!-- end of content -->
<?php get_sidebar(); ?>
  </div><!-- end of container -->
</div><!-- end of wrapper-main -->
<?php get_footer(); ?>