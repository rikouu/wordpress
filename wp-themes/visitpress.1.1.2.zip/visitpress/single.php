<?php
/**
 * The post template file.
 * @package WordPress
 * @subpackage VisitPress
 * @since VisitPress 1.0
*/
get_header(); ?>
<div id="wrapper-main">
  <div id="container">  
  <div id="content" <?php post_class(); ?>>
  <div class="content-inside">
<?php visitpress_get_breadcrumb(); ?>
<?php if ( get_header_image() != '' ) { ?>
  <div class="header-image"><img src="<?php header_image(); ?>" alt="<?php bloginfo( 'name' ); ?>" /></div>
<?php } ?> 
      
    <div class="full-content">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
      <h1><?php the_title(); ?></h1>
      <p class="post-meta"><?php visitpress_display_date_post(); ?> <?php visitpress_get_author_post(); ?> <?php visitpress_display_category_post(); ?></p>
      <?php visitpress_get_display_image_post(); ?>
        
      <?php the_content( 'Continue reading' ); ?>
      
      <?php wp_link_pages( array( 'before' => '<p class="page-link"><span>' . __( 'Pages:', 'visitpress' ) . '</span>', 'after' => '</p>' ) ); ?>
<?php edit_post_link( __( '(Edit)', 'visitpress' ), '<p>', '</p>' ); ?>
<?php endwhile; endif; ?>      
    </div><!-- end of full-content -->
 
<?php visitpress_social_buttons_post (); ?>
    
    <?php if (($visitpress_next_preview_post == '') || ($visitpress_next_preview_post == 'Display')) :  visitpress_prev_next('visitpress-post-nav');  endif; ?>
    
    <?php comments_template( '', true ); ?>
  
  </div><!-- end of content-inside -->
  </div><!-- end of content -->
<?php get_sidebar(); ?>
  </div><!-- end of container -->
</div><!-- end of wrapper-main -->
<?php get_footer(); ?>