<?php
/**
 * Template Name: Page without Title
 * The template file for pages without the page title.
 * @package WordPress
 * @subpackage VisitPress
 * @since VisitPress 1.1.2
*/
get_header(); ?>
<div id="wrapper-main">
  <div id="container">  
  <div id="content">
  <div class="content-inside">
<?php visitpress_get_breadcrumb(); ?>
<?php if ( get_header_image() != '' ) { ?>
  <div class="header-image"><img src="<?php header_image(); ?>" alt="<?php bloginfo( 'name' ); ?>" /></div>
<?php } ?> 
      
    <div class="full-content">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
      <p class="post-meta"><?php visitpress_display_date_page(); ?> <?php visitpress_get_author_page(); ?></p>
      
      <?php visitpress_get_display_image_page(); ?>
      
      <?php the_content( 'Continue reading' ); ?> 
<?php edit_post_link( __( '(Edit)', 'visitpress' ), '<p>', '</p>' ); ?>
<?php endwhile; endif; ?>      
    </div><!-- end of full-content -->
    
<?php visitpress_social_buttons_page (); ?>
    
    <?php comments_template( '', true ); ?>
  
  </div><!-- end of content-inside -->
  </div><!-- end of content -->
<?php get_sidebar(); ?>
  </div><!-- end of container -->
</div><!-- end of wrapper-main -->
<?php get_footer(); ?>