<?php
/**
 * Plugin Name: VisitPress Header Bar Widget
 * Description: Displays the home/contact/sitemap links in header.
 * Author: Tomas Toman	
 * Version: 1.0
*/

add_action('widgets_init', create_function('', 'return register_widget("Headerbar");'));
class Headerbar extends WP_Widget {
	function Headerbar() {
		$widget_ops = array('classname' => 'Headerbar', 'description' => __('Displays the home/contact/sitemap links in header.', 'visitpress') );
		$control_ops = array('width' => 200, 'height' => 400);
		$this->WP_Widget('visitpresshead', __('VisitPress Header Bar Widget', 'visitpress'), $widget_ops, $control_ops);
	}
	function form($instance) {
		// outputs the options form on admin

	if ( $instance ) {
			$sitemap = esc_attr( $instance[ 'sitemap' ] );
		}
		else {
			$sitemap = __( '', 'visitpress' );
		} 

		if ( $instance ) {
			$contact = esc_attr( $instance[ 'contact' ] );
		}
		else {
			$contact = __( '', 'visitpress' );
		} 
		if ( $instance ) {
			$home = esc_attr( $instance[ 'home' ] );
		}
		else {
			$home = __( '', 'visitpress' );
		} ?>
<!-- Home-->
<p>
	<label for="<?php echo $this->get_field_id('home'); ?>">
		<?php _e('Home page URL:', 'visitpress'); ?>
	</label>
	<input class="widefat" id="<?php echo $this->get_field_id('home'); ?>" name="<?php echo $this->get_field_name('home'); ?>" type="text" value="<?php echo $home; ?>" />
<p style="font-size: 10px; color: #999; margin: -10px 0 0 0px; padding: 0px;">
	<?php _e('Insert the URL of your Home page (example: http://www.yourdomain.com).', 'visitpress'); ?>
</p>
</p>
<!-- Contact-->
<p>
	<label for="<?php echo $this->get_field_id('contact'); ?>">
		<?php _e('Contact page/e-mail:', 'visitpress'); ?>
	</label>
	<input class="widefat" id="<?php echo $this->get_field_id('contact'); ?>" name="<?php echo $this->get_field_name('contact'); ?>" type="text" value="<?php echo $contact; ?>" />
<p style="font-size: 10px; color: #999; margin: -10px 0 0 0px; padding: 0px;">
	<?php _e('Insert the full URL of your Contact page or contact e-mail address If you want to insert an e-mail, please add the prefix "mailto:" (example: mailto:info@yourdomain.com).', 'visitpress'); ?>
</p>
</p>
<!-- Sitemap-->
<p>
	<label for="<?php echo $this->get_field_id('sitemap'); ?>">
		<?php _e('Sitemap URL:', 'visitpress'); ?>
	</label>
	<input class="widefat" id="<?php echo $this->get_field_id('sitemap'); ?>" name="<?php echo $this->get_field_name('sitemap'); ?>" type="text" value="<?php echo $sitemap; ?>" />
<p style="font-size: 10px; color: #999; margin: -10px 0 0 0px; padding: 0px;">
	<?php _e('Insert the full URL of your Sitemap page (example: http://www.yourdomain.com/sitemap).', 'visitpress'); ?>
</p>
</p>
<?php 

	} 

function update($new_instance, $old_instance) {
		// processes widget options to be saved
		$instance = $old_instance;
		$instance['sitemap'] = sanitize_text_field($new_instance['sitemap']);
		$instance['contact'] = $new_instance['contact'];
		$instance['home'] = $new_instance['home'];
	return $instance;
	}

function widget($args, $instance) {
		// outputs the content of the widget
		 extract( $args );
			$sitemap = apply_filters('widget_sitemap', $instance['sitemap']);
			$contact = apply_filters('widget_contact', $instance['contact']);
			$home = apply_filters('widget_home', $instance['home']); ?>
<?php echo $before_widget; ?>
<?php
    // Twitter
		if ($sitemap != "") {
			echo "<a class='link-sitemap' href='$sitemap'></a>";
		}	
    // Facebook
		if ($contact != "") {
			echo "<a class='link-contact' href='$contact'></a>";
		}	
    // RSS
		if ($home != "") {
			echo "<a class='link-home' href='$home'></a>";
		}	
	 	echo $after_widget; ?>
<?php
	}
}
?>