<?php 
/**
 * Library of Theme options functions.
 * @package WordPress
 * @subpackage VisitPress
 * @since VisitPress 1.0
*/
?>
<?php global $visitpress_options;
foreach ($visitpress_options as $value) {
	if (isset($value['id']) && get_option( $value['id'] ) === FALSE && isset($value['std'])) {
		$$value['id'] = $value['std'];
	}
	elseif (isset($value['id'])) { $$value['id'] = get_option( $value['id'] ); }
} ?>
<?php  

// Display Breadcrumb navigation
function visitpress_get_breadcrumb() { 
		if (get_option('visitpress_display_breadcrumb') == '' || get_option('visitpress_display_breadcrumb') == 'Display') { ?>
		<?php _e('<p class="breadcrumb-navigation">', 'visitpress'); ?><?php if(function_exists( 'bcn_display' )){bcn_display();} ?><?php _e('</p>', 'visitpress'); ?>
<?php } 
}

// Display featured images on single posts
function visitpress_get_display_image_post() { 
		if (get_option('visitpress_display_image_post') == '' || get_option('visitpress_display_image_post') == 'Display') { ?>
		<?php if ( has_post_thumbnail() ) : ?>
      <?php the_post_thumbnail(); ?>
    <?php endif; ?>
<?php } 
}

// Display featured images on pages
function visitpress_get_display_image_page() { 
		if (get_option('visitpress_display_image_page') == '' || get_option('visitpress_display_image_page') == 'Display') { ?>
		<?php if ( has_post_thumbnail() ) : ?>
      <?php the_post_thumbnail(); ?>
    <?php endif; ?>
<?php } 
}

// Display the date on posts
function visitpress_display_date_post () { 
	if (get_option('visitpress_display_date_post') == '' || get_option('visitpress_display_date_post') == 'Display'){ ?>
	<?php _e('<strong>Posted</strong>: ', 'visitpress'); ?><?php the_time( 'd. m. Y' ) ?>
	<?php }
  if (get_option('visitpress_display_author_post') == '' || get_option('visitpress_display_author_post') == 'Display' && get_option('visitpress_display_date_post') == 'Display') { ?>
		<?php _e(' | ', 'visitpress'); ?>
<?php }
}

// Display the date on pages
function visitpress_display_date_page () { 
	if (get_option('visitpress_display_date_page') == 'Display'){ ?>
	<?php _e('<strong>Posted</strong>: ', 'visitpress'); ?><?php the_time( 'd. m. Y' ) ?>
	<?php }
  if (get_option('visitpress_display_author_page') == 'Display' && get_option('visitpress_display_date_page') == 'Display') { ?>
		<?php _e(' | ', 'visitpress'); ?>
<?php }
}

// Display categories on posts
function visitpress_display_category_post() {
	if (is_single() && (get_option('visitpress_display_categories_post') == '' || get_option('visitpress_display_categories_post') == 'Display')) { ?>	
		<?php _e('<strong>Category</strong>: ', 'visitpress'); ?><?php the_category(', ') ?>
	<?php } // end 
}

 
// Display Author on page
function visitpress_get_author_page() { 
		if (get_option('visitpress_display_author_page') == 'Display') { ?>
		<?php _e('<strong>Author</strong>: ', 'visitpress'); ?><?php the_author_posts_link(); ?>
<?php } 
}
// Display Author on post
function visitpress_get_author_post() { 
		if (get_option('visitpress_display_author_post') == '' || get_option('visitpress_display_author_post') == 'Display') { ?>
		<?php _e('<strong>Author</strong>: ', 'visitpress'); ?><?php the_author_posts_link(); ?>
<?php }
    if (is_single() && (get_option('visitpress_display_categories_post') == '' || get_option('visitpress_display_categories_post') == 'Display' && get_option('visitpress_display_author_post') == 'Display')) { ?>	
		<?php _e(' | ', 'visitpress'); ?>
	<?php } 
  if (is_single() && (get_option('visitpress_display_categories_post') == 'Display' && get_option('visitpress_display_author_post') == 'Hide' && get_option('visitpress_display_date_post') == 'Display')) { ?>	
		<?php _e(' | ', 'visitpress'); ?>
	<?php } 
}

// Index page headline
function visitpress_get_index_headline() { 
		$index_headline = get_option('visitpress_index_headline');
    if ($index_headline != '') { ?>
    <?php _e('<h1>', 'visitpress'); ?><?php echo $index_headline; ?><?php _e('</h1>', 'visitpress'); ?> 
    <?php } 
}

//Social Buttons 

//Embed for twiter
 add_filter('oembed_providers','twitter_oembed');
function twitter_oembed($a) {
	$a['#http(s)?://(www\.)?twitter.com/.+?/status(es)?/.*#i'] = array( 'http://api.twitter.com/1/statuses/oembed.{format}', true);
	return $a;
}

function visitpress_open_graph() {
		if ( is_single() || is_page() ){
		global $wp_query;
		$visitpress_postid = $wp_query->post->ID;
		$visitpress_title = single_post_title('', false);
		$visitpress_url = get_permalink($visitpress_postid);
		$visitpress_blogname = get_bloginfo('name');
			echo "\n<meta property='og:title' content='$visitpress_title' />",
				"\n<meta property='og:site_name' content='$visitpress_blogname' />",
				"\n<meta property='og:url' content='$visitpress_url' />",
				"\n<meta property='og:type' content='article' />";
} }
		add_action('wp_head', 'visitpress_open_graph');
//
add_image_size( 'visitpress-fb-thumb', 320, 213, true );

function visitpress_fb_thumb() {
if ( is_single() || is_page() ) {
	if (has_post_thumbnail()) {
	$fbthumb = wp_get_attachment_image_src(get_post_thumbnail_id(), 'visitpress-fb-thumb');
	$fbthumburl = $fbthumb[0];
	echo "\n<meta property='og:image' content='$fbthumburl' />\n";
	}
	}
}
add_action( 'wp_head', 'visitpress_fb_thumb' );

//show social icons on page
function visitpress_social_buttons_page() { 
if (get_option('visitpress_share_buttons_page') == '' || get_option('visitpress_share_buttons_page') == 'Display') { ?>
	<div class="social-share">
  <fb:like href="<?php echo get_permalink(); ?>" send="true" layout="button_count" width="200" show_faces="true"></fb:like>
	<a href="http://twitter.com/share" class="twitter-share-button" data-url="<?php echo get_permalink(); ?>">Tweet</a>
	<g:plusone size="medium" href="<?php echo get_permalink(); ?>"></g:plusone>
	</div>
<?php } }

//show social icons on post
function visitpress_social_buttons_post() { 
if (get_option('visitpress_share_buttons_post') == '' || get_option('visitpress_share_buttons_post') == 'Display') {
?>
	<div class="social-share">
  <fb:like href="<?php echo get_permalink(); ?>" send="true" layout="button_count" width="200" show_faces="true"></fb:like>
	<a href="http://twitter.com/share" class="twitter-share-button" data-url="<?php echo get_permalink(); ?>">Tweet</a>
	<g:plusone size="medium" href="<?php echo get_permalink(); ?>"></g:plusone>
	</div>
<?php } }