<?php
/**
 * The header for our theme.
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package CleanWP
 */

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="profile" href="http://gmpg.org/xfn/11">
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<div id="wrapper">
<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'cleanwp' ); ?></a>
<header id="masthead" class="site-header" role="banner">

<div id="site-top">
<div id="blogname">
<?php if ( get_header_image() ) : ?>
    <div class="site-branding">
    <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" style="display: block;">
        <img src="<?php header_image(); ?>" width="<?php echo get_custom_header()->width; ?>" height="<?php echo get_custom_header()->height; ?>" alt="" class="header-image"/>
    </a>   
    </div>
<?php else: ?>
    <?php if ( get_cleanwp_options('sitelogo') ) : ?>
        <div class="site-branding" style="text-align:center;">
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" style="display: block;">
            <img src="<?php echo esc_url( get_cleanwp_options('sitelogo') ); ?>" alt="" class="header-image"/>
        </a>    
        </div>
    <?php else: ?>
        <div class="site-branding">
          <h1 class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h1>
          <h2 class="site-description"><?php bloginfo( 'description' ); ?></h2>
        </div>        
    <?php endif; ?>       
<?php endif; // End header image check. ?>
</div>
    
<div class="header-social-icons">
    <?php if ( !(get_cleanwp_options('hide_social_buttons')) ) { ?>
    <?php if ( get_cleanwp_options('facebooklink') ) : ?>
            <a href="<?php echo esc_url( get_cleanwp_options('facebooklink') ); ?>" target="_blank" class="social-facebook" title="Facebook"><i class="fa fa-facebook" aria-hidden="true"></i></a><?php endif; ?>
    <?php if ( get_cleanwp_options('twitterlink') ) : ?>
            <a href="<?php echo esc_url( get_cleanwp_options('twitterlink') ); ?>" target="_blank" class="social-twitter" title="Twitter"><i class="fa fa-twitter" aria-hidden="true"></i></a><?php endif; ?>
    <?php if ( get_cleanwp_options('googlelink') ) : ?>
            <a href="<?php echo esc_url( get_cleanwp_options('googlelink') ); ?>" target="_blank" class="social-googleplus" title="Google Plus"><i class="fa fa-google-plus" aria-hidden="true"></i></a><?php endif; ?>
    <?php if ( get_cleanwp_options('pinterestlink') ) : ?>
            <a href="<?php echo esc_url( get_cleanwp_options('pinterestlink') ); ?>" target="_blank" class="social-pinterest" title="Pinterest"><i class="fa fa-pinterest" aria-hidden="true"></i></a><?php endif; ?>
    <?php if ( get_cleanwp_options('linkedinlink') ) : ?>
            <a href="<?php echo esc_url( get_cleanwp_options('linkedinlink') ); ?>" target="_blank" class="social-linkedin" title="Linkedin"><i class="fa fa-linkedin" aria-hidden="true"></i></a><?php endif; ?>
    <?php if ( get_cleanwp_options('instagramlink') ) : ?>
            <a href="<?php echo esc_url( get_cleanwp_options('instagramlink') ); ?>" target="_blank" class="social-instagram" title="Instagram"><i class="fa fa-instagram" aria-hidden="true"></i></a><?php endif; ?>
    <?php if ( get_cleanwp_options('flickrlink') ) : ?>
            <a href="<?php echo esc_url( get_cleanwp_options('flickrlink') ); ?>" target="_blank" class="social-flickr" title="Flickr"><i class="fa fa-flickr" aria-hidden="true"></i></a><?php endif; ?>
    <?php if ( get_cleanwp_options('youtubelink') ) : ?>
            <a href="<?php echo esc_url( get_cleanwp_options('youtubelink') ); ?>" target="_blank" class="social-youtube" title="Youtube"><i class="fa fa-youtube" aria-hidden="true"></i></a><?php endif; ?>
    <?php if ( get_cleanwp_options('vimeolink') ) : ?>
            <a href="<?php echo esc_url( get_cleanwp_options('vimeolink') ); ?>" target="_blank" class="social-vimeo" title="Vimeo"><i class="fa fa-vimeo" aria-hidden="true"></i></a><?php endif; ?>
    <?php if ( get_cleanwp_options('soundcloudlink') ) : ?>
            <a href="<?php echo esc_url( get_cleanwp_options('soundcloudlink') ); ?>" target="_blank" class="social-soundcloud" title="SoundCloud"><i class="fa fa-soundcloud" aria-hidden="true"></i></a><?php endif; ?>
    <?php if ( get_cleanwp_options('lastfmlink') ) : ?>
            <a href="<?php echo esc_url( get_cleanwp_options('lastfmlink') ); ?>" target="_blank" class="social-lastfm" title="Lastfm"><i class="fa fa-lastfm" aria-hidden="true"></i></a><?php endif; ?>
    <?php if ( get_cleanwp_options('githublink') ) : ?>
            <a href="<?php echo esc_url( get_cleanwp_options('githublink') ); ?>" target="_blank" class="social-github" title="Github"><i class="fa fa-github" aria-hidden="true"></i></a><?php endif; ?>
    <?php if ( get_cleanwp_options('bitbucketlink') ) : ?>
            <a href="<?php echo esc_url( get_cleanwp_options('bitbucketlink') ); ?>" target="_blank" class="social-bitbucket" title="Bitbucket"><i class="fa fa-bitbucket" aria-hidden="true"></i></a><?php endif; ?>
    <?php if ( get_cleanwp_options('tumblrlink') ) : ?>
            <a href="<?php echo esc_url( get_cleanwp_options('tumblrlink') ); ?>" target="_blank" class="social-tumblr" title="Tumblr"><i class="fa fa-tumblr" aria-hidden="true"></i></a><?php endif; ?>
    <?php if ( get_cleanwp_options('digglink') ) : ?>
            <a href="<?php echo esc_url( get_cleanwp_options('digglink') ); ?>" target="_blank" class="social-digg" title="Digg"><i class="fa fa-digg" aria-hidden="true"></i></a><?php endif; ?>
    <?php if ( get_cleanwp_options('deliciouslink') ) : ?>
            <a href="<?php echo esc_url( get_cleanwp_options('deliciouslink') ); ?>" target="_blank" class="social-delicious" title="Delicious"><i class="fa fa-delicious" aria-hidden="true"></i></a><?php endif; ?>
    <?php if ( get_cleanwp_options('stumblelink') ) : ?>
            <a href="<?php echo esc_url( get_cleanwp_options('stumblelink') ); ?>" target="_blank" class="social-stumbleupon" title="Stumbleupon"><i class="fa fa-stumbleupon" aria-hidden="true"></i></a><?php endif; ?>
    <?php if ( get_cleanwp_options('redditlink') ) : ?>
            <a href="<?php echo esc_url( get_cleanwp_options('redditlink') ); ?>" target="_blank" class="social-reddit" title="Reddit"><i class="fa fa-reddit" aria-hidden="true"></i></a><?php endif; ?>
    <?php if ( get_cleanwp_options('dribbblelink') ) : ?>
            <a href="<?php echo esc_url( get_cleanwp_options('dribbblelink') ); ?>" target="_blank" class="social-dribbble" title="Dribbble"><i class="fa fa-dribbble" aria-hidden="true"></i></a><?php endif; ?>
    <?php if ( get_cleanwp_options('behancelink') ) : ?>
            <a href="<?php echo esc_url( get_cleanwp_options('behancelink') ); ?>" target="_blank" class="social-behance" title="Behance"><i class="fa fa-behance" aria-hidden="true"></i></a><?php endif; ?>
    <?php if ( get_cleanwp_options('codepenlink') ) : ?>
            <a href="<?php echo esc_url( get_cleanwp_options('codepenlink') ); ?>" target="_blank" class="social-codepen" title="Codepen"><i class="fa fa-codepen" aria-hidden="true"></i></a><?php endif; ?>
    <?php if ( get_cleanwp_options('jsfiddlelink') ) : ?>
            <a href="<?php echo esc_url( get_cleanwp_options('jsfiddlelink') ); ?>" target="_blank" class="social-jsfiddle" title="JSFiddle"><i class="fa fa-jsfiddle" aria-hidden="true"></i></a><?php endif; ?>
    <?php if ( get_cleanwp_options('stackoverflowlink') ) : ?>
            <a href="<?php echo esc_url( get_cleanwp_options('stackoverflowlink') ); ?>" target="_blank" class="social-stackoverflow" title="Stack Overflow"><i class="fa fa-stack-overflow" aria-hidden="true"></i></a><?php endif; ?>
    <?php if ( get_cleanwp_options('stackexchangelink') ) : ?>
            <a href="<?php echo esc_url( get_cleanwp_options('stackexchangelink') ); ?>" target="_blank" class="social-stackexchange" title="Stack Exchange"><i class="fa fa-stack-exchange" aria-hidden="true"></i></a><?php endif; ?>
    <?php if ( get_cleanwp_options('bsalink') ) : ?>
            <a href="<?php echo esc_url( get_cleanwp_options('bsalink') ); ?>" target="_blank" class="social-buysellads" title="BuySellAds"><i class="fa fa-buysellads" aria-hidden="true"></i></a><?php endif; ?>
    <?php if ( get_cleanwp_options('slidesharelink') ) : ?>
            <a href="<?php echo esc_url( get_cleanwp_options('slidesharelink') ); ?>" target="_blank" class="social-slideshare" title="SlideShare"><i class="fa fa-slideshare" aria-hidden="true"></i></a><?php endif; ?>
    <?php if ( get_cleanwp_options('skypeusername') ) : ?>
            <a href="skype:<?php echo esc_html( get_cleanwp_options('skypeusername') ); ?>?chat" class="social-skype" title="Skype"><i class="fa fa-skype" aria-hidden="true"></i></a><?php endif; ?>
    <?php if ( get_cleanwp_options('emailaddress') ) : ?>
            <a href="mailto:<?php echo esc_html( get_cleanwp_options('emailaddress') ); ?>" class="social-email" title="Email Us"><i class="fa fa-envelope" aria-hidden="true"></i></a><?php endif; ?>
    <?php if ( get_cleanwp_options('rsslink') ) : ?>
            <a href="<?php echo esc_url( get_cleanwp_options('rsslink') ); ?>" target="_blank" class="social-rss" title="RSS"><i class="fa fa-rss" aria-hidden="true"></i></a><?php endif; ?>
        <?php } ?>
</div>
</div>
    
<nav id="site-navigation" class="main-navigation clearfix" role="navigation">
    <button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false"><?php esc_html_e( 'Menu', 'cleanwp' ); ?></button>
	<?php wp_nav_menu( array( 'theme_location' => 'primary', 'menu_id' => 'primary-menu' ) ); ?>
</nav><!-- #site-navigation -->

</header><!--end masthead-->

<div id="content" class="site-content">