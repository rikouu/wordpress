jQuery(document).ready(function($) {
    
  // jQuery codes using $ as usual goes here.
  
});
