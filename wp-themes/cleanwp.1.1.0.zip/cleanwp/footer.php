<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package CleanWP
 */
?>

<div class="clear"></div>
</div>
</div>

<?php if ( is_active_sidebar( 'footer-1' ) || is_active_sidebar( 'footer-2' ) || is_active_sidebar( 'footer-3' ) ) : ?>
<div id="footer-widgets-container" class="clearfix">
    <div class="footer-widget-box footer-widget-box-1">
	    <?php dynamic_sidebar( 'footer-1' ); ?>
    </div>

    <div class="footer-widget-box footer-widget-box-2">
	    <?php dynamic_sidebar( 'footer-2' ); ?>
    </div>

    <div class="footer-widget-box footer-widget-box-3">
	    <?php dynamic_sidebar( 'footer-3' ); ?>
    </div>
</div>
<div class="clear"></div>
<?php endif; ?>

<footer id="colophon" class="site-footer" role="contentinfo">
<div class="site-info">
<?php if ( get_cleanwp_options('footer_text') ) : ?>
  <?php echo get_cleanwp_options('footer_text'); ?> | <a href="<?php echo esc_url( __( 'http://themesdna.com/', 'cleanwp' ) ); ?>"><?php printf( esc_html__( 'Design by %s', 'cleanwp' ), 'ThemesDNA.com' ); ?></a>
<?php else : ?>
  <?php printf( __( 'Copyright &copy; %s', 'cleanwp' ), date( 'Y' ) . ' ' . get_bloginfo( 'name' )  ); ?> | <a href="<?php echo esc_url( __( 'http://themesdna.com/', 'cleanwp' ) ); ?>"><?php printf( esc_html__( 'Design by %s', 'cleanwp' ), 'ThemesDNA.com' ); ?></a>
<?php endif; ?>
</div>
<div class='clear'></div>
</footer><!-- #colophon -->

<?php wp_footer(); ?>
</body>
</html>