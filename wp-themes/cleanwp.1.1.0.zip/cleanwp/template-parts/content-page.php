<?php
/**
 * Template part for displaying page content in page.php.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package CleanWP
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    
	<header class="entry-header">
	    <?php the_title( sprintf( '<h1 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h1>' ); ?>
	</header><!-- .entry-header -->

	<div class="entry-content clearfix">
            <?php
            if ( has_post_thumbnail() ) {
                if ( 1 === get_cleanwp_options('hide_thumbnail') ) {                 
                } else {
                    if ( 1 === get_cleanwp_options('hide_thumbnail_single') ) {
                    } else {
                        if ( get_cleanwp_options('thumbnail_link') == 'no' ) {
                            the_post_thumbnail(array(250,9999), array('class' => 'entry-featured-image entry-featured-image-block'));
                        } else { ?>
                            <a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_post_thumbnail(array(250,9999), array('class' => 'entry-featured-image entry-featured-image-block')); ?></a>
                <?php   }
                    }
                }       
            }
            the_content( sprintf(__( 'Continue reading %s <span class="meta-nav">&rarr;</span>', 'cleanwp' ), the_title( '<span class="screen-reader-text">"', '"</span>', false )) );

            wp_link_pages( array(
             'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'cleanwp' ) . '</span>',
             'after'       => '</div>',
             'link_before' => '<span>',
             'link_after'  => '</span>',
             ) );
             ?>
	</div><!-- .entry-content -->

	<footer class="entry-footer">
	    <?php edit_post_link( __( 'Edit', 'cleanwp' ), '<span class="edit-link">', '</span>' ); ?>
	</footer><!-- .entry-footer -->
        
</article>