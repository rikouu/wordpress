<?php
/**
 * Template part for displaying single posts.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package CleanWP
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
    
	<header class="entry-header">
	    <?php the_title( sprintf( '<h1 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h1>' ); ?>
            <div class="entry-meta">
                    <?php cleanwp_posted_on(); ?>
            </div><!-- .entry-meta -->
	</header><!-- .entry-header -->

	<div class="entry-content clearfix">
            <?php
            if ( has_post_thumbnail() ) {
                if ( 1 === get_cleanwp_options('hide_thumbnail') ) {                 
                } else {
                    if ( 1 === get_cleanwp_options('hide_thumbnail_single') ) {
                    } else {
                        if ( get_cleanwp_options('thumbnail_link') == 'no' ) {
                            the_post_thumbnail(array(250,9999), array('class' => 'entry-featured-image entry-featured-image-block'));
                        } else { ?>
                            <a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_post_thumbnail(array(250,9999), array('class' => 'entry-featured-image entry-featured-image-block')); ?></a>
                <?php   }
                    }
                }       
            }
            the_content( sprintf(__( 'Continue reading %s <span class="meta-nav">&rarr;</span>', 'cleanwp' ), the_title( '<span class="screen-reader-text">"', '"</span>', false )) );

            wp_link_pages( array(
             'before'      => '<div class="page-links"><span class="page-links-title">' . __( 'Pages:', 'cleanwp' ) . '</span>',
             'after'       => '</div>',
             'link_before' => '<span>',
             'link_after'  => '</span>',
             ) );
             ?>
	</div><!-- .entry-content -->

	<footer class="entry-footer">
	    <?php cleanwp_entry_footer(); ?>
	</footer><!-- .entry-footer -->
        
</article>