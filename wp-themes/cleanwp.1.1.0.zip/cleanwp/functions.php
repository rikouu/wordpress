<?php
/**
 * CleanWP functions and definitions.
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package CleanWP
 */

define( 'CLEANWP_PROURL', 'http://themesdna.com/products/cleanwp-pro/' );
define( 'CLEANWP_CONTACTURL', 'http://themesdna.com/contact/' );
define( 'CLEANWP_THEMEOPTIONSDIR', get_template_directory() . '/admin' );
require_once( CLEANWP_THEMEOPTIONSDIR . '/customizer.php' );

if ( ! isset( $content_width ) ) {
    $content_width = 650;
}

function get_cleanwp_options($option) {
    $cleanwp_options = get_option('cleanwp_options');
    if ((is_array($cleanwp_options)) && (array_key_exists($option, $cleanwp_options))) {
        return $cleanwp_options[$option];
    }
    else {
    	return '';
    }
}

if ( ! function_exists( 'cleanwp_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 */
function cleanwp_setup() {
    
    global $wp_version;
    
	/*
	 * Make theme available for translation.
	 * Translations can be filed in the /languages/ directory.
	 * If you're building a theme based on CleanWP, use a find and replace
	 * to change 'cleanwp' to the name of your theme in all the template files.
	 */
    load_theme_textdomain( 'cleanwp', get_template_directory() . '/languages' );

	// Add default posts and comments RSS feed links to head.
    add_theme_support( 'automatic-feed-links' );
        
	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
    add_theme_support( 'title-tag' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * @link http://codex.wordpress.org/Function_Reference/add_theme_support#Post_Thumbnails
	 */
    add_theme_support( 'post-thumbnails' );
    
	// This theme uses wp_nav_menu() in one location.
    register_nav_menus( array(
    'primary' => __('Primary Menu', 'cleanwp')
    ) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
    $markup = array( 'comment-list', 'comment-form', 'search-form', 'gallery', 'caption' );
    add_theme_support( 'html5', $markup );
    
    // Support for Custom Header
    add_theme_support( 'custom-header', apply_filters( 'cleanwp_custom_header_args', array(
	'default-image'          => '',
    'default-text-color'     => '000000',
	'width'                  => 1000,
	'height'                 => 250,
	'flex-height'            => true,
        'wp-head-callback'       => 'cleanwp_header_style',
        'uploads'                => true,
    ) ) );
    
	// Set up the WordPress core custom background feature.
    $background_args = array(
            'default-color'          => '717171',
            'default-image'          => '',
            'default-repeat'         => 'repeat',
            'default-position-x'     => 'left',
            'wp-head-callback'       => '_custom_background_cb',
            'admin-head-callback'    => 'admin_head_callback_func',
            'admin-preview-callback' => 'admin_preview_callback_func',
    );
    add_theme_support( 'custom-background', apply_filters( 'cleanwp_custom_background_args', $background_args) );
    
    // Support for Custom Editor Style
    add_editor_style( 'css/editor-style.css' );

}
endif;
add_action( 'after_setup_theme', 'cleanwp_setup' );

/**
 * Enqueue scripts and styles.
 */
function cleanwp_scripts() {
    wp_enqueue_style('cleanwp-maincss', get_stylesheet_uri(), array(), NULL);
	wp_enqueue_style('font-awesome', get_template_directory_uri() . '/css/font-awesome.min.css', array(), NULL );
    wp_enqueue_style('cleanwp-webfont', '//fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic|Raleway:700,900,400,300&subset=latin,latin-ext', array(), NULL);

    wp_enqueue_script('cleanwp-navigation-js', get_template_directory_uri() . '/js/navigation.js', array(), NULL, true );
    wp_enqueue_script('cleanwp-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), NULL, true );
    wp_enqueue_script('cleanwp-customjs', get_stylesheet_directory_uri() .'/js/custom.js', array( 'jquery' ), NULL, true);

    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'cleanwp_scripts' );

/**
 * Enqueue IE compatible scripts and styles.
 */
function cleanwp_ie_scripts() { ?>
<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
<script src="<?php echo get_template_directory_uri(); ?>/js/html5shiv.min.js" type="text/javascript"></script>
<script src="<?php echo get_template_directory_uri(); ?>/js/respond.min.js" type="text/javascript"></script>
<![endif]-->
  <?php
}
add_action( 'wp_head', 'cleanwp_ie_scripts' );

/**
 * Enqueue customizer styles.
 */
function cleanwp_enqueue_customizer_styles() {
	wp_enqueue_style( 'cleanwp-customizer-styles', get_template_directory_uri() . '/admin/css/customizer-styles.css', array(), NULL );
}
add_action( 'customize_controls_enqueue_scripts', 'cleanwp_enqueue_customizer_styles' );

/**
 * Enqueue customizer scripts.
 */
function cleanwp_enqueue_customizer_scripts() {
	wp_register_script( 'cleanwp-customizer-script', get_template_directory_uri() . '/admin/js/customizer-scripts.js', array( 'jquery' ), NULL, true );
	$params = array(
		'upgrade_text'       => esc_html__( 'Upgrade to Pro', 'cleanwp' ),
		'documentation_text' => esc_html__( 'Contact Us', 'cleanwp' ),
	);
	wp_localize_script( 'cleanwp-customizer-script', 'cleanwp_customizerjs', $params );
	wp_enqueue_script( 'cleanwp-customizer-script' );
}
add_action( 'admin_enqueue_scripts', 'cleanwp_enqueue_customizer_scripts' );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function cleanwp_widgets_init() {

register_sidebar(array(
    'id' => 'main-sidebar',
    'name' => __( 'Main Sidebar', 'cleanwp' ),
    'description' => __( 'This sidebar is located on the right-hand side of web page.', 'cleanwp' ),
    'before_widget' => '<div id="%1$s" class="side-widget widget %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h3 class="widget-title">',
    'after_title' => '</h3>'));

register_sidebar(array(
    'id' => 'footer-1',
    'name' => __( 'Footer 1', 'cleanwp' ),
    'description' => __( 'This sidebar is located on the left bottom of web page.', 'cleanwp' ),
    'before_widget' => '<div id="%1$s" class="footer-widget widget %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h3 class="fwidget-title">',
    'after_title' => '</h3>'));

register_sidebar(array(
    'id' => 'footer-2',
    'name' => __( 'Footer 2', 'cleanwp' ),
    'description' => __( 'This sidebar is located on the middle bottom of web page.', 'cleanwp' ),
    'before_widget' => '<div id="%1$s" class="footer-widget widget %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h3 class="fwidget-title">',
    'after_title' => '</h3>'));

register_sidebar(array(
    'id' => 'footer-3',
    'name' => __( 'Footer 3', 'cleanwp' ),
    'description' => __( 'This sidebar is located on the right bottom of web page.', 'cleanwp' ),
    'before_widget' => '<div id="%1$s" class="footer-widget widget %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h3 class="fwidget-title">',
    'after_title' => '</h3>'));

}
add_action( 'widgets_init', 'cleanwp_widgets_init' );

// Get our wp_nav_menu() fallback, wp_page_menu(), to show a "Home" link as the first item
function cleanwp_page_menu_args( $args ) {
	$args['show_home'] = true;
	return $args;
}
add_filter( 'wp_page_menu_args', 'cleanwp_page_menu_args' );

// Category ids in post class
function cleanwp_category_id_class($classes) {
        global $post;
        foreach((get_the_category($post->ID)) as $category)
            $classes [] = 'wpcat-' . $category->cat_ID . '-id';
            return $classes;
}
add_filter('post_class', 'cleanwp_category_id_class');

// Change excerpt length
function cleanwp_excerpt_length($length) {
	return 40;
}
add_filter('excerpt_length', 'cleanwp_excerpt_length');

// Change excerpt more word
function cleanwp_excerpt_more($more) {
       global $post;
       $readmoretext = 'Read More';
        if ( get_cleanwp_options('read_more_text') ) {
                $readmoretext = get_cleanwp_options('read_more_text');
        }
       return '<div class="entry-read-more"><a class="read-more-link" href="'. esc_url( get_permalink($post->ID) ) . '">'.$readmoretext.'<span class="screen-reader-text">  '.get_the_title().'</span></a></div>';
}
add_filter('excerpt_more', 'cleanwp_excerpt_more');

// Adds custom classes to the array of body classes.
function cleanwp_body_classes( $classes ) {
	// Adds a class of group-blog to blogs with more than 1 published author.
	if ( is_multi_author() ) {
		$classes[] = 'group-blog';
	}     
	if ( ( ! is_active_sidebar( 'main-sidebar' ) ) || is_page_template( 'page-full-width.php' ) || is_404() ) {
		$classes[] = 'body-full-width';
	}     
	return $classes;
}
add_filter( 'body_class', 'cleanwp_body_classes' );

/**
 * Other theme functions
 */
require get_template_directory() . '/admin/template-tags.php';

require_once get_template_directory() . '/admin/custom.php';
?>