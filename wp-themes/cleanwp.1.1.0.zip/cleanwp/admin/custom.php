<?php
/**
 * Decides how posts should be displayed on Homepage, Category Pages, Archive Pages and Search Pages
 *
 * @package CleanWP
 */

function cleanwp_blog_post_style() {
    if ( get_cleanwp_options('blogpoststyle') ) :
        if ( get_cleanwp_options('blogpoststyle') == 'excerpt' ) :
            if ( has_post_thumbnail() ) { 
                if ( 1 === get_cleanwp_options('hide_thumbnail') ) {                    
                } else { ?>
                <?php if ( get_cleanwp_options('thumbnail_link') == 'no' ) { ?>
                    <?php the_post_thumbnail(array(250,9999), array('class' => 'entry-featured-image')); ?>
                <?php } else { ?>
                    <a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_post_thumbnail(array(250,9999), array('class' => 'entry-featured-image')); ?></a>
                <?php }                
                }        
            }
            the_excerpt();
        else :
            if ( has_post_thumbnail() ) { 
                if ( 1 === get_cleanwp_options('hide_thumbnail') ) {                    
                } else { ?>
                <?php if ( get_cleanwp_options('thumbnail_link') == 'no' ) { ?>
                    <?php the_post_thumbnail(array(250,9999), array('class' => 'entry-featured-image entry-featured-image-block')); ?>
                <?php } else { ?>
                    <a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_post_thumbnail(array(250,9999), array('class' => 'entry-featured-image entry-featured-image-block')); ?></a>
                <?php }                
                }        
            }
            the_content( sprintf(
                    __( 'Continue reading %s <span class="meta-nav">&rarr;</span>', 'cleanwp' ),
                    the_title( '<span class="screen-reader-text">"', '"</span>', false )
            ) );            
        endif;
    else : 
        if ( has_post_thumbnail() ) { 
                if ( 1 === get_cleanwp_options('hide_thumbnail') ) {                    
                } else { ?>
                <?php if ( get_cleanwp_options('thumbnail_link') == 'no' ) { ?>
                        <?php the_post_thumbnail(array(250,9999), array('class' => 'entry-featured-image')); ?>
                <?php } else { ?>
                        <a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_post_thumbnail(array(250,9999), array('class' => 'entry-featured-image')); ?></a>
                <?php }                
                }        
        }
        the_excerpt();
    endif;
}

// Custom CSS
function cleanwp_customcss() {
    if ( get_cleanwp_options('customcss') ) : ?>
      <style type="text/css"><?php echo esc_html( get_cleanwp_options('customcss') ); ?></style>
    <?php endif;
}
add_action('wp_head', 'cleanwp_customcss');

// Customizer Options
function cleanwp_customizer_css() {
	?>
	<style type="text/css">
               <?php if ( get_cleanwp_options('body_text_color') ) { ?>
		body,button,input,select,textarea {color: <?php echo esc_attr( get_cleanwp_options('body_text_color') ); ?>}
               <?php } ?>
               <?php if ( get_cleanwp_options('link_color') ) { ?>
		a {color: <?php echo esc_attr( get_cleanwp_options('link_color') ); ?>}
               <?php } ?>
               <?php if ( get_cleanwp_options('link_hover_color') ) { ?>
		a:hover {color: <?php echo esc_attr( get_cleanwp_options('link_hover_color') ); ?>}
               <?php } ?>
               <?php if ( get_cleanwp_options('post_headings_color') ) { ?>
		.entry-title, .entry-title a {color: <?php echo esc_attr( get_cleanwp_options('post_headings_color') ); ?>}
               <?php } ?>
               <?php if ( get_cleanwp_options('post_headings_hover_color') ) { ?>
		.entry-title a:hover {color: <?php echo esc_attr( get_cleanwp_options('post_headings_hover_color') ); ?>}
               <?php } ?>
               <?php if ( get_cleanwp_options('sidebar_headings_color') ) { ?>
		.widget-title, .widget-title a {color: <?php echo esc_attr( get_cleanwp_options('sidebar_headings_color') ); ?>}
               <?php } ?>
               <?php if ( get_cleanwp_options('sidebar_text_color') ) { ?>
		.side-widget {color: <?php echo esc_attr( get_cleanwp_options('sidebar_text_color') ); ?>}
               <?php } ?>
               <?php if ( get_cleanwp_options('sidebar_link_color') ) { ?>
		.side-widget a {color: <?php echo esc_attr( get_cleanwp_options('sidebar_link_color') ); ?>}
               <?php } ?>
               <?php if ( get_cleanwp_options('sidebar_link_hover_color') ) { ?>
		.side-widget a:hover {color: <?php echo esc_attr( get_cleanwp_options('sidebar_link_hover_color') ); ?>}
               <?php } ?>
               <?php if ( get_cleanwp_options('footer_headings_color') ) { ?>
		.fwidget-title, .fwidget-title a {color: <?php echo esc_attr( get_cleanwp_options('footer_headings_color') ); ?>}
               <?php } ?>
               <?php if ( get_cleanwp_options('footer_text_color') ) { ?>
		.footer-widget {color: <?php echo esc_attr( get_cleanwp_options('footer_text_color') ); ?>}
               <?php } ?>
               <?php if ( get_cleanwp_options('footer_link_color') ) { ?>
		.footer-widget a {color: <?php echo esc_attr( get_cleanwp_options('footer_link_color') ); ?>}
               <?php } ?>
               <?php if ( get_cleanwp_options('footer_link_hover_color') ) { ?>
		.footer-widget a:hover {color: <?php echo esc_attr( get_cleanwp_options('footer_link_hover_color') ); ?>}
               <?php } ?>
               <?php if ( get_cleanwp_options('main_border_color') ) { ?>
		#content, .hentry, .entry-title, .postbox, .entry-meta, footer.entry-footer, .side-widget, .widget-title, .side-widget ul li, .side-widget ul li li, h2.comments-title {border-color: <?php echo esc_attr( get_cleanwp_options('main_border_color') ); ?>}
               <?php } ?>
		<?php if ( 1 === get_cleanwp_options('hide_posted_date') ) { ?>
			.posted-on {display: none;}
		<?php } ?>
		<?php if ( 1 === get_cleanwp_options('hide_post_author') ) { ?>
			.byline {display: none;}
            .single .byline, .group-blog .byline {display: none;}
		<?php } ?>
		<?php if ( 1 === get_cleanwp_options('hide_post_categories') ) { ?>
			.cat-links {display: none;}
		<?php } ?>
		<?php if ( 1 === get_cleanwp_options('hide_post_tags') ) { ?>
			.tags-links {display: none;}
		<?php } ?>
		<?php if ( 1 === get_cleanwp_options('hide_comments_link') ) { ?>
			.comments-link {display: none;}
		<?php } ?>
		<?php if ( 1 === get_cleanwp_options('hide_read_more_button') ) { ?>
			.entry-read-more {display: none;}
		<?php } ?>
	</style>
	<?php
}
add_action( 'wp_head', 'cleanwp_customizer_css' );

// Header styles
if ( ! function_exists( 'cleanwp_header_style' ) ) :
function cleanwp_header_style() {
	$header_text_color = get_header_textcolor();
	if ( HEADER_TEXTCOLOR == $header_text_color ) { return; }
	?>
	<style type="text/css">
	<?php if ( 'blank' == $header_text_color ) : ?>
	    .site-title, .site-description {position: absolute;clip: rect(1px, 1px, 1px, 1px);}
	<?php else : ?>
	    .site-title, .site-title a, .site-description {color: #<?php echo esc_attr( $header_text_color ); ?>;}
	<?php endif; ?>
	</style>
	<?php
}
endif;
?>