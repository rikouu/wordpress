<?php
/**
 * CleanWP Theme Customizer.
 *
 * @package CleanWP
 */

if ( ! class_exists( 'WP_Customize_Control' ) ) {return NULL;}

class CleanWP_Customize_Button_Control extends WP_Customize_Control {
        public $type = 'button';
        protected $button_tag = 'button';
        protected $button_class = 'button button-primary';
        protected $button_href = 'javascript:void(0)';
        protected $button_target = '';
        protected $button_onclick = '';
        protected $button_tag_id = '';

        public function render_content() {
        ?>
        <span class="center">
        <?php
        echo '<' . esc_html($this->button_tag);
        if (!empty($this->button_class)) {
            echo ' class="' . esc_attr($this->button_class) . '"';
        }
        if ('button' == $this->button_tag) {
            echo ' type="button"';
        }
        else {
            echo ' href="' . esc_url($this->button_href) . '"' . (empty($this->button_tag) ? '' : ' target="' . esc_attr($this->button_target) . '"');
        }
        if (!empty($this->button_onclick)) {
            echo ' onclick="' . esc_js($this->button_onclick) . '"';
        }
        if (!empty($this->button_tag_id)) {
            echo ' id="' . esc_attr($this->button_tag_id) . '"';
        }
        echo '>';
        echo esc_html($this->label);
        echo '</' . esc_html($this->button_tag) . '>';
        ?>
        </span>
        <?php
        }
}

class CleanWP_Customize_Static_Text_Control extends WP_Customize_Control {
	public $type = 'static-text';

	public function __construct( $manager, $id, $args = array() ) {
		parent::__construct( $manager, $id, $args );
	}

	protected function render_content() {
		if ( ! empty( $this->label ) ) :
			?><span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span><?php
		endif;

		if ( ! empty( $this->description ) ) :
			?><div class="description customize-control-description"><?php

			if( is_array( $this->description ) ) {
				echo '<p>' . implode( '</p><p>', $this->description ) . '</p>';
			} else {
				echo $this->description;
			}

			?></div><?php
		endif;

	}

}

function cleanwp_register_theme_customizer( $wp_customize ) {
    
    if(method_exists('WP_Customize_Manager', 'add_panel')):
    $wp_customize->add_panel('cleanwp_main_options_panel', array( 'title' => __('Theme Options', 'cleanwp'), 'priority' => 10, ));
    endif;
    
    $wp_customize->get_section( 'title_tagline' )->panel = 'cleanwp_main_options_panel';
    $wp_customize->get_section( 'title_tagline' )->priority = 20;
    $wp_customize->get_section( 'colors' )->panel = 'cleanwp_main_options_panel';
    $wp_customize->get_section( 'colors' )->priority = 40;
      
    $wp_customize->get_setting( 'blogname' )->transport = 'postMessage';
    $wp_customize->get_setting( 'blogdescription' )->transport = 'postMessage';
    $wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';
    $wp_customize->get_setting( 'background_color' )->transport = 'postMessage';    

	$wp_customize->add_section( 'sc_cleanwp_getting_started', array( 'title' => esc_html__( 'Getting Started', 'cleanwp' ), 'description' => __( 'Thanks for your interest in CleanWP! If you have any questions or run into any trouble, please visit us the following links. We will get you fixed up!', 'cleanwp' ), 'panel' => 'cleanwp_main_options_panel', 'priority' => 5, ) );

	$wp_customize->add_setting( 'cleanwp_options[documentation]', array( 'default' => '', 'sanitize_callback' => '__return_false', ) );

	$wp_customize->add_control( new CleanWP_Customize_Button_Control( $wp_customize, 'cleanwp_documentation_control', array( 'label' => esc_html__( 'Documentation', 'cleanwp' ), 'section' => 'sc_cleanwp_getting_started', 'settings' => 'cleanwp_options[documentation]', 'type' => 'button', 'button_tag' => 'a', 'button_class' => 'button button-primary', 'button_href' => 'http://themesdna.com/cleanwp-wordpress-theme/', 'button_target' => '_blank', ) ) );

	$wp_customize->add_setting( 'cleanwp_options[contact]', array( 'default' => '', 'sanitize_callback' => '__return_false', ) );

	$wp_customize->add_control( new CleanWP_Customize_Button_Control( $wp_customize, 'cleanwp_contact_control', array( 'label' => esc_html__( 'Contact Us', 'cleanwp' ), 'section' => 'sc_cleanwp_getting_started', 'settings' => 'cleanwp_options[contact]', 'type' => 'button', 'button_tag' => 'a', 'button_class' => 'button button-primary', 'button_href' => 'http://themesdna.com/contact/', 'button_target' => '_blank', ) ) );

	$wp_customize->add_setting( 'cleanwp_options[body_text_color]', array( 'default' => '#161514', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'sanitize_hex_color' ) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleanwp_body_text_color_control', array( 'label' => esc_html__( 'Main Text Color', 'cleanwp' ), 'section' => 'colors', 'settings' => 'cleanwp_options[body_text_color]' ) ) );

	$wp_customize->add_setting( 'cleanwp_options[link_color]', array( 'default' => '#C90000', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'sanitize_hex_color' ) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleanwp_link_color_control', array( 'label' => esc_html__( 'Main Link Color', 'cleanwp' ), 'section' => 'colors', 'settings' => 'cleanwp_options[link_color]' ) ) );

	$wp_customize->add_setting( 'cleanwp_options[link_hover_color]', array( 'default' => '#111111', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'sanitize_hex_color' ) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleanwp_link_hover_color_control', array( 'label' => esc_html__( 'Main Link Hover Color', 'cleanwp' ), 'section' => 'colors', 'settings' => 'cleanwp_options[link_hover_color]' ) ) );

	$wp_customize->add_setting( 'cleanwp_options[post_headings_color]', array( 'default' => '#1e1e1e', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'sanitize_hex_color' ) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleanwp_post_headings_color_control', array( 'label' => esc_html__( 'Post Title Color', 'cleanwp' ), 'section' => 'colors', 'settings' => 'cleanwp_options[post_headings_color]' ) ) );

	$wp_customize->add_setting( 'cleanwp_options[post_headings_hover_color]', array( 'default' => '#444444', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'sanitize_hex_color' ) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleanwp_post_headings_hover_color_control', array( 'label' => esc_html__( 'Post Title Hover Color', 'cleanwp' ), 'section' => 'colors', 'settings' => 'cleanwp_options[post_headings_hover_color]' ) ) );

	$wp_customize->add_setting( 'cleanwp_options[sidebar_headings_color]', array( 'default' => '#000000', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'sanitize_hex_color' ) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleanwp_sidebar_headings_color_control', array( 'label' => esc_html__( 'Sidebar Widget Title Color', 'cleanwp' ), 'section' => 'colors', 'settings' => 'cleanwp_options[sidebar_headings_color]' ) ) );

	$wp_customize->add_setting( 'cleanwp_options[sidebar_text_color]', array( 'default' => '#555555', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'sanitize_hex_color' ) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleanwp_sidebar_text_color_control', array( 'label' => esc_html__( 'Sidebar Text Color', 'cleanwp' ), 'section' => 'colors', 'settings' => 'cleanwp_options[sidebar_text_color]' ) ) );

	$wp_customize->add_setting( 'cleanwp_options[sidebar_link_color]', array( 'default' => '#333333', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'sanitize_hex_color' ) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleanwp_sidebar_link_color_control', array( 'label' => esc_html__( 'Sidebar Link Color', 'cleanwp' ), 'section' => 'colors', 'settings' => 'cleanwp_options[sidebar_link_color]' ) ) );

	$wp_customize->add_setting( 'cleanwp_options[sidebar_link_hover_color]', array( 'default' => '#777777', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'sanitize_hex_color' ) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleanwp_sidebar_link_hover_color_control', array( 'label' => esc_html__( 'Sidebar Link Hover Color', 'cleanwp' ), 'section' => 'colors', 'settings' => 'cleanwp_options[sidebar_link_hover_color]' ) ) );

	$wp_customize->add_setting( 'cleanwp_options[footer_headings_color]', array( 'default' => '#ffffff', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'sanitize_hex_color' ) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleanwp_footer_headings_color_control', array( 'label' => esc_html__( 'Footer Widget Title Color', 'cleanwp' ), 'section' => 'colors', 'settings' => 'cleanwp_options[footer_headings_color]' ) ) );

	$wp_customize->add_setting( 'cleanwp_options[footer_text_color]', array( 'default' => '#666666', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'sanitize_hex_color' ) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleanwp_footer_text_color_control', array( 'label' => esc_html__( 'Footer Text Color', 'cleanwp' ), 'section' => 'colors', 'settings' => 'cleanwp_options[footer_text_color]' ) ) );

	$wp_customize->add_setting( 'cleanwp_options[footer_link_color]', array( 'default' => '#666666', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'sanitize_hex_color' ) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleanwp_footer_link_color_control', array( 'label' => esc_html__( 'Footer Link Color', 'cleanwp' ), 'section' => 'colors', 'settings' => 'cleanwp_options[footer_link_color]' ) ) );

	$wp_customize->add_setting( 'cleanwp_options[footer_link_hover_color]', array( 'default' => '#222222', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'sanitize_hex_color' ) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleanwp_footer_link_hover_color_control', array( 'label' => esc_html__( 'Footer Link Hover Color', 'cleanwp' ), 'section' => 'colors', 'settings' => 'cleanwp_options[footer_link_hover_color]' ) ) );

	$wp_customize->add_setting( 'cleanwp_options[main_border_color]', array( 'default' => '#dddddd', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'sanitize_hex_color' ) );

	$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'cleanwp_main_border_color_control', array( 'label' => esc_html__( 'Main Border Color', 'cleanwp' ), 'section' => 'colors', 'settings' => 'cleanwp_options[main_border_color]' ) ) );

	$wp_customize->add_section( 'sc_cleanwp_posts', array( 'title' => esc_html__( 'Post Options', 'cleanwp' ), 'panel' => 'cleanwp_main_options_panel', 'priority' => 260 ) );

	$wp_customize->add_setting( 'cleanwp_options[hide_posted_date]', array( 'default' => false, 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'cleanwp_sanitize_checkbox', ) );

	$wp_customize->add_control( 'cleanwp_hide_posted_date_control', array( 'label' => esc_html__( 'Hide Posted Date', 'cleanwp' ), 'section' => 'sc_cleanwp_posts', 'settings' => 'cleanwp_options[hide_posted_date]', 'type' => 'checkbox', ) );

	$wp_customize->add_setting( 'cleanwp_options[hide_post_author]', array( 'default' => false, 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'cleanwp_sanitize_checkbox', ) );

	$wp_customize->add_control( 'cleanwp_hide_post_author_control', array( 'label' => esc_html__( 'Hide Post Author', 'cleanwp' ), 'section' => 'sc_cleanwp_posts', 'settings' => 'cleanwp_options[hide_post_author]', 'type' => 'checkbox', ) );

	$wp_customize->add_setting( 'cleanwp_options[hide_post_categories]', array( 'default' => false, 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'cleanwp_sanitize_checkbox', ) );

	$wp_customize->add_control( 'cleanwp_hide_post_categories_control', array( 'label' => esc_html__( 'Hide Post Categories', 'cleanwp' ), 'section' => 'sc_cleanwp_posts', 'settings' => 'cleanwp_options[hide_post_categories]', 'type' => 'checkbox', ) );

	$wp_customize->add_setting( 'cleanwp_options[hide_post_tags]', array( 'default' => false, 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'cleanwp_sanitize_checkbox', ) );

	$wp_customize->add_control( 'cleanwp_hide_post_tags_control', array( 'label' => esc_html__( 'Hide Post Tags', 'cleanwp' ), 'section' => 'sc_cleanwp_posts', 'settings' => 'cleanwp_options[hide_post_tags]', 'type' => 'checkbox', ) );

	$wp_customize->add_setting( 'cleanwp_options[hide_comments_link]', array( 'default' => false, 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'cleanwp_sanitize_checkbox', ) );

	$wp_customize->add_control( 'cleanwp_hide_comments_link_control', array( 'label' => esc_html__( 'Hide Comment Link', 'cleanwp' ), 'section' => 'sc_cleanwp_posts', 'settings' => 'cleanwp_options[hide_comments_link]', 'type' => 'checkbox', ) );

	$wp_customize->add_setting( 'cleanwp_options[hide_thumbnail]', array( 'default' => false, 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'cleanwp_sanitize_checkbox', ) );

	$wp_customize->add_control( 'cleanwp_hide_thumbnail_control', array( 'label' => esc_html__( 'Hide Thumbnails from Every Page', 'cleanwp' ), 'section' => 'sc_cleanwp_posts', 'settings' => 'cleanwp_options[hide_thumbnail]', 'type' => 'checkbox', ) );

	$wp_customize->add_setting( 'cleanwp_options[hide_thumbnail_single]', array( 'default' => false, 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'cleanwp_sanitize_checkbox', ) );

	$wp_customize->add_control( 'cleanwp_hide_thumbnail_single_control', array( 'label' => esc_html__( 'Hide Thumbnails from Posts/Pages', 'cleanwp' ), 'section' => 'sc_cleanwp_posts', 'settings' => 'cleanwp_options[hide_thumbnail_single]', 'type' => 'checkbox', ) );

	$wp_customize->add_setting( 'cleanwp_options[hide_read_more_button]', array( 'default' => false, 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'cleanwp_sanitize_checkbox', ) );

	$wp_customize->add_control( 'cleanwp_hide_read_more_button_control', array( 'label' => esc_html__( 'Hide Read More Button', 'cleanwp' ), 'section' => 'sc_cleanwp_posts', 'settings' => 'cleanwp_options[hide_read_more_button]', 'type' => 'checkbox', ) );

	$wp_customize->add_setting( 'cleanwp_options[thumbnail_link]', array( 'default' => 'yes', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'cleanwp_sanitize_thumbnail_link' ) );

	$wp_customize->add_control( 'cleanwp_thumbnail_link_control', array( 'label' => esc_html__( 'Thumbnail Link', 'cleanwp' ), 'description' => __('Do you want thumbnails to be linked to their post?', 'cleanwp'), 'section' => 'sc_cleanwp_posts', 'settings' => 'cleanwp_options[thumbnail_link]', 'type' => 'select', 'choices' => array( 'yes' => __('Yes', 'cleanwp'), 'no' => __('No', 'cleanwp') ) ) );

	$wp_customize->add_setting( 'cleanwp_options[blogpoststyle]', array( 'default' => 'excerpt', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'cleanwp_sanitize_blogpost_style' ) );

	$wp_customize->add_control( 'cleanwp_blogpoststyle_control', array( 'label' => esc_html__( 'Post Content', 'cleanwp' ), 'description' => __('<b>Show content</b> will show the whole post content while <b>show excerpt</b> will only show the first few lines', 'cleanwp'), 'section' => 'sc_cleanwp_posts', 'settings' => 'cleanwp_options[blogpoststyle]', 'type' => 'select', 'choices' => array( 'excerpt' => __('Show excerpt', 'cleanwp'), 'content' => __('Show content', 'cleanwp') ) ) );

	$wp_customize->add_setting( 'cleanwp_options[read_more_text]', array( 'default' => 'Read More', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'sanitize_text_field', ) );

	$wp_customize->add_control( 'cleanwp_read_more_text_control', array( 'label' => esc_html__( 'Read More Text', 'cleanwp' ), 'section' => 'sc_cleanwp_posts', 'settings' => 'cleanwp_options[read_more_text]', 'type' => 'text', ) );

	$wp_customize->add_section( 'sc_cleanwp_sitelogo', array( 'title' => esc_html__( 'Site Logo', 'cleanwp' ), 'panel' => 'cleanwp_main_options_panel', 'priority' => 30 ) );

	$wp_customize->add_setting( 'cleanwp_options[sitelogo]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'cleanwp_sitelogo_control', array( 'label' => esc_html__( 'Upload a Logo', 'cleanwp' ), 'description' => 'Upload a logo to your site header.', 'section' => 'sc_cleanwp_sitelogo', 'settings' => 'cleanwp_options[sitelogo]', 'type' => 'image', 'priority' => 1 ) ) );

	$wp_customize->add_section( 'sc_cleanwp_sociallinks', array( 'title' => esc_html__( 'Social Links', 'cleanwp' ), 'panel' => 'cleanwp_main_options_panel', 'priority' => 480, ));
    
	$wp_customize->add_setting( 'cleanwp_options[hide_social_buttons]', array( 'default' => false, 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'cleanwp_sanitize_checkbox', ) );

	$wp_customize->add_control( 'cleanwp_hide_social_buttons_control', array( 'label' => esc_html__( 'Hide Social Buttons', 'cleanwp' ), 'section' => 'sc_cleanwp_sociallinks', 'settings' => 'cleanwp_options[hide_social_buttons]', 'type' => 'checkbox', ) );
	
	$wp_customize->add_setting( 'cleanwp_options[facebooklink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

	$wp_customize->add_control( 'cleanwp_facebooklink_control', array( 'label' => esc_html__( 'Facebook URL', 'cleanwp' ), 'section' => 'sc_cleanwp_sociallinks', 'settings' => 'cleanwp_options[facebooklink]', 'type' => 'text' ) );

	$wp_customize->add_setting( 'cleanwp_options[twitterlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

	$wp_customize->add_control( 'cleanwp_twitterlink_control', array( 'label' => esc_html__( 'Twitter URL', 'cleanwp' ), 'section' => 'sc_cleanwp_sociallinks', 'settings' => 'cleanwp_options[twitterlink]', 'type' => 'text' ) );

	$wp_customize->add_setting( 'cleanwp_options[googlelink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) ); 

	$wp_customize->add_control( 'cleanwp_googlelink_control', array( 'label' => esc_html__( 'Google Plus URL', 'cleanwp' ), 'section' => 'sc_cleanwp_sociallinks', 'settings' => 'cleanwp_options[googlelink]', 'type' => 'text' ) );

	$wp_customize->add_setting( 'cleanwp_options[pinterestlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

	$wp_customize->add_control( 'cleanwp_pinterestlink_control', array( 'label' => esc_html__( 'Pinterest URL', 'cleanwp' ), 'section' => 'sc_cleanwp_sociallinks', 'settings' => 'cleanwp_options[pinterestlink]', 'type' => 'text' ) );
	
	$wp_customize->add_setting( 'cleanwp_options[linkedinlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

	$wp_customize->add_control( 'cleanwp_linkedinlink_control', array( 'label' => esc_html__( 'Linkedin Link', 'cleanwp' ), 'section' => 'sc_cleanwp_sociallinks', 'settings' => 'cleanwp_options[linkedinlink]', 'type' => 'text' ) );
	
	$wp_customize->add_setting( 'cleanwp_options[instagramlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

	$wp_customize->add_control( 'cleanwp_instagramlink_control', array( 'label' => esc_html__( 'Instagram Link', 'cleanwp' ), 'section' => 'sc_cleanwp_sociallinks', 'settings' => 'cleanwp_options[instagramlink]', 'type' => 'text' ) );
	
	$wp_customize->add_setting( 'cleanwp_options[flickrlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

	$wp_customize->add_control( 'cleanwp_flickrlink_control', array( 'label' => esc_html__( 'Flickr Link', 'cleanwp' ), 'section' => 'sc_cleanwp_sociallinks', 'settings' => 'cleanwp_options[flickrlink]', 'type' => 'text' ) );

	$wp_customize->add_setting( 'cleanwp_options[youtubelink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

	$wp_customize->add_control( 'cleanwp_youtubelink_control', array( 'label' => esc_html__( 'Youtube URL', 'cleanwp' ), 'section' => 'sc_cleanwp_sociallinks', 'settings' => 'cleanwp_options[youtubelink]', 'type' => 'text' ) );
	
	$wp_customize->add_setting( 'cleanwp_options[vimeolink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

	$wp_customize->add_control( 'cleanwp_vimeolink_control', array( 'label' => esc_html__( 'Vimeo URL', 'cleanwp' ), 'section' => 'sc_cleanwp_sociallinks', 'settings' => 'cleanwp_options[vimeolink]', 'type' => 'text' ) );
	
	$wp_customize->add_setting( 'cleanwp_options[soundcloudlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

	$wp_customize->add_control( 'cleanwp_soundcloudlink_control', array( 'label' => esc_html__( 'Soundcloud URL', 'cleanwp' ), 'section' => 'sc_cleanwp_sociallinks', 'settings' => 'cleanwp_options[soundcloudlink]', 'type' => 'text' ) );
	
	$wp_customize->add_setting( 'cleanwp_options[lastfmlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

	$wp_customize->add_control( 'cleanwp_lastfmlink_control', array( 'label' => esc_html__( 'Lastfm URL', 'cleanwp' ), 'section' => 'sc_cleanwp_sociallinks', 'settings' => 'cleanwp_options[lastfmlink]', 'type' => 'text' ) );
	
	$wp_customize->add_setting( 'cleanwp_options[githublink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

	$wp_customize->add_control( 'cleanwp_githublink_control', array( 'label' => esc_html__( 'Github URL', 'cleanwp' ), 'section' => 'sc_cleanwp_sociallinks', 'settings' => 'cleanwp_options[githublink]', 'type' => 'text' ) );
	
	$wp_customize->add_setting( 'cleanwp_options[bitbucketlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

	$wp_customize->add_control( 'cleanwp_bitbucketlink_control', array( 'label' => esc_html__( 'Bitbucket URL', 'cleanwp' ), 'section' => 'sc_cleanwp_sociallinks', 'settings' => 'cleanwp_options[bitbucketlink]', 'type' => 'text' ) );
	
	$wp_customize->add_setting( 'cleanwp_options[tumblrlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

	$wp_customize->add_control( 'cleanwp_tumblrlink_control', array( 'label' => esc_html__( 'Tumblr URL', 'cleanwp' ), 'section' => 'sc_cleanwp_sociallinks', 'settings' => 'cleanwp_options[tumblrlink]', 'type' => 'text' ) );
	
	$wp_customize->add_setting( 'cleanwp_options[digglink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

	$wp_customize->add_control( 'cleanwp_digglink_control', array( 'label' => esc_html__( 'Digg URL', 'cleanwp' ), 'section' => 'sc_cleanwp_sociallinks', 'settings' => 'cleanwp_options[digglink]', 'type' => 'text' ) );
	
	$wp_customize->add_setting( 'cleanwp_options[deliciouslink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

	$wp_customize->add_control( 'cleanwp_deliciouslink_control', array( 'label' => esc_html__( 'Delicious URL', 'cleanwp' ), 'section' => 'sc_cleanwp_sociallinks', 'settings' => 'cleanwp_options[deliciouslink]', 'type' => 'text' ) );

	$wp_customize->add_setting( 'cleanwp_options[stumblelink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

	$wp_customize->add_control( 'cleanwp_stumblelink_control', array( 'label' => esc_html__( 'Stumbleupon Link', 'cleanwp' ), 'section' => 'sc_cleanwp_sociallinks', 'settings' => 'cleanwp_options[stumblelink]', 'type' => 'text' ) );
	
	$wp_customize->add_setting( 'cleanwp_options[redditlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

	$wp_customize->add_control( 'cleanwp_redditlink_control', array( 'label' => esc_html__( 'Reddit Link', 'cleanwp' ), 'section' => 'sc_cleanwp_sociallinks', 'settings' => 'cleanwp_options[redditlink]', 'type' => 'text' ) );
	
	$wp_customize->add_setting( 'cleanwp_options[dribbblelink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

	$wp_customize->add_control( 'cleanwp_dribbblelink_control', array( 'label' => esc_html__( 'Dribbble Link', 'cleanwp' ), 'section' => 'sc_cleanwp_sociallinks', 'settings' => 'cleanwp_options[dribbblelink]', 'type' => 'text' ) );
	
	$wp_customize->add_setting( 'cleanwp_options[behancelink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

	$wp_customize->add_control( 'cleanwp_behancelink_control', array( 'label' => esc_html__( 'Behance Link', 'cleanwp' ), 'section' => 'sc_cleanwp_sociallinks', 'settings' => 'cleanwp_options[behancelink]', 'type' => 'text' ) );
	
	$wp_customize->add_setting( 'cleanwp_options[codepenlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

	$wp_customize->add_control( 'cleanwp_codepenlink_control', array( 'label' => esc_html__( 'Codepen Link', 'cleanwp' ), 'section' => 'sc_cleanwp_sociallinks', 'settings' => 'cleanwp_options[codepenlink]', 'type' => 'text' ) );
	
	$wp_customize->add_setting( 'cleanwp_options[jsfiddlelink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

	$wp_customize->add_control( 'cleanwp_jsfiddlelink_control', array( 'label' => esc_html__( 'JSFiddle Link', 'cleanwp' ), 'section' => 'sc_cleanwp_sociallinks', 'settings' => 'cleanwp_options[jsfiddlelink]', 'type' => 'text' ) );
	
	$wp_customize->add_setting( 'cleanwp_options[stackoverflowlink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

	$wp_customize->add_control( 'cleanwp_stackoverflowlink_control', array( 'label' => esc_html__( 'Stack Overflow Link', 'cleanwp' ), 'section' => 'sc_cleanwp_sociallinks', 'settings' => 'cleanwp_options[stackoverflowlink]', 'type' => 'text' ) );
	
	$wp_customize->add_setting( 'cleanwp_options[stackexchangelink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

	$wp_customize->add_control( 'cleanwp_stackexchangelink_control', array( 'label' => esc_html__( 'Stack Exchange Link', 'cleanwp' ), 'section' => 'sc_cleanwp_sociallinks', 'settings' => 'cleanwp_options[stackexchangelink]', 'type' => 'text' ) );
	
	$wp_customize->add_setting( 'cleanwp_options[bsalink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

	$wp_customize->add_control( 'cleanwp_bsalink_control', array( 'label' => esc_html__( 'BuySellAds Link', 'cleanwp' ), 'section' => 'sc_cleanwp_sociallinks', 'settings' => 'cleanwp_options[bsalink]', 'type' => 'text' ) );
	
	$wp_customize->add_setting( 'cleanwp_options[slidesharelink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

	$wp_customize->add_control( 'cleanwp_slidesharelink_control', array( 'label' => esc_html__( 'SlideShare Link', 'cleanwp' ), 'section' => 'sc_cleanwp_sociallinks', 'settings' => 'cleanwp_options[slidesharelink]', 'type' => 'text' ) );
	
	$wp_customize->add_setting( 'cleanwp_options[skypeusername]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'cleanwp_sanitize_text' ) );

	$wp_customize->add_control( 'cleanwp_skypeusername_control', array( 'label' => esc_html__( 'Skype Username', 'cleanwp' ), 'section' => 'sc_cleanwp_sociallinks', 'settings' => 'cleanwp_options[skypeusername]', 'type' => 'text' ) );
	
	$wp_customize->add_setting( 'cleanwp_options[emailaddress]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'cleanwp_sanitize_email' ) );

	$wp_customize->add_control( 'cleanwp_emailaddress_control', array( 'label' => esc_html__( 'Email Address', 'cleanwp' ), 'section' => 'sc_cleanwp_sociallinks', 'settings' => 'cleanwp_options[emailaddress]', 'type' => 'text' ) );

	$wp_customize->add_setting( 'cleanwp_options[rsslink]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'esc_url_raw' ) );

	$wp_customize->add_control( 'cleanwp_rsslink_control', array( 'label' => esc_html__( 'RSS Feed URL', 'cleanwp' ), 'section' => 'sc_cleanwp_sociallinks', 'settings' => 'cleanwp_options[rsslink]', 'type' => 'text' ) );
	
    
	$wp_customize->add_section( 'sc_cleanwp_footer', array( 'title' => esc_html__( 'Footer', 'cleanwp' ), 'panel' => 'cleanwp_main_options_panel', 'priority' => 440 ) );

	$wp_customize->add_setting( 'cleanwp_options[footer_text]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'cleanwp_sanitize_text', ) );

	$wp_customize->add_control( 'cleanwp_footer_text_control', array( 'label' => esc_html__( 'Footer copyright notice', 'cleanwp' ), 'section' => 'sc_cleanwp_footer', 'settings' => 'cleanwp_options[footer_text]', 'type' => 'text', ) );
	
	$wp_customize->add_section( 'sc_cleanwp_customcss', array( 'title' => esc_html__( 'Custom CSS', 'cleanwp' ), 'panel' => 'cleanwp_main_options_panel', 'priority' => 560 ) );

	$wp_customize->add_setting( 'cleanwp_options[customcss]', array( 'default' => '', 'type' => 'option', 'capability' => 'edit_theme_options', 'sanitize_callback' => 'wp_filter_nohtml_kses', ) );

	$wp_customize->add_control( 'cleanwp_customcss_control', array( 'label' => esc_html__( 'Custom CSS Codes', 'cleanwp' ), 'description' => esc_html__( 'Use this option only if you are compatible with CSS styling. Any bad input here can ruin the entire look of your theme. You can put your custom CSS styles into below textarea.', 'cleanwp' ), 'section' => 'sc_cleanwp_customcss', 'settings' => 'cleanwp_options[customcss]', 'type' => 'textarea', ) );

	$wp_customize->add_section( 'sc_cleanwp_upgrade', array( 'title' => esc_html__( 'Upgrade to Pro', 'cleanwp' ), 'priority' => 140 ) );
	
	$wp_customize->add_setting( 'cleanwp_options[upgrade_text]', array( 'default' => '', 'sanitize_callback' => '__return_false', ) );
	
	$wp_customize->add_control( new CleanWP_Customize_Static_Text_Control( $wp_customize, 'cleanwp_upgrade_text_control', array(
		'label'       => esc_html__( 'CleanWP Pro', 'cleanwp' ),
		'section'     => 'sc_cleanwp_upgrade',
		'settings' => 'cleanwp_options[upgrade_text]',
		'description' => array(
			esc_html__( 'Do you enjoy CleanWP? Upgrade to CleanWP Pro now and get:', 'cleanwp' ),
			'<ul>' .
				'<li>' . esc_html__( 'Font Options', 'cleanwp' ) . '</li>' .
				'<li>' . esc_html__( 'Layout Options', 'cleanwp' ) . '</li>' .
				'<li>' . esc_html__( 'Search Engine Optimized', 'cleanwp' ) . '</li>' .
				'<li>' . esc_html__( 'WooCommerce Support', 'cleanwp' ) . '</li>' .
				'<li>' . esc_html__( 'More Customizer options', 'cleanwp' ) . '</li>' .
			'</ul>',
			'<a href="'.CLEANWP_PROURL.'" class="customizer-prolink customizer-proupgrade" target="_blank">' . esc_html__( 'Upgrade To Pro', 'cleanwp' ) . '</a>',
			'<a href="'.CLEANWP_CONTACTURL.'" class="customizer-prolink customizer-prodoc" target="_blank">' . esc_html__( 'Contact Us', 'cleanwp' ) . '</a>'
		),
	) ) );	

}

function cleanwp_sanitize_checkbox( $input ) {
    if ( $input == 1 ) {
        return 1;
    } else {
        return '';
    }
}
function cleanwp_sanitize_text( $input ) {
    return wp_kses_post( force_balance_tags( $input ) );
}
function cleanwp_sanitize_thumbnail_link( $input ) {
    $valid = array('yes','no');
    if ( in_array( $input, $valid ) ) {
        return $input;
    } else {
        return '';
    }
}
function cleanwp_sanitize_blogpost_style( $input ) {
    $valid = array('excerpt','content');
    if ( in_array( $input, $valid ) ) {
        return $input;
    } else {
        return '';
    }
}
function cleanwp_sanitize_email( $input ) {

	if ( '' != $input && is_email( $input ) ) {
		$input = sanitize_email( $input );
	} else {
		$input = '';
    }
	return $input;
}

add_action( 'customize_register', 'cleanwp_register_theme_customizer' );

function cleanwp_customizer_js_scripts() {	
	wp_enqueue_script('cleanwp-theme-customizer-js', get_template_directory_uri() . '/admin/js/customizer.js', array( 'jquery', 'customize-preview' ), NULL, true);
}
add_action( 'customize_preview_init', 'cleanwp_customizer_js_scripts' );
?>