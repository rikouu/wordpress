<?php get_header(); ?>
<div id="roll"><div title="回到顶部" id="roll_top"></div><div title="转到底部" id="fall"></div></div>
<div id="content">
                <div class="content_l">
                  	<?php if (have_posts()) : ?>
	<?php while (have_posts()) : the_post(); ?>
		<div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
<div class="left">
<div class="post_date"><span class="date_m"><?php echo date('M',get_the_time('U'));?></span><span class="date_d"><?php the_time('d') ?></span><span class="date_y"><?php the_time('Y') ?></span></div>
<div class="article">
<div class="article_t">
<div class="article_b"><h2><a href="<?php the_permalink() ?>" rel="bookmark" title="详细阅读 <?php the_title_attribute(); ?>"><?php the_title(); ?></a><span class="new"><?php include('includes/new.php'); ?></span></h2>
<div class="thumbnail_box">
						<?php include('includes/thumbnail.php'); ?>
					</div>
<div class="entry_post"><?php
    if(is_singular()){the_content();}else{
    $pc=$post->post_content;
    $st=strip_tags(apply_filters('the_content',$pc));
    if(has_excerpt())
        the_excerpt();
    elseif(preg_match('/<!--more.*?-->/',$pc) || mb_strwidth($st)<300)
        the_content('');
    elseif(function_exists('mb_strimwidth'))
        echo'<p>'
        .mb_strimwidth($st,0,300,' ...')
        .'</p>';
    else the_content();
}?></div>
<p class="more_b"><span class="more"><a href="<?php the_permalink() ?>" title="详细阅读 <?php the_title(); ?>" rel="bookmark">阅读全文...</a></span></p><div class="clear"></div>
</div>
<div class="article_f">
<div class="article_info"><span class="author">&nbsp;&nbsp;&nbsp;&nbsp;<?php the_author() ?></span><span class="category">&nbsp;&nbsp;&nbsp;&nbsp;<?php the_category(', ') ?></span><span class="post_comm">&nbsp;&nbsp;&nbsp;&nbsp;<?php comments_popup_link ('抢沙发','1条评论','%条评论'); ?></span><span class="post_view">&nbsp;&nbsp;&nbsp;&nbsp;<?php if(function_exists(the_views)) { the_views(' 次阅读', true);}?></span><span class="tags">&nbsp;&nbsp;&nbsp;&nbsp;<?php the_tags('', ', ', ''); ?></span></div>
</div></div>
</div>       
       </div>

		</div>
		<?php endwhile; ?>
		<?php endif; ?> 
<div class="navigation"><?php pagination($query_string); ?></div>
</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>
