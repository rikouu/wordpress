<?php
/*
Template Name: Guestbook
*/
?>
<?php get_header(); ?>
<div id="roll"><div title="回到顶部" id="roll_top"></div><div title="查看评论" id="ct"></div><div title="转到底部" id="fall"></div></div>
<div id="content">

                <div class="content_l"><?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="left">
<div class="post_date"><span class="date_m"><?php echo date('M',get_the_time('U'));?></span><span class="date_d"><?php the_time('d') ?></span><span class="date_y"><?php the_time('Y') ?></span></div>
<div class="article">
<div class="article_t">
<div class="article_b"><h2 style="color:#f00">灌水先锋队</h2>



<div class="v_comment"><ul>
			<?php
				$query="SELECT COUNT(comment_ID) AS cnt, comment_author, comment_author_url, comment_author_email FROM (SELECT * FROM $wpdb->comments LEFT OUTER JOIN $wpdb->posts ON ($wpdb->posts.ID=$wpdb->comments.comment_post_ID) WHERE comment_date > date_sub( NOW(), INTERVAL 3 MONTH ) AND user_id='0' AND comment_author_email != '' AND post_password='' AND comment_approved='1' AND comment_type='') AS tempcmt GROUP BY comment_author_email ORDER BY cnt DESC LIMIT 39";
				$wall = $wpdb->get_results($query);
				foreach ($wall as $comment)
				{
					if( $comment->comment_author_url )
					$url = $comment->comment_author_url;
					else $url="#";
					$r="rel='external nofollow'";
					$tmp = "<li class='mostactive'><a href='".$url."' '".$r."' title='".$comment->comment_author." (留下".$comment->cnt."个脚印)'>".get_avatar($comment->comment_author_email, 40)."</a></li>";
					$output .= $tmp;
				}
				echo $output ;
			?></ul>
</div>

<p class="clear"></p>
<p>&nbsp;</p>
<p>欢迎大家多多灌水，有访必回！</p>
</div>
<div class="article_ff">
</div></div>
</div></div>

<div class="left">
<div class="article">
<div class="article_t">
<div class="article_b">
<?php comments_template(); ?>

</div>
<div class="article_ff">
</div></div>
</div></div>
	<?php endwhile; else: ?>
	<?php endif; ?>
</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>