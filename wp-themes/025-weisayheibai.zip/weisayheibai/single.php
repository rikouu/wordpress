<?php get_header(); ?>
<div id="roll"><div title="回到顶部" id="roll_top"></div><div title="查看评论" id="ct"></div><div title="转到底部" id="fall"></div></div>
<div id="content">

                <div class="content_l"><?php if (have_posts()) : while (have_posts()) : the_post(); ?>
<div class="left">
<div class="post_date"><span class="date_m"><?php echo date('M',get_the_time('U'));?></span><span class="date_d"><?php the_time('d') ?></span><span class="date_y"><?php the_time('Y') ?></span></div>
<div class="article">
<div class="article_t">
<div class="article_b"><h2><?php the_title(); ?></h2>
<div class="info">
		<span><img src="<?php bloginfo('template_directory'); ?>/images/meta_author.png" alt="作者" title="作者" /> <?php the_author() ?></span>
		<span><img src="<?php bloginfo('template_directory'); ?>/images/meta_date.png" alt="发布时间" title="发布时间" /> <?php the_time('Y-m-d H:i') ?></span>
		<span><img src="<?php bloginfo('template_directory'); ?>/images/meta_categories.png" alt="文章分类" title="文章分类" /> <?php the_category(', ') ?></span>
        <span><img src="<?php bloginfo('template_directory'); ?>/images/meta_comments.png" alt="文章评论" title="文章评论" /> <?php comments_popup_link ('抢沙发','1条评论','%条评论'); ?></span>
		<span><img src="<?php bloginfo('template_directory'); ?>/images/meta_views.png" alt="阅读次数" title="阅读次数" /> <?php if(function_exists(the_views)) { the_views(' 次阅读', true);}?></span>
		<span><?php edit_post_link('编辑', ' [ ', ' ] '); ?></span>
						</div>
        <div class="context"><?php the_content('Read more...'); ?></div>
<p>本文固定链接: <a href="<?php the_permalink() ?>" rel="bookmark" title="<?php the_title(); ?>"><?php the_permalink() ?> | <?php bloginfo('name');?></a></p>
</div>
<div class="article_ff">
</div></div>
</div></div>

<div class="left">
<div class="article">
<div class="article_t">
<div class="article_b">
<div class="author_pic">
					<a href="#" title="<?php the_author_description(); ?>"><?php echo get_avatar( get_the_author_email(), '48' ); ?></a>
				</div>
<div class="author_text">
			<span class="spostinfo">
				该日志由 <?php the_author_posts_link(); ?> 于<?php the_time('Y年m月d日') ?>发表在 <?php the_category(', ') ?> 分类下，
				<?php if (('open' == $post-> comment_status) && ('open' == $post->ping_status)) {?>
				你可以<a href="#respond">发表评论</a>，并在保留<a href="<?php the_permalink() ?>" rel="bookmark">原文地址</a>及作者的情况下<a href="<?php trackback_url(); ?>" rel="trackback">引用</a>到你的网站或博客。
				<?php } elseif (('open' == $post-> comment_status) && !('open' == $post->ping_status)) { ?>
				通告目前不可用，你可以至底部留下评论。
				<?php } ?><br/>
				原创文章转载请注明: <a href="<?php the_permalink() ?>" rel="bookmark" title="本文固定链接 <?php the_permalink() ?>"><?php the_title(); ?> | <?php bloginfo('name');?></a><br/>
				<?php the_tags('关键字: ', ', ', ''); ?>
			</span>
				</div><div class="clear"></div>
</div>
<div class="article_ff">
</div></div>
</div></div>

<div class="left">
<div class="article">
<div class="article_t">
<div class="article_b"><?php previous_post_link('【上一篇】%link') ?><br/><?php next_post_link('【下一篇】%link') ?>
</div>
<div class="article_ff">
</div></div>
</div></div>

<div class="left">
<div class="article">
<div class="article_t">
<div class="article_b"><?php include('includes/related.php'); ?>
<div class="clear"></div>
</div>
<div class="article_ff">
</div></div>
</div></div>

<div class="left">
<div class="article">
<div class="article_t">
<div class="article_b">
<?php comments_template(); ?>

</div>
<div class="article_ff">
</div></div>
</div></div>

	<?php endwhile; else: ?>
	<?php endif; ?>
</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>