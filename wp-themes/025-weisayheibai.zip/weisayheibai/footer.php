<div class="clear"></div>
   <div class="footer">
Copyright <?php echo comicpress_copyright(); ?> <?php bloginfo('name'); ?> All rights reserved. Powered by <a href="http://www.wordpress.org/" rel="external">WordPress</a>. Theme by <a href="http://www.weisay.com/">Weisay</a>. 
        <?php if (get_option('swt_beian') == 'Display') { ?><a href="http://www.miitbeian.gov.cn/" rel="external"><?php echo stripslashes(get_option('swt_beianhao')); ?></a><?php { echo ''; } ?><?php } else { } ?> <?php if (get_option('swt_tj') == 'Display') { ?><?php echo stripslashes(get_option('swt_tjcode')); ?><?php { echo ''; } ?>
	<?php } else { } ?><?php wp_footer(); ?>
    <div class="clear"></div>
  </div>
</div>
</body>
</html>