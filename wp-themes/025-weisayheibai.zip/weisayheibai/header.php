<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
<?php include('includes/seo.php'); ?>
<link rel="stylesheet" type="text/css" href="<?php bloginfo('template_directory'); ?>/style.css?ver=1.3" />
<link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>" />
<link rel="alternate" type="application/atom+xml" title="<?php bloginfo('name'); ?> Atom Feed" href="<?php bloginfo('atom_url'); ?>" />
<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
<link rel="shortcut icon" href="<?php bloginfo('template_directory'); ?>/images/favicon.ico" type="image/x-icon" />
<?php if (function_exists('wp_enqueue_script') && function_exists('is_singular')) : ?>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/jquery.min.js"></script>
<?php wp_head(); ?>
<?php if ( is_singular() ){ ?>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/comments-ajax.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/realgravatar.js"></script>
<?php } ?>
<?php endif; ?>
<script type="text/javascript" src="<?php bloginfo('template_directory'); ?>/js/weisay.js"></script>
<?php include('includes/lazyload.php'); ?>
</head>

<body>
<div id="page">
<div id="header">
<div class="topnav">
<?php wp_nav_menu( array( 'theme_location' => 'topmenu' ) ); ?>
</div>
<div class="open-follow">
<table class="rss">
  <tr>
    <td><?php if (get_option('swt_mailqq') == 'Display') { ?><a href="http://mail.qq.com/cgi-bin/feed?u=<?php bloginfo('rss2_url'); ?>" target="_blank" class="icon4" title="用QQ邮箱阅读空间订阅我的博客"></a><?php { echo ''; } ?><?php } else { } ?></td>
    <td><?php if (get_option('swt_tsina') == 'Display') { ?><a href="<?php echo stripslashes(get_option('swt_tsinaurl')); ?>" target="_blank" class="icon3" title="我的新浪微博"></a><?php { echo ''; } ?><?php } else { } ?></td>
    <td><?php if (get_option('swt_tqq') == 'Display') { ?><a href="<?php echo stripslashes(get_option('swt_tqqurl')); ?>" target="_blank" class="icon2" title="我的腾讯微博"></a><?php { echo ''; } ?><?php } else { } ?></td>
    <td><a href="<?php bloginfo('rss2_url'); ?>" target="_blank" class="icon1" title="欢迎订阅<?php bloginfo('name'); ?>"></a></td>
    <td><div class="search">
              <form method="get" id="searchform" action="<?php bloginfo('url'); ?>/">
                <fieldset id="search">
                  <span>
                  <input value="" onclick="this.value='';" name="s" id="s" type="text" />
                  <input name="searchsubmit" src="<?php bloginfo('template_directory'); ?>/images/gg.png" value="Go" id="searchsubmit" class="btn" type="image" />
                  </span>
                </fieldset>
              </form>
            </div></td>
  </tr>
</table>
				</div>
                <div class="clear"></div>
	<div id="blogname"><a href="<?php echo get_option('home'); ?>/"><?php bloginfo('name'); ?></a>
    <div id="blogtitle"><?php bloginfo('description'); ?></div></div>    
<div class="pagemenu"><?php wp_nav_menu( array( 'theme_location' => 'headermenu' ) ); ?></div>
                </div>