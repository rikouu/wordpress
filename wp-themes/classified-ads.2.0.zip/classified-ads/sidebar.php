	<?php if ( ! is_active_sidebar( 'Sidebar' ) ) {
		return;
	}
	?>

	<aside secondary" class="widget-area" role="complementary">
			<ul>	
				<?php if ( ! dynamic_sidebar('Sidebar') ) : ?><?php endif; ?>
			</ul>
	</aside>