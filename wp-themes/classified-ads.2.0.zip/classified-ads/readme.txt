=== Seos Classified Ads ===
Contributors: SEOS - Tsvetomir Tsvetanov
Tags: one-column, two-columns, left-sidebar, grid-layout, flexible-header, custom-background, custom-header, custom-logo, custom-menu, custom-colors, editor-style, featured-image-header, featured-images, full-width-template, post-formats, rtl-language-support, sticky-post, theme-options, threaded-comments, translation-ready, blog, e-commerce, education, entertainment, food-and-drink, holiday, news, photography, portfolio
Requires at least: 4.1
Tested up to: 4.1
Stable tag: 4.1

== Description ==

* Responsive Layout
* Custom Colors
* Custom Header
* Custom Background

== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the Add New button.
2. Click Upload and Choose File, then select the theme's ZIP file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= How do I change the color scheme? =

You can change the colors of your site easily using Seos Classified Ads Premium

1. In your admin panel, go to Appearance -> Customize.
4. Now you will see the Customizer and a tab called 'Colors'. Click this tab.
5. You can now change your color scheme by selecting one of the predefined ones. Choose a color scheme you want from Base Color Scheme dropdown. You can preview the change in the Customizer.



