<?php

/**
 * @author William Sergio Minossi
 * @copyright 2017
 */

echo '<div id="boatdealer-freebies-page">';

        
echo '<div class="boatdealer-block-title">'; 
echo 'Freebies';
echo '</div>';

echo'<br />';
echo'<br />';

echo '<img alt="aux" src="'.get_template_directory_uri().'/images/freebies.png" width="220px" />';

?>

<div id="freebies-tab">
    <div class="freebies-row">
    <?php echo  '<img class="freebies-tab-icon" alt="aux" src="'.get_template_directory_uri().'/images/download-2.png"  />';?>
    <a class="freebies-tab-link" href="https://wordpress.org/plugins/antihacker/">Anti Hacker Plugin</a>
    </div>
    <div class="freebies-row"> 
    <?php echo  '<img class="freebies-tab-icon" alt="aux" src="'.get_template_directory_uri().'/images/download-2.png"  />';?>
    <a class="freebies-tab-link" href="https://wordpress.org/plugins/stopbadbots/">Stop Bad Bots Plugin</a>
    </div> 
    <div class="freebies-row">
    <?php echo  '<img class="freebies-tab-icon" alt="aux" src="'.get_template_directory_uri().'/images/download-2.png"  />';?>
    <a class="freebies-tab-link" href="https://wordpress.org/plugins/reportattacks/">Report Attacks Plugin</a>
    </div> 

    <div class="freebies-row">
    <?php echo  '<img class="freebies-tab-icon" alt="aux" src="'.get_template_directory_uri().'/images/download-2.png"  />';?>
    <a class="freebies-tab-link" href="https://wordpress.org/themes/fordummies/">Theme For Dummies</a>
    </div>
    <div class="freebies-row"> 
    <?php echo  '<img class="freebies-tab-icon" alt="aux" src="'.get_template_directory_uri().'/images/download-2.png"  />';?>
    <a class="freebies-tab-link" href="https://wordpress.org/themes/verticalmenu/">Theme Vertical Menu</a>
    </div> 
 

    

<br />

</div>

</div>




