<?php

class Bill_Vote6 {
	function __construct() {
		add_action( 'admin_menu', array( __CLASS__, 'init' ) );
		add_action( 'wp_ajax_bill_vote',  array( __CLASS__, 'vote' ) );
	}
	public static function init() {
		$vote = get_option( 'bill_vote' );
        //$vote = '';
        // die('vote: '.$vote);
        // yes
		$timeout = time() > ( get_option( 'bill_installed' ) + 60*60*24*3 );
		if ( in_array( $vote, array( 'yes', 'no', 'tweet' ) ) || !$timeout ) return;
		add_action( 'in_admin_footer', array( __CLASS__, 'message' ) );
		add_action( 'admin_head',      array( __CLASS__, 'register' ) );
		add_action( 'admin_footer',    array( __CLASS__, 'enqueue' ) );
	}
	public static function register() {
	    wp_enqueue_style( 'bill-vote' , BOATDEALERURL.'/css/feedback.css');
    	wp_register_script( 'bill-vote',BOATDEALERURL.'/js/feedback.js' , array( 'jquery' ), BOATDEALERVERSION, true );
	}
	public static function enqueue() {
		wp_enqueue_style( 'bill-vote' );
		wp_enqueue_script( 'bill-vote' );
	}
	public static function vote() {
		$vote = sanitize_key( $_GET['vote'] );
		if ( !is_user_logged_in() || !in_array( $vote, array( 'yes', 'no', 'later' ) ) ) die( 'error' );
		update_option( 'bill_vote', $vote );
		if ( $vote === 'later' ) update_option( 'bill_installed', time() );
		die( 'OK: ' . $vote );
	}
	public static function message() {
?>
		<div class="bill-vote" style="display:none">
			<div class="bill-vote-wrap">
				<div class="bill-vote-gravatar"><a href="http://profiles.wordpress.org/sminozzi" target="_blank"><img src="https://en.gravatar.com/userimage/94727241/31b8438335a13018a1f52661de469b60.jpg?size=100" alt="<?php _e( 'Bill Minozzi', 'boatdealer' ); ?>" width="70" height="70"></a></div>
				<div class="bill-vote-message">
					<p>
                    <?php _e( 'Hello, my name is Bill Minozzi, and I am developer of Theme <b>Boat Dealer</b>.<br>', 'boatdealer' ); 
                          _e( 'If you like this theme, please write a few words about it. It will help other people find this useful theme more quickly.<br><b>Thank you!</b>', 'boatdealer' ); ?></p>
					<p>
						<a href="<?php echo admin_url( 'admin-ajax.php' ); ?>?action=bill_vote&amp;vote=yes" class="bill-vote-action button button-medium button-primary" data-action="http://boatdealerthemes.com/share/"><?php _e( 'Rate or Share', 'boatdealer' ); ?></a>
						<a href="<?php echo admin_url( 'admin-ajax.php' ); ?>?action=bill_vote&amp;vote=no" class="bill-vote-action button button-medium"><?php _e( 'No, dismiss', 'boatdealer' ); ?></a>
						<span><?php _e( 'or', 'boatdealer' ); ?></span>
						<a href="<?php echo admin_url( 'admin-ajax.php' ); ?>?action=bill_vote&amp;vote=later" class="bill-vote-action button button-medium"><?php _e( 'Remind me later', 'boatdealer' ); ?></a>
					</p>
				</div>
				<div class="bill-vote-clear"></div>
			</div>
		</div>
		<?php
	}
}
new Bill_Vote6;
