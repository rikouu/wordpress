<?php
/**
 * @author William Sergio Minossi
 * @copyright 2017
 */
 
  $host_name = trim(strip_tags($_SERVER['HTTP_HOST']));
  $host_name = strtolower($host_name);
  if(isset($_COOKIE["bill_activated_vm"]))
     {
        
      $mycookie = $_COOKIE["bill_activated_vm"];
      $pieces = explode("-", $mycookie);
      $cookie_domain = strip_tags(trim($pieces[1]));
      $activated = '';
          if(! empty($cookie_domain))
          {
            $pos = strpos($cookie_domain,$host_name);
            if( $pos !== false)
              $activated = strip_tags($pieces[0]);
          }
        if($activated == '0' or $activated == '1' )
        {
            if ( get_option( 'boatdealer_optin' ) !== false ) {
                // The option already exists, so we just update it.
                update_option( 'boatdealer_optin', $activated );
            } else {
                // The option hasn't been added yet. We'll add it with $autoload set to 'no'.
                add_option( 'boatdealer_optin', $activated );
            }
        }
       @setcookie("bill_activated_vm", "", time() - 3600);  
     } // Cookie exist
     else
     {
           if ( get_option( 'boatdealer_optin' ) !== false ) {
                $activated =  get_option('boatdealer_optin', '') ;
            } 
     }
     
if(! isset($activated)) 
     $activated = '';
     
     
     
// $activated = '';
 
     
        
  if($activated == '')
  {
 	wp_register_script( 'bill-feedback13',BOATDEALERURL.'/js/activated-manager.js' , array( 'jquery' ), BOATDEALERVERSION, true );
    wp_enqueue_style( 'bill-activated', get_template_directory_uri() . '/css/feedback.css', array( 'boatdealer-style' ), '20170321' );
	wp_enqueue_script( 'bill-feedback13' );
    $wpversion = get_bloginfo('version');
    $current_user = wp_get_current_user();
    $plugin = plugin_basename(__FILE__); 
    $email = $current_user->user_email;
    $username =  trim($current_user->user_firstname);
    $user = $current_user->user_login;
    $user_display = trim($current_user->display_name);
    if(empty($username))
       $username = $user;
    if(empty($username))
       $username = $user_display;
    $theme = wp_get_theme( );
    $themeversion = $theme->version ;
    $memory['limit'] = (int) ini_get('memory_limit') ;	
    $memory['usage'] = function_exists('memory_get_usage') ? round(memory_get_usage() / 1024 / 1024, 0) : 0;
    if(defined("WP_MEMORY_LIMIT"))
                $memory['wplimit'] =  WP_MEMORY_LIMIT ;
            else
                 $memory['wplimit'] = '';
  ?>
  <div class="bill-activ-boatdealer" style="display:none">
              <div class="bill-vote-gravatar"><a href="http://profiles.wordpress.org/sminozzi" target="_blank"><img src="https://en.gravatar.com/userimage/94727241/31b8438335a13018a1f52661de469b60.jpg?size=100" alt="Bill Minozzi" width="70" height="70"></a></div>
		    	<div class="bill-vote-message">
                 <h4>Hey  <?php echo strtoupper($username);?></h4>
                 <br />
                 <?php _e("Hi, my name is Bill Minozzi, and I am developer of theme boatdealer.","boatdealer");?>
                 <br />
                 Please help us improve our theme Boat Dealer.
                 If you opt-in, some not sensitive data about your usage of the theme
                 will be sent to us just one time. If you skip this, that's okay! Boat Dealer
                 will still work just fine. 
                 <br /><br />             
                 <strong><?php _e("Thank You!","boatdealer");?></strong>
                 <br /><br /> 
                 <br /><br /> 			
		    			<a href="#" class="button button-primary boatdealer-button-close-submit"><?php _e("Yes, Submit","boatdealer");?></a>
                        <img alt="aux" src="/wp-admin/images/wpspin_light-2x.gif" id="imagewait" style="display:none" />
		    			<a href="#" class="button button-Secondary boatdealer-button-close-dialog"><?php _e("Skip","boatdealer");?></a>
                        <input type="hidden" id="version" name="version" value="<?php echo $themeversion;?>" />
		                <input type="hidden" id="email" name="email" value="<?php echo $email;?>" />
		                <input type="hidden" id="username" name="username" value="<?php echo $username;?>" />
		                <input type="hidden" id="produto" name="produto" value="boatdealer" />
		                <input type="hidden" id="wpversion" name="wpversion" value="<?php echo $wpversion;?>" />
		                <input type="hidden" id="limit" name="limit" value="<?php echo $memory['limit'];?>" />
		                <input type="hidden" id="wplimit" name="wplimit" value="<?php echo $memory['wplimit'];?>" />
   		                <input type="hidden" id="usage" name="usage" value="<?php echo $memory['usage'];?>" />
                 <br /><br />
               </div>
    </div>
  <?php  
  }  
?>