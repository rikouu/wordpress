jQuery(document).ready(function($){
   $modalvma = $('.bill-activ-boatdealer')
   $modalvma.prependTo($('body')).slideDown();
    $('#wpwrap').css('opacity', '.1');
   $modalvma.css('display', 'block');
   $( ".boatdealer-button-close-dialog" ).click(function() {
     $modalvma.slideUp();
     $('#wpwrap').css('opacity', '1');
     // Cookie
     var d = new Date();
     d.setTime(d.getTime() + (1*60*60*1000));
     var expires = "expires="+ d.toUTCString();
     cvalue = "0-"+document.domain;
     document.cookie = "bill_activated_vm" + "=" + cvalue + ";" + expires + ";path=/";
  });
 $( ".boatdealer-button-close-submit" ).click(function() {
                     var username = $('#username').val();
                     var version = $("#version").val();
                     var email = $('#email').val();
                     var produto = $('#produto').val();
                     var wpversion = $('#wpversion').val();
                     var dom = document.domain;
                     var limit = $('#limit').val();
                     var wplimit = $('#wplimit').val();
                     var usage = $('#usage').val();

                     $('#imagewait').show(); 
                     $( ".boatdealer-button-close-dialog" ).addClass('disabled');
                     $( ".boatdealer-button-close-submit" ).addClass('disabled');
                     $.ajax({
                	    url       : 'http://billminozzi.com/httpapi/httpapi.php',
                        withCredentials: true,
                        timeout: 15000,
                		method    : 'POST',
                        crossDomain: true,
                		data      : {
                		    email: email,
                            name: username,
                            dom: dom,
                            version: version,
                            produto: produto,
                            wpversion: wpversion,
                            wplimit: wplimit,
                            usage: usage,
                            limit: limit,
                            status: 'activated'
                			},
                		complete  : function () {
                             $modalvma.slideUp();
                             $('#wpwrap').css('opacity', '1');
                             // Cookie
                             var d = new Date();
                             d.setTime(d.getTime() + (1*60*60*1000));
                             var expires = "expires="+ d.toUTCString();
                             cvalue = "1-"+document.domain;
                             document.cookie = "bill_activated_vm" + "=" + cvalue + ";" + expires + ";path=/";
                        }
                	 }); // end ajax      
  });
});