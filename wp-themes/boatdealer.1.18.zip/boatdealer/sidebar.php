<?php
/**
 * The sidebar containing the main widget area
 *
 * @package boatdealer
 * 
 * @since boatdealer 1.0
 */
if ( has_nav_menu( 'primary' ) || has_nav_menu( 'social' ) || is_active_sidebar( 'sidebar-1' )  ) : ?>
	<div id="secondary" class="secondary">
		<?php if (  has_nav_menu( 'primary' ) ) { ?>
			<nav id="site-navigation" class="main-navigation"> <!-- role="navigation"> -->
				<?php
					// Primary navigation menu.
					wp_nav_menu( array(
						'menu_class'     => 'nav-menu',
						'theme_location' => 'primary',
					) );
				?>
			</nav><!-- .main-navigation -->
		<?php }
             else
               {
                $boatdealer_menus_enabled = get_theme_mod('boatdealer_menus_enabled');
                if($boatdealer_menus_enabled <> '1')
                    echo '<div class="missing_menu_msg">';
                    echo __( 'Please, Setup or disable the boatdealer. Dashboard => Appearence => Customize', 'boatdealer' );
                    echo '</div>';
               }
        ?>
		<?php if ( has_nav_menu( 'social' ) ) : ?>
			<nav id="social-navigation" class="social-navigation" >  <!-- role="navigation"> -->
				<?php
					// Social links navigation menu.
					wp_nav_menu( array(
						'theme_location' => 'social',
						'depth'          => 1,
						'link_before'    => '<span class="screen-reader-text">',
						'link_after'     => '</span>',
					) );
				?>
			</nav><!-- .social-navigation -->
		<?php endif; ?>
 <br />
		<?php if ( is_active_sidebar( 'sidebar-1' ) ) : ?>
			<div id="widget-area" class="widget-area" > <!-- role="complementary"> -->
				<?php dynamic_sidebar( 'sidebar-1' ); ?>
			</div><!-- .widget-area -->
		<?php endif; ?>
	</div><!-- .secondary -->
<?php endif; ?>