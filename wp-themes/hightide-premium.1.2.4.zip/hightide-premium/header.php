<?php
/**
 * The header template file.
 * @package HighTide
 * @since HighTide 1.0.0
*/
?><!DOCTYPE html>
<!--[if IE 7]>
<html class="ie ie7" <?php language_attributes(); ?>>
<![endif]-->
<!--[if IE 8]>
<html class="ie ie8" <?php language_attributes(); ?>>
<![endif]-->
<!--[if !(IE 7) | !(IE 8)  ]><!-->
<html <?php language_attributes(); ?>>
<!--<![endif]-->
<head>
<?php global $hightide_options;
foreach ($hightide_options as $value) {
	if (isset($value['id']) && get_option( $value['id'] ) === FALSE && isset($value['std'])) {
		$$value['id'] = $value['std'];
	}
	elseif (isset($value['id'])) { $$value['id'] = get_option( $value['id'] ); }
} ?>
  <meta charset="<?php bloginfo( 'charset' ); ?>" /> 
  <meta name="viewport" content="width=device-width" />  
<?php if ( ! function_exists( '_wp_render_title_tag' ) ) { ?><title><?php wp_title( '|', true, 'right' ); ?></title><?php } ?>  
  <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
<?php if ($hightide_favicon_url != ''){ ?>
	<link rel="shortcut icon" href="<?php echo esc_url($hightide_favicon_url); ?>" />
<?php } ?>
<?php wp_head(); ?> 
<?php if ($hightide_own_javascript_header != ''){ ?>
<?php echo stripslashes_deep($hightide_own_javascript_header); ?>
<?php } ?>  
</head>
 
<body <?php body_class(); ?> id="wrapper">
<?php if ( $hightide_display_background_pattern != 'Hide' ) { ?>
<div class="pattern"></div> 
<?php } ?> 
<div id="container">
  <header id="header">
    <div class="header-content">
<?php if ( $hightide_logo_url == '' ) { ?>
      <p class="site-title"><a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a></p>
<?php } else { ?>
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><img class="header-logo" src="<?php echo esc_url($hightide_logo_url); ?>" alt="<?php bloginfo( 'name' ); ?>" /></a>
<?php } ?>
<?php if ( $hightide_display_site_description != 'Hide' ) { ?>
      <p class="site-description"><?php bloginfo( 'description' ); ?></p>
<?php } ?>
    </div>
<?php if ( has_nav_menu( 'main-navigation' ) && !is_page_template('template-landing-page.php') ) { ?>
    <div class="menu-box">
<?php wp_nav_menu( array( 'menu_id'=>'nav', 'theme_location'=>'main-navigation' ) ); ?>
    </div>
<?php } ?>
<?php if ( is_home() || is_front_page() ) { ?>
<?php if ( dynamic_sidebar( 'sidebar-7' ) ) : else : ?>
<?php if ( get_header_image() != '' ) { ?>    
    <div class="header-image"><img src="<?php header_image(); ?>" alt="<?php bloginfo( 'name' ); ?>" /></div>
<?php } ?>
<?php endif; ?>
<?php } else { ?>
<?php if ( get_header_image() != '' && $hightide_display_header_image != 'Only on Homepage' ) { ?>    
    <div class="header-image"><img src="<?php header_image(); ?>" alt="<?php bloginfo( 'name' ); ?>" /></div>
<?php } ?>
<?php } ?>
  </header> <!-- end of header -->