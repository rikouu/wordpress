<?php
/**
 * The archive template file.
 * @package HighTide
 * @since HighTide 1.0.0
*/
get_header(); ?>
<?php if ( have_posts() ) : ?>
  <div class="content-headline">
    <h1><?php if ( is_day() ) :
						printf( __( 'Daily Archive: %s', 'hightide' ), '<span>' . get_the_date() . '</span>' );
					elseif ( is_month() ) :
						printf( __( 'Monthly Archive: %s', 'hightide' ), '<span>' . get_the_date( _x( 'F Y', 'monthly archives date format', 'hightide' ) ) . '</span>' );
					elseif ( is_year() ) :
						printf( __( 'Yearly Archive: %s', 'hightide' ), '<span>' . get_the_date( _x( 'Y', 'yearly archives date format', 'hightide' ) ) . '</span>' );
					else :
						_e( 'Archive', 'hightide' );
					endif ;?></h1>
<?php hightide_get_breadcrumb(); ?>
  </div>
  <div id="main-content">
  <div id="content">
<?php while (have_posts()) : the_post(); ?>      
<?php get_template_part( 'content', 'archives' ); ?>
<?php endwhile; endif; ?>
<?php hightide_content_nav( 'nav-below' ); ?> 
  </div> <!-- end of content -->
<?php get_sidebar(); ?>
  </div> <!-- end of main-content -->
<?php get_footer(); ?>