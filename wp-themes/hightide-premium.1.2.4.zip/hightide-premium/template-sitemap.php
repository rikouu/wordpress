<?php
/**
 * Template Name: Sitemap
 * The sitemap page template file.
 * @package HighTide
 * @since HighTide 1.0.0
*/
get_header(); ?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
  <div class="content-headline">
    <h1><?php the_title(); ?></h1>
<?php hightide_get_breadcrumb(); ?>
  </div>
  <div id="main-content">
  <div id="content">
<?php hightide_get_display_image_page(); ?>
    <div class="entry-content">
<?php the_content(); ?>
<?php if ( function_exists('ddsg_create_sitemap') ) { echo ddsg_create_sitemap(); } ?>
<?php edit_post_link(); ?>
<?php endwhile; endif; ?>
    </div> 
  </div> <!-- end of content -->
<?php get_sidebar(); ?>
  </div> <!-- end of main-content -->
<?php get_footer(); ?>