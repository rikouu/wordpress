<?php
/**
 * Template Name: Logged In
 * The template file for displaying the page content only for logged in users.
 * @package HighTide
 * @since HighTide 1.0.4
*/
get_header(); ?>
<?php if ( is_user_logged_in() ) { ?>
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
  <div class="content-headline">
    <h1><?php the_title(); ?></h1>
<?php hightide_get_breadcrumb(); ?>
  </div>
  <div id="main-content">
  <div id="content">
<?php hightide_get_display_image_page(); ?>
    <div class="entry-content">
<?php the_content(); ?>
<?php wp_link_pages( array( 'before' => '<p class="page-link"><span>' . __( 'Pages:', 'hightide' ) . '</span>', 'after' => '</p>' ) ); ?>
<?php edit_post_link(); ?>
<?php endwhile; endif; ?>
<?php hightide_social_buttons_page(); ?>
<?php comments_template( '', true ); ?>
<?php } else { ?>
  <div class="content-headline">
    <h1><?php the_title(); ?></h1>
<?php hightide_get_breadcrumb(); ?>
  </div>
  <div id="main-content">
  <div id="content">
    <div class="entry-content">
  <p class="logged-in-message"><?php _e( 'You must be logged in to view this page.', 'hightide' ); ?></p>
<?php wp_login_form(); } ?>
    </div> 
  </div> <!-- end of content -->
<?php get_sidebar(); ?>
  </div> <!-- end of main-content -->
<?php get_footer(); ?>