/* Responsive.js v1.0 */
selectnav('nav');