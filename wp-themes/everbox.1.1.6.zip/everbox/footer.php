<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after
 *
 * @package EverBox
 */
?>
			</div>
			<!-- END .site-content -->
		</div>
		<!-- END .container-fluid -->
	</div>
	<!-- END #page -->
	<?php wp_footer(); ?>
</body>
</html>
