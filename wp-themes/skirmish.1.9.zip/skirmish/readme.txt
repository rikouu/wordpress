= Skirmish
* by Blank Themes, http://blankthemes.com/

== Credits ==
Skirmish is a derivative of _s ("Underscores") WordPress Theme, Copyright 2012 Automattic, Inc.
This theme, like WordPress, is licensed under the GPL.
Use it to make something cool, have fun, and share what you've learned with others.

== Changelog ==

=1.8 
* Re-released on BlankThemes.com. 
* GeneralThemes.com now being redirected to BlankThemes.com. 
* Updated for WordPress 3.4.

=1.7
* Fixed Chrome content width bug.

= 1.6
* Minor adjustments.

= 1.5
* Rebuilt using the _s theme. Fully responsive.

= 1.0
* Initial Release.