<?php if (!is_search()) {
		$search_text = "搜索";
	} else {
		$search_text = "$s";
	}
?>

<form method="get" id="searchform" action="<?php bloginfo('url'); ?>/">
	<input type="text" tabindex="3"  value="<?php echo wp_specialchars($search_text, 1); ?>" class="input_blogger_search" name="s" id="s"
		 onfocus="if (this.value == '搜索') {this.value = '';}" onblur="if (this.value == '') {this.value = '搜索';}">
	<input type="button" value="找找看" class="search_btn" id="searchsubmit" value="Search" >
</form>
