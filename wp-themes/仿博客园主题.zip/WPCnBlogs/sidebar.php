
<div id="side_nav"> 
	<div id="cate_title_block">   
		<div id="cate_title_title"><div class="cate_title"><?php _e('Categories'); ?></div></div>
		<ul id="cate_item">
			<?php wp_list_cats('sort_column=name&optioncount=1&hide_empty=1'); ?>
		</ul>
	<div class="cate_bottom"></div>
</div>

<div class="l_s"></div>
<p class="r_l_3"></p><p class="r_l_2"></p><p class="r_l_1"></p>

<div class="w_l">
	<h4><?php _e('Links'); ?></h4>
	<ul>
		<?php get_links('-1', '<li>· ', '</li>', '<br />', FALSE, 'id', FALSE, FALSE, -1, FALSE); ?>
	</ul>
</div>

<p class="r_l_1"></p><p class="r_l_2"></p><p class="r_l_3"></p>
<div class="l_s"></div>

<!--专题-->
<p class="r_l_3"></p><p class="r_l_2"></p><p class="r_l_1"></p>
<div class="w_l">
	<h4><?php _e('Archives'); ?></h4>
	<ul>
		<?php wp_get_archives('type=monthly'); ?>
	</ul>
</div>
<p class="r_l_1"></p><p class="r_l_2"></p><p class="r_l_3"></p>
<div class="l_s"></div>

<!--小工具1-->
<p class="r_l_3"></p><p class="r_l_2"></p><p class="r_l_1"></p>
<div class="w_l">
	<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('小工具1') ) : ?>
	<?php endif; ?>
</div>
<p class="r_l_1"></p><p class="r_l_2"></p><p class="r_l_3"></p>
<div class="l_s"></div>

<p class="r_l_3"></p><p class="r_l_2"></p><p class="r_l_1"></p>
<div class="w_l">
	<h4><?php _e('Meta'); ?></h4>
	<div id="blogger_list">
		<ul>
			<?php wp_register(); ?>
			<li><?php wp_loginout(); ?></li>
			<li><a href="http://validator.w3.org/check/referer" title="This page validates as XHTML 1.0 Transitional">Valid <abbr title="eXtensible HyperText Markup Language">XHTML</abbr></a></li>
			<li><a href="http://gmpg.org/xfn/"><abbr title="XHTML Friends Network">XFN</abbr></a></li>
			<li><a href="http://wordpress.org/" title="Powered by WordPress, state-of-the-art semantic personal publishing platform.">WordPress</a></li>
		</ul>
	</div>
</div>
<p class="r_l_1"></p><p class="r_l_2"></p><p class="r_l_3"></p>
<div class="l_s"></div>

<p class="r_l_3"></p><p class="r_l_2"></p><p class="r_l_1"></p>

<div class="w_l">

	<h4>友情链接</h4>

	<ul>
		<!--如愿意支持我们请保留链接，如不愿意请删掉，谢谢！-->
		<li><a href="http://www.syet.net" target="_blank">三叶草博客</a></li>
		<li><a href="http://www.zxlive.net" target="_blank">漂无痕</a></li>
		<li><a href="http://v7v3.com" target="_blank">wordpress主题</a></li>

	</ul>

</div>

<p class="r_l_1"></p><p class="r_l_2"></p><p class="r_l_3"></p>

<div class="l_s"></div>


<p class="r_l_3"></p><p class="r_l_2"></p><p class="r_l_1"></p>
<div class="w_l">
	<h4>统计信息</h4>
	<div id="site_stats">
		<ul>
			<li>日志总数：<span><?php $count_posts = wp_count_posts(); echo $published_posts = $count_posts->publish;?>篇</span></li>
			<li>评论总数：<span><?php echo $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->comments");?>条</span></li>
			<li>分类总数：<span><?php echo $count_categories = wp_count_terms('category'); ?>个</span></li>
			<li>标签总数：<span><?php echo $count_tags = wp_count_terms('post_tag'); ?>个</span></li>
			<li>友情链接：<span><?php $link = $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->links WHERE link_visible = 'Y'"); echo $link; ?>个</span></li>
			<li>网站运行：<span><?php echo floor((time()-strtotime("2010-12-06"))/86400); ?>天</span></li><!--"2010-12-06"改成你实际的网站上线时间-->
		</ul>
	</div>      
</div>
<p class="r_l_1"></p><p class="r_l_2"></p><p class="r_l_3"></p>
</div><!-- #left sidebar -->

<?php include('sidebar_r.php'); ?>
