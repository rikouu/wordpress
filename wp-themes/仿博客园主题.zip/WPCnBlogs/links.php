<?php
/*
Template Name: 友情链接
*/
?>
<?php get_header(); ?>

<?php get_sidebar(); ?>

<div id="content">
	<div class="post_nav_block_wrapper">
		<ul class="post_nav_block">
			<li><a <?php if ( is_home() && !(isset($_GET['order']))) echo 'class="current_nav"'; ?> href="<?php echo get_settings('home'); ?>">首页</a></li>
			<li><a <?php if ( isset($_GET['order']) && ($_GET['order']=='commented') ) echo 'class="current_nav"'; ?> href="<?php echo get_settings('home'); ?>?order=commented">热门文章</a></li>
			<li><a <?php if ( isset($_GET['order']) && ($_GET['order']=='rand') ) echo 'class="current_nav"'; ?> href="<?php echo get_settings('home'); ?>?order=rand">随便看看</a></li>
			<li><a class="current_nav" href="<?php echo curPageURL()?>"><?php the_title(); ?></a></li>
		</ul>
		<div id="feed"><a href="<?php bloginfo('rss2_url'); ?>" title="RSS">RSS</a></div>
		<div class="clear"></div>
    </div>
	<div class="link_page">
		<div class="link_head"><h2>不分先后，随机排序</h2></div>
		<div class="link-content">
		<?php
			$bookmarks = get_bookmarks('categorize=0&category=0&before=<span>&after=</span>&show_images=1&show_description=0&orderby=url');
			if ( !empty($bookmarks) ) {
				foreach ($bookmarks as $bookmark) {
					echo '<span class="links"><a href="' . $bookmark->link_url . '" title="' . $bookmark->link_description . '" target="_blank" >' .	$bookmark->link_name . '</a></span>';
				}
			} 
		?>
		<div class="clear"></div>
	</div>
</div><!-- #content -->

<?php get_footer(); ?>
