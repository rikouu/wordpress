<div id="side_right">
	<div id="blogger_search">
		<?php include (TEMPLATEPATH . '/searchform.php'); ?>
	</div>

	<div class="w_r">
		<div id="calendar_wrap">
			<?php get_calendar(); ?>
		</div>
	</div>
	
	<div class="w_r">
		<h4><?php _e('Recent Posts'); ?></h4>
		<ul>
			<?php get_archives('postbypost', '10', 'custom', '<li>', '</li>'); ?>
		</ul>
	</div>

	<div class="w_r">
		<h4>热门标签</h4>
		<div id="tag-cloud"><?php wp_tag_cloud('smallest=12&largest=12&unit=px&number=45');?></div>
	</div>

	<div class="w_r">
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('小工具2') ) : ?>
		<?php endif; ?>
	</div>

</div>