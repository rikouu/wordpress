<?php get_header(); ?>

<?php get_sidebar(); ?>

<div id="content">
	<div class="post_nav_block_wrapper">
		<ul class="post_nav_block">
			<li><a <?php if ( is_home() && !(isset($_GET['order']))) echo 'class="current_nav"'; ?> href="<?php echo get_settings('home'); ?>">首页</a></li>
			<li><a <?php if ( isset($_GET['order']) && ($_GET['order']=='commented') ) echo 'class="current_nav"'; ?> href="<?php echo get_settings('home'); ?>?order=commented">热门文章</a></li>
			<li><a <?php if ( isset($_GET['order']) && ($_GET['order']=='rand') ) echo 'class="current_nav"'; ?> href="<?php echo get_settings('home'); ?>?order=rand">随便看看</a></li>
			<li><a class="current_nav" href="#">未知页面</a></li>
		</ul>
		<div id="feed"><a href="<?php bloginfo('rss2_url'); ?>" title="RSS">RSS</a></div>
		<div class="clear"></div>
    </div>
	<!-- end: menu -->
	<div class="entry_box_s">
		 <div class="entry">
 			<div class="error">
 				 <h2>对不起！您找的文章可能已删除!</h2>
 			</div>
 		  </div>
		<div class="clear"></div>
		<!-- end: entry -->
	</div>
</div>
<?php get_footer(); ?>
