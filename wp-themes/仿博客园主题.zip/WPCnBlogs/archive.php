<?php get_header(); ?>

<?php get_sidebar(); ?>

<div id="content">
	<!-- menu -->
	<div class="post_nav_block_wrapper">
		<ul class="post_nav_block">
			<li><a <?php if ( is_home() && !(isset($_GET['order']))) echo 'class="current_nav"'; ?> href="<?php echo get_settings('home'); ?>">首页</a></li>
			<li><a <?php if ( isset($_GET['order']) && ($_GET['order']=='commented') ) echo 'class="current_nav"'; ?> href="<?php echo get_settings('home'); ?>?order=commented">热门文章</a></li>
			<li><a <?php if ( isset($_GET['order']) && ($_GET['order']=='rand') ) echo 'class="current_nav"'; ?> href="<?php echo get_settings('home'); ?>?order=rand">随便看看</a></li>
			<li><a href="<?php echo curPageURL()?>" class="current_nav">
				<?php if (have_posts()) : ?>                
				<?php $post = $posts[0]; ?>
				<?php if (is_category()) { ?>所有属于<?php single_cat_title(); ?>分类文章
				<?php } elseif( is_tag() ) { ?>所有关于<?php single_tag_title(); ?>的文章
				<?php } elseif (is_day()) { ?><?php the_time('Y年m月'); ?>发表的文章
				<?php } elseif (is_month()) { ?>所有<?php the_time('Y年m月'); ?>文章
				<?php } elseif (is_year()) { ?>Archive for <?php the_time('Y'); ?>
				<?php } elseif (is_author()) { ?><?php wp_title( '');?>发表的所有文章
				<?php } elseif (isset($_GET['paged']) && !empty($_GET['paged'])) { ?>
				<h1>Blog Archives</h1>
				<?php } ?>
				<?php endif; ?></a>
			</li>
		</ul> 
		<div id="feed"><a href="<?php bloginfo('rss2_url'); ?>" title="RSS">RSS</a></div>
		<div class="clear"></div>
    </div>
	<!-- end: menu -->
	<div class="navigation"><?php pagination($query_string); ?></div>
    <div class="clear"></div>
 	<!-- end: navigation -->
 	<!-- archive_box -->
	<div id="post-list">
	<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	<div class="post_item">
		<div class="indexdate">
			<div class="postdate">
				<span class="postday"><?php the_time('d') ?></span>
				<span class="postyear"><?php the_time('m') ?>/<?php the_time('y') ?></span>
			</div>
			<div class="clear"></div>
		</div>
		<div class="post_item_body">
			<h3><a href="<?php the_permalink() ?>" class="titlelnk" title="<?php the_title(); ?>"><?php the_title(); ?></a></h3>
			<p class="post_item_summary">
				<?php if (has_excerpt()){ the_excerpt() ;
					}else{
						echo mb_strimwidth(strip_tags(apply_filters('the_content', $post->post_content)), 0, 480,"...");
					}?>
			</p>
			<div class="post_item_foot">
				<span class="postdate_icon">&nbsp;<?php echo date("Y-m-d H:i",get_the_time('U')); ?></span>
				<span class="category"><?php the_category(', ') ?></span>
				<span class="article_comment"><?php comments_popup_link('暂无评论', '评论(1)', '评论(%)'); ?></span>
				<?php if(function_exists('the_views')){ print ' <span class="article_view grayline">阅读(<span>'; the_views(); print '</span>)</span>';   } ?>
			</div>
			<div class="clear"></div>
		</div>
	</div>
 	<!-- end: box_archive --> 
	<?php endwhile;  else: ?>
	<?php endif; ?>
	</div>
 	<!-- navigation -->
    <div class="navigation_b"><?php pagination($query_string); ?></div>
 	<!-- end: navigation -->
	<div class="clear"></div>
</div>
<!-- end: content -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>
