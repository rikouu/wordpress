/* Kratos Javascript Plus */
