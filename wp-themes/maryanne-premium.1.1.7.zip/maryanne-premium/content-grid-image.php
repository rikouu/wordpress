<?php
/**
 * The template for displaying content of Grid Post entries as Grid - Masonry.
 * @package MaryAnne
 * @since MaryAnne 1.0.0
*/
?>
      <article <?php post_class('grid-entry'); ?>>
      <div class="grid-entry-inner">
        <a href="<?php echo get_permalink(); ?>" title="<?php the_title(); ?>"><?php if ( has_post_thumbnail() ) { the_post_thumbnail(); } else {
echo '<img class="attachment-post-thumbnail" src="';
echo maryanne_catch_that_image();
echo '" alt="';
echo the_title();
echo '" />';
} ?></a>
      </div>
      </article>