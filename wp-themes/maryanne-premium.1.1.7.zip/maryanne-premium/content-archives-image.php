<?php
/**
 * The template for displaying content of Image Post entries in the standard way.
 * @package MaryAnne
 * @since MaryAnne 1.0.0
*/
?>
      <article <?php post_class('post-entry'); ?>>
        <div class="post-entry-content-wrapper">
          <div class="post-entry-content">
            <a href="<?php echo get_permalink(); ?>" title="<?php the_title(); ?>"><?php if ( has_post_thumbnail() ) { the_post_thumbnail(); } else {
echo '<img class="attachment-post-thumbnail" src="';
echo maryanne_catch_that_image();
echo '" alt="';
echo the_title();
echo '" />';
} ?></a>
          </div>
<?php maryanne_social_buttons_post_entry(); ?>
        </div>
      </article>