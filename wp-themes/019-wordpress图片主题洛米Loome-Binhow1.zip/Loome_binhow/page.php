<?php
 get_header();;echo '<div id="content">
';if (have_posts()) : while (have_posts()) : the_post();;echo '<div id="map">
<div class="site">当前位置：<a href="';bloginfo('siteurl');;echo '/" title="返回首页">首页</a> > ';the_title();;echo '</div>
</div><div class="main">
<div class="article article_c">
<h2>';the_title();;echo '</h2>
        <div class="context">';the_content('Read more...');;echo '</div>
</div>
<div class="article article_c article_b">
';comments_template();;echo '</div>

	';endwhile;else: ;echo '	';endif;;echo '</div>

';get_sidebar();;echo '';get_footer();
?>