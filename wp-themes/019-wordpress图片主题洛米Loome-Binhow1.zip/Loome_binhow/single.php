<?php
 get_header();;echo '<div id="content">
';if (have_posts()) : while (have_posts()) : the_post();;echo '<div id="map">
<div class="site">当前位置：<a href="';bloginfo('siteurl');;echo '/" title="返回首页">首页</a> > ';$categories = get_the_category();echo(get_category_parents($categories[0]->term_id,TRUE,' > '));;echo '正文</div>
</div><div class="main">
<div class="article article_c">
<div class="tith2">';the_title();;echo'</div>';echo'<span class="h2span">';setPostViews(get_the_ID());;echo getPostViews(get_the_ID());;echo'+</span><div class="clear"></div>
<div class="article_info">作者：';the_author() ;echo ' &nbsp; 发布：';the_time('Y-m-d') ;echo ' &nbsp; 分类：';the_category(', ') 
;echo ' &nbsp; ';echo ' &nbsp; ';edit_post_link('编辑',' [ ',' ] ');;echo '</div><div class="clear"></div><div class="context">'
;echo '';the_content('Read more...');;echo '<div class="baishare"><!-- Baidu Button BEGIN -->
    <div id="bdshare" class="bdshare_t bds_tools_32 get-codes-bdshare">
        <a class="bds_tsina"></a>
		<a class="bds_qzone"></a>
        <a class="bds_tqq"></a>
		<a class="bds_renren"></a>
        <a class="bds_t163"></a>
        <a class="bds_tfh"></a>
        <a class="bds_tsohu"></a>
        <a class="bds_tuita"></a>
        <a class="bds_hi"></a>
        <a class="bds_ty"></a>
        <a class="bds_baidu"></a>
        <a class="bds_tieba"></a>
        <a class="bds_fx"></a>
        <a class="bds_diandian"></a>
        <span class="bds_more">更多</span>
    </div>
<script type="text/javascript" id="bdshare_js" data="type=tools" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
	document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + new Date().getHours();
</script>
<!-- Baidu Button END --></div></div>
</div>
<div class="article article_c">
<div id="authorarea">'
;if (function_exists('get_avatar')) { echo get_avatar( get_the_author_email(), '100' ); }
;echo'<div class="authorinfo">
<h3>About ';echo the_author_posts_link();;echo'</h3>
<p>';echo the_author_description(); ;echo'</p>
</div>
</div>
</div>
<div class="article article_c">
<ul class="pre_nex">
<li>';previous_post_link('【上一篇】%link') ;echo '</li><li>';next_post_link('【下一篇】%link') ;echo '</li></ul>
</div>

<div class="article article_c">
';include('includes/related.php');;echo '<div class="clear"></div>
</div>
<div class="article article_c article_b">
';comments_template();;echo '</div>

	';endwhile;else: ;echo '	';endif;;echo '</div>

';get_sidebar();;echo '';get_footer()
?>