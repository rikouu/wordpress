<?php
echo '<div class="clear"></div>
<div id="footer"><div class="footer-top">';echo get_option('binhow_statistics');;echo '</div>Copyright ';echo comicpress_copyright();;echo ' <a href="';bloginfo('siteurl');;echo '/"><strong>';bloginfo('name');;echo '</strong></a> All Rights Reserved<br /> Template By <a href="http://www.thems.me/" target="_blank">Thems</a> ';echo get_option('binhow_start');;echo'<br /></div>
</div>
<script type="text/javascript" src="';bloginfo('template_directory');;echo '/js/scrolltopcontrol.js"></script>
<script type="text/javascript" src="';bloginfo('template_directory');;echo '/js/binhow.js"></script>
</body>
</html>'
?>