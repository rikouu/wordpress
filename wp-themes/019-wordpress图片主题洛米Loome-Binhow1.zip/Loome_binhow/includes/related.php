<?php
echo '<div class="relatedposts">
	';
$backup = $post;
$tags = wp_get_post_tags($post->ID);
$tagIDs = array();
if ($tags) {
echo '<h3>您可能还会对这些文章感兴趣！</h3>';
echo '<ul>';
$tagcount = count($tags);
for ($i = 0;$i <$tagcount;$i++) {
$tagIDs[$i] = $tags[$i]->term_id;
}
$args=array(
'tag__in'=>$tagIDs,
'post__not_in'=>array($post->ID),
'showposts'=>16,
'caller_get_posts'=>1
);
$my_query = new WP_Query($args);
if( $my_query->have_posts() ) {
while ($my_query->have_posts()) : $my_query->the_post();;echo '			<li><a href="';the_permalink() ;echo '" rel="bookmark" title="';the_title();;echo '">';echo cut_str($post->post_title,46);;echo '';comments_number(' ','(1)','(%)');;echo '</a></li>
			';endwhile;
echo '<div class=clear></div>';
echo '</ul>';
}else {;echo '		<!-- 没有相关文章显示随机文章 -->
	<ul>
		';
query_posts(array('orderby'=>'rand','showposts'=>16,'caller_get_posts'=>4));
if (have_posts()) :
while (have_posts()) : the_post();;echo '		<li><a href="';the_permalink() ;echo '" rel="bookmark" title="Permanent Link to ';the_title();;echo '">';echo cut_str($post->post_title,46);;echo '';comments_number(' ','(1)','(%)');;echo '</a></li>
		';endwhile;endif;;echo '	<div class="clear"></div></ul>
	';}
}
$post = $backup;
wp_reset_query();
;echo '</div>';
?>