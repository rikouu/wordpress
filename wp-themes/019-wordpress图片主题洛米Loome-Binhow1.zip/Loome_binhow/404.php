<?php
echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="';bloginfo('html_type');;echo '; charset=';bloginfo('charset');;echo '" />
<title>404-';bloginfo('name');;echo '</title>
<link rel="stylesheet" type="text/css" href="';bloginfo('template_directory');;echo '/style.css" />
<link rel="alternate" type="application/rss+xml" title="';bloginfo('name');;echo ' RSS Feed" href="';bloginfo('rss2_url');;echo '" />
<link rel="alternate" type="application/atom+xml" title="';bloginfo('name');;echo ' Atom Feed" href="';bloginfo('atom_url');;echo '" />
<link rel="pingback" href="';bloginfo('pingback_url');;echo '" />
';wp_enqueue_script('jquery');;echo '';wp_head();;echo '';if ( is_singular() ){;echo '<script type="text/javascript" src="';bloginfo('template_directory');;echo '/comments-ajax.js"></script>
';};echo '<script type="text/javascript" src="';bloginfo('template_directory');;echo '/js/binhow.js"></script>
<script type="text/javascript" src="';bloginfo('template_directory');;echo '/js/scrolltopcontrol.js"></script>
';};echo '';include('includes/lazyload.php');;echo '</head>
<body>
<div id="page">
<div id="head">
<div id="header">
<div class="subpage">
<div class="toppage">
<ul>';wp_list_pages('title_li=');;echo '<li><a href="http://www.bofaziran.com/category/%E4%B8%BB%E9%A2%98/">主题</a></li>
</ul></div>
<div id="rss"><ul>
<li><a href="';bloginfo('rss2_url');;echo '" target="_blank" class="icon1" title="欢迎订阅';bloginfo('name');;echo '"></a></li>
<li><a href="';if(get_option('binhow_sbaidu')!='') echo get_option('binhow_sbaidu');else echo 'http://www.bocaiguan.com/sitemap_baidu.xml';echo '" target="_blank" class="icon5" title="百度地图"></a></li>
<li><a href="';if(get_option('binhow_tqq')!='') echo get_option('binhow_tqq');else echo 'http://t.qq.com/binhow';echo '" target="_blank" class="icon2" title="我的腾讯微博" rel="nofollow"></a></li>
<li><a href="';if(get_option('binhow_weibo')!='') echo get_option('binhow_weibo');else echo 'http://weibo.com/binhow';echo '" target="_blank" class="icon3" title="我的新浪微博" rel="nofollow"></a></li>
<li><a href="http://mail.qq.com/cgi-bin/feed?u=';bloginfo('rss2_url');;echo '" target="_blank" class="icon4" title="用QQ邮箱阅读空间订阅本站" rel="nofollow"></a></li>
<li><a href="';if(get_option('binhow_ditu')!='') echo get_option('binhow_ditu');else echo 'http://www.bocaiguan.com/sitemap.html';echo '" target="_blank" class="icon6" title="网站地图"></a></li>
</ul></div>
<div class="clear"></div>
</div>
<div class="logo">
	<div id="blogname"><h1><a href="';bloginfo('siteurl');;echo '/">';bloginfo('name');;echo '</a></h1>
    <div id="blogtitle"><h2>';bloginfo('description');;echo '</h2></div></div>
	';if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('banner') ) :
; endif;
;echo '</div>
<div class="clear"></div>
</div>
</div>
<div class="mainmenus">
<div class="mainmenu">
<div class="topnav">
';
if(function_exists('wp_nav_menu')) {
wp_nav_menu(array('theme_location'=>'primary','menu_id'=>'nav','container'=>'ul'));
}
;echo '</div>
<div class="clear"></div>
</div>
</div>
<div id="roll"><div title="回到顶部" id="roll_top"></div><div title="查看评论" id="ct"></div><div title="转到底部" id="fall"></div></div>
<div id="content">
<div id="map">
<div class="site">当前位置：<a href="';bloginfo('siteurl');;echo '/" title="返回首页">首页</a> > 未知页面</div></div><div class="main">
<div class="article article_c">
<h3>抱歉，您打开的页面未能找到。</h3><div class="context">您可以使用本站的搜索框搜索您想要的内容，如有不便深感抱歉！</div>
<div id="adsense2"></div>
</div>
</div>

';get_sidebar();;echo '';get_footer()
?>