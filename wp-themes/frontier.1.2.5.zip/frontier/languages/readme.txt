Don't add your own language files here. They will be deleted when you update the theme.
Add your translations on a child-theme language folder.
Ex. /wp-content/themes/frontier-child/languages/

http://ronangelo.com/frontier/
http://ronangelo.com/add-language-files-on-a-wordpress-child-theme/