<?php
	register_nav_menus(
		array(
			'header-menu' => 'header-menu'
		)
	);
?>