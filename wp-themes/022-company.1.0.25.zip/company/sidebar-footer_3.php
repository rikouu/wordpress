<div id="footer_sidebar_3" class="footer-sidebar-container" role="complementary">
	<?php dynamic_sidebar( 'footer_widget_area_3' ); ?>
</div><!-- #footer_widget_area_3 -->