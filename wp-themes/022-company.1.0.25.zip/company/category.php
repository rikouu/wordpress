<?php 
get_header(); ?>
<div class="container">
	<?php company_print_layout("category"); ?>
</div>
<?php get_footer(); ?>