<?php get_header(); ?>
<div id="primary" class="content-area container">
	<?php company_print_layout("date"); ?>
</div><!-- #primary -->
<?php get_footer(); ?>