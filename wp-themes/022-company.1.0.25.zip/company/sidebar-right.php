<ul class="widget_list">
	<?php dynamic_sidebar( 'right_sidebar' ); ?>
</ul>
<!-- .widget-area -->