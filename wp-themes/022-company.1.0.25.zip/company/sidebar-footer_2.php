<div id="footer_sidebar_2" class="footer-sidebar-container" role="complementary">
	<?php dynamic_sidebar( 'footer_widget_area_2' ); ?>
</div><!-- #footer_widget_area_2 -->