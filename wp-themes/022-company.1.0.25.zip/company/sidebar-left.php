<ul class="widget_list">	
	<?php dynamic_sidebar( 'left_sidebar' ); ?>
</ul>
<!-- .widget-area -->

