<div id="footer_sidebar_1" class="footer-sidebar-container" role="complementary">
	<?php dynamic_sidebar( 'footer_widget_area_1' ); ?>
</div><!-- #footer_widget_area_1 -->