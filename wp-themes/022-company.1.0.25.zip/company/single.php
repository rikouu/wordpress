<?php
get_header(); ?>
<div id="primary" class="content-area container">
	<?php company_print_layout("single_post"); ?>
</div><!-- #primary -->
<?php
get_footer();