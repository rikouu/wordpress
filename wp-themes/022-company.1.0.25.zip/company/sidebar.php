<ul class="widget_list">
	<?php dynamic_sidebar( 'main_sidebar' ); ?>
</ul><!-- .widget-area -->
