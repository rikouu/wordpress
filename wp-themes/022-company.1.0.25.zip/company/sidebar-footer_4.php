<div id="footer_sidebar_4" class="footer-sidebar-container" role="complementary">
	<?php dynamic_sidebar( 'footer_widget_area_4' ); ?>
</div><!-- #footer_widget_area_4 -->