<?php get_header(); ?>
	<div id="maincontent">
		<div id="content" class="fl">
		<div class="breadnav"><h1>抱歉 这个貌似真没有...</h1></div>
		<div class="article">
			<p>当然，再试试搜索，也许他就有了呢？</p>
			<p><font size="+1" color="red">PS：通过搜索引擎过来的朋友，因为最近技术宅网站升级，导致搜索引擎收录本站内容的链接和实际不相符，您需要的信息仍然存在本站，请尝试使用下面搜索框即可获得。</font></p>
			<p><?php get_search_form(); ?></p>
			<iframe scrolling='no' frameborder='0' src='http://yibo.iyiyun.com/js/yibo404/key/4175' width='640' height='462' style='display:block;'></iframe>
		</div>
		</div><!-- end of content -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>