<?php get_header(); ?>
	<div id="maincontent">
		<div id="content" class="fl">
			<?php if ( have_posts() ) : ?>
				<?php while ( have_posts() ) : the_post(); ?>
					<div class="breadnav">
	当前位置：<a href="<?php bloginfo('home'); ?>" title="返回首页">首页</a> > <?php the_title(); ?>
	</div>
				<h1><?php the_title(); ?></h1>
				<div class="articlemeta">				
				　｜　浏览：<?php post_views(' ', ' '); ?>　｜　<?php comments_popup_link('暂无评论', '评论：1', '评论：%'); ?>　　<?php edit_post_link( __('[编辑]')); ?>
				</div>
				<div class="article"><?php the_content(); ?></div>
				<div class="articleother"><?php echo get_avatar( get_the_author_meta('ID'), 58 ); ?>
				作者：<?php the_author(); ?> <br/>
				除非注明，本文原创：<a href="http://www.jishuzh.com"><strong><?php bloginfo('name'); ?></strong></a>，欢迎转载！转载请以链接形式注明本文地址，谢谢。<br/>原文链接：<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php the_permalink(); ?></a>
				<div class="clearfloat"></div>
				</div>
				<?php comments_template( '', true ); ?>
				<?php endwhile; ?>
			<?php else : ?>
					<div class="breadnav">
						<p><?php _e( 'Apologies, but no results were found for the requested archive. Perhaps searching will help find a related post.', 'jishuzh' ); ?></p>						
					</div><?php get_search_form(); ?>
			<?php endif; ?>
		</div><!-- end of content -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>
