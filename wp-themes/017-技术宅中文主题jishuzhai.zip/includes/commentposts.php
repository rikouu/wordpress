<?php $commentposts = new WP_Query();//实例化
		function filter_where2( $where = '' ) {
		$where .= " AND post_date > '" . date('Y-m-d', strtotime('-90 days')) . "'";
		return $where;
		}
		add_filter( 'posts_where', 'filter_where2' );
		$commentposts->query(array('orderby' => 'comment_count','showposts'=>6));
		remove_filter( 'posts_where', 'filter_where2' );?>
		<?php while ($commentposts->have_posts()) : $commentposts->the_post(); ?>
			<li>
			<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
			</li>
		<?php endwhile; wp_reset_query();wp_reset_postdata();?>