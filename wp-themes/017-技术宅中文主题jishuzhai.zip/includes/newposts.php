<?php $newposts = new WP_Query();//实例化
		$newposts->query(array('showposts'=>6 ));?>
		<?php while ($newposts->have_posts()) : $newposts->the_post(); ?>
			<li>
			<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php the_title(); ?></a>
			</li>
		<?php endwhile; wp_reset_query();wp_reset_postdata();?>