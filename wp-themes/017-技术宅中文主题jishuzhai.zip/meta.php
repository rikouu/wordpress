<?php if ( is_home() ) { ?><title><?php bloginfo('name'); ?><?php if (is_paged()) echo "第".(get_query_var('paged'))."页"; ?> - <?php bloginfo('description'); ?></title><?php } ?>
<?php if ( is_search() ) { ?><title><?php the_search_query() ?> 搜索结果<?php if (is_paged()) echo "第".(get_query_var('paged'))."页"; ?> - <?php bloginfo('name'); ?></title><?php } ?>
<?php if ( is_single() ) { ?><title><?php echo trim(wp_title('',0)); ?><?php if (is_paged()) echo "第".(get_query_var('paged'))."页"; ?> - <?php bloginfo('name'); ?></title><?php } ?>
<?php if ( is_page() ) { ?><title><?php echo trim(wp_title('',0)); ?><?php if (is_paged()) echo "第".(get_query_var('paged'))."页"; ?> - <?php bloginfo('name'); ?></title><?php } ?>
<?php if ( is_category() ) { ?><title><?php single_cat_title(); ?><?php if (is_paged()) echo "第".(get_query_var('paged'))."页"; ?> - <?php bloginfo('name'); ?></title><?php } ?>
<?php  if ( is_year() ) { ?><title><?php the_time('Y年'); ?>文章的归类<?php if (is_paged()) echo "第".(get_query_var('paged'))."页"; ?> - <?php bloginfo('name'); ?></title><?php }
       elseif ( is_month() ) { ?><title><?php the_time('Y年F'); ?>文章的归类<?php if (is_paged()) echo "第".(get_query_var('paged'))."页"; ?> - <?php bloginfo('name'); ?></title><?php } 
       elseif ( is_day() ) { ?><title><?php the_time('Y年Fd日'); ?>文章的归类<?php if (is_paged()) echo "第".(get_query_var('paged'))."页"; ?> - <?php bloginfo('name'); ?></title><?php }?>
<?php if (function_exists('is_tag')) { if ( is_tag() ) { ?><title><?php  single_tag_title("", true); ?><?php if (is_paged()) echo "第".(get_query_var('paged'))."页"; ?> - <?php bloginfo('name'); ?></title><?php }  } ?>
<?php
##定义一个函数.解决截取中文乱码的问题###
if (!function_exists('utf8Substr')) {
 function utf8Substr($str, $from, $len)
 {
     return preg_replace('#^(?:[\x00-\x7F]|[\xC0-\xFF][\x80-\xBF]+){0,'.$from.'}'.
          '((?:[\x00-\x7F]|[\xC0-\xFF][\x80-\xBF]+){0,'.$len.'}).*#s',
          '$1',$str);
 }
}
echo "\n";
if (is_paged()){$paged = (get_query_var('paged')) ;
if ( is_year() ) { ?>
        <meta name="keywords" content="<?php bloginfo('name'); ?>,<?php the_time('Y年'); ?>的文章归类" /> 
        <meta name="description" content="<?php bloginfo('name'); ?>的<?php the_time('Y年'); ?>的文章归类<?php echo "第".$paged."页"; ?>，用于记录技术宅写于<?php the_time('Y年'); ?>的一些文章的<?php echo "第".$paged."页"; ?>，翻看一页，再续前缘。翻看过去，看看技术宅在<?php the_time('Y年'); ?>写的文章。" /><?php }
		elseif ( is_month() ) { ?>
        <meta name="keywords" content="<?php bloginfo('name'); ?>,<?php the_time('Y年F'); ?>的文章归类" /> 
        <meta name="description" content="<?php bloginfo('name'); ?>的<?php the_time('Y年F'); ?>的文章归类<?php echo "第".$paged."页"; ?>，用于记录技术宅写于<?php the_time('Y年F'); ?>的一些文章的<?php echo "第".$paged."页"; ?>，翻看一页，再续前缘。翻看过去，看看技术宅在<?php the_time('Y年F'); ?>写的文章。" /><?php }
        elseif ( is_day() ) { ?>
        <meta name="keywords" content="<?php bloginfo('name'); ?>,<?php the_time('Y年Fd日'); ?>的文章归类" /> 
        <meta name="description" content="<?php bloginfo('name'); ?>的<?php the_time('Y年Fd日'); ?>的文章归类<?php echo "第".$paged."页"; ?>，用于记录技术宅写于<?php the_time('Y年Fd日'); ?>的一些文章<?php echo "第".$paged."页"; ?>，翻看一页，再续前缘。翻看过去，看看技术宅在<?php the_time('Y年Fd日'); ?>写的所有文章。" /><?php }
		elseif ( is_tag() ) { ?>
        <meta name="keywords" content="<?php bloginfo('name'); ?>,<?php  single_tag_title("", true); ?>,tags标签页" /> 
        <meta name="description" content="<?php bloginfo('name'); ?>的<?php  single_tag_title("", true); ?>tags标签页面<?php echo "第".$paged."页"; ?>，翻看一页，再续前缘。记录了技术宅所写tags标签为<?php  single_tag_title("", true); ?>的文章。翻看过去，了解技术宅写的关于<?php  single_tag_title("", true); ?>标签的文章。" /><?php }
else{

if ( is_home() ){
	$keywords = "技术宅,地信,gis,网站建设,zblog,zblog主题,软件应用,wordpress主题,wordpress技巧";
    $description = "技术宅第".$paged."页，技术宅拯救世界。技术宅是一个专注电脑、互联网、地信GIS、网站建设、软件应用等领域的IT类博客。科技让生活更美好，这里有很多值得您探索。";

}
elseif ( is_single()||is_page() ){
$keywords = get_post_meta($post->ID, "keywords", true);
if($keywords!=""){
	$keywords = get_post_meta($post->ID, "keywords", true);
	}
	else{ $keywords = "";
$tags = wp_get_post_tags($post->ID);
foreach ($tags as $tag ) {
$keywords = $keywords . $tag->name . ",";
}}

$description = get_post_meta($post->ID, "description", true);
if($description!=""){
	$description = get_post_meta($post->ID, "description", true);}
	else{	if ($post->post_excerpt) {
$description  = $post->post_excerpt;
} else {
if(preg_match('/<p>(.*)<\/p>/iU',trim(strip_tags($post->post_content,"<p>")),$result)){
$post_content = $result['1'];
} else {
$post_content_r = explode("\n",trim(strip_tags($post->post_content)));
$post_content = $post_content_r['0'];
}
$description = utf8Substr($post_content,0,220);
}}
}
###这里是分类页面。自行改变is_category的ID。###
elseif ( is_category(2) ){
    $keywords = "技术宅,他山之石第".$paged."页,关注热点,博采众长";
    $description = strip_tags(category_description())."，他山之石第" . $paged . "页";
}
elseif ( is_category(3) ){
    $keywords = "技术宅,分享经验第".$paged."页,分享,经验";
    $description = strip_tags(category_description())."，分享经验第" . $paged . "页";
}
elseif ( is_category(4) ){
	$keywords = "技术宅,地信家园第".$paged."页,gis软件,gis资讯,gis技巧";
    $description = strip_tags(category_description())."，地信家园第" . $paged . "页";
}
elseif ( is_category(5) ){
    $keywords = "技术宅,编程开发第".$paged."页,源代码,程序猿";
    $description = strip_tags(category_description())."，编程开发第" . $paged . "页";
}
elseif ( is_category(6) ){
    $keywords = "技术宅,网站建设第".$paged."页,网站优化,seo,网站建设";
    $description = strip_tags(category_description()). "，网站建设第". $paged . "页";
}
elseif ( is_category(7) ){
    $keywords = "技术宅,网络日志第".$paged."页,记录生活,关注博客";
    $description = strip_tags(category_description())."，网络日志第" . $paged . "页";
}
elseif ( is_category(8) ){
    $keywords = "技术宅,软件应用第".$paged."页,实用的电脑软件,优秀手机软件";
    $description = strip_tags(category_description())."，软件应用第" . $paged . "页";
}
elseif ( is_category(9) ){
    $keywords = "技术宅,PC应用第".$paged."页,电脑软件,电脑技巧";
    $description = strip_tags(category_description())."，PC应用第" . $paged . "页";
}
elseif ( is_category(10) ){
    $keywords = "技术宅,SEO优化第".$paged."页,seo";
    $description = strip_tags(category_description())."，SEO优化第" . $paged . "页";
}
elseif ( is_category(11) ){
    $keywords = "技术宅,VPS教程第".$paged."页,vps教程";
    $description = strip_tags(category_description())."，VPS教程第" . $paged . "页";
}
elseif ( is_category(12) ){
    $keywords = "技术宅,wordpress第".$paged."页,wordpress技巧,wordpress主题,wordpress教程";
    $description = strip_tags(category_description())."，wordpress第" . $paged . "页";
}
elseif ( is_category(13) ){
    $keywords = "技术宅,zblog第".$paged."页,zblog技巧,zblog主题,zblog教程";
    $description = strip_tags(category_description())."，zblog第" . $paged . "页";
}
elseif ( is_category(14) ){
    $keywords = "技术宅,手机应用第".$paged."页,手机软件,手机游戏";
    $description = strip_tags(category_description())."，手机应用第" . $paged . "页";
}
	echo "  <meta name=\"keywords\" content=\"".rtrim($keywords,',')."\" />";
    echo "\n";
	echo "  <meta name=\"description\" content=\"".trim($description)."\" />";
}
}
else {
	if ( is_year() ) { ?>
        <meta name="keywords" content="<?php bloginfo('name'); ?>,<?php the_time('Y年'); ?>的文章归类" /> 
        <meta name="description" content="<?php bloginfo('name'); ?>的<?php the_time('Y年'); ?>的文章归类，用于记录技术宅写于<?php the_time('Y年'); ?>的一些文章的。翻看过去，看看技术宅在<?php the_time('Y年'); ?>写的文章。" /><?php }
		elseif ( is_month() ) { ?>
        <meta name="keywords" content="<?php bloginfo('name'); ?>,<?php the_time('Y年F'); ?>的文章归类" /> 
        <meta name="description" content="<?php bloginfo('name'); ?>的<?php the_time('Y年F'); ?>的文章归类，用于记录技术宅写于<?php the_time('Y年F'); ?>的一些文章的。翻看过去，看看技术宅在<?php the_time('Y年F'); ?>写的文章。" /><?php }
        elseif ( is_day() ) { ?>
        <meta name="keywords" content="<?php bloginfo('name'); ?>,<?php the_time('Y年Fd日'); ?>的文章归类" /> 
        <meta name="description" content="<?php bloginfo('name'); ?>的<?php the_time('Y年Fd日'); ?>的文章归类，用于记录技术宅写于<?php the_time('Y年Fd日'); ?>的一些文章的。翻看过去，了解技术宅。" /><?php }
		elseif ( is_tag() ) { ?>
        <meta name="keywords" content="<?php bloginfo('name'); ?>,<?php  single_tag_title("", true); ?>,tags标签页" /> 
        <meta name="description" content="<?php bloginfo('name'); ?>的<?php  single_tag_title("", true); ?>tags标签页面，记录了技术宅所写tags标签为<?php  single_tag_title("", true); ?>的文章。翻看过去，了解技术宅写的关于<?php  single_tag_title("", true); ?>的标签页面。" /><?php }
else{

if ( is_home() ){
    $keywords = "技术宅,地信,gis,网站建设,zblog,zblog主题,软件应用,wordpress主题,wordpress技巧";
    $description = "技术宅博客，技术宅拯救世界。技术宅是一个专注电脑、互联网、地信GIS、网站建设、软件应用等领域的IT类博客。科技让生活更美好，这里有很多值得您探索。";
}
elseif ( is_single()||is_page() ){
$keywords = get_post_meta($post->ID, "keywords", true);
if($keywords!=""){
	$keywords = get_post_meta($post->ID, "keywords", true);
	}
	else{ $keywords = "";
$tags = wp_get_post_tags($post->ID);
foreach ($tags as $tag ) {
$keywords = $keywords . $tag->name . ",";
}}

$description = get_post_meta($post->ID, "description", true);
if($description!=""){
	$description = get_post_meta($post->ID, "description", true);}
	else{	if ($post->post_excerpt) {
$description  = $post->post_excerpt;
} else {
if(preg_match('/<p>(.*)<\/p>/iU',trim(strip_tags($post->post_content,"<p>")),$result)){
$post_content = $result['1'];
} else {
$post_content_r = explode("\n",trim(strip_tags($post->post_content)));
$post_content = $post_content_r['0'];
}
$description = utf8Substr($post_content,0,300);
}}
}
###这里是分类页面。自行改变is_category的ID。###
elseif ( is_category(2) ){
    $keywords = "技术宅,他山之石,关注热点,博采众长";
    $description = strip_tags(category_description());
}
elseif ( is_category(3) ){
    $keywords = "技术宅,分享经验,分享,经验";
    $description = strip_tags(category_description());
}
elseif ( is_category(4) ){
	$keywords = "技术宅,地信家园,gis软件,gis资讯,gis技巧";
    $description = strip_tags(category_description());
}
elseif ( is_category(5) ){
    $keywords = "技术宅,编程开发,源代码,程序猿";
    $description = strip_tags(category_description());
}
elseif ( is_category(6) ){
    $keywords = "技术宅,网站建设,网站优化,seo";
    $description = strip_tags(category_description());
}
elseif ( is_category(7) ){
    $keywords = "技术宅,网络日志,记录生活,关注博客";
    $description = strip_tags(category_description());
}
elseif ( is_category(8) ){
    $keywords = "技术宅,软件应用,实用的电脑软件,优秀手机软件";
    $description = strip_tags(category_description());
}
elseif ( is_category(9) ){
    $keywords = "技术宅,PC应用,电脑软件,电脑技巧";
    $description = strip_tags(category_description());
}
elseif ( is_category(10) ){
    $keywords = "技术宅,SEO优化,seo";
    $description = strip_tags(category_description());
}
elseif ( is_category(11) ){
    $keywords = "技术宅,vps教程";
    $description = strip_tags(category_description());
}
elseif ( is_category(12) ){
    $keywords = "技术宅,wordpress,wordpress技巧,wordpress主题,wordpress教程";
    $description = strip_tags(category_description());
}
elseif ( is_category(13) ){
    $keywords = "技术宅,zblog,zblog技巧,zblog主题,zblog教程";
    $description = strip_tags(category_description());
}
elseif ( is_category(14) ){
    $keywords = "技术宅,手机应用,手机软件,手机游戏";
    $description = strip_tags(category_description());
}
	echo "  <meta name=\"keywords\" content=\"".rtrim($keywords,',')."\" />";
    echo "\n";
	echo "  <meta name=\"description\" content=\"".trim($description)."\" />";
}
}
?>
