<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
 <head>
  <meta http-equiv="Content-Type" content="<?php bloginfo('html_type'); ?>; charset=<?php bloginfo('charset'); ?>" />
  <?php include('meta.php'); ?>
  <link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />
  <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery-1.7.2.min.js"></script>
  <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jqueryslidemenu.js"></script>
  <link rel="shortcut icon" href="<?php bloginfo('url'); ?>/upload/favicon.ico"/>
  <link rel="alternate" type="application/rss+xml" title="<?php bloginfo('name'); ?> RSS Feed" href="<?php bloginfo('rss2_url'); ?>"/>
  <link rel="alternate" type="application/atom+xml" title="<?php bloginfo('name'); ?> Atom Feed" href="<?php bloginfo('atom_url'); ?>"/>
  <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
  <?php wp_head(); ?>
 </head>
 <body>
 <div id="container">
	<div id="header">
		<div id="logo" class="fl">
		<a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?>"></a>
		</div>
		<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('头部logo右方广告位') ) : ?><?php endif; ?>
	<div class="clearfloat"></div>
	</div> <!--end of the header-->
	<?php wp_nav_menu(array('container_class' => 'jqueryslidemenu','container_id' => 'myslidemenu','theme_location' => 'header-menu'));  ?><!--end of the menu-->
	<img src="http://www.gamesays.com/wp.jpg" alt="" height="0" width="0" />