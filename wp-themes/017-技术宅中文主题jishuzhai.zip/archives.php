<?php
 /*
 Template Name: archives
 */
 ?>
<?php get_header(); ?>
	<div id="maincontent">
		<div id="content" class="fl">
			<?php if ( have_posts() ) : ?>
				<?php while ( have_posts() ) : the_post(); ?>
					<div class="breadnav">
					当前位置：<a href="<?php bloginfo('home'); ?>" title="返回首页">首页</a> > <?php the_title(); ?>
					</div>
				<h1><?php the_title(); ?></h1>
				<div class="article"><?php the_content(); ?><?php jishuzh_archives_list(); ?></div>
				<?php endwhile; ?>
			<?php else : ?>
					<div class="breadnav">
						<p><?php _e( 'Apologies, but no results were found for the requested archive. Perhaps searching will help find a related post.', 'jishuzh' ); ?></p>						
					</div><?php get_search_form(); ?>
			<?php endif; ?>
		</div><!-- end of content -->
<?php get_sidebar(); ?>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/archives.js"></script>
<?php get_footer(); ?>
