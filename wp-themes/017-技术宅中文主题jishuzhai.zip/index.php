<?php get_header(); ?>
<?php include('content.php'); ?>
<?php get_sidebar(); ?>
<?php get_footer(); ?>