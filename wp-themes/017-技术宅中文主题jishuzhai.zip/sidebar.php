		<div id="sidebar" class="fr">
			<?php if ( is_home() ) {
				if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('首页侧边栏') ) :  endif; 
			} else { ?>
			<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('其他页侧边栏') ) : ?><?php endif; ?>
			<div id="sidebar-follow">
				<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('滑动侧边栏') ) : ?><?php endif; ?>
			</div> <!--end of the sidebar-follow-->
			<?php } ?>
		</div> <!--end of the sidebar-->
		<div class="clearfloat"></div>
	</div> <!--end of the maincontent-->