<?php get_header(); ?>
	<div id="maincontent">
		<div id="content" class="fl">
			<?php if ( have_posts() ) : ?>
	<div class="breadnav">
	当前位置：<a href="<?php bloginfo('home'); ?>" title="返回首页">首页 > </a><?php the_category(' > ','multiple'); ?> > <?php the_title(); ?>
	</div>
				<?php while ( have_posts() ) : the_post(); ?>
				<h1><?php the_title(); ?></h1>
				<div class="articlemeta"><?php the_time('Y年m月d日') ?>　｜　<?php the_tags('标签：', '　', ''); ?>　｜　浏览：<?php post_views(' ', ' '); ?>　｜　<?php comments_popup_link('暂无评论', '评论：1', '评论：%'); ?>　　<?php edit_post_link( __('[编辑]')); ?>
				</div>
				<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('正文右上广告位') ) : ?><?php endif; ?>
				<div class="article"><?php the_content(); ?></div>
				<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('正文下方广告位') ) : ?><?php endif; ?>
				<div class="articleother">
<!-- Baidu Button BEGIN -->
<div id="bdshare" class="bdshare_t bds_tools_32 get-codes-bdshare">
<a class="bds_tsina"></a>
<a class="bds_tqq"></a>
<a class="bds_renren"></a>
<a class="bds_qzone"></a>
<a class="bds_tqf"></a>
<a class="bds_douban"></a>
<a class="bds_hi"></a>
<span class="bds_more"></span>
<a class="shareCount"></a>
</div>
<script type="text/javascript" id="bdshare_js" data="type=tools&amp;uid=597670" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
document.getElementById("bdshell_js").src = "http://bdimg.share.baidu.com/static/js/shell_v2.js?cdnversion=" + Math.ceil(new Date()/3600000)
</script><div class="clearfloat"></div>
<!-- Baidu Button END -->
				<li class="fl" style="width:49%;"><?php previous_post_link(); ?></li>
				<li class="fr" style="width:49%;text-align:right;"><?php next_post_link(); ?></li>
				<div class="clearfloat"></div>
				</div>
				<div class="articleother"><?php echo get_avatar( get_the_author_meta('ID'), 58 ); ?>
				作者：<?php the_author(); ?> <br/>
				除非注明，本文原创：<a href="<?php bloginfo('home'); ?>"><strong><?php bloginfo('name'); ?></strong></a>，欢迎转载！转载请以链接形式注明本文地址，谢谢。<br/>原文链接：<a href="<?php the_permalink() ?>" title="<?php the_title(); ?>"><?php echo urldecode(get_permalink()); ?></a>
				</div>
				<div id="content-tab">
					<div id="tab-title"> 
						<h3><span class="selected">相关文章</span><span>近期热评</span><span>最新日志</span></h3>
					</div>
					<div id="tab-content"> 
						<ul><?php include('includes/tags_related.php');?></ul>
						<ul class="hide"><?php include('includes/commentposts.php');?></ul>
						<ul class="hide"><?php include('includes/newposts.php');?></ul>
					</div>
				</div>
				<?php comments_template( '', true ); ?>
				<?php endwhile; ?>
			<?php else : ?>
					<div class="breadnav">
						<p><?php _e( 'Apologies, but no results were found for the requested archive. Perhaps searching will help find a related post.', 'jishuzh' ); ?></p>						
					</div><?php get_search_form(); ?>
			<?php endif; ?>
		</div><!-- end of content -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>
