	<div id="footer">
	<?php if ( is_home() ) {
     if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('友情链接') ) :  endif; 
	} else { ?>
	<script src="<?php bloginfo('template_url'); ?>/js/sidebar-follow-jquery.js"></script>
	<script type="text/javascript">
	/* <![CDATA[ */
	(new SidebarFollow()).init({element: jQuery('#sidebar-follow'),distanceToTop: 15});
	/* ]]> */
	</script> 
	<?php } ?>
	<?php wp_nav_menu(array('container_id' => 'footermenu','theme_location' => 'footer-menu'));  ?>
	<script src="<?php bloginfo('template_url'); ?>/js/lazyload.js"></script>
	<script type="text/javascript">
      $(function() {
          $("img").lazyload({
              effect : "fadeIn"
          });
      });
	</script>
	<div id="shangxia"><div id="shang" title="返回顶部"></div>
		<?php if ( is_singular() ){ ?>
		<div id="comt" title="查看评论"></div>
		<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/comments-ajax.js"></script>
		<script src="<?php bloginfo('template_url') ?>/js/lightbox.js"></script>
		<?php } ?>
		<div id="xia" title="移至底部"></div>
	</div>
	<div id="footermeta">
	<p>Copyright © 2012-2013 <a href="<?php bloginfo('home'); ?>" title="<?php bloginfo('name'); ?>"><?php bloginfo('name'); ?></a> All rights reserved. <?php echo get_num_queries(); ?>次查询.<?php wp_register('',''); ?> <?php wp_loginout(); ?></p>
	<p>Powered by <a href="http://wordpress.org/" title="Wordpress" target="_blank" rel="external nofollow">WordPress</a> & Theme by <a href="http://www.jishuzh.com" title="技术宅" target="_blank">技术宅.</a><?php if (get_option('swt_beian') == 'Display') { ?><a href="http://www.miibeian.gov.cn/" rel="external nofollow"><?php echo stripslashes(get_option('swt_beianhao')); ?>.</a><?php } else { } ?><?php if (get_option('swt_tj') == 'Display') { ?><?php echo stripslashes(get_option('swt_tjcode')); ?><?php } else { } ?></p>
	</div>
	<?php wp_footer(); ?>
	</div> <!--end of the footer-->
 </div> <!--end of the container-->
 </body>
</html>
