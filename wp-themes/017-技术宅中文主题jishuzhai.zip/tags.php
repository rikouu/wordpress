<?php
 /*
 Template Name: tags
 */
 ?>
<?php get_header(); ?>
	<div id="maincontent">
		<div id="content" class="fl">
		<h1>所有标签：</h1>
			<?php wp_tag_cloud( array('number' => 300,'format'=> 'list')  ); ?>
		</div><!-- end of content -->
<?php get_sidebar(); ?>
<?php get_footer(); ?>
