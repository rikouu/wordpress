<?php get_header(); ?>
	<div id="maincontent">
		<div id="content" class="fl">
			<?php if ( have_posts() ) : ?>
			<div class="breadnav">
			<h1>You searched for " <?php the_search_query() ?> ". Here are the results:</h1>
			</div>
				<?php while ( have_posts() ) : the_post(); ?>
					<div class="loopcontent">
						<div class="imagebox fl">
	      <a href="<?php the_permalink() ?>" title="<?php the_title(); ?>" >
			<?php if ( get_post_meta($post->ID, 'image', true) ) : ?>
				<?php $image = get_post_meta($post->ID, 'image', true); ?>
				<img src="<?php bloginfo('template_url'); ?>/images/grey.gif" data-original="<?php echo $image; ?>" alt="<?php the_title(); ?>" /><noscript><img src="<?php echo $image; ?>" alt="<?php the_title(); ?>" /></noscript>
				<?php else: ?>
				<?php if (has_post_thumbnail()) { the_post_thumbnail('thumbnail'); }
				else { ?>
					<img src="<?php bloginfo('template_url'); ?>/images/grey.gif" data-original="<?php echo catch_first_image(); ?>" alt="<?php the_title(); ?>" /><noscript><img src="<?php echo catch_first_image(); ?>" alt="<?php the_title(); ?>" /></noscript>
				<?php } ?>
				<?php endif; ?>
		  </a>
						</div>
						<div class="contentbox">
						<h2><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php echo mb_strimwidth(get_the_title(), 0, 46,"..."); ?></a></h2><hr class="hr0" />
						<span style="font-size:13px;">作者：<?php the_author(); ?>　
						浏览：<?php post_views(' ', ' '); ?>　
						<?php comments_popup_link('暂无评论', '评论：1', '评论：%'); ?>　
						<?php edit_post_link( __('[编辑]')); ?><br />
						分类：<?php the_category(', ') ?>　<?php the_tags(); ?></span>
						<p><?php echo mb_strimwidth(strip_tags(apply_filters('the_excerpt', $post->post_content)), 0, 240,"..."); ?></p>
						</div>
						<div class="clearfloat"></div>
					</div><!-- end of the loopcontent -->
				<?php endwhile; ?>
				<div class="page_navi"><?php par_pagenavi(9); ?></div>
			<?php else : ?>
					<div class="breadnav">
						<p><?php _e( 'Apologies, but no results were found for the requested archive. Perhaps searching will help find a related post.', 'jishuzh' ); ?></p>						
					</div><?php get_search_form(); ?>
			<?php endif; ?>
		</div> <!--end of the content-->
<?php get_sidebar(); ?>
<?php get_footer(); ?>