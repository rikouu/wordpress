<div class="navigation">
	<?php if (function_exists('pagenavi')) { pagenavi(); } ?>
	<div class="clearfix"></div>
</div>