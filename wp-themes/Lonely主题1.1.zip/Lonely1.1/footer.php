</div>
<div id="footer">
	<p>
		Copyright <?php echo comicpress_copyright(); ?> <a target="_blank" href="<?php bloginfo('siteurl');?>/"><?php bloginfo('name');?></a>. 
		Powered by <a href="http://www.wordpress.org/" rel="external">WordPress</a>. 
		Theme by <a target="_blank" href="<?php bloginfo('siteurl');?>/"><?php bloginfo('name');?></a> And <a target="_blank" href="http://www.w3cshare.com/">Lonely 1.1</a>. 
		<a href="http://www.28tuiguang.com/blog/sitemap.html" rel="external">站点地图</a>. 
		<a href="http://www.28tuiguang.com/blog/sitemap_baidu.xml" rel="external">百度地图</a>. 
		<a href="http://www.28tuiguang.com/blog/sitemap.xml" rel="external">谷歌地图</a>. 
		<script type="text/javascript">
			var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
			document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3Fc465310ab9de6b9e93de7b38e6be11ca' type='text/javascript'%3E%3C/script%3E"));
		</script>. 
		<script src="http://s96.cnzz.com/stat.php?id=3771756&web_id=3771756" language="JavaScript"></script>
	</p>
</div>
<?php wp_footer(); ?>
<!-- Baidu Button BEGIN -->
<script type="text/javascript" id="bdshare_js" data="type=slide&img=0&pos=right&uid=281249" ></script>
<script type="text/javascript" id="bdshell_js"></script>
<script type="text/javascript">
		var bds_config = {"bdTop":150};
		document.getElementById("bdshell_js").src = "http://share.baidu.com/static/js/shell_v2.js?cdnversion=" + new Date().getHours();
</script>
<!-- Baidu Button END -->
</body>
</html>