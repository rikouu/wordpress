<?php 
    $options[] = array( "name" => "Custom CSS",
    					"sicon" => "css.png",
						"type" => "heading");

    $options[] = array( "name" => "CSS Code",
                        "desc" => "Add here your own custom CSS code for the theme.",
                        "id" => $shortname."_css_code",
                        "std" => "",
                        "type" => "textarea");

?>