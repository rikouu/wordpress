<?php
    $options[] = array( "name" => "Social",
    					"sicon" => "social.png",
						"type" => "heading");

    $options[] = array( "name" => "Twitter URL",
                        "id" => $shortname."_twitter_user",
                        "std" => "site5",
                        "type" => "text");
						
	$options[] = array( "name" => "Facebook URL",
                        "id" => $shortname."_facebook_link",
                        "std" => "http://www.facebook.com/site5",
                        "type" => "text");



?>