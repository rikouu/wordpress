<footer id="footer"> 

<p>		
&copy; <?php _e('Copyright', 'quickpress'); ?>
 <?php echo date('Y'); ?> - <?php bloginfo('name'); ?> 
</p>
	<?php wp_footer(); ?>

</footer>
</div> <!-- /page --> 
</body>
</html>