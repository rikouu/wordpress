<nav class="navigation">
	<div class="alignleft mainnav"><?php previous_posts_link(); ?></div>
	<div class="alignright mainnav"><?php next_posts_link(); ?></div>
</nav>