=== QuickPress Theme ===

Theme Name: QuickPress 
Theme URI: http://www.quickonlinethemes.com/wordpress/quickpress/
Description: A lightweight, 2-3 columns, widget ready, SEO optimized, fast loading, easy to customize wordpress theme.

Author: QuickOnlineTips
Author URI: http://www.quickonlinethemes.com/
Tags: white, blue, gray, silver, light, two-columns, three-columns, right-sidebar, fixed-width, threaded-comments, sticky-post

License: GNU General Public License v2.0
License URI: http://www.gnu.org/licenses/gpl-2.0.html

 