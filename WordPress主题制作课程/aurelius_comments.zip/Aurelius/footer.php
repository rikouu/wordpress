<!-- Footer -->
	<p class="grid_12 footer clearfix"> <span class="float">版权所有 &copy; 2010 <?php bloginfo('name'); ?>&nbsp;&nbsp;|&nbsp;&nbsp;Powered By <a rel="external" title="WordPress主页" class="link" href="http://wordpress.org/">WordPress</a>&nbsp;&nbsp;|&nbsp;&nbsp;Design By QwibbleDesigns&nbsp;&nbsp;|&nbsp;&nbsp;Code By <a href="http://www.ludou.org/">Ludou</a></span> <a class="float right" href="#">top</a> </p>
</div>
<!--end wrapper-->
<?php wp_footer(); ?>
</body>
</html>